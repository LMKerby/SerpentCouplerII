/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : comptonscattering.c                            */
/*                                                                           */
/* Created:       2011/04/15 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Handles incoherent Compton scattering of photons             */
/*                                                                           */
/* Comments: TTB is ingored for now                                          */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ComptonScattering:"

/*****************************************************************************/

void ComptonScattering(double *E0, double *u, double *v, double *w, long id)
{
  double mu, E;

  /* Sample energy and scattering cosine from Klein-Nishina formula */

  KleinNishina(*E0, &E, &mu, id);
  
  /* Check energy and cosine */

  CheckValue(FUNCTION_NAME, "E", "", E, 0.0, *E0);
  CheckValue(FUNCTION_NAME, "mu", "", mu, -1.0, 1.0);

  /* Put energy */

  *E0 = E;

  /* Rotate direction cosines */

  AziRot(mu, u, v, w, id);
}

/*****************************************************************************/
