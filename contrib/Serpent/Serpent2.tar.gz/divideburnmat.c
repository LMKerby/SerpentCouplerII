/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : divideburnmat.c                                */
/*                                                                           */
/* Created:       2011/07/03 (JLe)                                           */
/* Last modified: 2011/11/21 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Divides burnable materials in multiple rings etc.            */
/*                                                                           */
/* Comments: - The loop must always extend over all nests to close the       */
/*             region lists.                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "DivideBurnMat:"

/*****************************************************************************/

void DivideBurnMat()
{
  long nst, type, reg0, mat, nr, n, m, surf, loc0, loc1, loc2, ptr, nptr, reg;
  double r0, r1, r;
  char name[MAX_STR];

  /* Loop over nests */

  nst = RDB[DATA_PTR_NST0];
  while (nst > VALID_PTR)
    {
      /* Get nest type */

      type = (long)RDB[nst + NEST_TYPE];

      /* Get pointer if simple types, otherwise set to null */

      if ((type == SURF_CYL) || (type == SURF_CYLX) || (type == SURF_CYLY) || 
	  (type == SURF_CYLZ) || (type == SURF_SPH))
	reg0 = (long)RDB[nst + NEST_PTR_REGIONS];
      else
	reg0 = -1;

      /* Reset radii */

      r0 = 0.0;
      r1 = 0.0;

      /* Loop over regions */
	      
      while (reg0 > VALID_PTR)
	{
	  /* Pointer to surface */

	  if ((surf = (long)RDB[reg0 + NEST_REG_PTR_SURF_IN]) < VALID_PTR)
	    break;

	  /* Pointer to parameter list */

	  loc0 = (long)RDB[surf + SURFACE_PTR_PARAMS];
	  CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

	  /* Get radius */

	  if (type == SURF_SPH)
	    r1 = RDB[loc0 + 3];
	  else
	    r1 = RDB[loc0 + 2];

	  /* Find material */

	  if ((long)RDB[reg0 + NEST_REG_PTR_MAT] > 0)
	    {
	      mat = RDB[DATA_PTR_M0];
	      mat = SeekListStr(mat, MATERIAL_PTR_NAME,
				GetText(reg0 + NEST_REG_PTR_MAT));
	    }
	  else
	    mat = -1;

	  /* Get number of burnable zones */

	  if (mat > VALID_PTR)
	    nr = (long)RDB[mat + MATERIAL_BURN_RINGS];
	  else
	    nr = 0;

	  /* Region pointer */

	  reg = reg0;

	  /* Loop over regions */

	  for (n = 0; n < nr; n++)
	    {
	      /* Material name */

	      sprintf(name, "%sp%sr%ld", GetText(mat + MATERIAL_PTR_NAME),
		      GetText(nst + NEST_PTR_NAME), n + 1);

	      nptr = PutText(name);

	      /* Calculate radius (ei toimi annulaarisilla) */

	      if (type == SURF_SPH)
		r = cbrt(((double)(n + 1.0))/((double)nr))*(r1 - r0) + r0;
	      else
		r = sqrt(((double)(n + 1.0))/((double)nr))*(r1 - r0) + r0;

	      /* Duplicate material */

	      loc1 = DuplicateItem(mat);

	      /* Increase divider index */

	      WDB[mat + MATERIAL_DIV_IDX] = WDB[mat + MATERIAL_DIV_IDX] + 1.0;

	      /* Put parent pointer */

	      WDB[loc1 + MATERIAL_PTR_DIV_PARENT] = (double)mat;

	      /* Put name pointer */

	      WDB[loc1 + MATERIAL_PTR_NAME] = (double)nptr;

	      /* Duplicate region */

	      reg = DuplicateItem(reg);
	      
	      /* Duplicate surface */

	      loc2 = DuplicateItem(surf);

	      /* Put pointer */

	      WDB[reg + NEST_REG_PTR_SURF_IN] = (double)loc2;

	      /* Get number of surface parameters */

	      m = (long)RDB[loc2 + SURFACE_N_PARAMS];

	      /* Create parameter list */
		      
	      ptr = ReallocMem(DATA_ARRAY, m);
		      
	      /* Put pointer */
		      
	      WDB[loc2 + SURFACE_PTR_PARAMS] = (double)ptr;

	      /* Put radius (tää ei nyt sit kopioi noita muita) */
		      
	      WDB[ptr + m - 1] = r;

	      /* Put name pointer */

	      WDB[reg + NEST_REG_PTR_MAT] = (double)nptr;
	    }

	  /* Remove original region */

	  if (nr > 0)
	    RemoveItem(reg0);

	  /* Update radius */

	  r0 = r1;

	  /* Next region */

	  reg0 = NextItem(reg);
	}

      /* Close region list */
      
      if ((reg0 = (long)RDB[nst + NEST_PTR_REGIONS]) > VALID_PTR)
	CloseList(reg0);
      else
	Die(FUNCTION_NAME, "Nest %s has no regions", 
	    GetText(nst + NEST_PTR_NAME));
	    
      /* Next nest */

      nst = NextItem(nst);
    }
}

/*****************************************************************************/
