/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : fission.c                                      */
/*                                                                           */
/* Created:       2011/03/07 (JLe)                                           */
/* Last modified: 2011/12/22 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Handles fission                                              */
/*                                                                           */
/* Comments:  - Noihin analog chi -arvoihin ei kai pidä ottaa syntyneiden    */
/*              neutronien painoa?                                           */
/*                                                                           */
/*            - Tää on ihan kauhea sotku, eikä varmaan toimi enää muussa     */
/*              kuin analog criticality source moodissa.                     */
/*                                                                           */
/*            - Tota source bias -juttua ei oo testattu lähdelaskussa        */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Fission:"

/*****************************************************************************/

void Fission(long mat, long rea, long part, double *E0, double x, double y, 
	     double z, double *u, double *v, double *w, double *wgt, double f,
	     long id)
{
  long ptr, nmax, n, new, mode;
  double tnu, dnu, beta, E, wg, cf, emt, mu, u0, v0, w0;

  /* Check pointers */

  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
  CheckPointer(FUNCTION_NAME, "(part)", DATA_ARRAY, part);

  /* Check coordinates, energy and weight */

  CheckValue(FUNCTION_NAME, "x", "", x, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "y", "", y, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "z", "", z, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "E0", "", *E0, ZERO, INFTY);
  CheckValue(FUNCTION_NAME, "wgt", "", *wgt, ZERO, INFTY);

  /* Avoid compiler warning */

  tnu = -1.0;

  /* Get total nubar */

  if ((ptr = (long)RDB[rea + REACTION_PTR_TNUBAR]) > VALID_PTR)
    tnu = Nubar(ptr, *E0, id);
  else
    Die(FUNCTION_NAME, "No prompt nubar data");

  /* Get delayed nubar */

  if ((ptr = (long)RDB[rea + REACTION_PTR_DNUBAR]) > VALID_PTR)
    dnu = Nubar(ptr, *E0, id);
  else
    dnu = 0.0;
  
  /* Get simulation mode */
  
  mode = (long)RDB[DATA_SIMULATION_MODE];

  /* Calculate delayed neutron fraction */

  beta = dnu/tnu;

  /* Original direction cosines */

  u0 = *u;
  v0 = *v;
  w0 = *w;

  /* Check value */

  CheckValue(FUNCTION_NAME, "beta", "", beta, 0.0, 3E-2);

  /* Source biasing */

  if (((ptr = (long)RDB[DATA_SBIAS_PTR_COL_MESH]) > VALID_PTR) &&
      (RDB[DATA_CYCLE_IDX] > RDB[DATA_SKIP]))
    {
      /* Get adjustment factor */
      
      cf = MeshVal(ptr, x, y, z)/MeshTot(ptr)*RDB[ptr + MESH_N0]
	*RDB[ptr + MESH_N1]*RDB[ptr + MESH_N2];

      if (cf > 0.0)
	cf = pow(1.0/cf, RDB[DATA_SBIAS_ORD]);
      else
	cf = 1.0;

      if (cf > 10.0)
	cf = 10.0;
    }
  else
    cf = 1.0;

  /* Score incident neutron */

  ScoreFission(mat, rea, tnu, 0.0, *E0, 0.0, *wgt*f, 0.0, id);

  /***** Reaction physics ****************************************************/

  /* Check implicit fission mode */

  if ((long)RDB[DATA_OPT_IMPL_FISS] == YES)
    {
      /***********************************************************************/

      /***** Implicit fission ************************************************/

      /* Check criticality source mode */

      if (mode == SIMULATION_MODE_CRIT)
	Die(FUNCTION_NAME, "Implicit fission in criticality source mode");

      /* Reset mu */

      mu = 0.1;

      /* Sample between prompt and delayed neutron */

      if (RandF(id) > beta)
	{
	  /* Prompt neutron, sample energy */

	  SampleENDFLaw(rea, -1, *E0, E0, &mu, id);
	}
      else
	{
	  /* Delayed neutron, sample precursor group */

	  if ((ptr = SamplePrecursorGroup(rea, *E0, id)) > VALID_PTR)
	    {	  
	      /* Get pointer to energy distribution */

	      ptr = (long)RDB[ptr + PREC_PTR_ERG];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      /* Sample energy */
	      
	      SampleENDFLaw(rea, ptr, *E0, E0, &mu, id);
	    }
	  else
	    {
	      /* Sampling failed, sample prompt neutron energy */

	      SampleENDFLaw(rea, -1, *E0, E0, &mu, id);
	    }
	}

      /* Check if mu is sampled from distribution or sample isotropic */

      if (mu == 0.1)
	IsotropicDirection(u, v, w, id);
      else
	{
	  /* Get incident direction cosines */

	  *u = u0;
	  *v = v0;
	  *w = w0;

	  /* Rotate */
	  
	  AziRot(mu, u, v, w, id);
	}

      /* Score emitted neutron */

      ScoreFission(mat, rea, 0.0, 0.0, 0.0, E, *wgt*tnu, *wgt, id);

      /* Adjust weight (multiplication by f is done in collision.c) */
      
      *wgt = *wgt*tnu;

      /***********************************************************************/
    }
  else
    {
      /***** Analog fission **************************************************/
     
      /* Sample number of emitted neutrons and set weight for chi estimate */

      if (mode == SIMULATION_MODE_CRIT)
	{
	  nmax = SampleNu(*wgt*tnu*f*cf, id);
	  wg = 1.0/cf;
	}
      else
	{
	  nmax = SampleNu(tnu*cf, id);
	  wg = *wgt/cf;
	}

      /* Loop over source neutrons */

      for (n = 0; n < nmax; n++)
	{
	  /* Duplicate incident neutron */
	  
	  new = DuplicateParticle(part, id);

	  /* Reset mu */

	  mu = 0.1;

	  /* Sample between prompt and delayed neutron */

	  if (RandF(id) > beta)
	    {
	      /* Prompt neutron, sample energy */
	  
	      SampleENDFLaw(rea, -1, *E0, &E, &mu, id);

	      /* Set emission time to zero */

	      emt = 0.0;
	    }
	  else
	    {
	      /* Delayed neutron, sample precursor group */

	      if ((ptr = SamplePrecursorGroup(rea, *E0, id)) > VALID_PTR)
		{	  
		  /* Get pointer to energy distribution */
		  
		  ptr = (long)RDB[ptr + PREC_PTR_ERG];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  
		  /* Sample energy */
		  
		  SampleENDFLaw(rea, ptr, *E0, &E, &mu, id);

		  /* TODO: sample emission time */

		  emt = 1.0;
		}
	      else
		{
		  /* Sampling failed, sample prompt neutron energy */
		  
		  SampleENDFLaw(rea, -1, *E0, &E, &mu, id);

		  /* Set emission time to zero */

		  emt = 0.0;
		}	
	    }

	  /* Score emitted neutron */

	  ScoreFission(mat, rea, 0.0, emt, 0.0, E, wg, 1.0, id);
	  
	  /* Adjust minimum and maximum energy */
	  
	  if (E < 1.0000001*RDB[DATA_NEUTRON_EMIN])
	    E = 1.000001*RDB[DATA_NEUTRON_EMIN];
	  else if (E > 0.999999*RDB[DATA_NEUTRON_EMAX])
	    E = 0.999999*RDB[DATA_NEUTRON_EMAX];

	  /* Check if mu is sampled from distribution or sample isotropic */

	  if (mu == 0.1)
	    IsotropicDirection(u, v, w, id);
	  else
	    {
	      /* Get incident direction cosines */
	      
	      *u = u0;
	      *v = v0;
	      *w = w0;
	      
	      /* Rotate */
	      
	      AziRot(mu, u, v, w, id);
	    }
	  
	  /* Put variables */

	  WDB[new + PARTICLE_X] = x;
	  WDB[new + PARTICLE_Y] = y;
	  WDB[new + PARTICLE_Z] = z;
	  
	  WDB[new + PARTICLE_U] = *u;
	  WDB[new + PARTICLE_V] = *v;
	  WDB[new + PARTICLE_W] = *w;
	  
	  WDB[new + PARTICLE_E] = E;
	  WDB[new + PARTICLE_PTR_MAT] = (double)mat;

	  /* Check mode, set weight and store particle */

	  if (mode == SIMULATION_MODE_SRC)
	    {
	      /* Particle weight */

	      WDB[new + PARTICLE_WGT] = *wgt*f/cf;
	  
	      /* Put neutron in que */

	      ToQue(new, id);
	    }
	  else
	    {
	      /* Set weight to unity */

	      WDB[new + PARTICLE_WGT] = 1.0/cf;

	      /* Put particle in source */

	      ToSrc(new);
	    }
	}
 
      /***********************************************************************/
    }
}

/*****************************************************************************/
