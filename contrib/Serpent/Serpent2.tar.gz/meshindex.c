/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : meshindex.c                                    */
/*                                                                           */
/* Created:       2011/05/13 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Returns index to mesh structure                              */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "MeshIndex:"

/*****************************************************************************/

long MeshIndex(long msh, double x, double y, double z)
{
  long n0, n1, n2, i, j, k, idx;
  double min0, max0, min1, max1, min2, max2, r, phi;

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(msh)", DATA_ARRAY, msh);

  /* Get sizes */
  
  n0 = (long)RDB[msh + MESH_N0];
  n1 = (long)RDB[msh + MESH_N1];
  n2 = (long)RDB[msh + MESH_N2];

  /* Reset index */

  idx = -1;

  /* Get dimensions */

  min0 = RDB[msh + MESH_MIN0];
  max0 = RDB[msh + MESH_MAX0];
  min1 = RDB[msh + MESH_MIN1];
  max1 = RDB[msh + MESH_MAX1];
  min2 = RDB[msh + MESH_MIN2];
  max2 = RDB[msh + MESH_MAX2];
  
  /* Check type */

  if ((long)RDB[msh + MESH_TYPE] == MESH_TYPE_CARTESIAN)
    {
      /***** Cartesian mesh **************************************************/

      /* Get local normalised co-ordinates */
      
      if (max0 - min0 > 0.0)
	x = (x - min0)/(max0 - min0);
      else
	x = 0.0;
      
      if (max1 - min1 > 0.0)
	y = (y - min1)/(max1 - min1);
      else
	y = 0.0;
      
      if (max2 - min2 > 0.0)
	z = (z - min2)/(max2 - min2);
      else
	z = 0.0;
      
      /* Check that point is inside region */
      
      if ((x < 0.0) || (x > 1.0) ||
	  (y < 0.0) || (y > 1.0) ||
	  (z < 0.0) || (z > 1.0))
	return -1;
      
      /* Calculate indexes */
      
      i = (long)(x*n0);
      j = (long)(y*n1);
      k = (long)(z*n2);

      /* Calculate index */

      idx = i + j*n0 + k*n0*n1;
      
      /**********************************************************************/
    }
  else if ((long)RDB[msh + MESH_TYPE] == MESH_TYPE_CYLINDRICAL)
    {
      /***** Cylindrical mesh ***********************************************/

      /* Calculate radius */

      r = sqrt(x*x + y*y);

      /* Calculate angle */

      if ((x > 0.0) && (y > 0.0))
	phi = atan(y/(x));
      else if (x < 0.0)
	phi = atan(y/(x)) + PI;
      else if (y < 0.0)
	phi = atan(y/(x)) + 2.0*PI;
      else
	{
	  /* Special case: vector length is zero */
	  
	  phi = 0.0;
	}

      /* Check phi */

      CheckValue(FUNCTION_NAME, "phi", "", phi, 0.0, 2.0*PI);

      /* Get local normalised co-ordinates */
      
      if (max0 - min0 > 0.0)
	r = (r - min0)/(max0 - min0);
      else
	r = 0.0;
      
      if (max1 - min1 > 0.0)
	phi = (phi - min1)/(max1 - min1);
      else
	phi = 0.0;
      
      /* (invert z-co-ordinate) */
      
      if (max2 - min2 > 0.0)
	z = 1.0 - (z - min2)/(max2 - min2);
      else
	z = 0.0;
      
      /* Check that point is inside region */
      
      if ((r < 0.0) || (r > 1.0) ||
	  (phi < 0.0) || (phi > 1.0) ||
	  (z < 0.0) || (z > 1.0))
	return -1;
      
      /* Calculate indexes */
      
      i = (long)(r*n0);
      j = (long)(phi*n1);
      k = (long)(z*n2);

      /* Calculate index */

      idx = i + j*n0 + k*n0*n1;

      /**********************************************************************/
    }
  else
    Die(FUNCTION_NAME, "Invalid mesh type");
        
  /* Return index */

  return idx;
}

/*****************************************************************************/
