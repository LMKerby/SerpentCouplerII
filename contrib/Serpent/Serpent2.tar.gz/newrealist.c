/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : newrealist.c                                   */
/*                                                                           */
/* Created:       2011/11/02 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Creates and allocates memory for reaction lists              */
/*                                                                           */
/* Comments: - This routine is called only once, and it loops over all       */
/*             possible reactions in the list. If calculation uses pre-      */
/*             generated lists, memory is allocated here.                    */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "NewReaList:"

/*****************************************************************************/

void NewReaList(long mat, long mode)
{
  long loc0, ptr, rea, nr, ptp;
  double adens, Emin, Emax;

  /* Check material pointer */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /* Check if reaction list already exists */

  if ((long)RDB[mat + mode] > VALID_PTR)
    Die(FUNCTION_NAME, "Reaction list already exists");

  /* Allocate memory for structure */

  loc0 = NewItem(mat + mode, LIST_ROOT_BLOCK_SIZE);

  /* Put list pointer in material */

  WDB[mat + mode] = (double)loc0;

  /* Put material pointer and mode */

  WDB[loc0 + LIST_ROOT_PTR_MAT] = (double)mat;
  WDB[loc0 + LIST_ROOT_REA_MODE] = (double)mode;

  /* Allocate memory for reaction pointers */

  AllocValuePair(loc0 + LIST_ROOT_PTR_NEXT_REA);
  AllocValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO);
  AllocValuePair(loc0 + LIST_ROOT_PTR_NEXT_LST);

  /* Set null pointer */
      
  WDB[loc0 + LIST_ROOT_PTR_REA_LIST] = NULLPTR;
  
  /* Set list type to avoid cut-offs */

  WDB[loc0 + LIST_ROOT_LIST_TYPE] = (double)REA_LIST_TYPE_NOCUTOFF;

  /* Rewind list */

  RewindReaList(loc0, 0);

  /* Reset counter */

  nr = 0;

  /* Loop over reactions and allocate memory */
  
  while (NextReaction(loc0, &rea, &adens, &Emin, &Emax, 0) == 0)
    {
      ptr = (long)RDB[rea + REACTION_PTR_NUCLIDE];
      
      /* Allocate memory for data (NOTE: tähän se tarkistus totalista) */
      
      if ((long)RDB[DATA_OPTI_MACRO_REA_LISTS] == (double)YES)
	{
	  /* Create block */

	  ptr = NewItem(loc0 + LIST_ROOT_PTR_REA_LIST, REA_LIST_BLOCK_SIZE);

	  /* Allocate memory for reaction counter */

	  ptp = AllocPrivateData(1, PRIVA_ARRAY);
	  WDB[ptr + REA_LIST_PTR_COUNT] = (double)ptp;
	}

      /* Update counter */
      
      nr++;
    }
  
  /* Check if list was created */
  
  if (nr > 0)   
    {
      /* Close list */

      if ((ptr = (long)RDB[loc0 + LIST_ROOT_PTR_REA_LIST]) > VALID_PTR)
	CloseList(ptr);

      /* Set size */

      WDB[loc0 + LIST_ROOT_N_MAX] = (double)nr;
	  
      /* Set list type enable cut-offs */
      
      WDB[loc0 + LIST_ROOT_LIST_TYPE] = (double)REA_LIST_TYPE_EMULATED;
    }
  else
    {
      /* Set null pointer to erase list */
      
      WDB[mat + mode] = NULLPTR;
    }
}

/*****************************************************************************/
