/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : pairproduction.c                               */
/*                                                                           */
/* Created:       2011/04/15 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Handles pair production of photons                           */
/*                                                                           */
/* Comments: TTB is ignored for now                                          */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "PairProduction:"

/*****************************************************************************/

void PairProduction(long rea, long part, double x, double y, double z, 
		    double wgt, long id)
{
  long new1, new2;
  double u, v, w;
  
  /* Make two new photons */
  
  new1 = DuplicateParticle(part, id);
  new2 = DuplicateParticle(part, id);
  
  /* Put variables */

  WDB[new1 + PARTICLE_X] = x;
  WDB[new1 + PARTICLE_Y] = y;
  WDB[new1 + PARTICLE_Z] = z;
  WDB[new1 + PARTICLE_WGT] = wgt;	 

  WDB[new2 + PARTICLE_X] = x;
  WDB[new2 + PARTICLE_Y] = y;
  WDB[new2 + PARTICLE_Z] = z;
  WDB[new2 + PARTICLE_WGT] = wgt;	 

  /* Put energies */

  WDB[new1 + PARTICLE_E] = E_RESTMASS;
  WDB[new2 + PARTICLE_E] = E_RESTMASS;
  
  /* Sample direction isotropically */

  IsotropicDirection(&u, &v, &w, id);

  /* Put direction cosines (opposite directions) */

  WDB[new1 + PARTICLE_U] = u;
  WDB[new1 + PARTICLE_V] = v;
  WDB[new1 + PARTICLE_W] = w;

  WDB[new2 + PARTICLE_U] = -u;
  WDB[new2 + PARTICLE_V] = -v;
  WDB[new2 + PARTICLE_W] = -w;
  
  /* Put photons in que */

  ToQue(new1, id);	  
  ToQue(new2, id);	  

  /* Put incident photon back in stack */
	      
  ToStack(part, id);
}

/*****************************************************************************/
