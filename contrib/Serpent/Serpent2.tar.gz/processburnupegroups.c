/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processburnupegroups.c                         */
/*                                                                           */
/* Created:       2011/11/08 (JLe)                                           */
/* Last modified: 2011/12/15 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Sets up energy group structure used with spectrum-collapse   */
/*              method.                                                      */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessBurnupEGroups:"

/*****************************************************************************/

void ProcessBurnupEGroups()
{
  long erg, ptr, n, n0, ne;
  double *E;

  /* Check transport mode */

  if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_TRANSPORT)
    return;

  /* Get pointer to grid */

  erg = (long)RDB[DATA_BU_MG_PTR_GRID];
  CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);

  /* Check number of nuclides with ures data and b1 mode */
  
  if (((long)RDB[DATA_URES_USED] > 0) && 
      ((long)RDB[DATA_OPTI_FUM_CALC] == YES))
    {
      /***** Ures data with fum calculation **********************************/
      
      /* Get pointer to B1 energy grid */
  
      ptr = (long)RDB[DATA_FUM_PTR_EGRID];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);	
  
      if ((n0 = GridSearch(ptr, 0.999999*RDB[DATA_URES_EMIN])) < 0)
	Die(FUNCTION_NAME, "Grid search failed");

      if ((n = GridSearch(ptr, 1.000001*RDB[DATA_URES_EMAX])) < 0)
	Die(FUNCTION_NAME, "Grid search failed");

      /* Get pointer to grid data */
  
      ptr = (long)RDB[ptr + ENERGY_GRID_PTR_DATA];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);	

      /* Number of groups */

      ne = n - n0 + 1;

      /* Adjust grid */

      AdjustEnergyGrid(erg, ne + 1, &RDB[ptr + n0]);
  
      /* Set number of values */

      WDB[DATA_BU_MG_EGRID_NE] = ne;
      
      /* Set limits */

      WDB[DATA_BU_MG_EGRID_EMIN] = RDB[erg + ENERGY_GRID_EMIN];
      WDB[DATA_BU_MG_EGRID_EMAX] = RDB[erg + ENERGY_GRID_EMAX];

      /* Check */

      CheckValue(FUNCTION_NAME, "Emin", "", RDB[DATA_URES_EMIN], 
		 RDB[DATA_BU_MG_EGRID_EMIN], RDB[DATA_URES_EMAX]);
      CheckValue(FUNCTION_NAME, "Emin", "", RDB[DATA_URES_EMAX],
		 RDB[DATA_URES_EMIN], RDB[DATA_BU_MG_EGRID_EMAX]);

      /***********************************************************************/
    }
  else if ((long)RDB[DATA_URES_USED] > 0)
    {
      /***** Ures data, no fum calculation ***********************************/

      /* Allocate memory for temporary array */

      E = (double *)Mem(MEM_ALLOC, 2, sizeof(double));

      /* Put boundaries */

      E[0] = RDB[DATA_URES_EMIN];
      E[1] = RDB[DATA_URES_EMAX];
  
      /* Adjust grid */

      AdjustEnergyGrid(erg, 2, E);

      /* Set number of values */

      WDB[DATA_BU_MG_EGRID_NE] = 1.0;
      
      /* Set limits */

      WDB[DATA_BU_MG_EGRID_EMIN] = RDB[erg + ENERGY_GRID_EMIN];
      WDB[DATA_BU_MG_EGRID_EMAX] = RDB[erg + ENERGY_GRID_EMAX];

      /* Free temporary array */

      Mem(MEM_FREE, E);
      
      /***********************************************************************/
    }
}

/*****************************************************************************/
