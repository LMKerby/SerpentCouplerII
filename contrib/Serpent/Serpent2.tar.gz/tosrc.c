/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : tosrc.c                                        */
/*                                                                           */
/* Created:       2011/03/10 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Stores neutron in source for next generation                 */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ToSrc:"

/*****************************************************************************/

void ToSrc(long ptr)
{

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  
  /* Check particle type */
  
  if ((long)RDB[ptr + PARTICLE_TYPE] != PARTICLE_TYPE_NEUTRON)
    Die(FUNCTION_NAME, "Invalid particle type");
  
  /* Check simulation mode */
  
  if ((long)RDB[DATA_SIMULATION_MODE] != SIMULATION_MODE_CRIT)
    Die(FUNCTION_NAME, "Invalid simulation mode");
    
#ifdef OPEN_MP
#pragma omp critical
#endif

  {
    /* Put item in list */
    
    AddItem(DATA_PART_PTR_SRC_WRITE, ptr);
  }
}

/*****************************************************************************/
