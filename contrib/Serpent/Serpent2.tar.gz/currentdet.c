/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : currentdet.c                                   */
/*                                                                           */
/* Created:       2011/09/19 (JLe)                                           */
/* Last modified: 2011/11/10 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Scores current detector                                      */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CurrentDet:"

/*****************************************************************************/

double CurrentDet(long loc0, long part, double x1, double y1, double z1, 
		  double u, double v, double w, long id)
{
  long surf, type, ptr, uni, np, in0, in1, norm, idx, ncol;
  double x0, y0, z0, d, l, cross;

  /* Reset number of crossings */

  cross = 0.0;

  /* Get normal */

  norm = (long)RDB[loc0 + DET_SBIN_SURF_NORM];

  /* Get collision number */

  ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
  ncol = (long)GetPrivateData(ptr, id);
  
  /* Check surface pointer */

  if ((surf = (long)RDB[loc0 + DET_SBIN_PTR_SURF]) > VALID_PTR)
    {
      /***** Super-imposed surface *******************************************/
      
      /* Get previous coordinates */

      x0 = RDB[part + PARTICLE_PREV_X];
      y0 = RDB[part + PARTICLE_PREV_Y];
      z0 = RDB[part + PARTICLE_PREV_Z];

      /* Calculate distance between points */

      d = (x1 - x0)*(x1 - x0) + (y1 - y0)*(y1 - y0) + (z1 - z0)*(z1 - z0);
      d = sqrt(d);

      /* Invert direction cosines */

      u = -u;
      v = -v;
      w = -w;
      
      /* Get surface type */

      type = (long)RDB[surf + SURFACE_TYPE];
		
      /* Get number of parameters */
		
      np = (long)RDB[surf + SURFACE_N_PARAMS];
		
      /* Pointer to parameter list */
		
      ptr = (long)RDB[surf + SURFACE_PTR_PARAMS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Get initial position */

      in0 = TestSurface(surf, x1, y1, z1);

      /* Loop to previous point */

      while (d > 0.0)
	{      
	  /* Get distance */
		
	  l = SurfaceDistance(&RDB[ptr], type, np, x1, y1, z1, u, v, w);

	  /* Extrapolate */

	  l = l + EXTRAP_L;

	  /* Update distance between points */

	  if ((d = d - l) > 0.0)
	    {

	      /* Update coordinates */
	  
	      x1 = x1 + l*u;
	      y1 = y1 + l*v;
	      z1 = z1 + l*w;
	      
	      /* Get position */

	      in1 = TestSurface(surf, x1, y1, z1);
	      
	      /* Add to number of crossings */

	      if (norm == 0)
		{
		  /* Net current */

		  if ((in0 == YES) && (in1 == NO))
		    cross = cross - 1.0;
		  else if ((in0 == NO) && (in1 == YES))
		    cross = cross + 1.0;
		  else
		    Die(FUNCTION_NAME, "WTF?");
		}
	      else if (norm == -1)
		{
		  /* Inward current */
		  
		  if ((in0 == NO) && (in1 == YES))
		    cross = cross + 1.0;
		}
	      else if (norm == 1)
		{
		  /* Outward current */
		  
		  if ((in0 == YES) && (in1 == NO))
		    cross = cross - 1.0;
		}
	      else
		Die(FUNCTION_NAME, "Invalid normal");

	      /* Put previous position */

	      in0 = in1;
	    }
	}

      /***********************************************************************/
    }
  else
    {
      /***** Universe-based **************************************************/

      /* Universe pointer */
	  
      uni = RDB[loc0 + DET_SBIN_PTR_UNI];
      CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

      /* Get particle index */
      
      idx = (long)RDB[part + PARTICLE_IDX];
	  
      /* Get previous collision */
      
      if ((l = TestValuePair(loc0 + DET_SBIN_PREV_COL, idx, id)) > 0.0)
	in0 = YES;
      else
	in0 = NO;

      /* Check for collision */
	  
      if (TestValuePair(uni + UNIVERSE_COL_COUNT, ncol, id) > 0.0)
	in1 = YES;
      else
	in1 = NO;
      
      /* Store collision point */

      StoreValuePair(loc0 + DET_SBIN_PREV_COL, idx, in1, id);

      /* Add to number of crossings */

      if (norm == 0)
	{
	  /* Net current */
	  
	  if ((in0 == YES) && (in1 == NO))
	    cross = - 1.0;
	  else if ((in0 == NO) && (in1 == YES))
	    cross = 1.0;
	  else
	    cross = 0;
	}
      else if (norm == -1)
	{
	  /* Inward current */
	  
	  if ((in0 == NO) && (in1 == YES))
	    cross = 1.0;
	}
      else if (norm == 1)
	{
	  /* Outward current */
	  
	  if ((in0 == YES) && (in1 == NO))
	    cross = -1.0;
	}
      else
	Die(FUNCTION_NAME, "Invalid normal");
      
      /***********************************************************************/
    }

  /* Return number of crossings */

  return cross;
}

/*****************************************************************************/
