/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : totxs.c                                        */
/*                                                                           */
/* Created:       2011/07/21 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Returns continuous-energy or coarse multi-group total xs for */
/*                                                                           */
/* Comments: - Used in Tracking() and SampleReaction()                       */
/*                                                                           */
/*           - Tota arvoa ei voi tallentaa sillä samasta rea-structuresta    */
/*             haetaan sekä CE että MG -vaikutusalat.                        */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "TotXS:"

/*****************************************************************************/

double TotXS(long rea, double E, long id)
{
  long ptr, mt;
  double xs;

  /* Check Pointer */

  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

  /* Avoid compiler warning */

  xs = 0.0;

  /* Check for coarse multi-group xs */

  if ((ptr = (long)RDB[rea + REACTION_PTR_MGXS]) > VALID_PTR)
    xs = MGXS(rea, E, -1);
  else
    {
      /* Get mt */

      mt = (long)RDB[rea + REACTION_MT];

      /* Check mt for type */

      if (mt == MT_MACRO_TOTXS)
	xs = MacroXS(rea, E, id);
      else if (mt == MT_MACRO_TOTPHOTXS)
	xs = PhotonMacroXS(rea, E, id);
      else
	Die(FUNCTION_NAME, "Invalid reaction mode");
    }

  /* Return cross section */

  return xs;
}

/*****************************************************************************/
