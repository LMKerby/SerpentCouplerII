/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : die.c                                          */
/*                                                                           */
/* Created:       2010/11/19 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Terminates run in fatal error                                */
/*                                                                           */
/* Comments: - From Serpent 1.1.8                                            */
/*           - Use this for errors in code, user errors terminate the run    */
/*             with Error()                                                  */
/*           - This and Error() are the only functions that should make      */
/*             a call to exit().                                             */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Die:"

/*****************************************************************************/

int Die(char *func, ...)
{
  char date[MAX_STR];
  time_t t0;
  va_list argp;
  va_start (argp, func);

  /* Get time */

  time(&t0);
  strcpy(date, ctime(&t0));
  date[(int)strlen(date) - 1] = '\0';
  
  /* Print error message */
  
  fprintf(err, "\n***** %s (seed = %lu, MPI task = %d, OMP thread = %d)\n\n", 
	  date, parent_seed, mpiid, OMP_THREAD_NUM);

  fprintf(err, "Fatal error in function %s\n\n", func);
  vfprintf(err, va_arg(argp, char *), argp);
  fprintf(err, "\n\n");

  /*
  if ((int)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_XSTEST)
    return 0;
  */

  fprintf(err, "Simulation aborted.\n\n");

  /* Exit with value -1 to terminate all MPI tasks */

  exit(-1);
}

/*****************************************************************************/
