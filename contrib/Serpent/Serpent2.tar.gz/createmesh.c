/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : createmesh.c                                   */
/*                                                                           */
/* Created:       2011/05/14 (JLe)                                           */
/* Last modified: 2012/01/17 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Creates a new mesh structure                                 */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CreateMesh:"

/*****************************************************************************/

long CreateMesh(long type, long cont, long nx, double xmin, double xmax, 
		long ny, double ymin, double ymax, long nz, double zmin, 
		double zmax)
{
  long msh, ptr;

  /* Check dimensions */

  CheckValue(FUNCTION_NAME, "nx", "", nx, 1, 100000);
  CheckValue(FUNCTION_NAME, "ny", "", ny, 1, 100000);
  CheckValue(FUNCTION_NAME, "nz", "", nz, 1, 100000);

  /* Check type */

  if (type == MESH_TYPE_CARTESIAN)
    {
      /***** Cartesian mesh **************************************************/

      /* Check coordinates */
      
      CheckValue(FUNCTION_NAME, "xmin", "", xmin, -INFTY, INFTY);
      CheckValue(FUNCTION_NAME, "xmax", "", xmax, xmin, INFTY);
      CheckValue(FUNCTION_NAME, "ymin", "", ymin, -INFTY, INFTY);
      CheckValue(FUNCTION_NAME, "ymax", "", ymax, ymin, INFTY);
      CheckValue(FUNCTION_NAME, "zmin", "", zmin, -INFTY, INFTY);
      CheckValue(FUNCTION_NAME, "zmax", "", zmax, zmin, INFTY);
      
      /***********************************************************************/
    }
  else if (type == MESH_TYPE_CYLINDRICAL)
    {
      /***** Cylindrical mesh ************************************************/

      /* Check coordinates */
      
      CheckValue(FUNCTION_NAME, "xmin", "", xmin, 0.0, INFTY);
      CheckValue(FUNCTION_NAME, "xmax", "", xmax, xmin, INFTY);
      CheckValue(FUNCTION_NAME, "ymin", "", ymin, 0.0, PI);
      CheckValue(FUNCTION_NAME, "ymax", "", ymax, ymin, 2*PI);
      CheckValue(FUNCTION_NAME, "zmin", "", zmin, -INFTY, INFTY);
      CheckValue(FUNCTION_NAME, "zmax", "", zmax, zmin, INFTY);
      
      /***********************************************************************/
    }
  else
    Die(FUNCTION_NAME, "Invalid mesh type %ld", type);
  
  /* Allocate memory for structure */
  
  msh = ReallocMem(DATA_ARRAY, MESH_BLOCK_SIZE);
  
  /* Put parameters */
  
  WDB[msh + MESH_TYPE] = (double)type;
  WDB[msh + MESH_CONTENT] = (double)cont;
  WDB[msh + MESH_N0] = (double)nx;
  WDB[msh + MESH_N1] = (double)ny;
  WDB[msh + MESH_N2] = (double)nz;
  WDB[msh + MESH_MIN0] = xmin;
  WDB[msh + MESH_MAX0] = xmax;
  WDB[msh + MESH_MIN1] = ymin;
  WDB[msh + MESH_MAX1] = ymax;
  WDB[msh + MESH_MIN2] = zmin;
  WDB[msh + MESH_MAX2] = zmax;

  /* Check content */

  if (cont == MESH_CONTENT_DATA)
    {
      /* Allocate memory for data */
      
      ptr = AllocPrivateData(nx*ny*nz + 1, RES2_ARRAY);
      
      /* Put pointer */
      
      WDB[msh + MESH_PTR_RES2] = (double)ptr;
    }
  else
    {
      /* Allocate memory for pointer */
      
      ptr = ReallocMem(DATA_ARRAY, nx*ny*nz);
      
      /* Put pointer */

      WDB[msh + MESH_PTR_PTR] = (double)ptr;
    }

  /* Return mesh pointer */

  return msh;
}

/*****************************************************************************/
