/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : findnestregion.c                               */
/*                                                                           */
/* Created:       2010/10/07 (JLe)                                           */
/* Last modified: 2012/02/01 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Finds nest region based on coordinates                       */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "FindNestRegion:"

/*****************************************************************************/

long FindNestRegion(long nst, double x, double y, double z)
{
  long ptr, n, reg, surf;

  /* Get pointer to regions */
	      
  ptr = (long)RDB[nst + NEST_PTR_REGIONS];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  
  /* Loop over regions */ 

  n = 0;
  while ((reg = ListPtr(ptr, n++)) > VALID_PTR)
    {
      /* Get pointer to surface */

      if ((surf = (long)RDB[reg + NEST_REG_PTR_SURF_IN]) < VALID_PTR)
	return reg;

      /* Test surface */

      if (TestSurface(surf, x, y, z) == YES)
	return reg;
    }

  /* Something wrong */

  Die(FUNCTION_NAME, "Unable to find nest region");

  /* Avoid warning message */

  return 0;
}

/*****************************************************************************/
