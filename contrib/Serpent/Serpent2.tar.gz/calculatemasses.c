/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : calculatemasses.c                              */
/*                                                                           */
/* Created:       2011/05/31 (JLe)                                           */
/* Last modified: 2011/11/11 (AIs)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates material and fissile masses etc.                  */
/*                                                                           */
/* Comments: - NOTE: tän kanssa pitää olla varovainen, sillä palamat ym.     */
/*             tehdään alkuperäiseen fissiiliin massaan, eli niitä ei        */
/*             päivitetä ensimmäisen askeleen jälkeen. Serpent 1:ssä on      */
/*             optio sille että tuo massa muuttuu, mutta se on nyt jätetty   */
/*             tästä pois.                                                   */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CalculateMasses:"

/*****************************************************************************/

void CalculateMasses()
{
  long mat, iso, nuc;
  double mass, mdens, adens;

  /* Reset total masses */

  WDB[DATA_TOT_FMASS] = 0.0;
  WDB[DATA_TOT_BURN_FMASS] = 0.0;

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Get material density */
      
      mdens = RDB[mat + MATERIAL_MDENS];

      /* Check value */

      if (mdens < ZERO)
	Die(FUNCTION_NAME, "material %s density too low (%E)",
	    GetText(mat + MATERIAL_PTR_NAME), mdens);

      /* Calculate material and volume if not given */
      
      if (RDB[mat + MATERIAL_VOLUME] > 0.0)
	WDB[mat + MATERIAL_MASS] = RDB[mat + MATERIAL_VOLUME]*mdens;
      else if (RDB[mat + MATERIAL_MASS] > 0.0)
	WDB[mat + MATERIAL_VOLUME] = RDB[mat + MATERIAL_MASS]/mdens;

      /* Reset mass */

      mass = 0.0;

      /* Loop over composition and calculate mass of fissile isotopes */

      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
      while (iso > VALID_PTR)
	{
	  /* Get atomic density and pointer to nuclide */

	  adens = RDB[iso + COMPOSITION_ADENS];
	  nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];

	  /* Check fissile flag and add to mass */

	  if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_FISSILE)
	    mass = mass + adens*RDB[nuc + NUCLIDE_AW]*
	      RDB[mat + MATERIAL_VOLUME]/N_AVOGADRO;

	  /* Next isotope */

	  iso = NextItem(iso);
	}	

      /* Check fissile flag and burnup step (tarvitseeko moodia testata?) */

      if (((long)RDB[mat + MATERIAL_OPTIONS] & OPT_FISSILE_MAT) &&
          !(((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_INT_BURN) &&
            (RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP)))
	{
	  /* Add to initial fissile mass */

	  WDB[DATA_TOT_FMASS] = RDB[DATA_TOT_FMASS] + 1E-3*mass;

	  /* Put material-wise fissile mass */

	  WDB[mat + MATERIAL_TOT_FMASS] = 1E-3*mass;

	  /* Check burn-flag */

	  if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	    {
	      /* Add to burnable fissile mass */

	      WDB[DATA_TOT_BURN_FMASS] = RDB[DATA_TOT_BURN_FMASS] + 
		1E-3*mass;
	    }

	  /* Check for first step and add to initial masses */

	  if ((long)RDB[DATA_BURN_STEP] == 0)
	    {
	      /* Add to initial fissile mass */

	      WDB[DATA_INI_FMASS] = RDB[DATA_INI_FMASS] + 1E-3*mass;
	      
	      /* Put material-wise fissile mass */
	      
	      WDB[mat + MATERIAL_INI_FMASS] = 1E-3*mass;
	      
	      /* Check burn-flag */
	      
	      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
		{
		  /* Add to burnable fissile mass */
		  
		  WDB[DATA_INI_BURN_FMASS] = RDB[DATA_INI_BURN_FMASS] + 
		    1E-3*mass;
		}
	    }
	}

      /* Next material */

      mat = NextItem(mat);
    }
}

/*****************************************************************************/
