/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processdetectors.c                             */
/*                                                                           */
/* Created:       2011/03/03 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Processes source definitions                                 */
/*                                                                           */
/* Comments: - Detector cells and universes are processed in                 */
/*             creategeometry.c                                              */
/*           - TODO: se automaattinen volume-juttu                           */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessDetectors:"

/*****************************************************************************/

void ProcessDetectors()
{
  long det, ene, ptr, mat, uni, lat, cell, surf, tot, n1, n2;
  long ebins, ubins, cbins, mbins, lbins, rbins, zbins, ybins, xbins, tbins;
  char str[MAX_STR];

  /* Check that detector definitions exist */

  if ((long)RDB[DATA_PTR_DET0] < VALID_PTR)
    return;

  /***************************************************************************/

  /***** Link pointers and allocate memory ***********************************/

  /* Loop over detectors */

  det = (long)RDB[DATA_PTR_DET0];  
  while (det > 0)
    {
      /* Reset bin sizes */

      zbins = (long)RDB[det + DET_MESH_NZ];
      ybins = (long)RDB[det + DET_MESH_NY];
      xbins = (long)RDB[det + DET_MESH_NX];
      tbins = 1;
      
      /***********************************************************************/
      
      /***** Link energy grids to detectors **********************************/

      /* Check pointer */
      
      if ((long)RDB[det + DET_PTR_EGRID] > VALID_PTR)
	{
	  /* Find grid */
	  
	  ene = RDB[DATA_PTR_ENE0];
	  if ((ene = SeekListStr(ene, ENE_PTR_NAME, 
				 GetText(det + DET_PTR_EGRID))) < VALID_PTR)
	    Error(det, "Energy grid %s in detector %s is not defined", 
		  GetText(det + DET_PTR_EGRID), 
		  GetText(det + DET_PTR_NAME));
	  
	  /* Set pointer */
	  
	  WDB[det + DET_PTR_EGRID] = RDB[ene + ENE_PTR_GRID];
	  
	  /* Set number of bins */

	  ebins = (long)RDB[ene + ENE_NB];
	}
      else
	ebins = 1;

      /***********************************************************************/
      
      /***** Link materials to response functions ****************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_RBINS]) < VALID_PTR)
	{
	  /* Create response bin for flux */

	  if ((long)RDB[det + DET_PTR_RBINS] < VALID_PTR)
	    {
	      /* Allocate memory for structure */
	      
	      ptr = NewItem(det + DET_PTR_RBINS, DET_RBIN_BLOCK_SIZE);
	      
	      /* Put mt and material pointer */
	      
	      WDB[ptr + DET_RBIN_MT] = 0.0;
	      WDB[ptr + DET_RBIN_PTR_MAT] = NULLPTR;
	    }

	  /* Set counter */

	  rbins = 1;
	}
      else
	{
	  /* Reset counter */

	  rbins = 0;
	  
	  /* Loop over reaction bins */
 
	  while (ptr > VALID_PTR)
	    {
	      /* Check void */
	      
	      if (!strcmp(GetText(ptr + DET_RBIN_PTR_MAT), "void"))
		{
		  /* Set null pointer */
		  
		  WDB[ptr + DET_RBIN_PTR_MAT] = NULLPTR;
		}
	      else
		{
		  /* Find material */
		  
		  mat = RDB[DATA_PTR_M0];
		  if ((mat = SeekListStr(mat,MATERIAL_PTR_NAME, 
					 GetText(ptr + DET_RBIN_PTR_MAT))) 
		      < VALID_PTR)
		    Error(det,
			  "Material %s in detector %s response is not defined", 
			  GetText(ptr + DET_RBIN_PTR_MAT), 
			  GetText(det + DET_PTR_NAME));
		  
		  /* Set pointer */
		  
		  WDB[ptr + DET_RBIN_PTR_MAT] = (double)mat;
		  
		  /* Set used-flags */
		  
		  SetOption(mat + MATERIAL_OPTIONS, OPT_USED);
		}

	      /* Update number of bins */
	      
	      rbins++;
	      
	      /* Next bin */
	      
	      ptr = NextItem(ptr);
	    }
	}

      /***********************************************************************/

      /***** Link universes to detectors *************************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_UBINS]) < VALID_PTR)
	ubins = 1;
      else
	{
	  /* Reset counter */

	  ubins = 0;

	  /* Loop over universe bins */

	  while (ptr > VALID_PTR)
	    {
	      /* Find universe */
	      
	      uni = RDB[DATA_PTR_U0];
	      if ((uni = SeekListStr(uni, UNIVERSE_PTR_NAME, 
				     GetText(ptr + DET_UBIN_PTR_UNI))) 
		  < VALID_PTR)
		Error(det,"Universe %s in detector %s is not defined", 
		      GetText(ptr + DET_UBIN_PTR_UNI), 
		      GetText(det + DET_PTR_NAME));
	      
	      /* Set pointer */
	      
	      WDB[ptr + DET_UBIN_PTR_UNI] = (double)uni;
	      
	      /* Update number of bins */
	      
	      ubins++;
	      
	      /* Next bin */
	      
	      ptr = NextItem(ptr);
	    }
	}
      
      /***********************************************************************/

      /***** Link lattices to detectors **************************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_LBINS]) < VALID_PTR)
	lbins = 1;
      else
	{
	  /* Find lattice */
	      
	  lat = RDB[DATA_PTR_L0];
	  if ((lat = SeekListStr(lat, LAT_PTR_NAME, 
				 GetText(ptr + DET_LBIN_PTR_LAT))) 
	      < VALID_PTR)
	    Error(det,"Lattice %s in detector %s is not defined", 
		  GetText(ptr + DET_LBIN_PTR_LAT), 
		  GetText(det + DET_PTR_NAME));
	  
	  /* Set pointer */
	      
	  WDB[ptr + DET_LBIN_PTR_LAT] = (double)lat;
	  
	  /* Set number of bins */
	  
	  lbins = (long)RDB[lat + LAT_NTOT];
	}
      
      /***********************************************************************/

      /***** Link materials to detectors *************************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_MBINS]) < VALID_PTR)
	mbins = 1;
      else
	{
	  /* Reset counter */

	  mbins = 0;

	  /* Loop over bins */
      
	  while (ptr > VALID_PTR)
	    {
	      /* Find material */
	      
	      mat = RDB[DATA_PTR_M0];
	      if ((mat = SeekListStr(mat, MATERIAL_PTR_NAME, 
				     GetText(ptr + DET_MBIN_PTR_MAT))) 
		  < VALID_PTR)
		Error(det,"Material %s in detector %s is not defined", 
		      GetText(ptr + DET_MBIN_PTR_MAT), 
		      GetText(det + DET_PTR_NAME));
	      
	      /* Set pointer */
	      
	      WDB[ptr + DET_MBIN_PTR_MAT] = (double)mat;
	      
	      /* Update number of bins */
	      
	      mbins++;
	      
	      /* Next bin */
	      
	      ptr = NextItem(ptr);
	    }
	}
      
      /***********************************************************************/

      /***** Link cells to detectors *****************************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_CBINS]) < VALID_PTR)
	cbins = 1;
      else
	{
	  /* Reset counter */

	  cbins = 0;

	  /* Loop over cell bins */

	  while (ptr > VALID_PTR)
	    {
	      /* Find cell */
	      
	      cell = RDB[DATA_PTR_C0];
	      if ((cell = SeekListStr(cell, CELL_PTR_NAME, 
				      GetText(ptr + DET_CBIN_PTR_CELL))) 
		  < VALID_PTR)
		Error(det,"Cell %s in detector %s is not defined", 
		      GetText(ptr + DET_CBIN_PTR_CELL), 
		      GetText(det + DET_PTR_NAME));
	      
	      /* Set pointer */
	      
	      WDB[ptr + DET_CBIN_PTR_CELL] = (double)cell;
	      
	      /* Update number of bins */
	      
	      cbins++;
	      
	      /* Next bin */
	      
	      ptr = NextItem(ptr);
	    }
	}
      
      /***********************************************************************/

      /***** Link dividers and multipliers ***********************************/

      /* Check pointer */

      if ((long)RDB[det + DET_PTR_MUL] > VALID_PTR)
	{
	  /* Find detector */
	  
	  ptr = RDB[DATA_PTR_DET0];
	  if ((ptr = SeekListStr(ptr, DET_PTR_NAME,
				 GetText(det + DET_PTR_MUL)))
	      < VALID_PTR)
	    Error(det,"Multiplier / dividor detector %s is not defined", 
		  GetText(det + DET_PTR_MUL));
	  
	  /* Set pointer */
	  
	  WDB[ptr + DET_PTR_MUL] = (double)ptr;
	}
      
      /***********************************************************************/

      /***** Link adjoints ***************************************************/

      /* Check pointer */

      if ((long)RDB[det + DET_PTR_ADJOINT] > VALID_PTR)
	{
	  /* Find detector */
	  
	  ptr = RDB[DATA_PTR_DET0];
	  if ((ptr = SeekListStr(ptr, DET_PTR_NAME,
				 GetText(det + DET_PTR_ADJOINT)))
	      < VALID_PTR)
	    Error(det,"Adjoint detector %s is not defined", 
		  GetText(det + DET_PTR_ADJOINT));
	  
	  /* Set pointer */
	  
	  WDB[det + DET_PTR_ADJOINT] = (double)ptr;

	  /* Switch history lists on */
	  
	  WDB[DATA_HIST_LIST_SIZE] = fabs(RDB[DATA_HIST_LIST_SIZE]);
	}
      
      /***********************************************************************/

      /***** Link surface current parameters *********************************/

      /* Check pointer */

      if ((ptr = (long)RDB[det + DET_PTR_SBINS]) > VALID_PTR)
	{
	  /* Check surface pointer */

	  if ((long)RDB[ptr + DET_SBIN_PTR_SURF] > VALID_PTR)
	    {
	      /* Find surface */
	      
	      surf = RDB[DATA_PTR_S0];
	      if ((surf = SeekListStr(surf, SURFACE_PTR_NAME, 
				      GetText(ptr + DET_SBIN_PTR_SURF))) 
		  < VALID_PTR)
		Error(det,"Surface %s in detector %s is not defined", 
		      GetText(ptr + DET_SBIN_PTR_SURF), 
		      GetText(det + DET_PTR_NAME));
	      
	      /* Set pointer */
	      
	      WDB[ptr + DET_SBIN_PTR_SURF] = (double)surf;
	    }
	  else if ((long)RDB[ptr + DET_SBIN_PTR_UNI] > VALID_PTR)
	    {
	      /* Find first universe */
	      
	      uni = RDB[DATA_PTR_U0];
	      if ((uni = SeekListStr(uni, UNIVERSE_PTR_NAME, 
				     GetText(ptr + DET_SBIN_PTR_UNI))) 
		  < VALID_PTR)
		Error(det,"Universe %s in detector %s is not defined", 
		      GetText(ptr + DET_SBIN_PTR_UNI), 
		      GetText(det + DET_PTR_NAME));
	      
	      /* Set pointer */
	      
	      WDB[ptr + DET_SBIN_PTR_UNI] = (double)uni;

	      /* Allocate memory for previous collision */

	      AllocValuePair(ptr + DET_SBIN_PREV_COL);
	    }
	  else
	    Error(det, "Surface or universe missing in current parameter");

	  /* Check invalid options (Tää ei tarkista kaikkea) */

	  if ((long)RDB[det + DET_PTR_UBINS] > VALID_PTR)
	    Error(det, "Universe bins not allowed with current detector");
	  if ((long)RDB[det + DET_PTR_LBINS] > VALID_PTR)
	    Error(det, "Lattice bins not allowed with current detector");
	  if ((long)RDB[det + DET_PTR_MBINS] > VALID_PTR)
	    Error(det, "Material bins not allowed with current detector");
	  if ((long)RDB[det + DET_PTR_CBINS] > VALID_PTR)
	    Error(det, "Cell bins not allowed with current detector");
	}
      
      /***********************************************************************/

      /***** Allocate memory for statistics **********************************/
    
      /* Set final bin sizes */

      WDB[det + DET_N_EBINS] = (double)ebins;
      WDB[det + DET_N_UBINS] = (double)ubins;
      WDB[det + DET_N_CBINS] = (double)cbins;
      WDB[det + DET_N_MBINS] = (double)mbins;
      WDB[det + DET_N_LBINS] = (double)lbins;
      WDB[det + DET_N_RBINS] = (double)rbins;
      WDB[det + DET_N_TBINS] = (double)tbins;

      /* Calculate total size */

      tot = ebins*ubins*cbins*mbins*lbins*rbins*zbins*ybins*xbins*tbins;

      /* Check maximum size */

      if (tot > 100000)
	Error(det, "Total number of bins exceeds maximum");

      /* Check zero */

      if (tot < 1)
	Die(FUNCTION_NAME, "Error in bin sizes");

      /* Put total number fo bins */

      WDB[det + DET_N_TOT_BINS] = (double)tot;

      /* Put name */

      sprintf(str, "DET_%s", GetText(det + DET_PTR_NAME));

      /* Allocate memory for results for non-adjoint detectors */

      if ((long)RDB[det + DET_PTR_ADJOINT] < VALID_PTR)
	{
	  /* Allocate memory */
	  
	  ptr = NewStat(str, 1, tot);
	
	  /* Put pointer */
	  
	  WDB[det + DET_PTR_STAT] = (double)ptr;
	}
      /***********************************************************************/

      /* Next detector */

      det = NextItem(det);
    }
  
  /* Loop over detectors */

  det = (long)RDB[DATA_PTR_DET0];  
  while (det > 0)
    {
      /* Check adjoint type */
      
      if ((ptr = (long)RDB[det + DET_PTR_ADJOINT]) > VALID_PTR)
	{
	  /* Get sizes */

	  n1 = (long)RDB[det + DET_N_TOT_BINS];
	  n2 = (long)RDB[ptr + DET_N_TOT_BINS];
  
	  /* Allocate memory */

	  ptr = NewStat(str, 2, n1, n2);

	  /* Put pointer */
	  
	  WDB[det + DET_PTR_STAT] = (double)ptr;
	}
      
      /* Next detector */

      det = NextItem(det);
    }

  /***************************************************************************/

  /***** Checks **************************************************************/

  /* Loop over detectors */

  det = (long)RDB[DATA_PTR_DET0];  
  while (det > 0)
    {
      /***** Check multiplier / divider detectors ****************************/

      if ((ptr = (long)RDB[det + DET_PTR_MUL]) > VALID_PTR)
	{
	  /* Check number of values */

	  if ((long)RDB[ptr + DET_N_TOT_BINS] > 1)
	    {
	      /* Check each bin */

	      if (RDB[det + DET_N_EBINS] != RDB[ptr + DET_N_EBINS])
		Error(det, "Mismatch in energy bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_UBINS] != RDB[ptr + DET_N_UBINS])
		Error(det, "Mismatch in universe bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_CBINS] != RDB[ptr + DET_N_CBINS])
		Error(det, "Mismatch in cell bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_MBINS] != RDB[ptr + DET_N_MBINS])
		Error(det, "Mismatch in material bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_LBINS] != RDB[ptr + DET_N_LBINS])
		Error(det, "Mismatch in lattice bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_RBINS] != RDB[ptr + DET_N_RBINS])
		Error(det, "Mismatch in reaction bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_N_TBINS] != RDB[ptr + DET_N_TBINS])
		Error(det, "Mismatch in time bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_MESH_NX] != RDB[ptr + DET_MESH_NX])
		Error(det, "Mismatch in x-bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_MESH_NY] != RDB[ptr + DET_MESH_NY])
		Error(det, "Mismatch in y-bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	      if (RDB[det + DET_MESH_NZ] != RDB[ptr + DET_MESH_NZ])
		Error(det, "Mismatch in z-bins of detector %s",
		      GetText(ptr + DET_PTR_NAME));
	    }
	}
      
      /***********************************************************************/

      /* Next detector */

      det = NextItem(det);
    }

  /***************************************************************************/
}  

/*****************************************************************************/
