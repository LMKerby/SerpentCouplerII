/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : samplenu.c                                     */
/*                                                                           */
/* Created:       2011/03/10 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Samples number of fission neutrons                           */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "SampleNu:"

/*****************************************************************************/

long SampleNu(double nubar, long id)
{
  long nu;

  /* Check value */
  /*
  CheckValue(FUNCTION_NAME, "nubar", "", nubar, 0.0, 100.0);
  */
  /* Adjust nubar by cycle k-eff */
  
  nubar = nubar/RDB[DATA_CYCLE_KEFF];

  /* Get integer part */

  nu = (long)nubar;

  /* Sample extra neutron */

  if (RandF(id) < nubar - (double)nu)
    nu++;

  /* Return value */

  return nu;
}

/*****************************************************************************/
