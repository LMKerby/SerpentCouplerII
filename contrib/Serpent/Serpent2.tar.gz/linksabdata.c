/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : linksabdata.c                                  */
/*                                                                           */
/* Created:       2011/01/21 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Links materials to S(a,b) data                               */
/*                                                                           */
/* Comments: - Temperature interpolation is linear. Check if sqrt(T) is      */
/*             better (see work by Trumbull et. al.).                        */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "LinkSabData:"

/*****************************************************************************/

void LinkSabData()
{
  long mat, ptr, loc0, iso, nuc, ace, n;
  double T, T1, T2;

  /***************************************************************************/

  /***** Link data to materials **********************************************/

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Loop over S(a,b) data */

      ptr = (long)RDB[mat + MATERIAL_PTR_SAB];
      while (ptr > VALID_PTR)
	{
	  /* Pointer to S(a,b) definitions */

	  if ((loc0 = (long)RDB[DATA_PTR_T0]) < VALID_PTR)
	    Error(mat, "S(a,b) library %s is not defined",
		  GetText(ptr + THERM_PTR_ALIAS));
	  
	  /* Find match */

	  if ((loc0 = SeekListStr(loc0, THERM_PTR_ALIAS, 
				  GetText(ptr + THERM_PTR_ALIAS))) 
	      > VALID_PTR)	  
	    {
	      /* Check that ZA is found in nuclide composition */

	      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	      while (iso > VALID_PTR)
		{
		  /* Pointer to nuclide data */

		  nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
		  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

		  /* Compare ZA */

		  if (RDB[ptr + THERM_ZA] == RDB[nuc + NUCLIDE_ZA])
		    {
		      /* Put pointer */
		      
		      WDB[ptr + THERM_PTR_COMP] = (double)iso;
		      
		      /* Break loop */
		      
		      break;
		    }

		  /* Next nuclide */

		  iso = NextItem(iso);
		}

	      /* Check pointer */

	      if (iso < VALID_PTR)
		Error(mat, "S(a,b) ZA %ld not found in composition", 
		      (long)RDB[ptr + THERM_ZA]);

	      /* Put pointer */

	      WDB[ptr + THERM_PTR_THERM] = (long)loc0;

	      /* Check that ZA is not already assigned */

	      if ((RDB[loc0 + THERM_ZA] > 0.0) &&
		  (RDB[loc0 + THERM_ZA] != RDB[ptr + THERM_ZA]))
		Error(mat, "S(a,b) library %s is already assinged to ZA = %ld",
		      GetText(ptr + THERM_PTR_ALIAS), 
		      (long)RDB[loc0 + THERM_ZA]);

	      /* Put ZA */
	      
	      WDB[loc0 + THERM_ZA] = RDB[ptr + THERM_ZA];

	      /* Set used-flag */

	      SetOption(loc0 + THERM_OPTIONS, OPT_USED);
	    }
	  else
	    Error(mat, "S(a,b) library %s is not defined",
		  GetText(ptr + THERM_PTR_ALIAS));

	  /* Next */

	  ptr = NextItem(ptr);
	}

      /* Next material */

      mat = NextItem(mat);
    }

  /* Remove unused data */

  ptr = (long)RDB[DATA_PTR_T0];
  RemoveFlaggedItems(ptr, THERM_OPTIONS, OPT_USED, NO);

  /***************************************************************************/
  
  /***** Put ZA in ACE data **************************************************/

  /* Loop over data */

  loc0 = (long)RDB[DATA_PTR_T0];
  while (loc0 > VALID_PTR)
    {
      /* Loop over nuclides */
      
      for (n = 0; n < 2; n++)
	{
	  /* Pointer */
	  
	  if (n == 0)
	    ptr = loc0 + THERM_PTR_ISO1;
	  else
	    ptr = loc0 + THERM_PTR_ISO2;

	  /* Check */
	  
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  /* Check pointer */

	  if ((long)RDB[ptr] > VALID_PTR)
	    {
	      /* Loop over ace data (ei voi käyttää VALID_PTR) */
	      
	      ace = (long)RDB[DATA_PTR_ACE0];
	      while (ace > 0)
		{
		  /* Compare */
		  
		  WDB[DATA_DUMMY] = ACE[ace + ACE_PTR_ALIAS];
		  if (!strcmp(GetText(DATA_DUMMY), GetText(ptr)))
		    {
		      /* Check type */
		      
		      if ((long)ACE[ace + ACE_TYPE] == NUCLIDE_TYPE_SAB)
			{
			  /* Check that ZA is not already defined */

			  if ((ACE[ace + ACE_BOUND_ZA] > 0) &&
			      (ACE[ace + ACE_BOUND_ZA] != 
			       RDB[loc0 + THERM_ZA]))
			    Error(loc0, 
				  "S(a,b) library %s already assigned to ZA = %ld", 
				  GetText(ptr), (long)ACE[ace + ACE_BOUND_ZA]);
			  else		      
			    ACE[ace + ACE_BOUND_ZA] = RDB[loc0 + THERM_ZA];
			  
			  /* Break loop */
			  
			  break;
			}
		      else
			Error(loc0, "%s is an not S(a,b) libary",
			      GetText(ptr));
		    }
	      
		  /* next */
	      
		  ace = (long)ACE[ace + ACE_PTR_NEXT];
		}
	  
	      /* Check if found */
	      
	      if (ace < 0)
		Error(loc0, "Nuclide %s not found in data libraries", 
		      GetText(ptr));
	    }
	}

      /* Next */

      loc0 = NextItem(loc0);
    }
	  
  /***************************************************************************/

  /***** Calculate fractions for temperature interpolation *******************/

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Loop over S(a,b) data */

      ptr = (long)RDB[mat + MATERIAL_PTR_SAB];
      while (ptr > VALID_PTR)
	{
	  /* Get pointer */

	  loc0 = (long)RDB[ptr + THERM_PTR_THERM];
	  CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

	  /* Get temperatures */

	  T = RDB[loc0 + THERM_T];
	  T1 = RDB[loc0 + THERM_T1];
	  T2 = RDB[loc0 + THERM_T2];
	  
	  /* Check */
      
	  if (T < 0.0)
	    {
	      /* No interpolation */
	      
	      WDB[ptr + THERM_FRAC1] = 1.0;
	      WDB[ptr + THERM_FRAC2] = 0.0;
	    }
	  else if (T1 >= T2)
	    Error(ptr, "Error in temperature interpolation parameters");
	  else if ((T < T1) || (T > T2))
	    Error(ptr, "Interpolation temperature is not witihn boundaries");
	  else
	    {
	      /* Interpolate fractions */
	      
	      WDB[ptr + THERM_FRAC1] = (T2 - T)/(T2 - T1);
	      WDB[ptr + THERM_FRAC2] = 1.0 - RDB[ptr + THERM_FRAC1];
	    }
	  
	  /* Next */

	  ptr = NextItem(ptr);
	}

      /* Next material */

      mat = NextItem(mat);
    }

  /***************************************************************************/
}

/*****************************************************************************/
