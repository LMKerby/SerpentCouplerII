/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : main.c                                         */
/*                                                                           */
/* Created:       2010/11/22 (JLe)                                           */
/* Last modified: 2012/01/10 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Main program file                                            */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Main:"

/*****************************************************************************/

int main(int argc, char** argv)
{
  long ptr;
  char str[MAX_STR];

  /* Start runtime and init timers */

  StartTimer(TIMER_RUNTIME);
  StartTimer(TIMER_INIT);

  /* Initialise MPI */

  InitMPI(argc, argv);

  /* Init main data block */
  
  InitData();

  /***************************************************************************/

  /***** Initial processing before MPI parallelization ***********************/

  /* Check MPI id number */

  if (mpiid == 0)
    {
      /* Get system stat */
      
      SystemStat();
   
      /* Process command line */
      
      if (ParseCommandLine(argc, argv) < 0)
	return 0;

      /* Init OpenMP related stuff */

      InitOMP();

      /* Remove warning message file */

      sprintf(str, "%s.wrn", GetText(DATA_PTR_INPUT_FNAME));
      remove(str);

      /* print title */
      
      PrintTitle();
      
      fprintf(out, "Begin calculation on %s\n\n", GetText(DATA_PTR_DATE));

      /* Read input */
      
      ReadInput(GetText(DATA_PTR_INPUT_FNAME));
      fprintf(out, "\n");

      /* Read pebble bed geometries */

      ReadPBGeometry();

      /* Check duplicate input definitions */

      CheckDuplicates();

      /* Process depletion history (voidaan kutsua jo tässä) */

      ProcessDepHis();

      /* Set optimization */

      SetOptimization();

      /* Initialize secondary RNG */
      
      srand48(parent_seed);

      /* Divide burnable zones */

      DivideBurnMat();

      /* Process stochastic geometries */

      ProcessPBGeometry();

      /* Create universes in geometry */

      CreateGeometry();

      /* Process universe transformations */

      ProcessTransformations();

      /* Remove unused cells */

      ptr = (long)RDB[DATA_PTR_C0];
      RemoveFlaggedItems(ptr, CELL_OPTIONS, OPT_USED, NO);
      
      /* Remove unused nests */
      
      ptr = (long)RDB[DATA_PTR_NST0];
      RemoveFlaggedItems(ptr, NEST_OPTIONS, OPT_USED, NO);
      
      /* Remove unused lattices */
      
      ptr = (long)RDB[DATA_PTR_L0];
      RemoveFlaggedItems(ptr, LAT_OPTIONS, OPT_USED, NO);
      
      /* Remove unused transformations */
      
      ptr = (long)RDB[DATA_PTR_TR0];
      RemoveFlaggedItems(ptr, TRANS_OPTIONS, OPT_USED, NO);
      
      /* Remove unused cells */
      
      ptr = (long)RDB[DATA_PTR_C0];
      RemoveFlaggedItems(ptr, CELL_OPTIONS, OPT_USED, NO);

      /* Process cells */

      ProcessCells();

      /* Process nests */
      
      ProcessNests();
      
      /* Set material pointers */
      
      FindMaterialPointers();
      
      /* Process sources, energy grids and detectors (must be done before */
      /* unused cells and materials are removed) */

      ProcessSources();
      ProcessUserEGrids();
      ProcessDetectors();
      
      /* Remove unused materials */
      
      ptr = (long)RDB[DATA_PTR_M0];
      RemoveFlaggedItems(ptr, MATERIAL_OPTIONS, OPT_USED, NO);

      /* Remove unused surfaces */

      ptr = (long)RDB[DATA_PTR_S0];
      RemoveFlaggedItems(ptr, SURFACE_OPTIONS, OPT_USED, NO);

      /* Process lattices */

      ProcessLattices();

      /* Find universe boundaries */

      UniverseBoundaries();
      
      /* Calculate nest volumes */
      
      NestVolumes();
      
      /* Count number of cells */
      
      ptr = (long)RDB[DATA_PTR_ROOT_UNIVERSE];
      CellCount(ptr, 0, 1);
      
      /* Calculate material volumes */
      
      MaterialVolumes();
      
      /* Monte Carlo volume calculator */

      VolumesMC();

      /* Break if command-line volume MC mode */

      if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_VOLUMEMC)
	return -1;

      /* Process core power distributions */

      ProcessCPD();

      /* Process statistics */

      ProcessStats();

      /* Process entropy stuff */

      ProcessEntropy();

      /* Process GC stuff */

      ProcessGC();

      /* Process B1 FUM stuff */
      
      ProcessFUM();

      /* Process temperature feedbacks */

      ProcessTFB();
      
      /* Plot geometry */
      
      GeometryPlotter();
      
      /* Process nuclides */
      
      ProcessNuclides();

      /* Doppler-broadening on cross sections */

      DopplerBroad();
      
      /* Process data for on-the-fly calculation */
      
      ProcessOnTheFlyData();
      
      /* Process inventory list */
      
      ProcessInventory();
    }

  /***************************************************************************/

  /**** MPI parallel part ****************************************************/

  /* Distribute data to parallel MPI tasks */

  ShareInputData();

  /* Process energy grids */

  UnionizeGrid();

  /* Process XS data */

  ProcessXSData();

  /* Process mesh plots */

  ProcessMeshPlots();

  /* Process variance reduction stuff */

  ProcessVR();

  /* Process materials */

  ProcessMaterials();

  /* Link reactions to sources and detectors */

  LinkReactions();

  /* Check if calculation should proceed */

  if (((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_TRANSPORT) ||
      ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_EXT_BURN) ||
      ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_INT_BURN))
    {
      /* Reset parallel timer */

      ResetTimer(TIMER_OMP_PARA);

      /* Stop init timer */
      
      StopTimer(TIMER_INIT);
      
      /* Check mode and start calculation */
      
      if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_INT_BURN)
	{
	  /* Internal burnup mode, go to burnup cycle */
	  
	  BurnupCycle();
	}
      else
	{
	  /* Single transport cycle */
	  
	  PrepareTransportCycle();
	  TransportCycle();
	}
    }

  /* Free memory */
      
  FreeMem();

  /* Finalize MPI */

  FinalizeMPI();
  
  /* Exit */
  
  return 0;
}

/*****************************************************************************/

