/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : printcoredistr.c                               */
/*                                                                           */
/* Created:       2011/05/15 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Prints core power distribution                               */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "PrintCoreDistr:"

/*****************************************************************************/

void PrintCoreDistr()
{
  long ptr, n0, n1, n2, m0, m1, m2, m5, m10, N, i;
  double val, err, prof[101], cum[101];
  char outfile[MAX_STR];
  FILE *fp;

  /* Check that distribution is called */
  
  if (RDB[DATA_CORE_PDE_DEPTH] < 1.0)  
    return;

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* Check corrector step */

  if ((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP) 
    return;
  
  /* Set file name */

  sprintf(outfile, "%s_core%ld.m", GetText(DATA_PTR_INPUT_FNAME),
	  (long)RDB[DATA_BURN_STEP]);
	  
  /* Open file */
  
  if ((fp = fopen(outfile, "w")) == NULL)
    Die(FUNCTION_NAME, "Unable to open file for writing");

  /***************************************************************************/

  /***** Core level **********************************************************/

  if ((ptr = (long)RDB[DATA_CORE_PDE_PTR_RES0]) > VALID_PTR)
    {
      /* Reset counters */

      m0 = 0;
      m1 = 0;
      m2 = 0;
      m5 = 0;
      m10 = 0;
      
      for (i = 0; i < 100; i++)
	{
	  prof[i] = 0.0;
	  cum[i] = 0.0;
	}

      /* Print */

      fprintf(fp, "ass = [\n");

      for (n0 = 0; n0 < (long)RDB[DATA_CORE_PDE_N0]; n0++)
	{
	  val = Mean(ptr, n0);
	  err = RelErr(ptr, n0);
	  N = StatN(ptr, n0);

	  if ((val > 0.0) && (err > 0.0) && (err < 1.0))
	    {
	      fprintf(fp, " %3ld %1.5E %8.5f %ld %% a\n", n0 + 1, val, err, N);

	      m0++;

	      /* Compare limits */

	      if (err < 0.01)
		m1++;
	      if (err < 0.02)
		m2++;
	      if (err < 0.05)
		m5++;
	      if (err < 0.10)
		m10++;
	      
	      /* Add to profile */
	      
	      if (err < 0.2)
		prof[(long)(err*500.0)]++;
	    }
	}

      fprintf(fp, "];\n");
      fprintf(fp, "\nan = [ %ld %ld %ld %ld %ld %ld ];\n", 
	      (long)RDB[DATA_CORE_PDE_N0], m0, m1, m2, m5, m10);
      fprintf(fp, "af = [ %1.5f %1.5f %1.5f %1.5f ];\n", 
	      ((double)m1)/((double)m0), ((double)m2)/((double)m0),
	      ((double)m5)/((double)m0), ((double)m10)/((double)m0));
      
      if (m0 > 0)
	{
	  fprintf(fp, "profa = [ ");
	  
	  for (i = 0; i < 100; i++)
	    {
	      fprintf(fp, "%1.5E ", prof[i]/m0);
	      
	      if (i == 0)
		cum[i] = prof[i]/m0;
	      else
		cum[i] = cum[i - 1] + prof[i]/m0;
	    }
	  
	  fprintf(fp, "];\n");
	  
	  fprintf(fp, "cuma = [ ");
	  
	  for (i = 0; i < 100; i++)
	    fprintf(fp, "%1.5E ", cum[i]);
	  
	  fprintf(fp, "];\n");
	}
    }

  /***************************************************************************/

  /***** Pin level ***********************************************************/

  if ((ptr = (long)RDB[DATA_CORE_PDE_PTR_RES1]) > VALID_PTR)
    {
      /* Reset counters */

      m0 = 0;
      m1 = 0;
      m2 = 0;
      m5 = 0;
      m10 = 0;

      for (i = 0; i < 100; i++)
	{
	  prof[i] = 0.0;
	  cum[i] = 0.0;
	}
      
      /* Print */
      
      fprintf(fp, "\npin = [\n");
      
      for (n0 = 0; n0 < (long)RDB[DATA_CORE_PDE_N0]; n0++)
	for (n1 = 0; n1 < (long)RDB[DATA_CORE_PDE_N1]; n1++)
	  {
	    val = Mean(ptr, n0, n1);
	    err = RelErr(ptr, n0, n1);
	    N = StatN(ptr, n0, n1);

	    if ((val > 0.0) && (err > 0.0) && (err < 1.0))
	      {
		fprintf(fp, " %3ld %3ld %1.5E %8.5f %ld %% p\n", n0 + 1, 
			n1 + 1, val, err, N);

		m0++;
		
		/* Compare limits */
		
		if (err < 0.01)
		  m1++;
		if (err < 0.02)
		  m2++;
		if (err < 0.05)
		  m5++;
		if (err < 0.10)
		  m10++;

		/* Add to profile */
	      
		if (err < 0.2)
		  prof[(long)(err*500.0)]++;
	      }
	  }

      fprintf(fp, "];\n");
      fprintf(fp, "\npn = [ %ld %ld %ld %ld %ld %ld ];\n", 
	      (long)(RDB[DATA_CORE_PDE_N0]*RDB[DATA_CORE_PDE_N1]), 
	      m0, m1, m2, m5, m10);
      fprintf(fp, "pf = [ %1.5f %1.5f %1.5f %1.5f ];\n", 
	      ((double)m1)/((double)m0), ((double)m2)/((double)m0),
	      ((double)m5)/((double)m0), ((double)m10)/((double)m0));
     
      if (m0 > 0)
	{
	  fprintf(fp, "profp = [ ");
	  
	  for (i = 0; i < 100; i++)
	    {
	      fprintf(fp, "%1.5E ", prof[i]/m0);
	      
	      if (i == 0)
		cum[i] = prof[i]/m0;
	      else
		cum[i] = cum[i - 1] + prof[i]/m0;
	    }
	  
	  fprintf(fp, "];\n");
	  
	  fprintf(fp, "cump = [ ");
	  
	  for (i = 0; i < 100; i++)
	    fprintf(fp, "%1.5E ", cum[i]);
	  
	  fprintf(fp, "];\n");
	}
    }

  /***************************************************************************/

  /***** Region level ********************************************************/
    
  if ((ptr = (long)RDB[DATA_CORE_PDE_PTR_RES2]) > VALID_PTR)
    {
      /* Reset counters */

      m0 = 0;
      m1 = 0;
      m2 = 0;
      m5 = 0;
      m10 = 0;

      for (i = 0; i < 100; i++)
	{
	  prof[i] = 0.0;
	  cum[i] = 0.0;
	}
      
      /* Print */

      fprintf(fp, "\nreg = [\n");

      for (n0 = 0; n0 < (long)RDB[DATA_CORE_PDE_N0]; n0++)
	for (n1 = 0; n1 < (long)RDB[DATA_CORE_PDE_N1]; n1++)
	  for (n2 = 0; n2 < (long)RDB[DATA_CORE_PDE_N2]; n2++)
	    {
	      val = Mean(ptr, n0, n1, n2);
	      err = RelErr(ptr, n0, n1, n2);
	      N = StatN(ptr, n0, n1, n2);

	      if ((val > 0.0) && (err > 0.0) && (err < 1.0))
		{
		  fprintf(fp, " %3ld %3ld %3ld %1.5E %8.5f %ld %% r\n", n0 + 1, 
			  n1 + 1, n2 + 1, val, err, N);
		  
		  m0++;
		  
		  /* Compare limits */
		  
		  if (err < 0.01)
		    m1++;
		  if (err < 0.02)
		    m2++;
		  if (err < 0.05)
		    m5++;
		  if (err < 0.10)
		    m10++;

		  /* Add to profile */
	      
		  if (err < 0.2)
		    prof[(long)(err*500.0)]++;
		}
	    }

      fprintf(fp, "];\n");
      fprintf(fp, "\nrn = [ %ld %ld %ld %ld %ld %ld ];\n", 
	      (long)(RDB[DATA_CORE_PDE_N0]*RDB[DATA_CORE_PDE_N1]
		     *RDB[DATA_CORE_PDE_N2]), m0, m1, m2, m5, m10);
      fprintf(fp, "rf = [ %1.5f %1.5f %1.5f %1.5f ];\n", 
	      ((double)m1)/((double)m0), ((double)m2)/((double)m0),
	      ((double)m5)/((double)m0), ((double)m10)/((double)m0));

      if (m0 > 0)
	{
	  fprintf(fp, "profr = [ ");
	  
	  for (i = 0; i < 100; i++)
	    {
	      fprintf(fp, "%1.5E ", prof[i]/m0);
	      
	      if (i == 0)
		cum[i] = prof[i]/m0;
	      else
		cum[i] = cum[i - 1] + prof[i]/m0;
	    }
	  
	  fprintf(fp, "];\n");
	  
	  fprintf(fp, "cumr = [ ");
	  
	  for (i = 0; i < 100; i++)
	    fprintf(fp, "%1.5E ", cum[i]);
	  
	  fprintf(fp, "];\n");
	}
    }
  
  /***************************************************************************/

  /* Close file */

  fclose(fp);

  /***************************************************************************/
}

/*****************************************************************************/
