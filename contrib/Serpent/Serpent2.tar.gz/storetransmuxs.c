/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : storetransmuxs.c                               */
/*                                                                           */
/* Created:       2011/06/08 (AIs)                                           */
/* Last modified: 2012/01/27 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Stores the one-group cross-sections and flux written by      */
/*              ClaculateTransmuXS to REACTION_PTR_TRANSMUXS to              */
/*              DEP_TRA_PS1/BOS/EOS and moves BOS to PS1 when needed         */
/*                                                                           */
/* Comments: This should maybe be part of CalculateTransmuXS                 */
/*           parempi että pidetään erillisenä aliohjelmana niin on selkeämpi */
/*           (JLe)                                                           */
/*                                                                           */
/* input: mat = pointer to material for which to store the values            */
/*        step = #step in this intervall                                     */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "StoreTransmuXS:"

/*****************************************************************************/

void StoreTransmuXS(long mat, long step, long id)
{
  long dep, ptr, rea;
  double flx, xs;

  /* Check material pointer */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /* Check burnup mode and burn flag */

  if (((long)RDB[DATA_RUNNING_MODE] != RUNNING_MODE_INT_BURN) ||
      (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)))
    return;

  /* Check decay only mode */

  if ((long)RDB[DATA_BURN_DECAY_CALC] == YES)
    return;

  /* Avoid compiler warning */

  flx = -INFTY;
 
  /* Get flux */

  if (RDB[mat + MATERIAL_VOLUME] > 0.0)
    {
      ptr = (long)RDB[mat + MATERIAL_PTR_BURN_FLUX];
      flx = Mean(ptr, 0)/RDB[mat + MATERIAL_VOLUME];
    }
  else
    Die(FUNCTION_NAME, "Zero volume (%s)", GetText(mat + MATERIAL_PTR_NAME));

  /* Check value */

  CheckValue(FUNCTION_NAME, "flx", "", flx, 0.0, INFTY);

  /* store value */

  if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
    {
      /* Predictor */

      if (step == 0)
        WDB[mat + MATERIAL_BURN_FLUX_PS1] = -INFTY; 
      else
        WDB[mat + MATERIAL_BURN_FLUX_PS1] = RDB[mat + MATERIAL_BURN_FLUX_BOS];
      
      WDB[mat + MATERIAL_BURN_FLUX_BOS] = flx;
      WDB[mat + MATERIAL_BURN_FLUX_EOS] = -INFTY; 
    }
  else
    {
      /* Corrector */

      WDB[mat + MATERIAL_BURN_FLUX_EOS] = flx;
    }

  /**************************************************************************/

  /***** Transmutation list *************************************************/

  /* Pointer to transmutation list */
  
  dep = (long)RDB[mat + MATERIAL_PTR_DEP_TRA_LIST];
  CheckPointer(FUNCTION_NAME, "(dep)", DATA_ARRAY, dep);

  /* Loop over list */

  while (dep > VALID_PTR)
    {
      /* Get the reaction and its XS */

      rea = (long)RDB[dep + DEP_TRA_PTR_REA];
      xs = TestValuePair(rea + REACTION_PTR_TRANSMUXS, mat, id);

      if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
        {
          /* Predictor */

          if (step == 0)
            WDB[dep + DEP_TRA_PS1] = -INFTY; 
          else
            WDB[dep + DEP_TRA_PS1] = RDB[dep + DEP_TRA_BOS];

          WDB[dep + DEP_TRA_BOS] = xs;
          WDB[dep + DEP_TRA_EOS] = -INFTY; 
        }
      else
        {
          /* Corrector */

          WDB[dep + DEP_TRA_EOS] = xs;
        }

      /* Next reaction */

      dep = NextItem(dep);
    }

  /**************************************************************************/

  /***** Fission list *******************************************************/

  /* Pointer to fission list (pointteri voi olla null jos materiaali */
  /* on ei-fissiili) */

  dep = (long)RDB[mat + MATERIAL_PTR_DEP_FISS_LIST];
  
  /* Loop over list */

  while (dep > VALID_PTR)
    {
       /* Get the reaction and its XS */

      rea = (long)RDB[dep + DEP_TRA_PTR_REA];
      xs = TestValuePair(rea + REACTION_PTR_TRANSMUXS, mat, id);

      if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
        {
          /* Predictor */

          if (step == 0)
            WDB[dep + DEP_TRA_PS1] = -INFTY;
          else
            WDB[dep + DEP_TRA_PS1] = RDB[dep + DEP_TRA_BOS];

          WDB[dep + DEP_TRA_BOS] = xs;
          WDB[dep + DEP_TRA_EOS] = -INFTY;
        }
      else
        {
          /* Corrector */

          WDB[dep + DEP_TRA_EOS] = xs;
        }

      /* Next reaction */

      dep = NextItem(dep);
    }

  /**************************************************************************/
}

/*****************************************************************************/
