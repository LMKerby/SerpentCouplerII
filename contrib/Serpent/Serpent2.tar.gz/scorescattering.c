/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : scorescattering.c                              */
/*                                                                           */
/* Created:       2011/03/03 (JLe)                                           */
/* Last modified: 2011/11/20 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Scores parameters related to scattering reactions            */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ScoreScattering:"

/*****************************************************************************/

void ScoreScattering(long mat, long rea, double mu, double E0, double E1, 
		     double wgt, long id)
{
  long gcu, ptr, ntot, ng0, ng1, mt, ncol;
  double mult, P0, P1, P2, P3, P4, P5;

  /* Check weight and mu (toi mu lasketaan suuntavektoreiden skalaari- */
  /* tulona, ja se voi numeriikasta johtuen poiketa ykkösestä, vaikka  */
  /* se tarkastetaankin kaikissa sämpläysrutiineissa. */

  CheckValue(FUNCTION_NAME, "wgt", "", wgt, 0.0, 1E+6);
  CheckValue(FUNCTION_NAME, "mu", "", mu, -1.000001, 1.000001);
  
  /* Get multiplier */

  mult = RDB[rea + REACTION_WGT_F];
  CheckValue(FUNCTION_NAME, "mult", "", mult, 1.0, 4.0);
  
  /***************************************************************************/

  /***** Analog reaction rates ***********************************************/

  /* Check modes */

  if ((long)RDB[DATA_OPTI_IMPLICIT_RR] == NO)
    {
      /* Total reaction rate */

      ptr = (long)RDB[RES_TOT_RR];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(1.0, wgt, ptr, id, 0);

      /* Get mt */

      mt = (long)RDB[rea + REACTION_MT];

      /* Score elastic or inelastic scattering */

      if ((mt == 2) || (mt == 1002) || (mt == 1004))
	{
	  ptr = (long)RDB[RES_TOT_ELARATE];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(1.0, wgt, ptr, id, 0);
	}
      else
	{
	  ptr = (long)RDB[RES_TOT_N2NRATE];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(mult, wgt, ptr, id, 0);
	}

      /* Exit subroutine */

      return;
    }

  /***************************************************************************/

  /***** Check if data is required *******************************************/

  /* Check active cycle and corrector step */

  if ((RDB[DATA_CYCLE_IDX] < RDB[DATA_SKIP]) ||
      ((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP))
    return;

  /* Check that group constants are calculated */

  if ((long)RDB[DATA_OPTI_GC_CALC] == NO)
    return;

  /* Get collision number */

  ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
  ncol = (long)GetPrivateData(ptr, id);

  /* Get universe pointer */
  
  if ((gcu = TestValuePair(DATA_GCU_PTR_UNI, ncol, id)) < VALID_PTR)
    return;

  /***************************************************************************/

  /***** Scattering matrix ***************************************************/

  /* Number of groups */

  ntot = (long)RDB[DATA_ERG_FG_NG];

  /* Get pointer to few-group structure */
  
  ptr = (long)RDB[DATA_ERG_FG_PTR_GRID];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Get few-group indexes (E0 --> E1) */
  
  ng0 = GridSearch(ptr, E0);
  ng1 = GridSearch(ptr, E1);

  /* Score scattering rate */

  if ((ng0 > -1) && (ng1 > -1))
    {
      /* Check indexes */

      CheckValue(FUNCTION_NAME, "ng0", "", ng0, 0, ntot - 1);
      CheckValue(FUNCTION_NAME, "ng1", "", ng1, 0, ntot - 1);

      ptr = (long)RDB[gcu + GCU_RES_FG_GTRANSXS];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(mult, wgt, ptr, id, -1, ntot - ng1 - 1, ntot - ng0 - 1);
    }

  /***************************************************************************/

  /***** PN scattering cross sections ****************************************/

  /* Check energy group */

  if (ng0 > -1)
    {
      /* Check indexe */

      CheckValue(FUNCTION_NAME, "ng0", "", ng0, 0, ntot - 1);

      /* Legendre polynomial coefficients */

      P0 = 1.0;
      P1 = mu;
      P2 = 0.5*(3.0*mu*mu - 1.0);
      P3 = 0.5*(5.0*mu*mu*mu - 3.0*mu);
      P4 = (35.0*mu*mu*mu*mu - 30.0*mu*mu + 3)/8.0;
      P5 = (63.0*mu*mu*mu*mu*mu - 70.0*mu*mu*mu + 15*mu)/8.0;

      /* Score reaction rates */

      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT0];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(P0, wgt, ptr, id, ntot - ng0);
      AddBuf(P0, wgt, ptr, id, 0);

      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT1];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(P1, wgt, ptr, id, ntot - ng0);
      AddBuf(P1, wgt, ptr, id, 0);

      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT2];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(P2, wgt, ptr, id, ntot - ng0);
      AddBuf(P2, wgt, ptr, id, 0);

      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT3];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(P3, wgt, ptr, id, ntot - ng0);
      AddBuf(P3, wgt, ptr, id, 0);

      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT4];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(P4, wgt, ptr, id, ntot - ng0);
      AddBuf(P4, wgt, ptr, id, 0);

      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT5];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      AddBuf(P5, wgt, ptr, id, ntot - ng0);
      AddBuf(P5, wgt, ptr, id, 0);
    }

  /***************************************************************************/

  /***** Critical spectrum ***************************************************/

  /* Check flag */
  
  if ((long)RDB[DATA_OPTI_FUM_CALC] == NO)
    return; 
  
  /* Get pointer to energy grid */
  
  ptr = (long)RDB[DATA_FUM_PTR_EGRID];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);	

  /* Number of groups */

  ntot = (long)RDB[ptr + ENERGY_GRID_NE] - 1;

  /* Get micro-group indexes (E0 --> E1) */
  
  ng0 = GridSearch(ptr, E0);
  ng1 = GridSearch(ptr, E1);

  /* Check incident group */
  
  if (ng0 < 0)
    return;
  else
    ng0 = ntot - ng0 - 1;

  /* Check index */

  CheckValue(FUNCTION_NAME, "ng0", "", ng0, 0, ntot - 1);

  /* Average scattering cosine */

  ptr = RDB[gcu + GCU_FUM_PTR_MUBAR];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng0, mu*wgt, id);
  
  /* Check emitted group */

  if (ng1 < 0)
    return;
  else
    ng1 = ntot - ng1 - 1;

  /* Check index */

  CheckValue(FUNCTION_NAME, "ng1", "", ng1, 0, ntot - 1);

  /* Scattering matrix */

  ptr = RDB[gcu + GCU_FUM_PTR_SCATT_MTX];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng0*ntot + ng1, mult*wgt, id);

  /***************************************************************************/
}

/*****************************************************************************/
