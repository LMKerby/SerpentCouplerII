/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : gridsearch.c                                   */
/*                                                                           */
/* Created:       2010/12/09 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Finds energy interval from grid structure                    */
/*                                                                           */
/* Comments: - Yläraja otetaan väkisin mukaan vaikka sen pitäisi             */
/*             periaatteessa olla ulkopuolella.                              */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "GridSearch:"

/*****************************************************************************/

long GridSearch(long erg, double E)
{
  double Emin, Emax, Emid, logE;
  long ptr, ne, idx, i0, nb;

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);
  
  /* Get minimum and maximum energy */

  Emin = RDB[erg + ENERGY_GRID_EMIN];
  Emax = RDB[erg + ENERGY_GRID_EMAX];

  /* Compare to limits */

  if ((E < Emin) || (E > Emax))
    return -1;
    
  /***************************************************************************/

  /***** Sub-intervals *******************************************************/
  
  /* Take log of E */

  logE = log(E);
  
  /* Get number of bins */
  
  while ((nb = (long)RDB[erg + ENERGY_GRID_NB]) > 0)
    {
      if (RDB[erg + ENERGY_GRID_EMID] > 0.0)
	Die(FUNCTION_NAME, "Mid energy with bins");

      /* Check grid type */

      if ((long)RDB[erg + ENERGY_GRID_TYPE] == GRID_TYPE_LOG)
	{
	  /* Get log of minimum and maximum energy */
	  
	  Emin = RDB[erg + ENERGY_GRID_LOG_EMIN];
	  Emax = RDB[erg + ENERGY_GRID_LOG_EMAX];
	  
	  /* Check energy */
	  
	  CheckValue(FUNCTION_NAME, "logE", "", logE, Emin, Emax);
	  
	  /* Calculate bin index */
	  
	  idx = (long)((double)nb*(logE - Emin)/(Emax - Emin));
	}
      else
	{
	  /* Get minimum and maximum energy */
	  
	  Emin = RDB[erg + ENERGY_GRID_EMIN];
	  Emax = RDB[erg + ENERGY_GRID_EMAX];
	  
	  /* Check energy */
	  
	  CheckValue(FUNCTION_NAME, "logE", "", E, Emin, Emax);
	  
	  /* Calculate bin index */
	  
	  idx = (long)((double)nb*(E - Emin)/(Emax - Emin));
	}

      /* Check value */

      CheckValue(FUNCTION_NAME, "idx1", "", idx, -1, nb);

      /* Log-function may cause numerical problems */
      
      if (idx < 0)
	idx = 0;
      else if (idx > nb - 1)
	idx = nb - 1;

      /* Pointer to bins */
      
      ptr = (long)RDB[erg + ENERGY_GRID_PTR_BINS];
      
      /* Check pointer */

      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);      
      
      /* pointer to grid */
      
      erg = (long)RDB[ptr + idx];
      
      /* Check pointer */

      CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);      
    }
  
  /***************************************************************************/

  /***** Binary-tree search **************************************************/
      
  while ((Emid = RDB[erg + ENERGY_GRID_EMID]) > 0.0)
    {
      if (E < Emid)
	erg = (long)RDB[erg + ENERGY_GRID_PTR_LOW];
      else
	erg = (long)RDB[erg + ENERGY_GRID_PTR_HIGH];
      
      /* Check pointer */
      
      CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);
    }
  
  /***************************************************************************/

  /***** Find index in interval **********************************************/

  /* Check limits */

  CheckValue(FUNCTION_NAME, "E", "", E, RDB[erg + ENERGY_GRID_EMIN],
	     RDB[erg + ENERGY_GRID_EMAX]);
  
  /* Get number of points */
  
  ne = (long)RDB[erg + ENERGY_GRID_NE];

  /* Check value */

  CheckValue(FUNCTION_NAME, "ne", "", ne, 2, MAX_EGRID_NE);

  /* Get pointer to data */

  ptr = (long)RDB[erg + ENERGY_GRID_PTR_DATA];

  /* Check pointer */
  
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Get index to beginning */

  i0 = (long)RDB[erg + ENERGY_GRID_I0];

  /* Check value */

  CheckValue(FUNCTION_NAME, "i0", "", i0, 0, MAX_EGRID_NE - 2);

  /* Add value to pointer */

  ptr = ptr + i0;

  /* Find interval */

  if ((idx = SearchArray(&RDB[ptr], E, ne)) < 0)
    return -1;
        
  /* Check */

#ifdef DEBUG

  if (idx > ne - 2)
    Die(FUNCTION_NAME, "Search error 1");
  else if ((E < RDB[ptr + idx]) || (E >= RDB[ptr + idx + 1]))
    Die(FUNCTION_NAME, "Search error 2 %ld %ld (%E %E %E %E)", idx, ne, 
	RDB[ptr + idx], E, RDB[ptr + idx + 1], RDB[ptr + idx + 2]);
  
#endif

  /* Return index to grid */
  
  return i0 + idx;

  /***************************************************************************/
}

/*****************************************************************************/
