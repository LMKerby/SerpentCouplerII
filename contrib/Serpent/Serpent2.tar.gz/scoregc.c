/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : scoregc.c                                      */
/*                                                                           */
/* Created:       2011/05/04 (JLe)                                           */
/* Last modified: 2011/11/20 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Scores reaction rates needed for group constant generation   */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ScoreGC:"

/*****************************************************************************/

void ScoreGC(double flx, long mat, double E, double wgt, long id)
{
  long rea, gcu, ptr, ng, ntot, ncol;
  double spd, tot, capt, fiss, val;
  
  /* Check that group constants are calculated */

  if ((long)RDB[DATA_OPTI_GC_CALC] == NO)
    return;

  /* Get collision number */

  ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
  ncol = (long)GetPrivateData(ptr, id);

  /* Get universe pointer */

  if ((gcu = TestValuePair(DATA_GCU_PTR_UNI, ncol, id)) < VALID_PTR)
    return;

  /***************************************************************************/

  /***** Infinite spectrum ***************************************************/

  /* Number of groups */

  ntot = (long)RDB[DATA_ERG_FG_NG];

  /* Get pointer to few-group structure */
  
  ptr = (long)RDB[DATA_ERG_FG_PTR_GRID];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Get few-group index */

  if ((ng = GridSearch(ptr, E)) < 0)
    return;
  else
    ng = ntot - ng;

  /* Check index */

  CheckValue(FUNCTION_NAME, "ng1", "", ng, 0, ntot);

  /* Reset values */

  tot = 0.0;
  capt = 0.0;
  fiss = 0.0;

  /* Flux */
  
  ptr = (long)RDB[gcu + GCU_RES_FG_FLX];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddBuf(flx, wgt, ptr, id, ng);
  AddBuf(flx, wgt, ptr, id, 0);
  
  /* Calculate neutron speed */
  
  if (E  < 0.1)
    spd = sqrt(ETOV2*E);
  else
    spd = SPD_C*sqrt(1.0 - 1.0/((E/NEUTRON_E0 + 1.0)*(E/NEUTRON_E0 + 1.0)));
      
  /* 1/v */
  
  ptr = (long)RDB[gcu + GCU_RES_FG_RECIPVEL];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  AddBuf(flx/spd, wgt, ptr, id, ng);
  AddBuf(flx/spd, wgt, ptr, id, 0);
  
  /* Check material pointer (cannot exit here because flux is also scored */
  /* for B1 fundamental mode calculation). */

  if (mat > VALID_PTR)
    {  
      /* Total reaction rate */
      
      if ((rea = (long)RDB[mat + MATERIAL_PTR_TOTXS]) > VALID_PTR)
	{
	  tot = MacroXS(rea, E, id)*flx;
	  
	  ptr = (long)RDB[gcu + GCU_RES_FG_TOTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(tot, wgt, ptr, id, ng);
	  AddBuf(tot, wgt, ptr, id, 0);
	}

      /* Capture rate */
      
      if ((rea = (long)RDB[mat + MATERIAL_PTR_ABSXS]) > VALID_PTR)
	{
	  capt = MacroXS(rea, E, id)*flx;
	  
	  ptr = (long)RDB[gcu + GCU_RES_FG_CAPTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(capt, wgt, ptr, id, ng);
	  AddBuf(capt, wgt, ptr, id, 0);
	}
      
      /* Fission rate */
      
      if ((rea = (long)RDB[mat + MATERIAL_PTR_FISSXS]) > VALID_PTR)
	{
	  fiss = MacroXS(rea, E, id)*flx;
	  
	  ptr = (long)RDB[gcu + GCU_RES_FG_FISSXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(fiss, wgt, ptr, id, ng);
	  AddBuf(fiss, wgt, ptr, id, 0);
	}
      
      /* Elastic rate */
      
      if ((rea = (long)RDB[mat + MATERIAL_PTR_ELAXS]) > VALID_PTR)
	{
	  val = MacroXS(rea, E, id)*flx;
	  
	  ptr = (long)RDB[gcu + GCU_RES_FG_ELAXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(val, wgt, ptr, id, ng);
	  AddBuf(val, wgt, ptr, id, 0);
	}
      
      /* Scattering multiplication rate */
      
      if ((rea = (long)RDB[mat + MATERIAL_PTR_NUXNXS]) > VALID_PTR)
	{
	  val = MacroXS(rea, E, id)*flx;
	  
	  ptr = (long)RDB[gcu + GCU_RES_FG_N2NXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(val, wgt, ptr, id, ng);
	  AddBuf(val, wgt, ptr, id, 0);
	}
    }

  /***************************************************************************/

  /***** Critical spectrum ***************************************************/

  /* Check flag */
  
  if ((long)RDB[DATA_OPTI_FUM_CALC] == NO)
    return; 
  
  /* Get pointer to energy grid */
  
  ptr = (long)RDB[DATA_FUM_PTR_EGRID];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);	
  
  /* Number of groups */

  ntot = (long)RDB[ptr + ENERGY_GRID_NE] - 1;
  
  /* Get group index */

  if ((ng = GridSearch(ptr, E)) < 0)
    return;
  else
    ng = ntot - ng - 1;

  /* Check index */

  CheckValue(FUNCTION_NAME, "ng2", "", ng, 0, ntot - 1);

  /* Put values */

  ptr = RDB[gcu + GCU_FUM_PTR_FLX];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng, wgt*flx, id);

  ptr = RDB[gcu + GCU_FUM_PTR_TOT];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng, wgt*tot, id);

  ptr = RDB[gcu + GCU_FUM_PTR_ABS];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng, wgt*(capt + fiss), id);

  ptr = RDB[gcu + GCU_FUM_PTR_FISS];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr + ng, wgt*fiss, id);

  /***************************************************************************/
}

/*****************************************************************************/
