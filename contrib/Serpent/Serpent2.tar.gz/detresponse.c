/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : detresponse.c                                  */
/*                                                                           */
/* Created:       2011/07/08 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates value for detector response function              */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "DetResponse:"

/*****************************************************************************/

double DetResponse(long loc0, long mat, double E, long id)
{
  long mt, rea;
  double f;

  /* Get mt and pointer to reaction */

  mt = (long)RDB[loc0 + DET_RBIN_MT];
  rea = (long)RDB[loc0 + DET_RBIN_PTR_REA];
  
  /* Check type and get response */
  
  if (mt == 0)
    f = 1.0;
  else if (mt < 0)
    {
      /* Check reaction pointer */
      
      if (rea < VALID_PTR)
	{
	  /* Use material at collision point */
	  
	  if (mat < VALID_PTR)
	    rea = -1;
	  else if (mt == -1)
	    rea = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	  else if (mt == -2)
	    rea = (long)RDB[mat + MATERIAL_PTR_ABSXS];
	  else if (mt == -3)
	    rea = (long)RDB[mat + MATERIAL_PTR_ELAXS];
	  else if (mt == -5)
	    rea = (long)RDB[mat + MATERIAL_PTR_NUXNXS];
	  else if (mt == -6)
	    rea = (long)RDB[mat + MATERIAL_PTR_FISSXS];
	  else if (mt == -7)
	    rea = -1;
	  else
	    Die(FUNCTION_NAME, "Invalid mt %ld", mt);
	}
      
      /* Get cross section */
      
      if (rea > VALID_PTR)
	f = MacroXS(rea, E, id);
      else
	f = 0.0;
    }
  else
    {
      /* Check reaction pointer */
      
      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
      
      /* Get cross section */
      
      f = MicroXS(rea, E, id);
    }
  
  /* Return value */

  return f;
}

/*****************************************************************************/
