/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : setoptimization.c                              */
/*                                                                           */
/* Created:       2011/07/17 (JLe)                                           */
/* Last modified: 2012/01/26 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: - Set various options based on optimization                  */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "SetOptimization:"

/*****************************************************************************/

void SetOptimization()
{
  /* Include total list in mode 0 */

  WDB[DATA_OPTI_MODE0_INCLUDE_TOTAL] = 1.0;

  /* Set on-the-fly Doppler-broadening mode if TFB is in use */

  if ((long)RDB[DATA_USE_TFB] == YES)
    WDB[DATA_DOPPLER_MODE] = DOPPLER_MODE_ONTHEFLY;

  /* Switch to optimization mode max 2 if on-the-fly mode */

  if (((long)RDB[DATA_DOPPLER_MODE] == DOPPLER_MODE_ONTHEFLY) &&
      ((long)RDB[DATA_OPTI_MODE] > 2))
    WDB[DATA_OPTI_MODE] = 2.0;

  /* Check optimization mode */

  switch ((long)RDB[DATA_OPTI_MODE])
    {
    case 0:
      {
	WDB[DATA_OPTI_MACRO_REA_LISTS] = (double)NO;
	WDB[DATA_OPTI_RECONSTRUCT_MICROXS] = (double)NO;
	WDB[DATA_OPTI_RECONSTRUCT_MACROXS] = (double)NO;
	WDB[DATA_OPTI_IMPLICIT_RR] = (double)NO;
	WDB[DATA_OPTI_GC_CALC] = (double)NO;

	if ((long)RDB[DATA_OPTI_MG_MODE] < 0)
	  WDB[DATA_OPTI_MG_MODE] = (double)NO;

	if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] < 0)
	  WDB[DATA_BU_SPECTRUM_COLLAPSE] = (double)NO;

	break;
      }
    case 1:
      {
	WDB[DATA_OPTI_MACRO_REA_LISTS] = (double)YES;
	WDB[DATA_OPTI_RECONSTRUCT_MICROXS] = (double)NO;
	WDB[DATA_OPTI_RECONSTRUCT_MACROXS] = (double)NO;
	WDB[DATA_OPTI_IMPLICIT_RR] = (double)NO;
	WDB[DATA_OPTI_GC_CALC] = (double)NO;

	if ((long)RDB[DATA_OPTI_MG_MODE] < 0)
	  WDB[DATA_OPTI_MG_MODE] = (double)NO;	

	if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] < 0)
	  WDB[DATA_BU_SPECTRUM_COLLAPSE] = (double)NO;

	break;
      }
    case 2:
      {
	WDB[DATA_OPTI_MACRO_REA_LISTS] = (double)YES;
	WDB[DATA_OPTI_RECONSTRUCT_MICROXS] = (double)YES;
	WDB[DATA_OPTI_RECONSTRUCT_MACROXS] = (double)NO;
	WDB[DATA_OPTI_IMPLICIT_RR] = (double)NO;
	WDB[DATA_OPTI_GC_CALC] = (double)NO;

	if ((long)RDB[DATA_OPTI_MG_MODE] < 0)
	  WDB[DATA_OPTI_MG_MODE] = (double)YES;	

	if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] < 0)
	  WDB[DATA_BU_SPECTRUM_COLLAPSE] = (double)YES;

	break;
      }
    case 3:
      {
	WDB[DATA_OPTI_MACRO_REA_LISTS] = (double)YES;
	WDB[DATA_OPTI_RECONSTRUCT_MICROXS] = (double)NO;
	WDB[DATA_OPTI_RECONSTRUCT_MACROXS] = (double)YES;
	WDB[DATA_OPTI_IMPLICIT_RR] = (double)YES;
	WDB[DATA_OPTI_GC_CALC] = (double)YES;

	if ((long)RDB[DATA_OPTI_MG_MODE] < 0)
	  WDB[DATA_OPTI_MG_MODE] = (double)NO;	

	if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] < 0)
	  WDB[DATA_BU_SPECTRUM_COLLAPSE] = (double)YES;
      
	break;
      }
    case 4:
      {
	WDB[DATA_OPTI_MACRO_REA_LISTS] = (double)YES;
	WDB[DATA_OPTI_RECONSTRUCT_MICROXS] = (double)YES;
	WDB[DATA_OPTI_RECONSTRUCT_MACROXS] = (double)YES;
	WDB[DATA_OPTI_IMPLICIT_RR] = (double)YES;
	WDB[DATA_OPTI_GC_CALC] = (double)YES;

	if ((long)RDB[DATA_OPTI_MG_MODE] < 0)
	  WDB[DATA_OPTI_MG_MODE] = (double)NO;	

	if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] < 0)
	  WDB[DATA_BU_SPECTRUM_COLLAPSE] = (double)YES;
      
	break;
      }
    default:
      Error(0, "Invalid optimization mode %ld", (long)RDB[DATA_OPTI_MODE]);
    }
  
  /* Set unionization flag */

  if (((long)RDB[DATA_OPT_USE_DT] == YES) || 
      ((long)RDB[DATA_OPTI_RECONSTRUCT_MICROXS] == YES) ||
      ((long)RDB[DATA_OPTI_RECONSTRUCT_MACROXS] == YES))
    WDB[DATA_OPTI_UNIONIZE_GRID] = (double)YES;
  else
    WDB[DATA_OPTI_UNIONIZE_GRID] = (double)NO;

  /* Set group constant calculation on if universe is given and off if */
  /* set to null */

  if ((long)RDB[DATA_PTR_GCU0] > 0)
    WDB[DATA_OPTI_GC_CALC] = (double)YES;
  else if ((long)RDB[DATA_PTR_GCU0] < 0)
    WDB[DATA_OPTI_GC_CALC] = (double)NO;

  /* Use implicit reaction rates if group constants are generated */

  if ((long)RDB[DATA_OPTI_GC_CALC] == YES)
    WDB[DATA_OPTI_IMPLICIT_RR] = (double)YES;

  /* Check that group constant calculation is used with fum */
  
  if (((long)RDB[DATA_OPTI_GC_CALC] == NO) &&
      ((long)RDB[DATA_OPTI_FUM_CALC] == YES))
    Error(0, "Group constant calculation needed for B1 mode");

  /* Generate macroscopic reaction lists if implicit reaction rates are used */

  if ((long)RDB[DATA_OPTI_IMPLICIT_RR] == YES)
    WDB[DATA_OPTI_MACRO_REA_LISTS] = (double)YES;

  /* Set multi-group mode if on-the-fly mode is used */

  if ((long)RDB[DATA_DOPPLER_MODE] == DOPPLER_MODE_ONTHEFLY)
    WDB[DATA_OPTI_MG_MODE] = (double)YES;
  
  /* Switch DBRC off in on-the-fly mode */

  if ((long)RDB[DATA_DOPPLER_MODE] == DOPPLER_MODE_ONTHEFLY)
    WDB[DATA_USE_DBRC] = (double)NO;

  /* Set delayed nubar flag if not set in input */

  if ((long)RDB[DATA_USE_DELNU] == -1)
    {
      /* Check simulation mode */

      if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT)
	WDB[DATA_USE_DELNU] = (double)YES;
      else
	WDB[DATA_USE_DELNU] = (double)NO;
    }

  /* Reset replay option if no reproducibility */

  if ((long)RDB[DATA_OPTI_OMP_REPRODUCIBILITY] == NO)
    WDB[DATA_OPTI_REPLAY] = (double)NO;

  /* Disable grid thinning if problems */

  if (((long)RDB[DATA_OPTI_RECONSTRUCT_MACROXS] == NO) &&
      ((long)WDB[DATA_OPTI_MG_MODE] == NO))
    WDB[DATA_ERG_TOL] = 0.0;

  /* Disable shared results array if source biasing is in use */

  if ((long)RDB[DATA_SBIAS_MODE] > 0)
    WDB[DATA_OPTI_SHARED_RES2] = (double)NO;
}

/*****************************************************************************/
