/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : finduniversecell.c                             */
/*                                                                           */
/* Created:       2010/10/13 (JLe)                                           */
/* Last modified: 2012/02/01 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Find cell in universe                                        */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "FindUniverseCell:"

/*****************************************************************************/

long FindUniverseCell(long uni, double x, double y, double z, long id)
{
  long cell, ptr, found, loc0, loc1, loc2, n;

  /* Check universe pointer */

  CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

  /* Pointer to cell list */
	
  ptr = (long)RDB[uni + UNIVERSE_PTR_CELL_LIST];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);  

  /* Reset flag and cell pointer */

  found = NO;
  cell = GEOM_ERROR_NO_CELL;

  /* Loop over cells */
  
  n = 0;

  while ((loc0 = ListPtr(ptr, n++)) > 0)
    {
      /* Pointer to cell */

      loc1 = (long)RDB[loc0 + CELL_LIST_PTR_CELL];
      CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);

      /* Test cell */

      if (InCell(loc1, x, y, z, id) == YES)
	{
	  /* Check plotter mode */

	  if ((long)RDB[DATA_PLOTTER_MODE] == NO)
	    {
	      /* Pointer to counter */

	      loc2 = (long)RDB[loc0 + CELL_LIST_PTR_COUNT];
	      CheckPointer(FUNCTION_NAME, "(loc2)", PRIVA_ARRAY, loc2);

	      /* Add counter */

	      AddPrivateData(loc2, 1, id);
	      
	      /* Return cell pointer */

	      return loc1;
	    }
	  else if (found == YES)
	    {
	      /* Duplicate definition of geometry region */

	      return GEOM_ERROR_MULTIPLE_CELLS;
	    }
	  else
	    {
	      /* Put pointer */

	      cell = loc1;

	      /* Put found flag */

	      found = YES;
	    }
	}
    }

  /* Return cell pointer */

  return cell;
}

/*****************************************************************************/
