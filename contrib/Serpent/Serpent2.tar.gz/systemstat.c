/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : systemstat.c                                   */
/*                                                                           */
/* Created:       2011/05/06 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Reads some system data                                       */
/*                                                                           */
/* Comments: - From Serpent 1.1.9, the values are not really used for        */
/*             anything                                                      */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "SystemStat:"

/*****************************************************************************/

void SystemStat()
{
  double sz;
  char *dum1;
  long n, dum2;
  FILE *fp;
  char tmpstr[MAX_STR], unit[MAX_STR];

  /* Try to open /proc/cpuinfo for reading */

  if ((fp = fopen("/proc/cpuinfo", "r")) != NULL)
    {
      /* Skip first 4 lines */

      dum1 = fgets(tmpstr, 82, fp);
      dum1 = fgets(tmpstr, 82, fp);
      dum1 = fgets(tmpstr, 82, fp);
      dum1 = fgets(tmpstr, 82, fp);

      /* Get model name */

      dum1 = fgets(tmpstr, 82, fp);

      /* Find last character */

      for (n = strlen(tmpstr); n > 0; n--)
	if (isalnum(tmpstr[n]))
	  {
	    tmpstr[n + 1] = '\0';

	    break;
	  }

      /* Find first character */

      for (n = 0; n < (int)strlen(tmpstr); n++)
	if (tmpstr[n] == ':')
	  break;

      /* Store value */
      
      WDB[DATA_PTR_CPU_NAME] = (double)PutText(&tmpstr[n + 2]);

      /* Skip line */

      dum1 = fgets(tmpstr, 82, fp);

      /* Get MHZ */

      dum1 = fgets(tmpstr, 82, fp);

      /* Find first character */

      for (n = 0; n < (int)strlen(tmpstr); n++)
	if (tmpstr[n] == ':')
	  break;

      /* Store value */
      
      WDB[DATA_CPU_MHZ] = atof(&tmpstr[n + 2]);
      
      /* Close file */

      fclose(fp);
    }
  else
    WDB[DATA_PTR_CPU_NAME] = (double)PutText("Unknown");

  /* Try to open /proc/meminfo for reading */

  if ((fp = fopen("/proc/meminfo", "r")) != NULL)
    {
      /* Get total memory */

      dum2 = fscanf(fp, "%s %lf %s\n", tmpstr, &sz, unit);
      
      /* Check unit */

      if (!strcmp(unit, "kB"))
	WDB[DATA_CPU_MEM] = sz*KILO/GIGA;

      /* Close file */

      fclose(fp);
    }
}

/*****************************************************************************/
