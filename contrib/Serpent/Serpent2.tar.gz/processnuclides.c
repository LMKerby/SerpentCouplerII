/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processnuclides.c                              */
/*                                                                           */
/* Created:       2010/09/10 (JLe)                                           */
/* Last modified: 2012/01/27 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Selects which nuclides are included in the calculation,      */
/*              ace abd decat data, sets up decay / transmutation paths,     */
/*              constructs fission product lists, etc.                       */
/*                                                                           */
/* Comments: - TestDosFile pitää jotenkin ujuttaa opendatafileen             */
/*           - Termisen sironnan datasta luetaan pelkkä nimi (nuklidin vois  */
/*             lukea osuuteen?)                                              */
/*           - Toi OPT_BURN -juttu sotkee (optiota ei kopioida, ym)          */
/*           - External burnup moodi ei varmaan toimi                        */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessNuclides:"

/*****************************************************************************/

void ProcessNuclides()
{
  long mat, src, iso, ace, nuc, ptr, ZAI, new, n, mode, rea;
  static char lib[MAX_STR], name[MAX_STR];
  double T;

  /* Get material pointer */

  if ((mat = (long)RDB[DATA_PTR_M0]) < VALID_PTR)
    Error(0, "No material definitions");

  /* Sort materials by number of burnable zones to get burnable materials */
  /* at the beginning (this is needed to get all processing done). */

  SortList(mat, MATERIAL_BURN_RINGS, SORT_MODE_DESCEND);

  /* Read data from ACE directory files */

  ReadDirectoryFile();

  /* Read decay data from ENDF format file */

  ReadDecayFile();

  /* Check that nuclear data exists */

  if ((long)RDB[DATA_PTR_ACE0] < 1)
    Error(0, "Missing file path for transport and/or decay data");

  /* Add stable nuclides at the end */

  if ((long)RDB[DATA_RUNNING_MODE] != RUNNING_MODE_TRANSPORT)
    AddStableNuclides();

  /* Read fission yield data */

  if ((long)RDB[DATA_RUNNING_MODE] != RUNNING_MODE_TRANSPORT)
    ReadFissionYields();

  /* Read isomeric branching ratios */

  if ((long)RDB[DATA_RUNNING_MODE] != RUNNING_MODE_TRANSPORT)
    ReadIBRFile();

  /***************************************************************************/
 
  /***** Combine identical nuclides in composition ***************************/

  /* Loop over materials */

  mat = RDB[DATA_PTR_M0];	
  while (mat > VALID_PTR)
    {
      /* Loop over composition */

      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
      while (iso > VALID_PTR)
	{
	  /* Second loop */

	  ptr = NextItem(iso);	  
	  while (ptr > VALID_PTR)
	    {
	      /* Compare names */

	      if (CompareStr(iso + COMPOSITION_PTR_NUCLIDE, 
			     ptr + COMPOSITION_PTR_NUCLIDE))
		{
		  /* Combine densities */

		  WDB[iso + COMPOSITION_ADENS] = RDB[iso + COMPOSITION_ADENS] + 
		    RDB[ptr + COMPOSITION_ADENS];

		  /* Copy pointer */

		  n = ptr;
		  
		  /* Pointer to next */

		  ptr = NextItem(ptr);

		  /* Remove duplicate */

		  RemoveItem(n);
		}
	      else
		{	      
		  /* Next */
		  
		  ptr = NextItem(ptr);
		}
	    }	      

	  /* Next */
	  
	  iso = NextItem(iso);
	}
 
      /* Next material */

      mat = NextItem(mat);
    }

  /***************************************************************************/

  /***** Link nuclides to ACE data *******************************************/

  /* Loop over materials */
  
  mat = RDB[DATA_PTR_M0];  
  while (mat > VALID_PTR)
    {
      /* Loop over composition */

      iso = RDB[mat + MATERIAL_PTR_COMP];
      while (iso > VALID_PTR)
	{
	  /* Get name */

	  sprintf(name, "%s", GetText(iso + COMPOSITION_PTR_NUCLIDE));

	  /* Try converting to ZAI (this will take care of decay nuclides */
	  /* entered using symbolic names) */

	  if ((ZAI = IsotoZAI(name)) > 0)
	    sprintf(name, "%ld", ZAI);

	  /* Loop over ace data (ei voi käyttää VALID_PTR) */
	  
	  ace = (long)RDB[DATA_PTR_ACE0];	  
	  while (ace > 0)
	    {
	      /* Compare */

	      WDB[DATA_DUMMY] = ACE[ace + ACE_PTR_ALIAS];
	      if (!strcmp(GetText(DATA_DUMMY), name))
		{
		  /* Put name */
		  
		  WDB[iso + COMPOSITION_PTR_NUCLIDE] =  
		    ACE[ace + ACE_PTR_NAME];
		  
		  /* Break loop */
		  
		  break;
		}
	      
	      /* next */
	      
	      ace = (long)ACE[ace + ACE_PTR_NEXT];
	    }
	  
	  /* Check if found */

	  if (ace < 0)
	    Error(mat, "Nuclide %s not found in data libraries",
		  GetText(iso + COMPOSITION_PTR_NUCLIDE));

	  /* Check type */

	  if ((long)ACE[ace + ACE_TYPE] == NUCLIDE_TYPE_SAB)
	    Error(mat, "S(a,b) library %s in composition list",
		 GetText(iso + COMPOSITION_PTR_NUCLIDE));

	  /* Next */

	  iso = NextItem(iso);
	}

      /* Next */

      mat = NextItem(mat);
    }  
  
  /***************************************************************************/

  /***** Internal burnup mode ************************************************/

  if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_INT_BURN)
    {
      /***********************************************************************/

      /***** Nuclides in burnable materials **********************************/

      fprintf(out, "Reading nuclides in burnable materials...\n\n");
  
      /* Loop over materials */

      mat = RDB[DATA_PTR_M0];
      while (mat > 0)
	{
	  /* Check burn-flag and divisor index */
	  
	  if (((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT) &&
	      ((long)RDB[mat + MATERIAL_DIV_IDX] == 0))
	    {
	      /* Set temperature */

	      if ((long)RDB[DATA_DOPPLER_MODE] == DOPPLER_MODE_ONTHEFLY)
		T = -1.0;
	      else
		T = RDB[mat + MATERIAL_TEMP];

	      /* Loop over composition */
	      
	      iso = (long)RDB[mat + MATERIAL_PTR_COMP];	      
	      while (iso > VALID_PTR)
		{
		  /* Add nuclide */
		  
		  if ((nuc = 
		       AddNuclide(GetText(iso + COMPOSITION_PTR_NUCLIDE),-1, 
				  NULL, T, -1)) == 0)
		    Die(FUNCTION_NAME, "Nuclide %s not found",
			GetText(iso + COMPOSITION_PTR_NUCLIDE));
	      
		  /* Set initial flag (if-lause poistettu 27.1.2012) */
		  /*
		  if ((long)RDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_DECAY)
		  */
		  SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_INITIAL);
		  
		  /* Set pointer */
		  
		  WDB[iso + COMPOSITION_PTR_NUCLIDE] = (double)nuc;
		  
		  /* Next isotope */
	      
		  iso = NextItem(iso);
		}
	    }
      
	  /* Next material */
      
	  mat = NextItem(mat);
	}

      /* Check sum */

      if (RDB[DATA_N_TRANSPORT_NUCLIDES] + RDB[DATA_N_DOSIMETRY_NUCLIDES] + 
	  RDB[DATA_N_DECAY_NUCLIDES] < 1.0)
	Error(0, "Burnup mode without burnable materials");

      /***********************************************************************/
      
      /***** Decay and activation products ***********************************/

      fprintf(out, "\nReading decay and activation products...\n\n");
    
      /* Put transport nuclides at the beginning of list */
      
      nuc = (long)RDB[DATA_PTR_NUC0];
      SortList(nuc, NUCLIDE_TYPE, SORT_MODE_ASCEND);
      
      /* Loop over nuclides */
      
      nuc = (long)RDB[DATA_PTR_NUC0];      
      while (nuc > VALID_PTR)
	{
	  /* Check initial flag */
	  
	  if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_INITIAL)
	    {
	      /* Copy library id (NOTE: tää pitää tehdä näin tai */
	      /* myöhemmin tulee ongelmia pointterien kanssa). */

	      sprintf(lib, "%s", GetText(nuc + NUCLIDE_PTR_LIB_ID));
	      
	      /* Generate chain */
	      
	      GenerateTransmuChain(nuc, lib, RDB[nuc + NUCLIDE_TEMP], 
				   (long)RDB[nuc + NUCLIDE_TYPE], 0);
	    }

	  /* Next */
	  
	  nuc = NextItem(nuc);
	}

      /***********************************************************************/
  
      /***** Fission products ************************************************/
      
      /* Combine fission yield distributions */
      
      CombineFissionYields();
	  
      /* Check count */

      if ((long)RDB[DATA_TOT_FP_NUCLIDES] > 0)
	{
	  fprintf(out, "\nAdding fission products (%ld nuclides)...\n\n",
		  (long)RDB[DATA_TOT_FP_NUCLIDES]);
	  
	  /* Put transport nuclides at the beginning of list */
	  
	  nuc = (long)RDB[DATA_PTR_NUC0];
	  SortList(nuc, NUCLIDE_TYPE, SORT_MODE_ASCEND);
	  
	  /* Loop over fission product ID's */
	  
	  ptr = (long)RDB[DATA_PTR_FP_LIB_ID_LIST];
	  
	  while (ptr > 0)
	    {
	      /* Get library id and temperature */
	      
	      sprintf(lib, "%s", GetText(ptr + FP_IDENT_PTR_ID));
	      T = RDB[ptr + FP_IDENT_TEMP];

	      /* Loop over distribution */
	      
	      n = (long)RDB[DATA_PTR_FP_ZAI_LIST];
	      
	      while ((ZAI = (long)RDB[n++]) > 0)
		{
		  /* Add nuclide */
		  
		  if ((new = AddNuclide(NULL, ZAI, lib, T, 
					NUCLIDE_TYPE_TRANSPORT)) == 0)
		    new = AddNuclide(NULL, ZAI, lib, T, -1);
		  
		  if (new > 0) 
		    {
		      /* Set fission product flag */
		      
		      SetOption(new + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_FP);
		      
		      /* Generate chain */
		      
		      GenerateTransmuChain(new, lib, T, NUCLIDE_TYPE_TRANSPORT,
					   0);
		    }
		}
	      
	      /* Next */
	      
	      ptr = NextItem(ptr);
	    }
	}
      
      /***********************************************************************/
      
      /***** Find targets ****************************************************/

      fprintf(out, "\nLooping over decay and transmutation chains:\n\n");

      /* Reset used flags */

      nuc = (long)RDB[DATA_PTR_NUC0];
  
      while (nuc > 0)
	{
	  /* Reset flag */
	  
	  ResetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);
	  
	  /* Next */
      
	  nuc = NextItem(nuc);
	}

      /* Generate nuclide for lost data */

      nuc = NewItem(DATA_PTR_NUCLIDE_LOST, NUCLIDE_BLOCK_SIZE);

      /* Put name and alias and library ID */
      
      WDB[nuc + NUCLIDE_PTR_NAME] = (double)PutText("lost");
      WDB[nuc + NUCLIDE_PTR_LIB_ID] = RDB[nuc + NUCLIDE_PTR_NAME];

      /* Put ZAI */

      WDB[nuc + NUCLIDE_ZAI] = -1.0;

      /* Allocate memory for matrix index */
      
      AllocValuePair(nuc + NUCLIDE_PTR_MATRIX_IDX);

      /* Put pointer */

      WDB[DATA_PTR_NUCLIDE_LOST] = (double)nuc;

      /* Put transport nuclides at the beginning of list */

      nuc = (long)RDB[DATA_PTR_NUC0];
      SortList(nuc, NUCLIDE_TYPE, SORT_MODE_ASCEND);

      /* Find targets */
  
      nuc = (long)RDB[DATA_PTR_NUC0];      
      while (nuc > 0)
	{
	  /* Check initial and burn flags */
	  
	  if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_INITIAL)
	    {
	      /* Find targets recursively */
	      
	      FindTargetNuclides(nuc);
	    }

	  /* Next */
      
	  nuc = NextItem(nuc);
	}

      /* Check that all transport nuclides are used */

      /* NOTE: Tää tarkistus kaatuu siihen että fission yieldeistä luetaan */
      /*       kaikki nuklidit yhteen listaan ja lib ID:t ja T:t toiseen.  */
      /*       jos eri ID:illä on eri aktinideja, jotain tytärnuklideja ei */
      /*       välttämättä pidäkään löytyä listasta. TODO: Muuta listat ID */
      /*       ja T-kohtaisiksi tai poista koko tarkistus. */
      
      nuc = (long)RDB[DATA_PTR_NUC0];
  
      while (nuc > 0)
	{
	  /* Check type and used-flag */
	  
	  if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT) &&
	      !((long)RDB[nuc + NUCLIDE_OPTIONS] & OPT_USED))
	    Warn(FUNCTION_NAME, "Unused transport nuclide %s", 
		 GetText(nuc + NUCLIDE_PTR_NAME));
	  
	  /* Next */
	  
	  nuc = NextItem(nuc);
	}

      /* Allocate memory for matrix indexes */

      nuc = (long)RDB[DATA_PTR_NUC0];
      while (nuc > 0)
	{
	  /* Check used-flag and allocate memory */
	  
	  if ((long)RDB[nuc + NUCLIDE_OPTIONS] & OPT_USED)
	    AllocValuePair(nuc + NUCLIDE_PTR_MATRIX_IDX);
	  
	  /* Next */
	  
	  nuc = NextItem(nuc);
	}

      /* Check that transport nuclides are not available for decay types */

      nuc = (long)RDB[DATA_PTR_NUC0];
  
      while (nuc > 0)
	{
	  /* Check type and used-flag */
	  
	  if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_DECAY) &&
	      ((long)RDB[nuc + NUCLIDE_OPTIONS] & OPT_USED))
	    {
	      ptr = (long)RDB[DATA_PTR_NUC0];
	      
	      while (ptr > 0)
		{
		  /* Compare */
		  
		  if ((RDB[nuc + NUCLIDE_ZAI] == RDB[ptr + NUCLIDE_ZAI]) &&
		      (RDB[nuc + NUCLIDE_TEMP] == RDB[ptr + NUCLIDE_TEMP]) &&
		      CompareStr(nuc + NUCLIDE_PTR_LIB_ID, 
				 ptr + NUCLIDE_PTR_LIB_ID) &&
		      (RDB[ptr + NUCLIDE_TYPE] != NUCLIDE_TYPE_DECAY))
		    Die(FUNCTION_NAME, "Transport data not used (%s / %s)",
			GetText(nuc + NUCLIDE_PTR_NAME),
			GetText(ptr + NUCLIDE_PTR_NAME));
		  
		  /* Next */
		  
		  ptr = NextItem(ptr);
		}
	    }
	  
	  /* Next */
	  
	  nuc = NextItem(nuc);
	}

      /***********************************************************************/

      /***** Nuclides in non-burnable materials ******************************/

      fprintf(out, "\nReading nuclides in remaining materials...\n\n");
  
      /* Set mode to normal to prevent braches in non-burnable nuclides */

      WDB[DATA_RUNNING_MODE] = (double)RUNNING_MODE_TRANSPORT;

      /* Loop over materials */

      mat = RDB[DATA_PTR_M0];

      while (mat > 0)
	{
	  /* Check burn-flag */
	  
	  if (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT))
	    {
	      /* Set temperature */

	      if ((long)RDB[DATA_DOPPLER_MODE] == DOPPLER_MODE_ONTHEFLY)
		T = -1.0;
	      else
		T = RDB[mat + MATERIAL_TEMP];

	      /* Loop over composition */
	      
	      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	      while (iso > VALID_PTR)
		{
		  /* Add nuclide */
		  
		  if ((nuc = 
		       AddNuclide(GetText(iso + COMPOSITION_PTR_NUCLIDE),-1, 
				  NULL, T, -1)) == 0)
		    Die(FUNCTION_NAME, "Nuclide %s not found",
			GetText(iso + COMPOSITION_PTR_NUCLIDE));
	      
		  /* Set initial and used-flags */
	      
		  SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_INITIAL);
		  SetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);

		  /* Set pointer */
		  
		  WDB[iso + COMPOSITION_PTR_NUCLIDE] = (double)nuc;
	      
		  /* Next isotope */
	      
		  iso = NextItem(iso);
		}
	    }
      
	  /* Next material */
      
	  mat = NextItem(mat);
	}

      /* Set mode to back to internal burnup */

      WDB[DATA_RUNNING_MODE] = (double)RUNNING_MODE_INT_BURN;

      /***********************************************************************/
    }
  
  /***************************************************************************/

  /***** External burnup mode ************************************************/

  else if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_EXT_BURN)
    {
      /***********************************************************************/

      /***** Nuclides in all materials ***************************************/

      fprintf(out, "Reading nuclides...\n\n");

      /* Remember mode */

      mode = (long)RDB[DATA_RUNNING_MODE];
  
      /* Loop over materials */

      mat = RDB[DATA_PTR_M0];

      while (mat > 0)
	{
	  /* Set temperature */
	  
	  if ((long)RDB[DATA_DOPPLER_MODE] == DOPPLER_MODE_ONTHEFLY)
	    T = -1.0;
	  else
	    T = RDB[mat + MATERIAL_TEMP];

	  /* Set mode to normal if not burnable material */
	  
	  if (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT))
	    WDB[DATA_RUNNING_MODE] = (double)RUNNING_MODE_TRANSPORT;

	  /* Loop over composition */
	      
	  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	  while (iso > VALID_PTR)
	    {
	      /* Add nuclide */
	      
	      if ((nuc = 
		   AddNuclide(GetText(iso + COMPOSITION_PTR_NUCLIDE),-1, 
			      NULL, T, -1)) == 0)
		Die(FUNCTION_NAME, "Nuclide %s not found",
		    GetText(iso + COMPOSITION_PTR_NUCLIDE));
	      
	      /* Check burn-flag */
	      
	      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
		{
		  /* Loop over reactions and set target ZAI's */

		  rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
		  while (rea > VALID_PTR)
		    {
		      /* Put ZAI */
		      
		      WDB[rea + REACTION_TGT_ZAI] = 
			(double)ReactionTargetZAI(rea);
		      
		      /* Next reaction */
		      
		      rea = NextItem(rea);
		    }
		}

	      /* Set initial and used-flags */
	      
	      SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_INITIAL);
	      SetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);

	      /* Set pointer */
	      
	      WDB[iso + COMPOSITION_PTR_NUCLIDE] = (double)nuc;
	      
	      /* Next isotope */
	      
	      iso = NextItem(iso);
	    }

	  /* Set mode */

	  WDB[DATA_RUNNING_MODE] = (double)mode;
	  
	  /* Next material */
      
	  mat = NextItem(mat);
        }
  
      /***********************************************************************/
    }
  
  /***************************************************************************/

  /***** Transport mode ******************************************************/

  else 
    {
      /***********************************************************************/

      /***** Nuclides in all materials ***************************************/

      fprintf(out, "Reading nuclides...\n\n");

      /* Loop over materials */

      mat = RDB[DATA_PTR_M0];

      while (mat > 0)
	{
	  /* Set temperature */
	  
	  if ((long)RDB[DATA_DOPPLER_MODE] == DOPPLER_MODE_ONTHEFLY)
	    T = -1.0;
	  else
	    T = RDB[mat + MATERIAL_TEMP];
	  
	  /* Loop over composition */
	      
	  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	  while (iso > VALID_PTR)
	    {
	      /* Add nuclide */
	      
	      if ((nuc = 
		   AddNuclide(GetText(iso + COMPOSITION_PTR_NUCLIDE),-1, 
			      NULL, T, -1)) == 0)
		Die(FUNCTION_NAME, "Nuclide %s not found",
		    GetText(iso + COMPOSITION_PTR_NUCLIDE));
	      
	      /* Set initial and used-flags */
	      
	      SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_INITIAL);
	      SetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);

	      /* Set pointer */
	      
	      WDB[iso + COMPOSITION_PTR_NUCLIDE] = (double)nuc;
	      
	      /* Next isotope */
	      
	      iso = NextItem(iso);
	    }
	  
	  /* Next material */
      
	  mat = NextItem(mat);
        }

      /***********************************************************************/
    }
  
  /***************************************************************************/

  /***** Nuclides in sources *************************************************/

  /* Loop over sources */
  
  src = RDB[DATA_PTR_SRC0];
  
  while (src > 0)
    {
      /* Check reaction pointer */

      if ((long)RDB[src + SRC_PTR_XSDATA] > VALID_PTR)
	{
	  /* Add nuclide */
	      
	  if ((nuc = AddNuclide(GetText(src + SRC_PTR_XSDATA),-1, NULL, 
				-1.0, -1)) == 0)
	    Error(src, "Nuclide %s not found", GetText(src + SRC_PTR_XSDATA));
	  
	  /* Set source and used-flag */
	      
	  SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_SRC);
	  SetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);

	  /* Set pointer */
	      
	  WDB[src + SRC_PTR_XSDATA] = (double)nuc;
	}

      /* Next source */
      
      src = NextItem(src);
    }
  
  /***************************************************************************/

  /***** Add zero-kelvin data for DBRC ***************************************/

  /* Check pointer to list. NOTE: Tää pitää tosiaan kutsua vasta täällä */
  /* ihan viimeiseksi tai muuten kaikkia reaktioita ei lueta mukaan jos */
  /* samaa nuklidia käytetään muuallakin. */

  if ((ptr = (long)RDB[DATA_PTR_DBRC]) > VALID_PTR)
    {
      fprintf(out, "\nAdding 0K data for DBRC...\n\n");
      
      while ((long)RDB[ptr] > VALID_PTR)
	{
	  /* Add nuclide */
	      
	  if ((nuc = AddNuclide(GetText(ptr), -1, NULL, -1, 
				NUCLIDE_TYPE_DBRC)) == 0)
	    Error(src, "Nuclide %s not found", GetText(ptr));
	  
	  /* Check temperature */

	  if (RDB[nuc + NUCLIDE_TEMP] != 0.0)
	    Error(0, "DBRC nuclide %s is not at 0K temperature",
	    GetText(nuc + NUCLIDE_PTR_NAME));

	  /* Set dbrc and used-flag */
	      
	  SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_DBRC);
	  SetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);

	  /* Next nuclide */

	  ptr++;
	}
    }

  /***************************************************************************/

  /***** Add S(a,b) data *****************************************************/

  /* Link thermal scattering data (must be called before the pointer */
  /* check to remove unused data) */

  LinkSabData();

  /* Check if data is defined */

  if ((ptr = RDB[DATA_PTR_T0]) > VALID_PTR)
    {
      fprintf(out, "\nReading S(a,b) data...\n\n");

      /* Loop definitions */
      
      while (ptr > VALID_PTR)
	{
	  /* First nuclide */

	  if ((nuc = AddNuclide(GetText(ptr + THERM_PTR_ISO1),
				-1, NULL, -1, -1)) == 0)
	    Die(FUNCTION_NAME, "S(a,b) library %s not found",
		GetText(ptr + THERM_PTR_ISO1));
	  
	  /* Set pointer */
	  
	  WDB[ptr + THERM_PTR_ISO1] = (double)nuc;
	  
	  /* Check for temperature interpolation */
	  
	  if ((long)RDB[ptr + THERM_PTR_ISO2] > VALID_PTR)
	    {
	      /* Second nuclide */
	      
	      if ((nuc = AddNuclide(GetText(ptr + THERM_PTR_ISO2),
				    -1, NULL, -1, -1)) == 0)
		Die(FUNCTION_NAME, "S(a,b) library %s not found",
		    GetText(ptr + THERM_PTR_ISO1));
	      
	      /* Set pointer */
	  
	      WDB[ptr + THERM_PTR_ISO2] = (double)nuc;
	    }

	  /* Next */
	  
	  ptr = NextItem(ptr);
	}

      /* Add S(a,b) data into nuclides */

      AddSabData();
    } 
  
  /***************************************************************************/

  /***** Remaining stuff *****************************************************/

  /* Remove unused nuclides */

  nuc = (long)RDB[DATA_PTR_NUC0];
  RemoveFlaggedItems(nuc, NUCLIDE_OPTIONS, OPT_USED, NO);
  
  /* Set path levels */
  
  nuc = (long)RDB[DATA_PTR_NUC0];
  
  while (nuc > 0)
    {
      /* Check initial flag */
      
      if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_INITIAL)
	SetPathLevels(nuc, 0);
      
      /* Next */
      
      nuc = NextItem(nuc);
    }

  /* Read additional photon data */

  ReadPhotonData();

  /* Sort list */

  fprintf(out, "\nSorting nuclide list...\n");

  nuc = (long)RDB[DATA_PTR_NUC0];
  SortList(nuc, NUCLIDE_ZAI, SORT_MODE_ASCEND);

  fprintf(out, "OK.\n\n");

  /* Close list */

  nuc = (long)RDB[DATA_PTR_NUC0];
  CloseList(nuc);

  /* Put number of nuclides */

  WDB[DATA_TOT_NUCLIDES] = (double)ListSize(nuc);

  /* Put indexes (lost is zero) */

  n = 1;

  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      WDB[nuc + NUCLIDE_IDX] = (double)(n++);
      WDB[nuc + NUCLIDE_INVENTORY_IDX] = -1.0;

      /* Next nuclide */

      nuc = NextItem(nuc);
    }

  /* Update reaction count */

  ReactionCount();

  /* Set global precursor group structure */

  SetPrecursorGroups();

  /* Check and print */

  CheckNuclideData();

  /* Adjust energy grid minimum and maximum */

  if (RDB[DATA_NEUTRON_EMIN] < RDB[DATA_NEUTRON_XS_EMIN])
    WDB[DATA_NEUTRON_EMIN] = RDB[DATA_NEUTRON_XS_EMIN];

  if (RDB[DATA_NEUTRON_EMAX] > RDB[DATA_NEUTRON_XS_EMAX])
    WDB[DATA_NEUTRON_EMAX] = RDB[DATA_NEUTRON_XS_EMAX];

  if (RDB[DATA_PHOTON_EMIN] < RDB[DATA_PHOTON_XS_EMIN])
    WDB[DATA_PHOTON_EMIN] = RDB[DATA_PHOTON_XS_EMIN];

  if (RDB[DATA_PHOTON_EMAX] > RDB[DATA_PHOTON_XS_EMAX])
    WDB[DATA_PHOTON_EMAX] = RDB[DATA_PHOTON_XS_EMAX];

  /***************************************************************************/
}

/*****************************************************************************/
