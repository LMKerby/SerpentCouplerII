/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : testsurface.c                                  */
/*                                                                           */
/* Created:       2010/10/07 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Checks if point is inside a surface or not                   */
/*                                                                           */
/* Comments: - Adopted from Serpent 1.1.14                                   */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "TestSurface:"

/*****************************************************************************/

long TestSurface(long surf, double x, double y, double z)
{
  double d, l, r, h, x0, y0, r2, R1, R2, alpha, k, A, B, C, D, E, F, G, H, J,K;
  long ptr, type, params;

  /* Check surface pointer */

  CheckPointer(FUNCTION_NAME, "(surf)", DATA_ARRAY, surf);

  /* Get surface type */

  type = (long)RDB[surf + SURFACE_TYPE];

  /* Pointer to parameter list */

  ptr = (long)RDB[surf + SURFACE_PTR_PARAMS];
  
  /* Check number of parameters */

#ifdef DEBUG

  if((type != SURF_INF) && (ptr < 0))
    Die(FUNCTION_NAME, "Surface %s has no parameters",
	GetText(surf + SURFACE_PTR_NAME));

#endif

  /* Get number of parameters */

  params = (long)RDB[surf + SURFACE_N_PARAMS];

  /***************************************************************************/

  switch(type)
    {
      /***********************************************************************/

    case SURF_CYL:
    case SURF_CYLZ:
      {
	/* NOTE: Tähän lisättiin katkaisu z-suunnassa 3.12.2009 (JLE) */

	x = x - RDB[ptr];
	y = y - RDB[ptr + 1];
	r = RDB[ptr + 2];
	
	/* Check if cylinder is cut */

	if (params == 5)
	  {
	    /* Test z-planes */

	    if (z < RDB[ptr + 3])
	      return NO;
	    else if (z > RDB[ptr + 4])
	      return NO;
	  }

	if (x*x + y*y > r*r)
	  return NO;
	else
	  return YES;
      }

      /**********************************************************************/

    case SURF_CYLX:
      {
	y = y - RDB[ptr];
	z = z - RDB[ptr + 1];
	r = RDB[ptr + 2];
	
	/* Check if cylinder is cut */

	if (params == 5)
	  {
	    /* Test x-planes */

	    if (x < RDB[ptr + 3])
	      return NO;
	    else if (x > RDB[ptr + 4])
	      return NO;
	  }

	if (y*y + z*z > r*r)
	  return NO;
	else
	  return YES;
      }

      /**********************************************************************/

    case SURF_CYLY:
      {
	x = x - RDB[ptr];
	z = z - RDB[ptr + 1];
	r = RDB[ptr + 2];
	
	/* Check if cylinder is cut */

	if (params == 5)
	  {
	    /* Test y-planes */

	    if (y < RDB[ptr + 3])
	      return NO;
	    else if (y > RDB[ptr + 4])
	      return NO;
	  }

	if (x*x + z*z > r*r)
	  return NO;
	else
	  return YES;
      }

      /**********************************************************************/

    case SURF_PAD:
      {
	x = x - RDB[ptr];
	y = y - RDB[ptr + 1];
	R1 = RDB[ptr + 2];
	R2 = RDB[ptr + 3];

	/* Test annular regions */

	r2 = x*x + y*y;

	if (r2 < R1*R1)
	  return NO;
	else if (r2 > R2*R2)
	  return NO;
	else
	  {
	    /* Test first sector surface */

	    alpha = RDB[ptr + 4] - (long)(RDB[ptr + 4]/360)*360.0;
	    
	    if ((alpha == 90.0) || (alpha == 270.0))
	      k = -INFTY;
	    else if ((alpha == -90.0) || (alpha == -270.0))
	      k = INFTY;
	    else
	      k = -sin(PI*alpha/180.0)/cos(PI*alpha/180.0);
	    
	    if (((fabs(alpha) > 90) && (fabs(alpha) <= 270)))
	      {
		if (y < k*x)
		  return NO;
	      }
	    else 
	      {
		if (y > k*x)
		  return NO;
	      }

	    /* Test second sector surface */

	    alpha = RDB[ptr + 5] - (long)(RDB[ptr + 5]/360)*360.0;
	    if ((alpha == 90.0) || (alpha == 270.0))
	      k = -INFTY;
	    else if ((alpha == -90.0) || (alpha == -270.0))
	      k = INFTY;
	    else
	      k = -sin(PI*alpha/180.0)/cos(PI*alpha/180.0);
	    
	    if (((fabs(alpha) > 90) && (fabs(alpha) <= 270)))
	      {
		if (y > k*x)
		  return NO;
	      }
	    else 
	      {
		if (y < k*x)
		  return NO;
	      }
	  }

	return YES;
      }

      /**********************************************************************/

    case SURF_SPH:
      {
	x = x - RDB[ptr];
	y = y - RDB[ptr + 1];
	z = z - RDB[ptr + 2];
	r = RDB[ptr + 3];

	if (x*x + y*y + z*z > r*r)
	  return NO;
	else
	  return YES;
      }

      /**********************************************************************/

    case SURF_CUBE:
      {
	x = x - RDB[ptr];
	y = y - RDB[ptr + 1];
	z = z - RDB[ptr + 2];
	r = RDB[ptr + 3];
	
        if ((x > r) || (x < -r) || (y > r) || (y < -r)|| (z > r) || (z < -r))
	  return NO;
	else
	  return YES;
      }

      /**********************************************************************/

    case SURF_CUBOID:
      {
	if (x < RDB[ptr++])
	  return NO;
	else if (x > RDB[ptr++])
	  return NO;
	else if (y < RDB[ptr++])
	  return NO;
	else if (y > RDB[ptr++])
	  return NO;
	else if (z < RDB[ptr++])
	  return NO;
	else if (z > RDB[ptr])
	  return NO;
	else
	  return YES;
      }

      /**********************************************************************/

    case SURF_PX:
      {
	x = x - RDB[ptr];

	if (x > 0)
	  return NO;
	else
	  return YES;
      }

      /**********************************************************************/

    case SURF_PY:
      {
	y = y - RDB[ptr];

	if (y > 0)
	  return NO;
	else
	  return YES;
      }

      /**********************************************************************/

    case SURF_PZ:
      {
	z = z - RDB[ptr];

	if (z > 0)
	  return NO;
	else
	  return YES;
      }      

      /**********************************************************************/

    case SURF_CONE:
      {
	x = x - RDB[ptr];
	y = y - RDB[ptr + 1];
	z = z - RDB[ptr + 2];
	h = RDB[ptr + 4];

	/* Check half-plane */

	if (h > 0.0)
	  {
	    /* Downward pointing cone */
	    
	    if (z > h)
	      return NO;	    
	  }
	else
	  {
	    /* Upward pointing cone */
	    
	    if (z < h)
	      return NO;	    
	  }

	/* Calculate radius */

	r = RDB[ptr + 3]*(1.0 - z/h);
	
	/* Neutron inside half-plane */

	if (x*x + y*y > r*r)
	  return NO;
	else
	  return YES;
      }

      /**********************************************************************/

    case SURF_INF:
      {
	return YES;
      }

      /**********************************************************************/

    case SURF_SQC:
      {
	/* Check definition of rounded corners */

	if (params == 3)
	  {
	    /* Sharp corners */
	    
	    x = x - RDB[ptr];
	    y = y - RDB[ptr + 1];
	    r = RDB[ptr + 2];
	    
	    if (fabs(x) > r)
	      return NO;
	    else if (fabs(y) > r)
	      return NO;
	    else
	      return YES;
	  }
	else
	  {
	    /* Rounded corners. Try outer boundaries first */

	    x = x - RDB[ptr];
	    y = y - RDB[ptr + 1];
	    r = RDB[ptr + 2];
	    
	    if (fabs(x) > r)
	      return NO;
	    else if (fabs(y) > r)
	      return NO;
	    
	    /* Inner boundaries */
	    
	    r = r - RDB[ptr + 3];
	    
	    if (fabs(x) < r)
	      return YES;
	    else if (fabs(y) < r)
	      return YES;
	    
	    /* corners */
	    
	    x = fabs(x) - r;
	    y = fabs(y) - r;
	    
	    if (x*x + y*y < RDB[ptr + 3]*RDB[ptr + 3])
	      return YES;
	    else
	      return NO;
	  }
      }

      /**********************************************************************/

    case SURF_HEXYC:
      {
	/* Check definition of rounded corners */

	if (params == 3)
	  {
	    /* Sharp corners */

	    x = fabs(x - RDB[ptr]);
	    y = fabs(y - RDB[ptr + 1]);
	    r = RDB[ptr + 2];

	    if (y > r)
	      return NO;
	    else if (y > -SQRT3*x + 2*r)
	      return NO;
	    else 
	      return YES;
	  }
	else
	  {
	    /* Rounded corners. Try outer boundaries first */

	    x = fabs(x - RDB[ptr]);
	    y = fabs(y - RDB[ptr + 1]);
	    r = RDB[ptr + 2];
	    
	    if (y > r)
	      return NO;
	    else if (y > -SQRT3*x + 2*r)
	      return NO;
	    
	    /* Inner boundaries */
	    
	    r = r - RDB[ptr + 3]*(1.0 - SIN30);
	    
	    if ((y < r) && (y > SQRT3*x - 2*r))
	      return YES;
	    else if (y < -SQRT3*x + 2*r)
	      return YES;
	    
	    /* Corners */
	    
	    x0 = (RDB[ptr + 2] - RDB[ptr + 3])/COS30;
	    r2 = RDB[ptr + 3]*RDB[ptr + 3];
	    
	    if ((x - x0)*(x - x0) + y*y < r2)
	      return YES;
	    
	    x0 = x0/2.0;
	    y0 = (RDB[ptr + 2] - RDB[ptr + 3]);
	    
	    if ((x - x0)*(x - x0) + (y - y0)*(y - y0) < r2)
	      return YES;
	    
	    /* Neutron is outside */
	    
	    return NO;
	  }
      }

      /**********************************************************************/

    case SURF_HEXXC:
      {
	/* Check definition of rounded corners */

	if (params == 3)
	  {
	    /* Sharp corners */

	    y0 = fabs(x - RDB[ptr]);
	    x = fabs(y - RDB[ptr + 1]);
	    y = y0;
	    r = RDB[ptr + 2];
	    
	    if (y > r)
	      return NO;
	    else if (y > -SQRT3*x + 2*r)
	      return NO;
	    else 
	      return YES;
	  }
	else
	  {
	    /* Rounded corners. Try outer boundaries first */

	    y0 = fabs(x - RDB[ptr]);
	    x = fabs(y - RDB[ptr + 1]);
	    y = y0;
	    r = RDB[ptr + 2];
	    
	    if (y > r)
	      return NO;
	    else if (y > -SQRT3*x + 2*r)
	      return NO;
	    
	    /* Inner boundaries */
	    
	    r = r - RDB[ptr + 3]*(1.0 - SIN30);
	    
	    if ((y < r) && (y > SQRT3*x - 2*r))
	      return YES;
	    else if (y < -SQRT3*x + 2*r)
	      return YES;
	    
	    /* Corners */
	    
	    x0 = (RDB[ptr + 2] - RDB[ptr + 3])/COS30;
	    r2 = RDB[ptr + 3]*RDB[ptr + 3];
	    
	    if ((x - x0)*(x - x0) + y*y < r2)
	      return YES;
	    
	    x0 = x0/2.0;
	    y0 = (RDB[ptr + 2] - RDB[ptr + 3]);
	    
	    if ((x - x0)*(x - x0) + (y - y0)*(y - y0) < r2)
	      return YES;
	    
	    /* Neutron is outside */
	    
	    return NO;
	  }
      }

      /**********************************************************************/

    case SURF_HEXYPRISM:
      {
	/* Check z-boundaries */

	if (z < RDB[ptr + 3])
	  return NO;
	else if (z > RDB[ptr + 4])
	  return NO;

	/* Transfer co-ordinates */
	
	x = fabs(x - RDB[ptr]);
	y = fabs(y - RDB[ptr + 1]);
	r = RDB[ptr + 2];
	
	/* Test sides */

	if (y > r)
	  return NO;
	else if (y > -SQRT3*x + 2*r)
	  return NO;
	else 
	  return YES;
      }

      /**********************************************************************/
      
    case SURF_HEXXPRISM:
      {
	/* Check z-boundaries */

	if (z < RDB[ptr + 3])
	  return NO;
	else if (z > RDB[ptr + 4])
	  return NO;

	/* Transfer co-ordinates */

	y0 = fabs(x - RDB[ptr]);
	x = fabs(y - RDB[ptr + 1]);
	y = y0;
	r = RDB[ptr + 2];
	
	/* Test sides */
	
	if (y > r)
	  return NO;
	else if (y > -SQRT3*x + 2*r)
	  return NO;
	else 
	  return YES;
	
      }
      
      /**********************************************************************/
      
    case SURF_CROSS:
      {
	x = fabs(x - RDB[ptr]);
	y = fabs(y - RDB[ptr + 1]);
	l = RDB[ptr + 2];
	d = RDB[ptr + 3];

	/* Check rounded corners (fifth co-ordinate is dummy?) */

	if (params == 5)
	  r = d;
	else
	  r = 0;

	if (x > l)
	  return NO;
	else if (y > l)
	  return NO;
	else if ((x > d) && (y > d))
	  return NO;

	if (r == 0)
	  return YES;

	/* test corners */

	l = l - r;

	if (x > l)
	  {
	    x = x - l;
	    if (x*x + y*y > r*r)
	      return NO;
	    else 
	      return YES;
	  }
	else if (y > l)
	  {
	    y = y - l;
	    if (x*x + y*y > r*r)
	      return NO;
	    else 
	      return YES;
	  }
	else
	  return YES;
      }

      /**********************************************************************/

    case SURF_SVC:
      {

	x = x - RDB[ptr];
	y = y - RDB[ptr + 1];

	d = RDB[ptr + 2];

	if ((fabs(y - x)  < SIN45*(2.96 + 2*d)) &&
	    (fabs(y + x)  < SIN45*(2.96 + 2*d)))
	  return YES;

	if (fabs(x) > 6.87)
	  return NO;

	if (fabs(y) > 6.87)
	  return NO;
       
	if (fabs(x) < d)
	  return YES;

	if (fabs(y) < d)
	  return YES;

	x = x + 4.7;

	if ((fabs(y) < 0.2 + d) &&
	    (fabs(y - x)  < SIN45*(2.5 + 2*d)) &&
	    (fabs(y + x)  < SIN45*(2.5 + 2*d)))
	  return YES;

	x = x - 2*4.7;

	if ((fabs(y) < 0.2 + d) &&
	    (fabs(y - x)  < SIN45*(2.5 + 2*d)) &&
	    (fabs(y + x)  < SIN45*(2.5 + 2*d)))
	  return YES;

	x = x + 4.7;
	y = y + 4.7;

	if ((fabs(x) < 0.2 + d) &&
	    (fabs(y - x)  < SIN45*(2.5 + 2*d)) &&
	    (fabs(y + x)  < SIN45*(2.5 + 2*d)))
	  return YES;

	y = y - 2*4.7;

	if ((fabs(x) < 0.2 + d) &&
	    (fabs(y - x)  < SIN45*(2.5 + 2*d)) &&
	    (fabs(y + x)  < SIN45*(2.5 + 2*d)))
	  return YES;

	return NO;
      }

      /**********************************************************************/

    case SURF_DODE:
      {
	/* Sharp corners */
	
	x = fabs(x - RDB[ptr]);
	y = fabs(y - RDB[ptr + 1]);
	r = RDB[ptr + 2];

	if (params == 4)
	  l = RDB[ptr + 3];
	else
	  l = r;
	if (y > l)
	  return NO;
	else if (x > r)
	  return NO;	
	else if (y > -SQRT3*x + 2*l)
	  return NO;
	else if (x > -SQRT3*y + 2*r)
	  return NO;
	else
	  return YES;
      }
	
      /**********************************************************************/
	  
    case SURF_OCTA:
      {
	/* Sharp corners */
	
	x = fabs(x - RDB[ptr]);
	y = fabs(y - RDB[ptr + 1]);
	r = RDB[ptr + 2];

	if (params == 4)
	  l = RDB[ptr + 3];
	else
	  l = r;

	if (y > r)
	  return NO;
	else if (x > r)
	  return NO;
	else if (y > -x + SQRT2*l)
	  return NO;
	else
	  return YES;
      }
      
      /**********************************************************************/
	  
    case SURF_ASTRA:
      {
	/* Sharp corners */
	
	x = fabs(x - RDB[ptr]);
	y = fabs(y - RDB[ptr + 1]);
	r = RDB[ptr + 2];
	l = RDB[ptr + 3];

	if ((y < r) && (x < r) && (y < -x + SQRT2*l))
	  return YES;
	else 
	  /* Two cylinders */
	  x0 = -0.5*r + 0.75*SQRT2*l;
	  y0 =  0.5*r + 0.25*SQRT2*l;
	  r2 = RDB[ptr + 4]*RDB[ptr + 4];
	  
	  if ((x - x0)*(x - x0) + (y - y0)*(y - y0) < r2)
	    return YES;
	    
	  x0 =  0.5*r + 0.25*SQRT2*l;
	  y0 = -0.5*r + 0.75*SQRT2*l;
	    
	  if ((x - x0)*(x - x0) + (y - y0)*(y - y0) < r2)
	    return YES;
	    
	  /* Neutron is outside */
	    
	  return NO;
      }
    
      /***********************************************************************/	
      
    case SURF_PLANE:
      {
	/* Reset optional parameters */

	B = 0.0;
	C = 0.0;
	D = 0.0;
	
	/* Get parameters */

	A = RDB[ptr];

	if (params > 1)
	  B = RDB[ptr + 1];

	if (params > 2)
	  C = RDB[ptr + 2];

	if (params > 3)
	  D = RDB[ptr + 3];

	/* Test */

	if (A*x + B*y + C*z < D)
	  return YES;
	else
	  return NO;
      }

      /**********************************************************************/

    case SURF_QUADRATIC:
      {
	/* Reset optional parameters */

	B = 0.0;
	C = 0.0;
	D = 0.0;
	E = 0.0;
	F = 0.0;
	G = 0.0;
	H = 0.0;
	J = 0.0;
	K = 0.0;

	/* Get parameters */

	A = RDB[ptr];

	if (params > 1)
	  B = RDB[ptr + 1];

	if (params > 2)
	  C = RDB[ptr + 2];

	if (params > 3)
	  D = RDB[ptr + 3];

	if (params > 4)
	  E = RDB[ptr + 4];

	if (params > 5)
	  F = RDB[ptr + 5];

	if (params > 6)
	  G = RDB[ptr + 6];

	if (params > 7)
	  H = RDB[ptr + 7];

	if (params > 8)
	  J = RDB[ptr + 8];

	if (params > 9)
	  K = RDB[ptr + 9];

	/* Test */

	if (A*x*x + B*y*y + C*z*z + D*x*y + E*y*z + F*z*x + G*x + H*y + J*z + K
	    < 0.0)
	  return YES;
	else
	  return NO;
      }
      
      /**********************************************************************/

    default:
      break;
    }
  
  /***************************************************************************/
  
  /***** Invalid surface type ************************************************/
  
  Die(FUNCTION_NAME, "Invalid surface type %ld (surface %s)",
      type, GetText(surf + SURFACE_PTR_NAME));
   
  /* Avoid warnings */

  return 0;
}

/*****************************************************************************/
