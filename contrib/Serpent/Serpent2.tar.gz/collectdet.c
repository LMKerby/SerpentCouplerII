/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : collectdet.c                                   */
/*                                                                           */
/* Created:       2011/03/03 (JLe)                                           */
/* Last modified: 2011/12/27 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Collects detector results                                    */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CollectDet:"

/*****************************************************************************/

void CollectDet()
{
  long det0, det1, ptr, erg, type, stp;
  long ebins0, ubins0, cbins0, mbins0, lbins0, rbins0, zbins0, ybins0, xbins0;
  long tbins0, ebins1, ubins1, cbins1, mbins1, lbins1, rbins1, zbins1, ybins1;
  long xbins1, tbins1, eb0, ub0, cb0, mb0, lb0, rb0, zb0, yb0, xb0, tb0, eb1;
  long ub1, cb1, mb1, lb1, rb1, zb1, yb1, xb1, tb1, idx0, idx1;
  double val, norm, div, mul;

  /* Reduce scoring buffer */

  ReduceBuffer();

  /* Get normalization factor */

  norm = NormCoef();
  CheckValue(FUNCTION_NAME, "norm", "", norm, 0.0, INFTY);

  /* Loop over detectors */

  det0 = (long)RDB[DATA_PTR_DET0];
  while(det0 > VALID_PTR)
    {
      /* Get detector type */

      type = (long)RDB[det0 + DET_TYPE];

      /* Get number of bins */

      ebins0 = (long)RDB[det0 + DET_N_EBINS];
      ubins0 = (long)RDB[det0 + DET_N_UBINS];
      cbins0 = (long)RDB[det0 + DET_N_CBINS];
      mbins0 = (long)RDB[det0 + DET_N_MBINS];
      lbins0 = (long)RDB[det0 + DET_N_LBINS];
      rbins0 = (long)RDB[det0 + DET_N_RBINS];
      zbins0 = (long)RDB[det0 + DET_MESH_NZ];
      ybins0 = (long)RDB[det0 + DET_MESH_NY];
      xbins0 = (long)RDB[det0 + DET_MESH_NX];
      tbins0 = (long)RDB[det0 + DET_N_TBINS];

      /* Pointer to adjoint detector */

      if ((det1 = (long)RDB[det0 + DET_PTR_ADJOINT]) > VALID_PTR)
	{
	  /* Get number of bins */

	  ebins1 = (long)RDB[det1 + DET_N_EBINS];
	  ubins1 = (long)RDB[det1 + DET_N_UBINS];
	  cbins1 = (long)RDB[det1 + DET_N_CBINS];
	  mbins1 = (long)RDB[det1 + DET_N_MBINS];
	  lbins1 = (long)RDB[det1 + DET_N_LBINS];
	  rbins1 = (long)RDB[det1 + DET_N_RBINS];
	  zbins1 = (long)RDB[det1 + DET_MESH_NZ];
	  ybins1 = (long)RDB[det1 + DET_MESH_NY];
	  xbins1 = (long)RDB[det1 + DET_MESH_NX];
	  tbins1 = (long)RDB[det1 + DET_N_TBINS];
	}
      else
	{
	  /* Reset number of bins */

	  ebins1 = -1;
	  ubins1 = -1;
	  cbins1 = -1;
	  mbins1 = -1;
	  lbins1 = -1;
	  rbins1 = -1;
	  zbins1 = -1;
	  ybins1 = -1;
	  xbins1 = -1;
	  tbins1 = -1;
	}

      /* Pointer to statistics */

      stp = (long)RDB[det0 + DET_PTR_STAT];

      /* Pointer to energy distribution */

      erg = (long)RDB[det0 + DET_PTR_EGRID];
      erg = (long)RDB[erg + ENERGY_GRID_PTR_DATA];

      /* Loop over bins */

      for (eb0 = 0; eb0 < ebins0; eb0++)
      for (ub0 = 0; ub0 < ubins0; ub0++)
      for (cb0 = 0; cb0 < cbins0; cb0++)
      for (mb0 = 0; mb0 < mbins0; mb0++)
      for (lb0 = 0; lb0 < lbins0; lb0++)
      for (rb0 = 0; rb0 < rbins0; rb0++)
      for (zb0 = 0; zb0 < zbins0; zb0++)
      for (yb0 = 0; yb0 < ybins0; yb0++)
      for (xb0 = 0; xb0 < xbins0; xb0++)
      for (tb0 = 0; tb0 < tbins0; tb0++)
	{
	  /* Get index */

	  idx0 = DetIdx(det0, eb0, ub0, cb0, mb0, lb0, rb0, zb0, yb0, xb0, 
			tb0);

	  /* Divide by volume */
	  
	  div = RDB[det0 + DET_VOL];

	  /* Energy and lethargy divider */

	  if (type == -2)
	    div = div*(RDB[erg + eb0 + 1] - RDB[erg + eb0]);
	  else if (type == -3)
	    div = div*(log(RDB[erg + eb0 + 1]) - log(RDB[erg + eb0]));

	  /* Reset multiplier */

	  mul = 1.0;

	  /* Detector divider and multiplier */

	  if ((type == 2) || (type == 3))
	    {
	      /* Pointer to second detector */

	      ptr = (long)RDB[det0 + DET_PTR_MUL];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      /* Pointer to statistics */

	      ptr = (long)RDB[ptr + DET_PTR_STAT];	      

	      /* Get multiplier or divider */

	      if (type == 2)
		mul = BufVal(ptr, idx0);
	      else
		div = div*BufVal(ptr, idx0);
	    }

	  /* Check pointer to adjoint */

	  if (det1 < VALID_PTR)
	    {
	      /* Get buffer value */
	  
	      val = BufVal(stp, idx0);
	      
	      /* Normalize */
	      
	      val = val*norm;

	      /* Store */
	      
	      if (div != 0.0)
		AddStat(mul*val/div, stp, idx0);
	    }
	  else
	    {
	      /* Loop over bins */

	      for (eb1 = 0; eb1 < ebins1; eb1++)
	      for (ub1 = 0; ub1 < ubins1; ub1++)
	      for (cb1 = 0; cb1 < cbins1; cb1++)
	      for (mb1 = 0; mb1 < mbins1; mb1++)
	      for (lb1 = 0; lb1 < lbins1; lb1++)
	      for (rb1 = 0; rb1 < rbins1; rb1++)
	      for (zb1 = 0; zb1 < zbins1; zb1++)
	      for (yb1 = 0; yb1 < ybins1; yb1++)
	      for (xb1 = 0; xb1 < xbins1; xb1++)
	      for (tb1 = 0; tb1 < tbins1; tb1++)
		{
		  /* Get index */

		  idx1 = DetIdx(det1, eb1, ub1, cb1, mb1, lb1, rb1, zb1, yb1, 
				xb1, tb1);
		  /* Get buffer value */
		  
		  val = BufVal(stp, idx0, idx1);
		  
		  /* Normalize */
		  
		  val = val*norm;

		  /* Store */
	      
		  if (div != 0.0)
		    AddStat(mul*val/div, stp, idx0, idx1);
		}
	    }
	}
      
      /* Next detector */
      
      det0 = NextItem(det0);
    }
}

/*****************************************************************************/
