/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : fromstack.c                                    */
/*                                                                           */
/* Created:       2011/03/09 (JLe)                                           */
/* Last modified: 2012/01/10 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Retrieves neutron / photon from stack                        */
/*                                                                           */
/* Comments: - Tarkista onko toi datan tuhoaminen ihan välttämätöntä         */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "FromStack:"

/*****************************************************************************/

long FromStack(long type, long id)
{
  long ptr, n, hst;

  /* Avoid compiler warning */

  ptr = -1;

  /* Check mode */

  if (id < 0)
    {
      /* Check OpenMP thread number */

      if (OMP_THREAD_NUM != 0)
	Die(FUNCTION_NAME, "Called from parallel loop");

      /* Loop over threads and find next available particle */

      for (id = 0; id < (long)RDB[DATA_OMP_MAX_THREADS];id++)
	{
	  /* Check type and get pointer to stack */
	  
	  if (type == PARTICLE_TYPE_NEUTRON)
	    ptr = (long)RDB[OMPPtr(DATA_PART_PTR_NSTACK, id)];
	  else if (type == PARTICLE_TYPE_GAMMA)
	    ptr = (long)RDB[OMPPtr(DATA_PART_PTR_GSTACK, id)];
	  else
	    Die(FUNCTION_NAME, "Invalid particle type");

	  /* Check pointer */

	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  /* Get pointer to last item */

	  ptr = LastItem(ptr);

	  /* Check type */

	  if ((long)RDB[ptr + PARTICLE_TYPE] != PARTICLE_TYPE_DUMMY)
	    break;
	}

      /* Check count and retrieve from thread 0 */

      if (id == (long)RDB[DATA_OMP_MAX_THREADS])
	id = 0;
    }

  /* Check type and get pointer to stack */

  if (type == PARTICLE_TYPE_NEUTRON)
    ptr = (long)RDB[OMPPtr(DATA_PART_PTR_NSTACK, id)];
  else if (type == PARTICLE_TYPE_GAMMA)
    ptr = (long)RDB[OMPPtr(DATA_PART_PTR_GSTACK, id)];
  else
    Die(FUNCTION_NAME, "Invalid particle type");
  
  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Get pointer to last item */

  ptr = LastItem(ptr);

  /* Check type */

  if ((long)RDB[ptr + PARTICLE_TYPE] == PARTICLE_TYPE_DUMMY)
    {
      /* NOTE: Jos tää ei oo omp critical, niin toi historiadatan varaus */
      /* ei jostain kumman syystä toimi. (no daa) */

#ifdef OPEN_MP
#pragma omp critical
#endif

      {
	/* Stack empty, create new item */
	
	if (type == PARTICLE_TYPE_NEUTRON)
	  ptr = NewItem(OMPPtr(DATA_PART_PTR_NSTACK, id), PARTICLE_BLOCK_SIZE);
	else
	  ptr = NewItem(OMPPtr(DATA_PART_PTR_GSTACK, id), PARTICLE_BLOCK_SIZE);
	
	/* Add combined stack size */
	
	WDB[DATA_PART_STACK_SIZE]++;
		
	/* Check limit */
	
	if ((long)RDB[DATA_PART_STACK_SIZE] > 100000000)
	  Die(FUNCTION_NAME, "Stack size exceeds maximum");
	
	/* Allocate memory for history data */
	
	if ((long)RDB[DATA_HIST_LIST_SIZE] > 0)
	  {
	    /* Loop over events */
	    
	    for (n = 0; n < (long)RDB[DATA_HIST_LIST_SIZE]; n++)
	      {
		/* Allocate memory for data */
		
		hst = NewItem(ptr + PARTICLE_PTR_HIST, HIST_BLOCK_SIZE);
		
		/* Reset weight to indicate unused value */
		
		WDB[hst + HIST_WGT] = -1.0;
	      }
	    
	    /* Make list into ring */
	    
	    hst = (long)RDB[ptr + PARTICLE_PTR_HIST];
	    MakeRing(hst);
	  }
      }
    }
  
  /* Remove particle from stack */
  
  RemoveItem(ptr);

  /* Remember pointer to history data */

  hst = (long)RDB[ptr + PARTICLE_PTR_HIST];

  /* Wipe data */

  memset(&WDB[ptr + LIST_DATA_SIZE], 0.0, 
	 (PARTICLE_BLOCK_SIZE - LIST_DATA_SIZE)*sizeof(double));

  /* Put type */

  WDB[ptr + PARTICLE_TYPE] = (double)type;

  /* Put pointer to history data */

  WDB[ptr + PARTICLE_PTR_HIST] = (double)hst;

  /* Check history pointer */

  if (hst > VALID_PTR)
    {
      /* Loop over data */

      do
	{
	  /* Wipe data */
	  
	  memset(&WDB[hst + LIST_DATA_SIZE], 0.0, 
		 (HIST_BLOCK_SIZE - LIST_DATA_SIZE)*sizeof(double));
	  
	  /* Reset weight to indicate unused value */
		
	  WDB[hst + HIST_WGT] = -1.0;

	  /* Pointers to previous */

	  hst = PrevItem(hst);
	}
      while (hst != (long)RDB[ptr + PARTICLE_PTR_HIST]);
    }

  /* Return pointer */
  
  return ptr;
}

/*****************************************************************************/
