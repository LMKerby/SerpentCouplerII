/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : burnupcycle.c                                  */
/*                                                                           */
/* Created:       2011/05/23 (JLe)                                           */
/* Last modified: 2012/01/27 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Loop over burnup history                                     */
/*                                                                           */
/* Comments: the "step" variable indexes steps within current burnup interval*/
/*           while DATA_BURN_STEP  indexes total steps.                      */
/*                                                                           */
/*           See:                                                            */
/*                                                                           */
/*           A.E Isotalo & P.A. Aarnio "Higher Order methods for burnup      */
/*           calculations with Bateman solutions" Ann.Nucl.Energy 38 (2011)  */
/*           pp. 1987-1995.                                                  */
/*                                                                           */
/*           and                                                             */
/*                                                                           */
/*           A.E. Isotalo & P.A. Aarnio "Substep methods for burnup          */
/*           calculations with Bateman solutions" Ann.Nucl.Energy            */
/*           (Submitted)                                                     */
/*                                                                           */
/* for description of the burnup calculation methods used.                   */
/*                                                                           */
/* TODO? tätä vois ehkä  muuttaa niin että asteluvut, aliaskeleet ja tuleeko */
/*       correctori määritellään askeleen aluksi erillisessä funktiossa      */
/*       niin ettei tarkastuksia olisi siellä täällä                         */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "BurnupCycle:"

/*****************************************************************************/

void BurnupCycle()
{
  long dep, type, step, steps, pc;

  /* First loop is over intervals */

  dep = (long)RDB[DATA_BURN_PTR_DEP];
  while (dep > VALID_PTR)
    {
      /* Set normalization (NOTE: toi norm-rakenne ei tämän jälkeen  */
      /* välttämättä toimi enää linkitettynä listana, mutta sillä ei */
      /* pitäisi olla väliä koska sen yli ei loopata enää missään.   */

      WDB[DATA_PTR_NORM] = RDB[dep + DEP_HIS_PTR_NORM];

      /* Get step type and number of steps */

      type = (long)RDB[dep + DEP_HIS_STEP_TYPE];
      steps = (long)RDB[dep + DEP_HIS_N_STEPS];

      /* Put type */

      WDB[DATA_BURN_STEP_TYPE] = (double)type;

      /* Add final step for last interval */

      if (NextItem(dep) < VALID_PTR)
	steps++;

      /* Second loop is over steps */

      for (step = 0; step < steps; step++)
	{
	  /* Predictor-corrector -loop */

          for (pc = 0; pc < 2; pc++)
            {
             /* Set the predictor/corrector status. pc is not used directly */

              if (pc == 0)
                WDB[DATA_BURN_STEP_PC] = PREDICTOR_STEP;
              else
                WDB[DATA_BURN_STEP_PC] = CORRECTOR_STEP;
              
              /* Prepare transport cycle */
              
              PrepareTransportCycle();

	      /* Print material compositions */

	      PrintCompositions(step);
              
              /* Transport calculation cycle if not decay step */
              
              if ((type != DEP_STEP_DEC_STEP) && (type != DEP_STEP_DEC_TOT))
                TransportCycle();
              else
		MatlabOutput();
               
              /* Start burnup timers */
              
              ResetTimer(TIMER_BURNUP);
              StartTimer(TIMER_BURNUP);
              StartTimer(TIMER_BURNUP_TOTAL);
              
	      /* output only at predictor (corresponding to BOS and earlier) */
              
              if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
                {
                  fprintf(out, "Writing depletion output...\n");
              
		  /* Write binary depletion file */

		  WriteDepFile();       

		  /* Print depletion output */

                  PrintDepOutput();     
                  
		  fprintf(out, "OK.\n\n");
                }
              
              /* Break here if final step */
              
              if (step == RDB[dep + DEP_HIS_N_STEPS])
                break;
              
              /* Calculate coefficients for the fit to xs/flux/power */
              
              DepletionPolyFit(dep, step);
              
              /* Set depletion step size */
              
              SetDepStepSize(dep, step);
              
              /* Burnup calculation */
              
              BurnMaterials(dep, step);
              
	      /* Collect material compositions from MPI parallel tasks */

	      CollectBurnData();

              /* Stop burnup timers */
              
              StopTimer(TIMER_BURNUP);
              StopTimer(TIMER_BURNUP_TOTAL);
             
	      /* Add to number of predictor and corrector cycles */

	      if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
		WDB[DATA_BURN_PRED_STEP] = RDB[DATA_BURN_PRED_STEP] + 1.0;
	      else
		WDB[DATA_BURN_CORR_STEP] = RDB[DATA_BURN_CORR_STEP] + 1.0;
 
              /* No corrector if: -User requested none,                      */
	      /*                  -On decay step (flux is zero, CE is exact) */
              /*                  -When flux is zero (from normalization),   */
              /*                   making CE exact                           */

              if (((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_NONE) ||
                  (type == DEP_STEP_DEC_STEP) || (type == DEP_STEP_DEC_TOT) ||
                  (Mean((long)RDB[RES_TOT_FLUX], 0) <= 0.0))
                break;
            }

	  /* Update cumulative burnup and time */

	  WDB[DATA_BURN_CUM_BURNTIME] = RDB[DATA_BURN_CUM_BURNTIME] 
	    + WDB[DATA_BURN_TIME_INTERVAL];
	  WDB[DATA_BURN_CUM_BURNUP] = RDB[DATA_BURN_CUM_BURNUP]
	    +  WDB[DATA_BURN_BURNUP_INTERVAL];

	  /* Update burnup step (total, not in this interval) */
       
	  WDB[DATA_BURN_STEP] = RDB[DATA_BURN_STEP] + 1.0;
	}
      
      /* Next interval */

      dep = NextItem(dep);
    }

  /* Check total time */

  if (RDB[DATA_BURN_CUM_BURNTIME] == 0.0)
    Die(FUNCTION_NAME, "No burnup calculation performed");  
}

/*****************************************************************************/
