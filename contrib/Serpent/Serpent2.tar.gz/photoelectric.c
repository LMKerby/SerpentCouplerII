/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : photoelectric.c                                */
/*                                                                           */
/* Created:       2011/04/15 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Handles photoelectric effect for photons                     */
/*                                                                           */
/* Comments: Production of fluoresence photons is ignored for now            */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "PhotoElectric:"

/*****************************************************************************/

void PhotoElectric(long rea, long part, double E, double x, double y, 
		   double z, double u, double v, double w, long id)
{
  /* Put particle back in stack */
	      
  ToStack(part, id);
}

/*****************************************************************************/
