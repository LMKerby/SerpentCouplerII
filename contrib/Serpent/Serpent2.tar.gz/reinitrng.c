/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : reinitrng.c                                    */
/*                                                                           */
/* Created:       2011/03/03 (TVi)                                           */
/* Last modified: 2011/12/20 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: This routine is used to skip n*2^STRIDE steps forward in the */
/*              random number sequence beginning from parent seed.           */ 
/*                                                                           */
/* Comments: Algorithm taken from MCNP5. Basically calculates                */
/*           g^(n*2^STRIDE)*parentseed+(g^(n*2^STRIDE)-1)/(g-1)*12345mod2^64 */
/*           efficiently.                                                    */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ReInitRNG:"

/*****************************************************************************/

unsigned long ReInitRNG(long n)
{
  unsigned long gen, g, inc, c, gp;
  
  /* Adjust index in MPI mode */
  
  if ((mpiid > 0) && ((long)RDB[DATA_OPTI_MPI_REPRODUCIBILITY] == NO))
    n = n + (long)(mpiid*RDB[DATA_MPI_TOT_PARTICLES]);

  /* Re-initialize RNG */

  n = n<<STRIDE;

  gen = 1;
  g = 2862933555777941757;
  inc = 0;
  c = 12345;

  while(n > 0)
    {
      if((n%2) == 1)
	{
	  gen *= g;
	  inc = inc*g + c;
	}
      
      gp = g + 1;
      g *= g;
      c *= gp;
      
      n = n>>1;
    }  

  return parent_seed*gen + inc;
}

/*****************************************************************************/


#ifdef mmmmmmmmmmmmm

}

/* This routine is used to skip forward 2^STRIDE steps 
   in the random number sequence. (corresponds to "next neutron")
   NOT TO BE USED IN OPEN MP PARALLEL MODE !!! (TVi) */

void Rand64SkipNeutron(unsigned long *seed){

  /* If STRIDE < 12 or STRIDE > 19, no optimized implementation
     available. Skip using significantly slower skiptoneutron
     function. */

#if STRIDE < 12 || STRIDE > 19
  Rand64_SkipToNeutron(seed, *seed, 1);
#endif
  
#if STRIDE==12
  /* For stride = 2^12 =4096 */  
  *seed+=*seed*0xbe3cfc5baadf4000+0x19db40804bfeb000;
#endif
#if STRIDE==13 
  /* For stride = 2^13 =8192 */  
  *seed+=*seed*0xef3ebc67e5be8000+0x5ed877bb93fd6000;
#endif
#if STRIDE==14 
  /* For stride = 2^14 =16384 */  
  *seed+=*seed*0x57f6d7920b7d0000+0x7f99d66317fac000;
#endif
#if STRIDE==15 
  /* For stride = 2^15 =32768 */  
  *seed+=*seed*0xc105aa2d16fa0000+0xb3dfa875eff58000;
#endif
#if STRIDE==16 
  /* For stride = 2^16 =65536 */  
  *seed+=*seed*0x9fff407e2df40000+0xc2b23faadfeb0000;
#endif
#if STRIDE==17 
  /* For stride = 2^17 =131072 */  
  *seed+=*seed*0x846e318c5be80000+0x33483a51bfd60000;
#endif
#if STRIDE==18 
  /* For stride = 2^18 =262144 */  
  *seed+=*seed*0x7f9b2558b7d00000+0x2edf60937fac0000;
#endif
#if STRIDE==19
  /* For stride = 2^19 =524288 */  
  *seed+=*seed*0x23153b16fa00000+0x4fa70e6ff580000 ;
#endif

}

#endif
