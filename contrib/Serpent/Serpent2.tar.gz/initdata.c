/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : initdata.c                                     */
/*                                                                           */
/* Created:       2010/11/21 (JLe)                                           */
/* Last modified: 2012/01/27 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Inits values in main data block                              */
/*                                                                           */
/* Comments: - Tää vaatii vielä paljon työtä                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

/* initdata.c: modified 27.8.2010 - Version 1.1.14 (JLe) */

#define FUNCTION_NAME "InitData:"

/*****************************************************************************/

void InitData()
{
  char tmpstr[MAX_STR];
  time_t t0;
  clock_t cput0;

  /* Set error pointer */

  err = stdout;

  /* Reset pointers */

  WDB = NULL;
  ACE = NULL;
  ASCII = NULL;
  PRIVA = NULL;
  BUF = NULL;
  RES1 = NULL;
  RES2 = NULL;

  /* Set pointer to standard output */
  
  if (mpiid == 0)
    out = stdout;
  else
    {
      out = fopen("/dev/null", "w");
      return;
    }

  /* Allocate memory for main data block */

  ReallocMem(DATA_ARRAY, DATA_FIXED_BLOCK_SIZE);

  /* Allocate memory for ASCII data block to simplify error testing */

  ASCII = (char *)Mem(MEM_ALLOC, (long)(VALID_PTR + 1), sizeof(char));
  
  WDB[DATA_ASCII_DATA_SIZE] = (double)(VALID_PTR + 1);

  /* Init list pointers */

  WDB[DATA_PTR_C0] = NULLPTR;
  WDB[DATA_PTR_S0] = NULLPTR;
  WDB[DATA_PTR_M0] = NULLPTR;
  WDB[DATA_PTR_L0] = NULLPTR;
  WDB[DATA_PTR_T0] = NULLPTR;
  WDB[DATA_PTR_NST0] = NULLPTR;
  WDB[DATA_PTR_GPL0] = NULLPTR;
  WDB[DATA_PTR_TR0] = NULLPTR;
  WDB[DATA_PTR_PB0] = NULLPTR;

  /*
  WDB[DATA_PTR_U0] = NULLPTR;
  WDB[DATA_PTR_I0] = NULLPTR;
  WDB[DATA_PTR_X0] = NULLPTR;
  WDB[DATA_PTR_D0] = NULLPTR;
  WDB[DATA_PTR_E0] = NULLPTR;
  WDB[DATA_PTR_MPL0] = NULLPTR;
  WDB[DATA_PTR_DEP0] = NULLPTR;
  WDB[DATA_PTR_VAR0] = NULLPTR;
  WDB[DATA_PTR_SRC0] = NULLPTR;
  */

  /* Init file names */

  WDB[DATA_PTR_ACEDATA_FNAME_LIST] = NULLPTR;
  WDB[DATA_PTR_DECDATA_FNAME_LIST] = NULLPTR;
  WDB[DATA_PTR_NFYDATA_FNAME_LIST] = NULLPTR;
  WDB[DATA_PTR_SFYDATA_FNAME_LIST] = NULLPTR;
  
  /* Few-group constant generation */

  WDB[DATA_ERG_FG_NG] = 2.0;
  
  /* Misc. pointers */

  /*
  WDB[DATA_PTR_MAJORANT_REA] = NULLPTR;
  WDB[DATA_PTR_ALPHA_REA] = NULLPTR;
  WDB[DATA_PTR_B1_REA] = NULLPTR;
  */



  /* Energy grid data */

  /*
  WDB[DATA_ERG_SET] = 0.0;
  WDB[DATA_ERG_FG_NG] = 2.0;
  WDB[DATA_ERG_FG_PTR_E0] = NULLPTR;
  */

  /* Thinning tolerance and energy boundaries (tarkista noi fotonirajat) */

  WDB[DATA_ERG_TOL] = -1.0;

  WDB[DATA_NEUTRON_EMIN] = 1E-11;
  WDB[DATA_NEUTRON_EMAX] = 20.0;

  WDB[DATA_PHOTON_EMIN] = 1E-3;
  WDB[DATA_PHOTON_EMAX] = 10.0;



  /* Set boundary condition and albedo */

  WDB[DATA_GEOM_BC0] = (double)BC_BLACK;
  WDB[DATA_GEOM_BC1] = (double)BC_BLACK;
  WDB[DATA_GEOM_BC2] = (double)BC_BLACK;
  WDB[DATA_GEOM_BC3] = (double)BC_BLACK;
  WDB[DATA_GEOM_ALBEDO] = 1.0;

  /* Set adf cell flux radius */
  /*
  WDB[DATA_GEOM_ADF_CFLUX_RAD] = 0.2;
  */
  /* Default symmetry */
  /*
  WDB[DATA_GC_SYM] = 0.0;
  */
  /* Parameters for delta-tracking */
  /*
  WDB[DATA_DT_OPTIMIZE] = (double)NO;
  WDB[DATA_DT_THRESH] = 0.1;

  WDB[DATA_DT_PTR_MAT_LIST] = NULLPTR;
  */
  /* Reset number of precursor groups */
  /*
  WDB[DATA_PRECURSOR_GROUPS] = 0.0;
  */
  /* Set initial date */

  time(&t0);
  strcpy(tmpstr, ctime(&t0));
  tmpstr[(int)strlen(tmpstr) - 1] = '\0';
  WDB[DATA_PTR_DATE] = (double)PutText(tmpstr);

  /* Get initial cpu time */

  cput0 = clock();
  WDB[DATA_CPU_T0] = (double)cput0;

  /* Set running mode */

  WDB[DATA_RUNNING_MODE] = (double)RUNNING_MODE_TRANSPORT;

  /* Total fissile mass */
  /*
  WDB[DATA_TOT_FMASS] = -1.0;
  WDB[DATA_BURN_FMASS] = -1.0;
  */
  /* No shuffling */
  /*
  WDB[DATA_BURN_DO_SHUFFLING] = (double)NO;
  */

  /* Set pop, cycles and skip */
  /*
  WDB[DATA_POP] = 5000.0;
  WDB[DATA_CYCLES] = 500.0;
  WDB[DATA_SKIP] = 100.0;

  */
  /* Normalisation */

  WDB[DATA_PTR_NORM] = NULLPTR;
  WDB[DATA_NORM_U235_FISSE] = U235_FISSE;

  /* Initial guess for k-eff */
  /*
  WDB[DATA_CYCLE_KEFF] = 1.0;
  */
  /* Set default random number seed */

  parent_seed = (unsigned long)t0;

  /* Put null pointers to stat variables */
  /*
  for (n = 0; n < RES_STAT_VARIABLES; n++)
    WDB[DATA_LAST_VALUE + n + 1] = NULLPTR;
  */
  
  /* Put null pointer to total xs data block */
  /*
  WDB[DATA_PTR_TOTXS_BLOCK] = NULLPTR;
  */
  /* XS data plotter parameters */

  WDB[DATA_XSPLOT_NE] = -1.0;
  WDB[DATA_XSPLOT_EMIN] = -1.0;
  WDB[DATA_XSPLOT_EMAX] = -1.0;

  /* Null pointers to burnup vectors */
  /*
  WDB[DATA_PTR_BURNUP_STEPS] = NULLPTR;
  WDB[DATA_PTR_BURNDAY_STEPS] = NULLPTR;
  */
  /* Predictor-corrector mode */
  /*
  WDB[DATA_TOT_BURN_PRED_STEPS] = 2.0;
  */
  /* Burnup calculation mode */
  /*
  WDB[DATA_BURN_BUMODE] = (double)BUMODE_CRAM;
  */
  /* List of nuclides in depletion calculation */
  /*
  WDB[DATA_BURN_PTR_DEP_LIST] = NULLPTR;
  */
  /* Transmutation xs mode */
  /*
  WDB[DATA_BURN_TRANSMU_XS_MODE] = 1.0;
  */
  /* Print compositions */

  WDB[DATA_BURN_PRINT_COMP] = (double)NO;
  WDB[DATA_BURN_PRINT_COMP_LIM] = 1.0;

  /* Decay only mode */

  WDB[DATA_BURN_DECAY_CALC] = (double)NO;

  /* Print burnup matrix */
  /*
  WDB[DATA_BURN_PRINT_BUMAT] = (double)NO;
  */
  /* Print histories */
  
  WDB[DATA_OPTI_PRINT_HIS] = (double)NO;
  
  /* Pointer to maximum fp yield vector */
  /*
  WDB[DATA_BURN_PTR_MAX_NFY] = NULLPTR;
  */
  /* Cut-offs for depletion calculation */
  /*
  WDB[DATA_DEP_TTA_CUTOFF]       = 1E-15;
  WDB[DATA_DEP_STABILITY_CUTOFF] = 1E-22;
  WDB[DATA_DEP_FP_YIELD_CUTOFF]  = 0.0;
  WDB[DATA_DEP_XS_FRAC_CUTOFF]   = 0.0;
  */
  WDB[DATA_DEP_HALF_LIFE_CUTOFF] = INFTY;
  WDB[DATA_DEP_TTA_CUTOFF]       = 1E-18;

  /* Decay heating power off */
  /*
  WDB[DATA_DEP_DECAY_HEATING] = (double)NO;
  */
  /* Preserve total mass */
  /*
  WDB[DATA_DEP_PRESERVE_MASS] = (double)NO;
  */
  /* Re-calculate fissile mass in burnup calculation */
  /*
  WDB[DATA_DEP_RECALC_FMASS] = (double)NO;
  */
  /* Pointer to inventory data */
  /*
  WDB[DATA_PTR_INVENTORY] = NULLPTR;
  */
  /* Fission source entropy */

  WDB[DATA_OPTI_ENTROPY_CALC] = (double)NO;

  WDB[DATA_ENTROPY_NX] = 5.0;
  WDB[DATA_ENTROPY_NY] = 5.0;
  WDB[DATA_ENTROPY_NZ] = 5.0;

  WDB[DATA_ENTROPY_XMIN] = -INFTY;
  WDB[DATA_ENTROPY_XMAX] =  INFTY;

  WDB[DATA_ENTROPY_YMIN] = -INFTY;
  WDB[DATA_ENTROPY_YMAX] =  INFTY;

  WDB[DATA_ENTROPY_ZMIN] = -INFTY;
  WDB[DATA_ENTROPY_ZMAX] =  INFTY;

  /* Cell temperature pointer */
  /*
  WDB[DATA_PTR_CELL_TEMP] = NULLPTR;
  */
  /* Soluble absorber */
  /*
  WDB[DATA_PTR_SOLU_ABS] = NULLPTR;
  */
  /* Iteration */
  /*
  WDB[DATA_ITER_GOAL] = 1.0;
  WDB[DATA_ITER_PTR_SURF] = NULLPTR;
  */
  /* Pointer to source point list */
  /*
  WDB[DATA_PTR_SRC_LIST] = NULLPTR;
  */
  /* Source material */
  /*
  WDB[DATA_PTR_SRC_MAT] = NULLPTR;
  */
  /* Cross section grid mode */
  /*
  WDB[DATA_XS_EGRID_MODE] = EGRID_UNI;
  */
  /* Reset fission heating value vector */
  /*
  WDB[DATA_PTR_FISSH] = NULLPTR;
  */
  /* Reset branhing ratio vector */
  /*
  WDB[DATA_PTR_BRANCH] = NULLPTR;
  */
  /* Neutron tail in randomly dispersed medium */
  /*
  WDB[DATA_RND_NN_TAIL_PTS] = 1.0;
  */
  /* CPU type and memory size */
  /*
  WDB[DATA_PTR_CPU_NAME] = NULLPTR;
  WDB[DATA_CPU_MEM] = -INFTY;
  WDB[DATA_CPU_MHZ] = -INFTY;
  */




  /* Microscopic partial total cross section limit for including nuclide */
  /* in reaction lists. */

  WDB[DATA_MIN_TOTXS] = 1E-5;




  /* Number of points for geometry testing TODO: testaa toi versioon 1.1.3 */
  /*
  WDB[DATA_GEOM_TEST_NPS] = 1000.0;
  */  
  
  /* No TLE */
  /*
  WDB[DATA_FORCE_TLE] = (double)NO;
  */

  /* Use unresolved resonance probability tables (turned off by default) */

  WDB[DATA_USE_URES] = (double)NO;
  WDB[DATA_URES_PTR_USE_LIST] = NULLPTR;

  /* Minimum and maximum energies */
  /*
  WDB[DATA_URES_EMIN] =  INFTY;
  WDB[DATA_URES_EMAX] = -INFTY;
  */
  /* Number of skip cycles before iteration */
  /*
  WDB[DATA_SKIP_ITER] = 5.0;
  */
  /* Number of energy bins and index in B1 iteration */
  /*
  WDB[DATA_B1_SPECTRUM_NE] = 500.0;
  WDB[DATA_B1_SPECTRUM_IDX] = -1.0;
  */
  /* B1 mode */
  /*
  WDB[DATA_B1_SPECTRUM_MODE] = B1_MODE_NONE;
  */
  /* Ures mode */
  /*
  WDB[DATA_URES_MODE] = URES_MODE_PRECALC;
  */
  /* Infinite dilution cut-off for unresolved resonance probability tables */
  /*
  WDB[DATA_URES_DILU_CUT] = 0.0;
  */

  /* Core power distribution */
  /*
  WDB[DATA_CORE_PDE_DEPTH] = -1.0;
  */
  /* Collision points */
  /*
  WDB[DATA_PTR_COL_BUF] = NULLPTR;
  WDB[DATA_COL_BUF_PTR_FNAME] = NULLPTR;
  WDB[DATA_COL_BUF_MAX] = -1.0;
  WDB[DATA_COL_BUF_N] = 0.0;
  WDB[DATA_COL_BUF_WRITE_SIZE] = 0.0;
  */
  /* Xenon equilibrium calculation */
  /*
  WDB[DATA_XENON_EQUIL] = (double)NO;
  WDB[DATA_XENON_MAT_LIST] = NULLPTR;
  */
  /* Actinide mass number range for burnup calculation */
  /*
  WDB[DATA_ACT_BURN_MIN_A] = -1.0;
  WDB[DATA_ACT_BURN_MAX_A] = -1.0;
  */

  /* Number of generation in external source k-eff */
  /*
  WDB[DATA_EXT_KEFF_N] = 5.0;
  */
  /* Summation xs mode */
  /*
  WDB[DATA_USE_SUMXS] = (double)YES;
  */
  /* Exclude group constant calculation */
  /*
  WDB[DATA_NO_GC] = (double)NO;
  */
  /* Number of energy points in fission spectrum */
  /*
  WDB[DATA_FISS_SPECTR_NE] = 1000.0;
  */

  /* Plotter */

  WDB[DATA_STOP_AFTER_PLOT] = (double)NO;
  WDB[DATA_PLOTTER_MODE] = (double)NO;

  /* Buffer factor */
  /*
  WDB[DATA_BUF_FACTOR] = -1.0;
  */
  /* Transmutation reaction energy cutoff */
  /*
  WDB[DATA_DEP_TRANSMU_E_CUTOFF] = -1.0;
  */
  /* MPI mode */
  /*
  if (mpitasks == 1)
    WDB[DATA_MPI_MODE] = (double)MPI_MODE_NONE;
  else
    WDB[DATA_MPI_MODE] = (double)MPI_MODE_COLLECT_END;
  */
  /* Population control mode */
  /*
  WDB[DATA_POP_CTRL_MODE] = POP_CTRL_MODE_NUM;
  */
  /* Source buffers from mpi mode 2 */
  /*
  mpi_src_buff1 = NULL;
  mpi_src_buff2 = NULL;
  */
  /* B1 Critical spectrum calculation */
  /*
  WDB[DATA_FUM_NE] = -1.0;
  */

  /* Data options */

  /* Optimization and memory/data options */

  WDB[DATA_OPTI_MODE] = 4.0;
  WDB[DATA_OPTI_UNIONIZE_GRID] = -1.0;
  WDB[DATA_OPTI_RECONSTRUCT_MICROXS] = -1.0;
  WDB[DATA_OPTI_RECONSTRUCT_MACROXS] = -1.0;
  WDB[DATA_OPTI_MACRO_REA_LISTS] = -1.0;
  WDB[DATA_OPTI_INCLUDE_SPECIALS] = (double)NO;

  /* Delta-tracking */

  WDB[DATA_OPT_USE_DT] = (double)YES;
  WDB[DATA_DT_THRESH] = 0.1;

  /* Implicit Monte Carlo */

  WDB[DATA_OPT_IMPL_FISS] = (double)NO;
  WDB[DATA_OPT_IMPL_CAPT] = (double)NO;
  WDB[DATA_OPT_IMPL_NXN] = (double)YES;
  WDB[DATA_OPT_ROULETTE_W0] = 0.001;
  WDB[DATA_OPT_ROULETTE_P0] = 1.0/6.0;

  /* Run-time variables */

  WDB[DATA_CYCLE_KEFF] = 1.0;

  /* Simulation mode */

  WDB[DATA_SIMULATION_MODE] = (double)SIMULATION_MODE_CRIT;
  WDB[DATA_NBATCH] = 1000.0;
  WDB[DATA_CYCLES] = 500.0;
  WDB[DATA_SKIP] = 10.0;
  WDB[DATA_COLLECT_INTERVAL] = 1.0;

  /* OpenMP stuff */

  WDB[DATA_OMP_MAX_THREADS] = 1.0;

  /****************************************************************/

  /* uudet: */

  /* Allocate empty memory ACE array to deal with zero pointers */

  WDB[DATA_PTR_ACE0] = NULLPTR;
  ReallocMem(ACE_ARRAY, DATA_FIXED_BLOCK_SIZE);

  WDB[DATA_PTR_ACE_NFY_DATA] = NULLPTR;
  WDB[DATA_PTR_ACE_SFY_DATA] = NULLPTR;

  /* Root universe */

  WDB[DATA_PTR_ROOT_UNIVERSE] = (double)PutText("0");

  /* History list size */

  WDB[DATA_HIST_LIST_SIZE] = -50.0;

  /* Monte Carlo volume calculation */

  WDB[DATA_VOLUME_MC_NMAX] = -1.0;
  WDB[DATA_VOLUME_MC_TMAX] = -1.0;
  WDB[DATA_VOLUME_MC_EMAX] = -1.0;

  /* DBRC */

  WDB[DATA_USE_DBRC] = (double)NO;
  WDB[DATA_PTR_DBRC] = NULLPTR;
  WDB[DATA_DBRC_EMIN] = 0.4E-6;
  WDB[DATA_DBRC_EMAX] = 210E-6;

  /* Energy cut-off for transmutation reactions */

  WDB[DATA_BURN_ENECUT] = 10.0;

  /* Normalization */

  WDB[DATA_NORM_BURN] = BURN_NORM_ALL;

  /* Burnup mode */

  WDB[DATA_BURN_BUMODE] = (double)BUMODE_CRAM;
  WDB[DATA_BU_SPECTRUM_COLLAPSE] = -1.0;

  /* CRAM:n asteluku */

  WDB[DATA_BURN_CRAM_K] = 8.0;

  /* Predictor-corrector calculation */

  WDB[DATA_BURN_PRED_TYPE] = (double)PRED_TYPE_CONSTANT;
  WDB[DATA_BURN_PRED_NSS] = 1.0;
  WDB[DATA_BURN_CORR_TYPE] = (double)CORR_TYPE_LINEAR;
  WDB[DATA_BURN_CORR_NSS] = 1.0;

  /* Core power distribution */

  WDB[DATA_CORE_PDE_DEPTH] = -1.0;

  /* Source biasing */

  WDB[DATA_SBIAS_PTR_COL_MESH] = NULLPTR;
  WDB[DATA_SBIAS_ORD] = 1.0;

  /* Energy grid for coarse multi-group xs */

  WDB[DATA_COARSE_MG_NE] = 4000.0;
  WDB[DATA_OPTI_MG_MODE] = -1.0;

  /* Reset minimum and maximum energies of cross section data */

  WDB[DATA_NEUTRON_XS_EMIN] = INFTY;
  WDB[DATA_NEUTRON_XS_EMAX] = -INFTY;

  WDB[DATA_PHOTON_XS_EMIN] = INFTY;
  WDB[DATA_PHOTON_XS_EMAX] = -INFTY;

  /* Delayed nubar flag */

  WDB[DATA_USE_DELNU] = -1.0;

  /* Doppler broadening mode and temperature feedback */

  WDB[DATA_DOPPLER_MODE] = DOPPLER_MODE_NONE;
  WDB[DATA_USE_TFB] = (double)NO;

  /* Ures energy boundaries */

  WDB[DATA_URES_EMIN] = INFTY;
  WDB[DATA_URES_EMAX] = -INFTY;

  /* Energy bin structure for burnup caluclation */

  WDB[DATA_BU_MG_EGRID_NE] = 1.0;
  WDB[DATA_BU_MG_PTR_GRID] = NULLPTR;

  /* Fundamental mode calculation off */

  WDB[DATA_OPTI_FUM_CALC] = (double)NO;

  /* Shared scoring buffer */

  WDB[DATA_OPTI_SHARED_BUF] = (double)NO;

  /* Shared RES2 array */

  WDB[DATA_OPTI_SHARED_RES2] = (double)NO;

  /* Replay mode */

  WDB[DATA_OPTI_REPLAY] = (double)NO;

  /* Reproducibility in OpenMP and MPI modes */

  WDB[DATA_OPTI_OMP_REPRODUCIBILITY] = (double)YES;
  WDB[DATA_OPTI_MPI_REPRODUCIBILITY] = (double)NO;
  
  /***************************************************************************/
}

/*****************************************************************************/
