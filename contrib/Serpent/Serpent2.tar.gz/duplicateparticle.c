/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : duplicateparticle.c                            */
/*                                                                           */
/* Created:       2011/03/09 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Duplicates particle                                          */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "DuplicateParticle:"

/*****************************************************************************/

long DuplicateParticle(long ptr, long id)
{
  long new, hst0, hst1;

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Get particle from stack */

  new = FromStack((long)RDB[ptr + PARTICLE_TYPE], id);

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(new)", DATA_ARRAY, new);

  /* Get history pointers */

  hst0 = (long)RDB[ptr + PARTICLE_PTR_HIST];
  hst1 = (long)RDB[new + PARTICLE_PTR_HIST];
  
  /* Copy data */

  memcpy(&WDB[new + LIST_DATA_SIZE], &RDB[ptr + LIST_DATA_SIZE],
	 (PARTICLE_BLOCK_SIZE - LIST_DATA_SIZE)*sizeof(double));

  /* Check history pointer */

  if (hst0 > VALID_PTR)
    {
      /* Loop over data */

      do
	{
	  /* Check second pointer */

	  CheckPointer(FUNCTION_NAME, "(hst1)", DATA_ARRAY, hst1);

	  /* Copy data */

	  memcpy(&WDB[hst1 + LIST_DATA_SIZE], &RDB[hst0 + LIST_DATA_SIZE],
		 (HIST_BLOCK_SIZE - LIST_DATA_SIZE)*sizeof(double));

	  /* Pointers to previous */

	  hst0 = PrevItem(hst0);
	  hst1 = PrevItem(hst1);
	}
      while (hst0 != (long)RDB[ptr + PARTICLE_PTR_HIST]);

      /* Put pointer */

      WDB[new + PARTICLE_PTR_HIST] = (double)hst1;
    }

  /* Return pointer */
  
  return new;
}

/*****************************************************************************/
