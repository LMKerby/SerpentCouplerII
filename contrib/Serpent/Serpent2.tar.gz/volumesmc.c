/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : volumesmc.c                                    */
/*                                                                           */
/* Created:       2010/11/10 (JLe)                                           */
/* Last modified: 2012/01/18 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates volumes by Monte Carlo simulation                 */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "VolumesMC"

/*****************************************************************************/

void VolumesMC()
{
  long cell, mat, ptr, loc0, nt, idx, m, nmax, nb, id;
  unsigned long seed;
  double xmin, xmax, ymin, ymax, zmin, zmax, x, y, z, vol;
  double max, err, tmax, emax, t, val, est, diff;

  /* Cut-offs */

  nmax = (long)RDB[DATA_VOLUME_MC_NMAX];
  tmax = RDB[DATA_VOLUME_MC_TMAX];
  emax = RDB[DATA_VOLUME_MC_EMAX];

  /* Check if calculation is required */

  if ((nmax < 0) && (tmax < 0.0) && (emax < 0.0))
    return;

  fprintf(out, "Calculating material volumes by Monte Carlo...\n");

  /***************************************************************************/

  /***** Allocate memory for statistics **************************************/

  /* Reset stat pointer */

  loc0 = -1;

  /* Loop over materials */

  mat = RDB[DATA_PTR_M0];		
  while (mat > VALID_PTR)
    {
      /* Allocate memory for volume */

      ptr = NewStat("VOLUME", 1, 1);
      WDB[mat + MATERIAL_PTR_MC_VOLUME] = (double)ptr;      

      /* Remember pointer to first */

      if (loc0 < 0)
	loc0 = ptr;

      /* Next */
      
      mat = NextItem(mat);
    }

  /***************************************************************************/

  /***** Monte carlo volume calculation **************************************/

  /* Get geometry boundaries */

  xmin = RDB[DATA_GEOM_MINX];
  xmax = RDB[DATA_GEOM_MAXX];
  ymin = RDB[DATA_GEOM_MINY];
  ymax = RDB[DATA_GEOM_MAXY];
  zmin = RDB[DATA_GEOM_MINZ];
  zmax = RDB[DATA_GEOM_MAXZ];

  /* Calculate total volume */

  vol = (xmax - xmin)*(ymax - ymin);
  
  /* Check dimension */
  
  if ((long)RDB[DATA_GEOM_DIM] == 3)
    {
      /* Add axial dimension to volume */
      
      vol = vol*(zmax - zmin);
    }

  /* Start timer */

  StartTimer(TIMER_VOLUME_CALC);

  /* Number of samples per batch */

  if (nmax > 0)
    nt = (long)(nmax/100.0);
  else
    nt = 100000;

  /* Reset counters */

  nb = 0;

  /* Loop over batches */

  while (1 != 2)
    {

#ifdef OPEN_MP
#pragma omp parallel private (m, idx, seed, ptr, x, y, z, cell, mat, id)
#endif
      {
	/* Loop over points */

#ifdef OPEN_MP
#pragma omp for      
#endif
	for (m = 0; m < nt; m++)
	  {
	    /* Get OpenMP thread num */

	    id = OMP_THREAD_NUM;

	    /* Calculate index */
	    
	    idx = nb*nt + m + 1;

	    /* Init random number sequence */
      
	    seed = ReInitRNG(idx);
      
	    /* Put seed in private data */
      
	    ptr = (long)RDB[DATA_PTR_RNG_SEED];
	    PutPrivateData(ptr, seed, id);
      	    
	    /* Sample point */
	    
	    x = RandF(id)*(xmax - xmin) + xmin;
	    y = RandF(id)*(ymax - ymin) + ymin;

	    if ((long)RDB[DATA_GEOM_DIM] == 3)
	      z = RandF(id)*(zmax - zmin) + zmin;
	    else
	      z = 0.0;
	    
	    /* Find position */
	    
	    if ((cell = WhereAmI(x, y, z, 1.0, 0.0, 0.0, id)) < 0)
	      Error(0, "Geometry error at %E %E %E", x, y, z);
	    
	    /* Get material pointer */
	    
	    if ((mat = (long)RDB[cell + CELL_PTR_MAT]) > VALID_PTR)
	      {
		/* Score point estimator */
		
		ptr = (long)RDB[mat + MATERIAL_PTR_MC_VOLUME];
		AddBuf(vol/((double)nt), 1.0, ptr, id, 0);
	      }
	  }
      }

      /* Update batch number */

      nb++;

      /* Reduce scoring buffer */

      ReduceBuffer();

      /* Maximum error */

      max = 0.0;

      /* Loop over statistics */
      
      ptr = loc0;      
      while (ptr > VALID_PTR)
	{
	  /* Collect data */

	  val = BufVal(ptr, 0);
	  AddStat(val, ptr, 0);

	  /* Get relative error */

	  err = RelErr(ptr, 0);

	  /* Compare maximum error */

	  if (err > max)
	    max = err;	     
	  
	  /* Next */
	  
	  ptr = NextItem(ptr);
	}

      /* Clear buffer */
	  
      ClearBuf();
	
      /* Get time */

      t = TimerVal(TIMER_VOLUME_CALC);

      if (nb == 1)
	fprintf(out, "\nEstimated calculation time: %s\n",
		TimeStr(t*nmax/nt));

      /* Check batch cut-off */
      
      if ((nmax > 0) && (nb*nt >= nmax))
	{
	  fprintf(out, "Realized calculation time:  %s\n\n",
		  TimeStr(t));
	  break;
	}
      
      /* Check time cut-off */

      if ((tmax > 0.0) && (t > tmax))
	break;
      
      /* Check error cut-off */
      
      if ((emax > 0.0) && (max > 0.0) && (max < emax))
	break;
    }
  
  /* Put volumes */

  mat = RDB[DATA_PTR_M0]; 		
  while (mat > VALID_PTR)
    {
      /* Pointer to statistics */

      ptr = (long)RDB[mat + MATERIAL_PTR_MC_VOLUME];

      /* Given or calculated volume */

      vol = RDB[mat + MATERIAL_VOLUME];

      /* Estimated volume, error and relative difference */

      est = Mean(ptr, 0);
      err = RelErr(ptr, 0);
      diff = est/vol - 1.0;

      /* Print */

      if ((vol > ZERO) && (vol < INFTY))
	{
	  if (diff > 1.0)
	  fprintf(out, "Material %-12s : %1.4E %1.4E (%5.3f) :   > 1.0\n", 
		GetText(mat + MATERIAL_PTR_NAME), vol, est, err);
	  else if (diff < -1.0)
	    fprintf(out, "Material %-12s : %1.4E %1.4E (%5.3f) :  < -1.0\n", 
		  GetText(mat + MATERIAL_PTR_NAME), vol, est, err);
	  else
	  fprintf(out, "Material %-12s : %1.4E %1.4E (%5.3f) : %7.3f\n", 
		GetText(mat + MATERIAL_PTR_NAME), vol, est, err, diff);
	}
      else
	fprintf(out, 
		"Material %-12s :        N/A %1.4E (%5.3f) :     N/A\n", 
		GetText(mat + MATERIAL_PTR_NAME), est, err);

      /* Put volume if not given */

      if (RDB[mat + MATERIAL_VOLUME_GIVEN] == 0.0)
	WDB[mat + MATERIAL_VOLUME] = Mean(ptr, 0);


      /* Next */
      
      mat = NextItem(mat);
    }

  fprintf(out, "OK.\n\n");

  /***************************************************************************/
}

/*****************************************************************************/
