/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : reactiontargetzai.c                            */
/*                                                                           */
/* Created:       2010/09/10 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates ZAI for daughter nuclide after decay or           */
/*              transmutation reaction. Return ZAI, -1 if neutron-induced    */
/*              fission, -2 if spontaneous fission or 0 if reaction doesn't  */
/*              change the nuclide (used also for natural elements).         */
/*                                                                           */
/* Comments: - Reaktiomoodeja ei oo tarkistettu                              */
/*           - Decay reation MT's are defined as MT = 10000 + RTYP           */
/*           - Secondaries are defined as MT = product ZA + 20000            */
/*           - Tää ei ota nyt huomioon sitä että nuklidi voi "hävitä"        */
/*             kokonaan, esim B10(n,t2a) tuottaa ZAI:n 0. Mutta vaikuttaako  */
/*             se?                                                           */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ReactionTargetZAI:"

/*****************************************************************************/

long ReactionTargetZAI(long rea)
{
  long nuc, ZAI, ZA, Z, A, I, new, diff, mt, sta;

  /* Exit if sum or special reaction */

  if (((long)RDB[rea + REACTION_TYPE] == REACTION_TYPE_SPECIAL) ||
      ((long)RDB[rea + REACTION_TYPE] == REACTION_TYPE_SUM))
    return 0;

  /* Get pointer to nuclide */

  nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

  /* Get ZAI */

  ZAI = (long)RDB[nuc + NUCLIDE_ZAI];

  /* Get ZA */

  ZA = (long)(ZAI/10.0);

  /* Separate Z and A */
      
  Z = (long)((double)ZA/1000.0);
  A = ZA - 1000*Z;
  
  /* Get mt */

  mt = (long)RDB[rea + REACTION_MT];

  /* Get target isomeric state */
  
  sta = (long)RDB[rea + REACTION_RFS];

  /* Change mt of (n,t2a) to (n,2a) for B-10 */

  if ((ZAI == 50100) && (mt == 113))
    mt = 108;

  /* Check natural (branching must be excluded) */

  if ((mt < 20000) && (A == 0))
    return 0;
  
  /* Get I */
  
  I = ZAI - 10*ZA;

  /* Reset value */

  new = 0;

  /* Neutron reactions */
  
  switch (mt)
    {
    case 16:
      {
	/* (n,2n) */
	
	new = (10*(ZA + 1 - 2*1) + sta);

	break;
      }
    case 17:
      {
	/* (n,3n) */
	
	new = (10*(ZA + 1 - 3*1) + sta);

	break;
      }
    case 18:
    case 19:
    case 20:
    case 21:
    case 38:
      {
	/* (n,f) */

	return FISSION_YIELD_TYPE_NFY;
      }
    case 22:
      {
	/*(n,na) */
	
	new = (10*(ZA + 1 - (1 + 2004)) + sta);

	break;
      }
    case 23:
      {
	/* (n,n3a) */
	
	new = (10*(ZA + 1 - (1 + 3*2004)) + sta);

	break;
      }
    case 24:
      {
	/* (n,2na) */

	new = (10*(ZA + 1 - (2*1 + 2004)) + sta);

	break;
      }
    case 25:
      {
	/* (n,3na) */
	
	new = (10*(ZA + 1 - (3*1 + 2004)) + sta);

	break;
      }
    case 28:
      {
	/* (n,np) */
	
	new = (10*(ZA + 1 - (1 + 1001)) + sta);

	break;
      }
    case 29:
      {
	/* (n,n2a) */

	new = (10*(ZA + 1 - (1 + 2*2004)) + sta);

	break;
      }
    case 30:
      {
	/* (n,2n2a) */

	new = (10*(ZA + 1 - (2*1 + 2*2004)) + sta);

	break;
      }
    case 32:
      {
	/* (n,nd) */

	new = (10*(ZA + 1 - (1 + 1002)) + sta);

	break;
      }
    case 33:
      {
	/* (n,nt) */
	
	new = (10*(ZA + 1 - (1 + 1003)) + sta);

	break;
      }
    case 34:
      {
	/* (n,nHe-3) */
	
	new = (10*(ZA + 1 - (1 + 2003)) + sta);

	break;
      }
    case 35:
      {
	/* (n,nd2a) */

	new = (10*(ZA + 1 - (1 + 1002 + 2*2004)) + sta);

	break;
      }
    case 36:
      {
	/* (n,nt2a) */
	
	new = (10*(ZA + 1 - (1 + 1003 + 2*2004)) + sta);

	break;
      }
    case 37:
      {
	/* (n,4n) */
	
	new = (10*(ZA + 1 - 4*1) + sta);

	break;
      }
    case 41:
      {
	/* (n,2np) */
	
	new = (10*(ZA + 1 - (2*1 + 1001)) + sta);

	break;
      }
    case 42:
      {
	/* (n,3np) */
	
	new = (10*(ZA + 1 - (3*1 + 1001)) + sta);

	break;
      }
    case 44:
      {
	/* (n,n2p) */
	
	new = (10*(ZA + 1 - (1 + 2*1001)) + sta);

	break;
      }
    case 45:
      {
	/* (n,npa) */
	
	new = (10*(ZA + 1 - (1 + 1001 + 2004)) + sta);

	break;
      }
    case 102:
      {
	/* (n,g) */

	new = (10*(ZA + 1) + sta);

	break;
      }
    case 103:
      {
	/* (n,p) */

	new = (10*(ZA + 1 - 1001) + sta);

	break;
      }
    case 104:
      {
	/* (n,d) */

	new = (10*(ZA + 1 - 1002) + sta);

	break;
      }
    case 105:
      {
	/* (n,t) */
	
	new = (10*(ZA + 1 - 1003) + sta);

	break;
      }
    case 106:
      {
	/* (n,He-3) */
	
	new = (10*(ZA + 1 - 2003) + sta);

	break;
      }
    case 107:
      {
	/* (n,a) */
	
	new = (10*(ZA + 1 - 2004) + sta);

	break;
      }
    case 108:
      {
	/* (n,2a) */
	
	new = (10*(ZA + 1 - 2*2004) + sta);

	break;
      }
    case 109:
      {
	/* (n,3a) */
	
	new = (10*(ZA + 1 - 3*2004) + sta);

	break;
      }
    case 111:
      {
	/* (n,2p) */
	
	new = (10*(ZA + 1 - 2*1001) + sta);

	break;
      }
    case 112:
      {
	/* (n,pa) */
	
	new = (10*(ZA + 1 - (1001 + 2004)) + sta);

	break;
      }
    case 113:
      {
	/* (n,t2a) */
	
	new = (10*(ZA + 1 - (1003 + 2*2004)) + sta);

	break;
      }
    case 114:
      {
	/* (n,d2a) */
	
	new = (10*(ZA + 1 - (1002 + 2*2004)) + sta);

	break;
      }
    case 115:
      {
	/* (n,pd) */
	
	new = (10*(ZA + 1 - (1001 + 1002)) + sta);

	break;
      }
    case 116:
      {
	/* (n,pt) */
	
	new = (10*(ZA + 1 - (1001 + 1003)) + sta);

	break;
      }
    case 117:
      {
	/* (n,da) */
	
	new = (10*(ZA + 1 - (1002 + 2004)) + sta);

	break;
      }
    }

  /* Decay reactions */
  
  switch (mt - 10000)
    {
    case 1:  
      {
	/* Beta decay */
	
	new = (10*(ZA + 1000) + sta);

	break;
      }
    case 2:
      {
	/* Electron capture / positron emission */
	
	new = (10*(ZA - 1000) + sta);

	break;
      }
    case 3:
      {
	/* Isomeric transition */

	if (I == 0)
	  Die(FUNCTION_NAME, 
	      "Isomeric transition from ground state (ZA = %ld, mt = %ld)",
	      ZA, mt);
	else
	  new = (10*ZA);

	break;
      }
    case 4:
      {
	/* Alpha decay */
	
	new = (10*(ZA - 2004) + sta);

	break;
      }
    case 5:
      {
	/* Neutron emission */
	
	new = (10*(ZA - 1) + sta);

	break;
      }
    case 6:
      {
	/* Spontaneous fission */
	
	return FISSION_YIELD_TYPE_SFY;
      }
    case 7: 
      {
	/* Proton emission */
	
	new = (10*(ZA - 1001) + sta);

	break;
      }
    }

  /* Additional branching modes to account for secondaries */

  if (mt > 20000)
    return (10*(mt - 20000));

  /* Partial (n,p) reactions */

  if ((mt > 599) && (mt < 650))
    new = (10*(ZA + 1 - 1001) + sta);

  /* Partial (n,d) reactions */

  if ((mt > 649) && (mt < 700))
    new = (10*(ZA + 1 - 1002) + sta);

  /* Partial (n,t) reactions */

  if ((mt > 699) && (mt < 750))
    new = (10*(ZA + 1 - (1 + 1003)) + sta);

  /* Partial (n,He-3) reactions */
  
  if ((mt > 749) && (mt < 800))
    new = (10*(ZA + 1 - 2003) + sta);

  /* Partial (n,a) reactions */

  if ((mt > 799) && (mt < 850))
    new = (10*(ZA + 1 - 2004) + sta);

  /* Partial (n,2n) reactions */

  if (((mt > 874) && (mt < 892)))
    new = (10*(ZA + 1 - 2*1) + sta);

  /* Check if no match */
  
  if (new == 0)
    return 0;

  /* Calculate difference between old and new ZA */

  diff = (long)((double)new/10.0) - (long)((double)ZAI/10.0);

  /* Check some values */

  if ((diff != 1000) && (diff > 1))
    Die(FUNCTION_NAME, "mt = %ld: %ld --> %ld (%ld)", mt, ZAI, new, diff);
  else if ((diff == 0) && (I == 0) && (sta == 0))
    Die(FUNCTION_NAME, "mt = %ld: %ld --> %ld (%ld)", mt, ZAI, new, diff);
  else if (diff < -3*2004 - 1)
    Die(FUNCTION_NAME, "mt = %ld: %ld --> %ld (%ld)", mt, ZAI, new, diff);

  /* Return new ZAI */

  return new;
}

/*****************************************************************************/
