/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : main.c                                         */
/*                                                                           */
/* Created:       2011/11/29 (JLe)                                           */
/* Last modified: 2011/12/22 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Finalizes MPI before exiting program                         */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"

#define FUNCTION_NAME "FinalizeMPI:"

/*****************************************************************************/

void FinalizeMPI()
{
#ifdef MPI

  int rc;

  /* Synchronise */

  MPI_Barrier(MPI_COMM_WORLD);

  /* Finalize */

  rc = MPI_Finalize();

#endif
}

/*****************************************************************************/
