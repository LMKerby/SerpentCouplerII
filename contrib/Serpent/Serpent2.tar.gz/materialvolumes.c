/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : materialvolumes.c                              */
/*                                                                           */
/* Created:       2011/07/03 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates material volumes from cell volumes                */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "MaterialVolumes:"

/*****************************************************************************/

void MaterialVolumes()
{
  long mat, cell, n;
  double vol;

  /* Reset volumes */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Reset volume */

      WDB[mat + MATERIAL_VOLUME] = 0.0;

      /* Next material */

      mat = NextItem(mat);
    }

  /* Loop over cells */

  cell = (long)RDB[DATA_PTR_C0];
  while (cell > VALID_PTR)
    {
      /* Get volume */

      vol = RDB[cell + CELL_VOLUME];

      /* Get multiplicity */

      if ((n = (long)RDB[cell + CELL_VOL_COUNT]) == 0)
	Die(FUNCTION_NAME, "Cell %s not included in volume calculation",
	    GetText(cell + CELL_PTR_NAME));

      /* Add to material volume */
      
      if ((mat = (long)RDB[cell + CELL_PTR_MAT]) > VALID_PTR)
	WDB[mat + MATERIAL_VOLUME] = RDB[mat + MATERIAL_VOLUME] + n*vol;

      /* Next item */

      cell = NextItem(cell);
    }

  /* Override user-given values */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Put value if given */

      if ((vol = RDB[mat + MATERIAL_VOLUME_GIVEN]) > 0.0)
	WDB[mat + MATERIAL_VOLUME] = vol;

      /* Next material */

      mat = NextItem(mat);
    }
}

/*****************************************************************************/
