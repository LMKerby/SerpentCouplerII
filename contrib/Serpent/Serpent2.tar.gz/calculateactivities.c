/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : calculateactivities.c                          */
/*                                                                           */
/* Created:       2011/04/15 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates activities, decay heat and spontaneous fission    */
/*              rates for materials                                          */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CalculateActivities:"

/*****************************************************************************/

void CalculateActivities()
{
  long mat, iso, nuc, fail;
  double vol, adens, A, H, SF;

  /* Reset total data */

  WDB[DATA_TOT_ACTIVITY] = 0.0;
  WDB[DATA_TOT_SFRATE] = 0.0;
  WDB[DATA_TOT_DECAY_HEAT] = 0.0;
  WDB[DATA_ACT_ACTIVITY] = 0.0;
  WDB[DATA_ACT_DECAY_HEAT] = 0.0;
  WDB[DATA_FP_ACTIVITY] = 0.0;
  WDB[DATA_FP_DECAY_HEAT] = 0.0;

  /* Reset fail flag */

  fail = NO;

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Reset material-wise values */

      WDB[mat + MATERIAL_ACTIVITY] = 0.0;
      WDB[mat + MATERIAL_SFRATE] = 0.0;
      WDB[mat + MATERIAL_DECAY_HEAT] = 0.0;
      
      /* Check physical flag */

      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_PHYSICAL_MAT)
	{
	  /* Get volume */

	  vol = RDB[mat + MATERIAL_VOLUME];

	  /* Loop over composition */

	  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	  while (iso > VALID_PTR)
	    {
	      /* Pointer to nuclide */
	      
	      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

	      /* Get atomic density */
	      
	      adens = RDB[iso + COMPOSITION_ADENS];

	      /* Check if decay constant is given and volume is not */

	      if ((vol == 0.0) && (RDB[nuc + NUCLIDE_LAMBDA]))
		fail = YES;

	      /* Calculate activity and decay heat */
	      
	      A = vol*adens*RDB[nuc + NUCLIDE_LAMBDA]*1E+24;
	      H = A*RDB[nuc + NUCLIDE_DECAY_E]*MEV;
	      SF = A*RDB[nuc + NUCLIDE_SFBR];

	      /* Check values */

	      CheckValue(FUNCTION_NAME, "A", "", A, 0, 1E+30);
	      CheckValue(FUNCTION_NAME, "H", "", H, 0, 1E+30);
	      CheckValue(FUNCTION_NAME, "SF", "", SF, 0, A);

	      /* Add to totals */
		      
	      WDB[DATA_TOT_ACTIVITY] = RDB[DATA_TOT_ACTIVITY] + A;
	      WDB[DATA_TOT_DECAY_HEAT] = RDB[DATA_TOT_DECAY_HEAT] + H;
	      WDB[DATA_TOT_SFRATE] = RDB[DATA_TOT_SFRATE] + SF;
	      
	      /* Add to burnable material values */

	      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
		{
		  WDB[DATA_BURN_DECAY_HEAT] = RDB[DATA_BURN_DECAY_HEAT] + H;
		  WDB[DATA_BURN_SFRATE] = RDB[DATA_BURN_SFRATE] + SF;
		}

	      /* Add partials */

	      if ((long)RDB[nuc + NUCLIDE_Z] > 89)
		{
		  WDB[DATA_ACT_ACTIVITY] = RDB[DATA_ACT_ACTIVITY] + A;
		  WDB[DATA_ACT_DECAY_HEAT] = RDB[DATA_ACT_DECAY_HEAT] + H;
		}

	      /* Add to material data */

	      WDB[mat + MATERIAL_ACTIVITY] = RDB[mat + MATERIAL_ACTIVITY] + A;

	      WDB[mat + MATERIAL_DECAY_HEAT] =
		RDB[mat + MATERIAL_DECAY_HEAT] + H;

	      WDB[mat + MATERIAL_SFRATE] = RDB[mat + MATERIAL_SFRATE] + SF;
 
	      /* Next isotope */

	      iso = NextItem(iso);
	    }
	}

      /* Next material */

      mat = NextItem(mat);
    }

  /* Reset data if fail flag is set */

  if (fail == YES)
    {
      WDB[DATA_TOT_ACTIVITY] = 0.0;
      WDB[DATA_TOT_SFRATE] = 0.0;
      WDB[DATA_TOT_DECAY_HEAT] = 0.0;
      WDB[DATA_BURN_SFRATE] = 0.0;
      WDB[DATA_BURN_DECAY_HEAT] = 0.0;
      WDB[DATA_ACT_ACTIVITY] = 0.0;
      WDB[DATA_ACT_DECAY_HEAT] = 0.0;
      WDB[DATA_FP_ACTIVITY] = 0.0;
      WDB[DATA_FP_DECAY_HEAT] = 0.0;
    }  
}

/*****************************************************************************/
