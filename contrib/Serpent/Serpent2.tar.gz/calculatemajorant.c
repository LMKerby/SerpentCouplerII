/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : calculatemajorant.c                            */
/*                                                                           */
/* Created:       2011/01/06 (JLe)                                           */
/* Last modified: 2011/11/10 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates majorant for a delta-tracking or DBRC             */
/*                                                                           */
/* Comments: - NOTE: Tää pitää nimetä DBRC-majorantiksi, tms.                */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CalculateMajorant:"

/*****************************************************************************/

void CalculateMajorant(long rea0, double kT)
{
  long nuc, erg, ne, loc0, loc1, loc2, n, i;
  double Emin, Emax, ar, max, f, E;

  /* Check reaction pointer */

  CheckPointer(FUNCTION_NAME, "(rea0)", DATA_ARRAY, rea0);

  /* Get pointer to energy grid */

  erg = (long)RDB[rea0 + REACTION_PTR_EGRID];
  CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);

  /* Pointer to energy array */

  loc0 = (long)RDB[erg + ENERGY_GRID_PTR_DATA];
  CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

  /* Number of points */

  ne = (long)RDB[erg + ENERGY_GRID_NE];

  /* Check that data begins from zero */

  if ((long)RDB[rea0 + REACTION_XS_I0] != 0)
    Die(FUNCTION_NAME, "Data does not begin from zero");

  /* Check if data exists */
  
  if ((loc1 = (long)RDB[rea0 + REACTION_PTR_MAJORANT_XS]) < VALID_PTR)
    Die(FUNCTION_NAME, "Memory not allocated");
  else
    {
      /* Reset data */

      memset(&WDB[loc1], 0.0, ne*sizeof(double));
    }

  /* Pointer to nuclide data */
  
  nuc = (long)RDB[rea0 + REACTION_PTR_NUCLIDE];
  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
  
  /* Check that data is at 0K */
  
  if (RDB[nuc + NUCLIDE_TEMP] != 0.0)
    Die(FUNCTION_NAME, "Nuclide %s is not at 0K temperature",
	GetText(nuc + NUCLIDE_PTR_NAME));
  
  /* AWT/kT */
  
  ar = RDB[nuc + NUCLIDE_AWR]/kT;
  
  /* Pointer to cross section data */
  
  loc2 = RDB[rea0 + REACTION_PTR_XS];
  CheckPointer(FUNCTION_NAME, "(loc2)", DATA_ARRAY, loc2);
  
  /* Loop over energy grid */
  
  for (n = 0; n < ne; n++)
    {
      /* Get energy */
      
      E = RDB[loc0 + n];
      
      /* Calculate factor */
      
      f = (1.0 + 4.0/sqrt(ar*E))*(1.0 + 4.0/sqrt(ar*E));
      
      /* Check value */
      
      CheckValue(FUNCTION_NAME, "f", "", f, 1.0, INFTY);
      
      /* Calculate limits */
      
      if ((Emin = E/f) < RDB[erg + ENERGY_GRID_EMIN])
	Emin = RDB[erg + ENERGY_GRID_EMIN];
      
      if ((Emax = E*f) > RDB[erg + ENERGY_GRID_EMAX])
	Emax = RDB[erg + ENERGY_GRID_EMAX];
      
      /* Get maximum of three points: n - 1, n, n + 1 */
      
      max = RDB[loc2 + n];
      
      if ((n > 0) && (max < RDB[loc2 + n - 1]))
	max = RDB[loc2 + n - 1];
      
      if ((n < ne - 1) && (max < RDB[loc2 + n + 1]))
	max = RDB[loc2 + n + 1];
      
      /* Find maximum below energy */
      
      i = n;
      while ((i > -1) && (RDB[loc0 + i] > Emin))
	{
	  /* Compare */
	  
	  if (RDB[loc2 + i] > max)
	    max = RDB[loc2 + i];
	  
	  /* Next */
	  
	  i--;
	}
      
      /* Find maximum above energy */
      
      i = n;
      while ((i < ne) && (RDB[loc0 + i] < Emax))
	{
	  /* Compare */
	  
	  if (RDB[loc2 + i] > max)
	    max = RDB[loc2 + i];
	  
	  /* Next */
	  
	  i++;
	}
      
      /* Put value */
      
      WDB[loc1 + n] = max;
    }
  
  /* Check data */
  
  for (n = 0; n < ne; n++)
    if (RDB[loc2 + n] > RDB[loc1 + n])
      Die(FUNCTION_NAME, "Cross section exceeds majorant");
}

/*****************************************************************************/
