/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : samplereaction.c                               */
/*                                                                           */
/* Created:       2011/01/04 (JLe)                                           */
/* Last modified: 2012/02/01 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Samples reaction after collision                             */
/*                                                                           */
/* Comments: - Nuclide and reaction lists must be sorted according to sample */
/*             counter.                                                      */
/*                                                                           */
/*           - Tähän pitäisi saada se majorantin mahdollisuus mukaan?        */
/*                                                                           */
/*           - Analog estimaattoreihin pitää saada neutronin paino           */
/*                                                                           */
/*           - Toi uusi multi-group -mode on vielä kokeiluasteella ja se on  */
/*             tehty omaksi haarakseen niin että vanhaan ja toimivaan        */
/*             rutiiniin ei kosketa.                                         */
/*                                                                           */
/*           - Rutiinia muutettu radikaalisti 3.11.2011 (2.0.37)             */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "SampleReaction:"

/*****************************************************************************/

long SampleReaction(long mat, long type, double E, double wgt, long id)
{
  long lst0, lst1, rea, rls1, rls2, ptr, i, n, N, nuc, ng, ptp;
  double totxs, adens, xs, absxs, E0, f, Er, Emin, Emax, T;

  /* Check material pointer */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /* Check energy */

  CheckValue(FUNCTION_NAME, "E", "", E, ZERO, INFTY);

  /* Get material temperature for on-the-fly temperature treatment */

  T = GetTemp(mat, id);

  /***************************************************************************/
  
  /***** Multi-group rejection mode ******************************************/

  /* Check coarse multi-group majorant mode */

  if ((long)RDB[DATA_OPTI_MG_MODE] == YES)
    {
      /* Add to total reaction count */

      ptp = (long)RDB[RES_REA_SAMPLE_REAL];
      CheckPointer(FUNCTION_NAME, "(ptp)", DATA_ARRAY, ptp);
      AddBuf(1.0, 1.0, ptp, id, 2 - type);
      
      /* Pointer to energy groups */

      ptr = (long)RDB[DATA_COARSE_MG_PTR_GRID];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Find group index */

      if ((ng = GridSearch(ptr, E)) < 0)
	return -1;

      /* Check particle type */
	  
      if (type == PARTICLE_TYPE_NEUTRON)
	{
	  /* Get (macroscopic) total neutron cross section */
	  
	  ptr = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  totxs = MGXS(ptr, E, ng);
	      
	  /* Check implicit capture mode */
	      
	  if (RDB[DATA_OPT_IMPL_CAPT] == YES)
	    Die(FUNCTION_NAME, "Implicit capture not working in this mode");
	}
      else
	{
	  /* Get total gamma cross section */
	  
	  ptr = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  totxs = MGXS(ptr, E, ng);
	}
	  
      /* Sample fraction of total cross section */
	  
      totxs = RandF(id)*totxs;
	  
      /* Value may be zero if energy is outside the boundaries */
      
      if (totxs == 0.0)
	return -1;
      
      /***********************************************************************/

      /***** Sample target nuclide *******************************************/
	  
      /* Pointer to material total */

      if (type == PARTICLE_TYPE_NEUTRON)
	{
	  ptr = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	}
      else
	{
	  ptr = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	}
      
      /* Get pointer to partial list */
	  
      lst1 = (long)RDB[ptr + REACTION_PTR_PARTIAL_LIST];
      CheckPointer(FUNCTION_NAME, "(lst1)", DATA_ARRAY, lst1);

      /* Avoid compiler warning */
	  
      xs = -1.0;
      rea = -1;
      rls1 = -1;

      /* Rewind */
	      
      RewindReaList(lst1, id);
      
      /* Loop over reactions (NOTE: pointer is zero if list does not exist) */
      
      while ((rls1 = NextReaction(lst1, &rea, &adens, &Emin, &Emax, id)) > -1)
	{
	  /* Get microscopic cross section */
	  
	  xs = MGXS(rea, E, ng);
	  
	  /* Adjust total and check */
	  
	  if ((totxs = totxs - adens*xs) < 0.0)
	    {
	      /* Break loop */
	      
	      break;
	    }
	}
    
      /* Check pointers */
	  
      if (rea < VALID_PTR)
	Die(FUNCTION_NAME, "Failed to sample target nuclide");
      
      /* Pointer to nuclide */
      
      nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
      
      /* Check implicit capture mode */
      
      if ((RDB[DATA_OPT_IMPL_CAPT] == YES) && (type == PARTICLE_TYPE_NEUTRON))
	Die(FUNCTION_NAME, "Implicit capture not yet working");
      
      /* Pointer to total xs */
	  
      rea = (long)RDB[nuc + NUCLIDE_PTR_TOTXS];
      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
      
      /* Check on-the-fly mode and temperature */
      
      if (((long)RDB[DATA_DOPPLER_MODE] == DOPPLER_MODE_ONTHEFLY) && 
	  (T > 0.0))
	{
	  /* Get total cross section at temperature-adjusted energy */
	  
	  totxs = DopMicroXS(mat, rea, E, &Er, T, id);
	  
	  /* Rejection probability with low-energy correction */
	  
	  f = totxs*PotCorr(nuc, E, T*KELVIN)/xs;
	  
	  /* Check */
	  
	  if (f > 1.0)
	    {
	      /* Add to failure counter */

	      ptp = (long)RDB[RES_REA_SAMPLE_FAIL];
	      CheckPointer(FUNCTION_NAME, "(ptp)", DATA_ARRAY, ptp);
	      AddBuf(1.0, 1.0, ptp, id, 2 - type);
	    }
	}
      else
	{
	  /* Get total cross section */
	  
	  totxs = MicroXS(rea, E, id);
	  
	  /* Rejection probability */
	  
	  f = totxs/xs;
	  
	  /* Check */
	  
	  if (f > 1.0)
	    Die(FUNCTION_NAME, "f = %10f (%s E = %E)\n", f,
		GetText(nuc + NUCLIDE_PTR_NAME), E);
	  
	  /* Set relative energy */
	  
	  Er = E;
	}
      
      /* Rejection sampling */
      
      if (RandF(id) < f)
	{
	  /* Add to nuclide counter */
	  
	  if (rls1 > VALID_PTR)
	    {	
	      ptp = (long)RDB[rls1 + REA_LIST_PTR_COUNT];
	      CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
	      AddPrivateData(ptp, 1.0, id);
	    }		

	  /* Add to rejection sampling counter */

	  ptp = (long)RDB[RES_REA_SAMPLE_ACC];
	  CheckPointer(FUNCTION_NAME, "(ptp)", DATA_ARRAY, ptp);
	  AddBuf(1.0, 1.0, ptp, id, 2 - type);
	}
      else
	{
	  /* Add to rejection sampling counter */

	  ptp = (long)RDB[RES_REA_SAMPLE_REJ];
	  CheckPointer(FUNCTION_NAME, "(ptp)", DATA_ARRAY, ptp);
	  AddBuf(1.0, 1.0, ptp, id, 2 - type);

	  /* Sample rejected */
	  
	  return -1;
	}
      
      /* Sample fraction of microscopic total cross section */
      
      totxs = totxs*RandF(id); 
      
      /* Pointer to partial reaction list */
      
      lst0 = (long)RDB[nuc + NUCLIDE_PTR_SAMPLE_REA_LIST];
      CheckPointer(FUNCTION_NAME, "(lst0)", DATA_ARRAY, lst0);
      
      /* Loop over partials */
      
      i = 0;
      while ((rls2 = ListPtr(lst0, i++)) > VALID_PTR)
	{
	  /* Pointer to reaction data */
	  
	  rea = (long)RDB[rls2 + REA_LIST_PTR_REA];
	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	  
	  /* Get cross section */
	  
	  xs = MicroXS(rea, Er, id);
	  
	  /* Adjust total and check */
	  
	  if ((totxs = totxs - xs) < 0.0)
	    {
	      /* Add to counter */
	      
	      ptp = (long)RDB[rls2 + REA_LIST_PTR_COUNT];
	      CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
	      AddPrivateData(ptp, 1.0, id);
	      
	      /* Score analog reaction rate estimator */
	      
	      ptr = (long)RDB[rea + REACTION_PTR_ANA_RATE];
	      AddBuf(1.0, wgt, ptr, id, 0);
	      
	      /* Return reaction pointer */
	      
	      return rea;
	    }
	}
    }

  /***************************************************************************/

  /***** Continuous-energy mode **********************************************/

  else
    {
      /* Remember energy */
      
      E0 = E;
      
      /* Set maximum number of resamples */
      
      N = 10;
      
      /* Resampling loop */
      
      for (n = 0; n < N; n++)
	{
	  /* Add to total reaction count */

	  ptp = (long)RDB[RES_REA_SAMPLE_REAL];
	  CheckPointer(FUNCTION_NAME, "(ptp)", DATA_ARRAY, ptp);
	  AddBuf(1.0, 1.0, ptp, id, 2 - type);
  
	  /*******************************************************************/

	  /***** Get pointers and total xs ***********************************/

	  /* Check particle type */
	  
	  if (type == PARTICLE_TYPE_NEUTRON)
	    {
	      /* Get total neutron cross section */
	      
	      ptr = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      totxs = MacroXS(ptr, E, id);

	      /* Check implicit capture mode and get absorption xs*/
	      
	      if (RDB[DATA_OPT_IMPL_CAPT] == YES)
		{
		  ptr = (long)RDB[mat + MATERIAL_PTR_ABSXS];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  absxs = MacroXS(ptr, E, id);
		}
	      else
		{
		  /* Set absorption xs to zero */
		  
		  absxs = 0.0;
		}
	    }
	  else
	    {
	      /* Get total gamma cross section */
	      
	      ptr = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      totxs = PhotonMacroXS(ptr, E, id);
	      
	      /* Set absorption xs to zero */

	      absxs = 0.0;
	    }

	  /* Calculate total cross section reduced by absorption */
	  
	  totxs = totxs - absxs;

	  /* Check values */

	  CheckValue(FUNCTION_NAME, "absxs", "", absxs, 0.0, INFTY);
	  CheckValue(FUNCTION_NAME, "totxs", "", totxs, 0.0, INFTY);
	  
	  /* Value may be zero if energy is outside the boundaries */
	  
	  if (totxs == 0.0)
	    return -1;
	  
	  /* Sample fraction of total cross section */
	  
	  totxs = RandF(id)*totxs;
	  
	  /*******************************************************************/

	  /***** Sample target nuclide ***************************************/
	  
	  /* Avoid compiler warning */

	  nuc = -1;
	  xs = -1.0;

	  /* Pointer to material total */

	  if (type == PARTICLE_TYPE_NEUTRON)
	    {
	      ptr = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	    }
	  else
	    {
	      ptr = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	    }

	  /* Get pointer to partial list */
	  
	  lst1 = (long)RDB[ptr + REACTION_PTR_PARTIAL_LIST];
	  CheckPointer(FUNCTION_NAME, "(lst1)", DATA_ARRAY, lst1);

	  /* Rewind */
	      
	  RewindReaList(lst1, id);

	  /* Loop over reactions */
	  
	  while ((rls1 = NextReaction(lst1, &rea, &adens, &Emin, &Emax, id))
		 > -1)
	    {
	      /* Check reaction pointer */

	      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

	      /* Pointer to nuclide */

	      nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
	      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

	      /* Check particle type */
	  
	      if (type == PARTICLE_TYPE_NEUTRON)
		{
		  /* Get total neutron cross section */
		  
		  xs = MicroXS(rea, E, id);
		      
		  /* Check implicit capture mode and get absorption xs*/
		  
		  if (RDB[DATA_OPT_IMPL_CAPT] == YES)
		    {
		      ptr = (long)RDB[nuc + NUCLIDE_PTR_SUM_ABSXS];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      absxs = MicroXS(ptr, E, id);
		    }
		  else
		    {
		      /* Set absorption xs to zero */
			  
		      absxs = 0.0;
		    }
		}
	      else
		{
		  /* Get total gamma cross section */
		      
		  xs = PhotonMicroXS(rea, E, id);
		  
		  /* Set absorption xs to zero */
		  
		  absxs = 0.0;
		}	      

	      /* Calculate total cross section reduced by absorption */
	  
	      xs = xs - absxs;

	      /* Adjust total and check */
		  
	      if ((totxs = totxs - adens*xs) < 0.0)
		{
		  /* Add to counter */
		  
		  if (rls1 > VALID_PTR)
		    {
		      ptp = (long)RDB[rls1 + REA_LIST_PTR_COUNT];
		      CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
		      AddPrivateData(ptp, 1.0, id);
		    }
		  
		  /* Break loop */
		  
		  break;
		}
	    }

	  /* Check pointers */
	  
	  if ((ptr < VALID_PTR) || (rea < VALID_PTR))
	    break;
	  
	  /*******************************************************************/

	  /***** Sample reaction *********************************************/
	  
	  /* Sample fraction of microscopic total cross section */
	  
	  totxs = RandF(id)*xs;
	  
	  /* Check nuclide pointer */
	  
	  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
	  
	  /* Pointer to partial reaction list */
	  
	  lst0 = (long)RDB[nuc + NUCLIDE_PTR_SAMPLE_REA_LIST];
	  CheckPointer(FUNCTION_NAME, "(lst0)", DATA_ARRAY, lst0);
	  
	  /* Loop over partials */
	  
	  i = 0;
	  while ((rls1 = ListPtr(lst0, i++)) > VALID_PTR)
	    {
	      /* Pointer to reaction data */
	      
	      rea = (long)RDB[rls1 + REA_LIST_PTR_REA];
	      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	      
	      /* Get cross section */
	      
	      if (type == PARTICLE_TYPE_NEUTRON)
		xs = MicroXS(rea, E, id);
	      else
		xs = PhotonMicroXS(rea, E, id);
	      
	      /* Adjust total and check */
	      
	      if ((totxs = totxs - xs) < 0.0)
		{
		  /* Add to counter */
		  
		  ptp = (long)RDB[rls1 + REA_LIST_PTR_COUNT];
		  CheckPointer(FUNCTION_NAME, "(ptp)",PRIVA_ARRAY, ptp);
		  AddPrivateData(ptp, 1.0, id);
		  
		  /* Score analog reaction rate estimator */
		  
		  ptr = (long)RDB[rea + REACTION_PTR_ANA_RATE];
		  AddBuf(1.0, wgt, ptr, id, 0);
		  
		  /* Add to sample accepted counter */

		  ptp = (long)RDB[RES_REA_SAMPLE_ACC];
		  CheckPointer(FUNCTION_NAME, "(ptp)", DATA_ARRAY, ptp);
		  AddBuf(1.0, 1.0, ptp, id, 2 - type);

		  /* Return reaction pointer */
		  
		  return rea;
		}
	    }
	  
	  /*******************************************************************/
    
	  /***** Something wrong *********************************************/
      
	  /* Add to sample failure counter */

	  ptp = (long)RDB[RES_REA_SAMPLE_FAIL];
	  CheckPointer(FUNCTION_NAME, "(ptp)", DATA_ARRAY, ptp);
	  AddBuf(1.0, 1.0, ptp, id, 2 - type);

	  /* Sampling failed, break re-sampling loop if residual is large */
	  /* NOTE: Jollain nuklideilla (60144.03c @ JEFF-3.1.1 & JEF-2.2) */
	  /* reaktiot summautuu ures-alueella joskus nollaan vaikka total */
	  /* on ~1E-16. Voi olla että ongelma on numeerinen. */
	  
	  if (totxs > 1E-12)
	    break;
	  
	  /* Print warning */
	  
	  Warn(FUNCTION_NAME, "Reaction sampling failed (%s, E = %E)",
	       GetText(mat + MATERIAL_PTR_NAME), E);
	  
	  /* Check reaction lists */
	  
	  CheckReaListSum(mat, E, NO, id);
	  
	  /* Adjust energy and retry */
	  
	  E = (1.0 + (1.0 - RandF(id))*1E-6)*E;
	  
	  /* Check boundaries */
	  
	  if (type == PARTICLE_TYPE_NEUTRON)
	    {
	      if (E < RDB[DATA_NEUTRON_EMIN])
		E = (1.0 + RandF(id)*1E-6)*RDB[DATA_NEUTRON_EMIN];
	      else if (E > RDB[DATA_NEUTRON_EMAX])
		E = (1.0 - RandF(id)*1E-6)*RDB[DATA_NEUTRON_EMIN];
	    }
	  else
	    {
	      if (E < RDB[DATA_PHOTON_EMIN])
		E = (1.0 + RandF(id)*1E-6)*RDB[DATA_PHOTON_EMIN];
	      else if (E > RDB[DATA_PHOTON_EMAX])
		E = (1.0 - RandF(id)*1E-6)*RDB[DATA_PHOTON_EMIN];
	    }
	  
	  /*******************************************************************/
	}
      
      /* Maximum number of retries */
  
      fprintf(err, "\nReaction sampling failed after %ld / %ld attempts.\n", 
	      n, N);
      fprintf(err, "Remaining totxs: %E\n", totxs);
      
      /* Print reaction list data and terminate calculation */
      
      if (type == PARTICLE_TYPE_NEUTRON)
	CheckReaListSum(mat, E, YES, id);
      
      /***********************************************************************/
    }
      
  /* No reaction sampled (virtual collision) */
  
  return -1;
}

/*****************************************************************************/
