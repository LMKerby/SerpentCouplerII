/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : preallocxsmem.c                                */
/*                                                                           */
/* Created:       2011/11/30 (JLe)                                           */
/* Last modified: 2012/01/27 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Estimates total memory required by cross section data and    */
/*              pre-allocates it                                             */
/*                                                                           */
/* Comments: - This is to speed up ProcessXSData()                           */
/*           - Ei ota huomioon gammavaikutusaloja                            */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "PreAllocXSMem:"

/*****************************************************************************/

void PreAllocXSMem()
{
  long mem, ptr, ne, nuc, rea, type, NES, tot;
  double f;

  /* Check decay only mode */

  if ((long)RDB[DATA_BURN_DECAY_CALC] == YES)
    return;

  /* Reset memory size */

  mem = 0;

  /* Get unionized grid size */

  if ((long)RDB[DATA_OPTI_RECONSTRUCT_MICROXS] == YES)
    {
      /* Pointer to grid */

      ptr = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Get number of energy points */
	  
      ne = RDB[ptr + ENERGY_GRID_NE];
    }
  else
    ne = 0; 

  /* Loop over nuclides */

  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Check pointer to ACE data */

      if ((long)RDB[nuc + NUCLIDE_PTR_ACE] > VALID_PTR)
	{
	  /* Pointer to reaction data */

	  rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

	  /* Get total number of points (elastic XS should be first) */

	  tot = (long)RDB[rea + REACTION_XS_NE];

	  /* Add total xs to estimate */

	  if ((long)RDB[DATA_OPTI_RECONSTRUCT_MICROXS] == NO)
	    mem = mem + 2*tot;
	  else
	    mem = mem + 2*ne;	  

	  /* Loop over remaining reactions */

	  while (rea > VALID_PTR)
	    {
	      /* Get type */
		
	      type = (long)RDB[rea + REACTION_TYPE];
	      
	      /* Skip everything but partial and special reactions */
		
	      if ((type == REACTION_TYPE_PARTIAL) ||
		  (type == REACTION_TYPE_SPECIAL))
		{
		  /* Number of energy points */
		
		  NES = (long)RDB[rea + REACTION_XS_NE];

		  /* Check reconstruction mode */

		  if ((long)RDB[DATA_OPTI_RECONSTRUCT_MICROXS] == NO)
		    {
		      /* No reconstruction, add points to total */

		      mem = mem + NES;
		    }
		  else
		    {
		      /* Reconstructed cross section, calculate fraction */
		      
		      f = ((double)NES)/((double)tot);

		      /* Add to total (additional factor to account for */
		      /* other data). */
		      
		      mem = mem + (long)(f*ne*1.0);
		    }
		}

	      /* Next reaction */

	      rea = NextItem(rea);
	    }
	}

      /* Next nuclide */

      nuc = NextItem(nuc);
    }

  /* Allocate memory */

  ptr = ReallocMem(DATA_ARRAY, mem);

  /* Put pointer back to beginning of allocated region (tässä varataan     */
  /* kerralla iso blokki ja tehdään se uudestaan käytettäväksi asettamalla */
  /* toi pointteri). */

  WDB[DATA_ALLOC_MAIN_SIZE] = (double)ptr;  

  /* Calculate allocated memory in bytes */

  CalculateBytes();
}

/*****************************************************************************/
