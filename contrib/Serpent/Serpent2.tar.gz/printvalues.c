/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : printvalues.c                                  */
/*                                                                           */
/* Created:       2011/03/13 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Formatted printing of mean and statistical error             */
/*                                                                           */
/* Comments: - Used for printing Serpent 1 style output                      */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "PrintValues:"

/*****************************************************************************/

void PrintValues(FILE *fp, char *name, long param, long nv1, long nv2, long iu,
		 long n0, long m0)
{
  long n, m, ptr;
  char tmpstr[MAX_STR];

  if (nv1 < 1)
    return;

  /* Print title */

  if (nv2 < 1)
    sprintf(tmpstr, "%-26s(idx, [1: %3ld])", name, 2*nv1);
  else
    sprintf(tmpstr, "%-26s(idx, [1: %3ld])", name, 2*nv1*nv2);

  fprintf(fp, "%-40s = [", tmpstr);

  /* Get pointer to data */

  ptr = (long)RDB[param];

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Print values */

  if (iu < 0)
    {
      if (nv2 < 1)
	{
	  for (n = 0; n < nv1; n++)
	    fprintf(fp, " %12.5E %7.5f", Mean(ptr, n0 + n), 
		    RelErr(ptr, n0 + n));
	}
      else
	{
	  for (n = 0; n < nv1; n++)
	    for (m = 0; m < nv2; m++)
	      fprintf(fp, " %12.5E %7.5f", Mean(ptr, n0 + n, m0 + m), 
		      RelErr(ptr, n0 + n, m0 + m));
	}
    }
  else
    Die(FUNCTION_NAME, "iu = %ld", iu);

  fprintf(fp, " ];\n");
}

/*****************************************************************************/
