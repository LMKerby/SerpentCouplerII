/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processontheflydata.c                          */
/*                                                                           */
/* Created:       2011/11/04 (JLe)                                           */
/* Last modified: 2012/01/24 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Processing for on-the-fly temperature treatment routine      */
/*                                                                           */
/* Comments: - NOTE: tänne esim. nuklidikohtaisten maksimilämpötilojen       */
/*                   määrittäminen, ym.                                      */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessOnTheFlyData:"

void SetMaxTemp(long, long);

/*****************************************************************************/

void ProcessOnTheFlyData()
{
  long mat, iso, nuc;

  /* Check on-the-fly mode */
 
  if ((long)RDB[DATA_DOPPLER_MODE] != DOPPLER_MODE_ONTHEFLY)
    return;    

  /***************************************************************************/

  /***** Set maximum temperatures from materials *****************************/

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check temperature */
      
      if (RDB[mat + MATERIAL_TEMP] > 0.0)
	{
	  /* Reset used-flags on nuclides */
      
	  nuc = (long)RDB[DATA_PTR_NUC0];
	  while (nuc > VALID_PTR)
	    {
	      /* Reset flag */
	      
	      ResetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);
	      
	      /* Next nuclide */
	      
	      nuc = NextItem(nuc);
	    }

	  /* Loop over (initial) composition */

	  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	  while (iso > VALID_PTR)
	    {
	      /* Pointer to nuclide */
	      
	      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
	
	      /* Set temperature (recursive routine) */

	      SetMaxTemp(mat, nuc);

	      /* Next nuclide */

	      iso = NextItem(iso);
	    }

	  /* Set used-flags on nuclides */
      
	  nuc = (long)RDB[DATA_PTR_NUC0];
	  while (nuc > VALID_PTR)
	    {
	      /* Reset flag */
	      
	      SetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);
	      
	      /* Next nuclide */
	      
	      nuc = NextItem(nuc);
	    }
	}
      
      /* Next material */
      
      mat = NextItem(mat);
    }

  /***************************************************************************/
}

/*****************************************************************************/

void SetMaxTemp(long mat, long nuc)
{
  long rea, new, yld;

  /* Check used-flag */

  if ((long)RDB[nuc + NUCLIDE_OPTIONS] & OPT_USED)
    return;
  else
    SetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);

  /* Check cross section temperature */

  if (RDB[nuc + NUCLIDE_XS_TEMP] > 0.0)
    Error(mat, "Nuclide %s must be at zero temperature",
	  GetText(nuc + NUCLIDE_PTR_NAME));

  /* Compare to maximum temperature and set */
  
  if (RDB[mat + MATERIAL_TEMP] > RDB[nuc + NUCLIDE_MAX_TEMP])
    WDB[nuc + NUCLIDE_MAX_TEMP] = RDB[mat + MATERIAL_TEMP];

  /* Check for lost nuclide */

  if (nuc == (long)RDB[DATA_PTR_NUCLIDE_LOST])
    return;

  /* Loop over reactions */

  rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
  while (rea > VALID_PTR)
    {
      /* Get pointer to target */
      
      if ((new = (long)RDB[rea + REACTION_PTR_TGT]) > VALID_PTR)
	{
	  /* Call recursively */
	  
	  SetMaxTemp(mat, new);
	}
      else if ((yld = (long)RDB[rea + REACTION_PTR_FISSY]) > VALID_PTR)
	{
	  /* Get pointer to distribution */
	  
	  yld = (long)RDB[yld + FISSION_YIELD_PTR_DISTR];
	  CheckPointer(FUNCTION_NAME, "yld", DATA_ARRAY, yld);
	  
	  /* Loop over distribution */ 

	  while (yld > VALID_PTR)
	    {
	      /* Get pointer to target */
	      
	      if ((new = (long)RDB[yld + FY_PTR_TGT]) > VALID_PTR)
		{
		  /* Call recursively */
		  
		  SetMaxTemp(mat, new);
		}

	      /* Next */

	      yld = NextItem(yld);
	    }
	}
          
      /* Next reaction */
      
      rea = NextItem(rea);
    }  
}
