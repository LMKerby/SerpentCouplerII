/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processreactionlists.c                         */
/*                                                                           */
/* Created:       2010/12/29 (JLe)                                           */
/* Last modified: 2012/01/10 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Creates reaction lists materials                             */
/*                                                                           */
/* Comments: - Rutiinia muutettu radikaalisti 2.11.2011 (2.0.37)             */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessReactionLists:"

/* Use local function to simplify OpenMP implementation */

void ProcessReactionLists0(long);

/*****************************************************************************/

void ProcessReactionLists()
{
  long mat, count;

  /* Reset thread numbers */
  
  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check thread number */
      
      WDB[mat + MATERIAL_OMP_ID] = -1.0;
      
      /* Next material */
      
      mat = NextItem(mat);
    }	  

  /* Reset count */

  count = 0;

  fprintf(out, "Processing material-wise reaction lists:\n\n");

  /* Start parallel timer */

  StartTimer(TIMER_OMP_PARA);

#ifdef OPEN_MP
#pragma omp parallel private (mat)
#endif
  {
    /* Loop over materials */
    
    mat = (long)RDB[DATA_PTR_M0];
    while (mat > VALID_PTR)
      {
	/* Check MPI id number */

	if (((long)RDB[mat + MATERIAL_MPI_ID] == -1) ||
	    ((long)RDB[mat + MATERIAL_MPI_ID] == mpiid))
	  {

#ifdef OPEN_MP
#pragma omp critical
#endif
	    {
	      /* Grab material */
	      
	      if ((long)RDB[mat + MATERIAL_OMP_ID] == -1)
		WDB[mat + MATERIAL_OMP_ID] = OMP_THREAD_NUM;
	    }
	    
	    /* Check thread number */
	    
	    if ((long)RDB[mat + MATERIAL_OMP_ID] == OMP_THREAD_NUM)
	      {
		/* Print */
		
		if (OMP_THREAD_NUM == 0)
		  if (count < (long)RDB[DATA_MATERIALS_THREAD0])
		    fprintf(out, " %3.0f%% complete\n", 
			    100.0*(count++)/RDB[DATA_MATERIALS_THREAD0]);
		
		/* Process */
		
		ProcessReactionLists0(mat);
	      }
	  }

	/* Next material */
	
	mat = NextItem(mat);
      }
  }

  /* Stop parallel timer */

  StopTimer(TIMER_OMP_PARA);

  /* Done */

  fprintf(out, " 100%% complete\n\n"); 
}

/*****************************************************************************/

/*****************************************************************************/

void ProcessReactionLists0(long mat)
{
  long n, mode, loc0, loc1, nr, rea, iso, nuc, ptr, id;
  double adens, Emin, Emax;

  /* Get OpenMP id */

  id = OMP_THREAD_NUM;

  /***************************************************************************/

  /***** Put reactions in list ***********************************************/

  /* Loop over lists */
  
  for (n = 0; n < 11; n++)
    {
      /* Avoid compiler warning */
      
      mode = -1;
      
      /* Get mode */
      
      if (n == 0)
	mode = MATERIAL_PTR_TOT_REA_LIST;
      else if (n == 1)
	mode = MATERIAL_PTR_ELA_REA_LIST;
      else if (n == 2)
	mode = MATERIAL_PTR_ABS_REA_LIST;
      else if (n == 3)
	mode = MATERIAL_PTR_FISS_REA_LIST;
      else if (n == 4)
	mode = MATERIAL_PTR_NUXN_REA_LIST;
      else if (n == 5)
	mode = MATERIAL_PTR_PHOT_TOT_LIST;
      else if (n == 6)
	mode = MATERIAL_PTR_PHOT_HEAT_LIST;
      else if (n == 7)
	mode = MATERIAL_PTR_TOT_URES_LIST;
      else if (n == 8)
	mode = MATERIAL_PTR_ABS_URES_LIST;
      else if (n == 9)
	mode = MATERIAL_PTR_ELA_URES_LIST;
      else if (n == 10)
	mode = MATERIAL_PTR_FISS_URES_LIST;
      else
	Die(FUNCTION_NAME, "Overflow");
      
      /* Pointer to list */
      
      if ((loc0 = (long)RDB[mat + mode]) > VALID_PTR)
	{
	  /* Set list type to enable cut-offs */
	  
	  WDB[loc0 + LIST_ROOT_LIST_TYPE] = (double)REA_LIST_TYPE_EMULATED;
	  
	  /* Pointer to reactions */
	  
	  if ((loc1 = (long)RDB[loc0 + LIST_ROOT_PTR_REA_LIST]) < VALID_PTR)
	    {
	      /* No pre-generated list, only count reactions */
	      
	      nr = 0;
	      
	      /* Rewind */
	      
	      RewindReaList(loc0, id);
	      
	      /* Loop over reactions and add counter */
	      
	      while (NextReaction(loc0, &rea, &adens, &Emin, &Emax, id) == 0)
		nr++;
	    }
	  else
	    {
	      /* Put data in pre-generated list and count reactions */
	      
	      nr = 0;
	      
	      /* Rewind */
	      
	      RewindReaList(loc0, id);
	      
	      /* Loop over reactions */
	      
	      while (NextReaction(loc0, &rea, &adens, &Emin, &Emax, id) == 0)
		{
		  /* Check reaction pointer */
		  
		  CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);
		  
		  /* Put data */
		  
		  WDB[loc1 + REA_LIST_PTR_REA] = (double)rea;
		  WDB[loc1 + REA_LIST_ADENS] = adens;
		  WDB[loc1 + REA_LIST_EMIN] = Emin;
		  WDB[loc1 + REA_LIST_EMAX] = Emax;
		  
		  /* Reset list counters */
		  
		  ptr = (long)RDB[loc1 + REA_LIST_PTR_COUNT];
		  CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
		  ClearPrivateData(ptr);
		  
		  /* Pointer to next */
		  
		  loc1 = NextItem(loc1);
		  
		  /* Add counter */
		  
		  nr++;
		}
	      
	      /* Reset remaining data in list */
	      
	      while (loc1 > VALID_PTR)
		{
		  WDB[loc1 + REA_LIST_PTR_REA] = NULLPTR;
		  WDB[loc1 + REA_LIST_ADENS] = -1.0;
		  WDB[loc1 + REA_LIST_EMIN] = INFTY;
		  WDB[loc1 + REA_LIST_EMAX] = -INFTY;
		  
		  /* Reset list counters */
		  
		  ptr = (long)RDB[loc1 + REA_LIST_PTR_COUNT];
		  CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
		  ClearPrivateData(ptr);
		  
		  /* Put negative value (needed for sorting?) */
		  
		  PutPrivateData(ptr, -1.0, id);
		  
		  loc1 = NextItem(loc1);
		}
	      
	      /* Sort total list by density and others by energy */
	      
	      if (mode == MATERIAL_PTR_TOT_REA_LIST)
		{
		  loc1 = (long)RDB[loc0 + LIST_ROOT_PTR_REA_LIST];
		  SortList(loc1, REA_LIST_ADENS, SORT_MODE_DESCEND);
		}
	      else
		{
		  loc1 = (long)RDB[loc0 + LIST_ROOT_PTR_REA_LIST];
		  SortList(loc1, REA_LIST_EMIN, SORT_MODE_ASCEND);
		}
	      
	      /* Set list type */
	      
	      WDB[loc0 + LIST_ROOT_LIST_TYPE] = (double)REA_LIST_TYPE_REAL;
	    }
	  
	  /* Compare count to max */
	  
	  if (nr > (long)RDB[loc0 + LIST_ROOT_N_MAX])
	    Die(FUNCTION_NAME, "Error in reaction count");
	  
	  /* Put count */
	  
	  WDB[loc0 + LIST_ROOT_N_REA] = (double)nr;
	}
    }
  
  /***************************************************************************/

  /***** Sort composition if total list doesn't exist ************************/
  
  /* Check that list exists and list data doesn't */
  
  if ((loc0 = (long)RDB[mat + MATERIAL_PTR_TOT_REA_LIST]) > VALID_PTR)
    if ((long)RDB[loc0 + LIST_ROOT_PTR_REA_LIST] < VALID_PTR)
      {
	/* Convert atomic density for sorting */
	
	iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	while (iso > VALID_PTR)
	  {
	    /* Pointer to nuclide */
	    
	    nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	    CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
	    
	    /* Check type and convert density */
	    
	    if ((long)RDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_TRANSPORT)
	      WDB[iso + COMPOSITION_ADENS] = -RDB[iso + COMPOSITION_ADENS];
	    else
	      WDB[iso + COMPOSITION_ADENS] = RDB[iso + COMPOSITION_ADENS]*
		RDB[nuc + NUCLIDE_MAX_TOTXS];
	    
	    /* Next nuclide */
	    
	    iso = NextItem(iso);
	  }
	
	/* Sort list */
	
	iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	SortList(iso, COMPOSITION_ADENS, SORT_MODE_DESCEND);
	
	/* Convert back */
	
	iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	while (iso > VALID_PTR)
	  {
	    /* Pointer to nuclide */
	    
	    nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	    CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
	    
	    /* Check type and convert density */
	    
	    if ((long)RDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_TRANSPORT)
	      WDB[iso + COMPOSITION_ADENS] = -RDB[iso + COMPOSITION_ADENS];
	    else
	      WDB[iso + COMPOSITION_ADENS] = RDB[iso + COMPOSITION_ADENS]/
		RDB[nuc + NUCLIDE_MAX_TOTXS];
	    
	    /* Next nuclide */
	    
	    iso = NextItem(iso);
	  }
      }
  
  /***************************************************************************/

  /***** Put ures limits to materials ****************************************/
  
  /* Loop over reaction modes */
  
  for (n = 0; n < 4; n++)
    {
      /* Avoid compiler warning */
      
      mode = -1;
      rea = -1;
      
      /* Get reaction and list pointer */
      
      if (n == 0)
	{
	  rea = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	  mode = MATERIAL_PTR_TOT_URES_LIST;
	}
      else if (n == 1)
	{
	  rea = (long)RDB[mat + MATERIAL_PTR_ABSXS];
	  mode = MATERIAL_PTR_ABS_URES_LIST;
	}	  
      else if (n == 2)
	{
	  rea = (long)RDB[mat + MATERIAL_PTR_ELAXS];
	  mode = MATERIAL_PTR_ELA_URES_LIST;
	}	  
      else if (n == 3)
	{
	  rea = (long)RDB[mat + MATERIAL_PTR_FISSXS];
	  mode = MATERIAL_PTR_FISS_URES_LIST;
	}
      
      /* Pointer to list */
      
      loc0 = (long)RDB[mat + mode];
      
      /* Cycle loop if list is not defined */
      
      if (loc0 < VALID_PTR)
	continue;
      
      /* Check reaction pointer */
      
      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
      
      /* Rewind */
      
      RewindReaList(loc0, id);
      
      /* Reset ures energy boundaries */
      
      WDB[rea + REACTION_URES_EMIN] = INFTY;
      WDB[rea + REACTION_URES_EMAX] = -INFTY;
      
      /* Loop over reactions (loc1 is used as dummy pointer) */
      
      while (NextReaction(loc0, &loc1, &adens, &Emin, &Emax, id) > -1)
	{
	  /* Compare energy boundaries to ures limits */
	  
	  if (Emin < RDB[rea + REACTION_URES_EMIN])
	    WDB[rea + REACTION_URES_EMIN] = Emin;
	  
	  if (Emax > RDB[rea + REACTION_URES_EMAX])
	    WDB[rea + REACTION_URES_EMAX] = Emax;
	}
    }
  
  /***************************************************************************/
}

/*****************************************************************************/
