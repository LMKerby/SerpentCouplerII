/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processdbrcdata.c                              */
/*                                                                           */
/* Created:       2011/04/21 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Processes special cross sections needed for DBRC treatment   */
/*              and links data to nuclides                                   */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessDBRCData:"

/*****************************************************************************/

void ProcessDBRCData()
{
  long nuc, loc0, rea0, rea1, ptr, ne;
  double kT;

  /* Check DBRC flag */

  if ((long)RDB[DATA_USE_DBRC] == NO)
    return;

  /***************************************************************************/
  
  /***** Find maximum value for kT *******************************************/

  /* Reset kT */

  kT = -INFTY;

  /* Loop over nuclides with DBRC data */

  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Check DBRC flag */

      if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_DBRC)
	{
	  /* Find nuclides with same ZAI */

	  loc0 = (long)RDB[DATA_PTR_NUC0];
	  while (loc0 > VALID_PTR)
	    {
	      /* Compare ZAI */

	      if (RDB[nuc + NUCLIDE_ZAI] == RDB[loc0 + NUCLIDE_ZAI])
		{
		  /* Compare kT */

		  if (RDB[loc0 + NUCLIDE_TEMP] > kT)
		    kT = RDB[loc0 + NUCLIDE_TEMP];
		}

	      /* Next nuclide */

	      loc0 = NextItem(loc0);
	    }
	}

      /* Next nuclide */

      nuc = NextItem(nuc);
    }

  /* Check if data is used at all and convert to MeV */

  if (kT < 0.0)
    {
      /* Reset flag */

      WDB[DATA_USE_DBRC] = (double)NO;

      /* Exit subroutine */

      return;
    }
  else
    kT = kT*KELVIN;
  
  /***************************************************************************/

  /***** Process and link data ***********************************************/

  /* Loop over nuclides with DBRC data */

  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Check DBRC flag */

      if (!((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_DBRC))
	{
	  /* No data, get pointer to next */

	  nuc = NextItem(nuc);

	  /* Cycle */

	  continue;
	}

      /* Pointer to elastic data */

      rea0 = (long)RDB[nuc + NUCLIDE_PTR_ELAXS];
      CheckPointer(FUNCTION_NAME, "(rea0)", DATA_ARRAY, rea0);

      /* Duplicate reaction channel */

      rea1 = DuplicateItem(rea0);

      /* Allocate memory for previous values */

      WDB[rea1 + REACTION_PTR_PREV_XS] = NULLPTR;
      WDB[rea1 + REACTION_PTR_PREV_XS0] = NULLPTR;

      AllocValuePair(rea1 + REACTION_PTR_PREV_XS);
      AllocValuePair(rea1 + REACTION_PTR_PREV_XS0);

      /* Get number of energy points */

      ptr = (long)RDB[rea0 + REACTION_PTR_EGRID];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      ne = (long)RDB[ptr + ENERGY_GRID_NE];

      /* Allocate memory for data */

      ptr = ReallocMem(DATA_ARRAY, ne);
      WDB[rea1 + REACTION_PTR_MAJORANT_XS] = (double)ptr;

      /* Generate temperature-dependent majorant */

      CalculateMajorant(rea1, kT);      

      /* Link pointers (for plotting cross section) */

      WDB[rea0 + REACTION_PTR_0K_REA] = (double)rea0;
      WDB[rea0 + REACTION_PTR_0K_MAJORANT] = (double)rea1;

      /* Link to other nuclides */

      loc0 = (long)RDB[DATA_PTR_NUC0];
      while (loc0 > VALID_PTR)
	{
	  /* Check ZAI and DBRC flag */

	  if ((RDB[nuc + NUCLIDE_ZAI] == RDB[loc0 + NUCLIDE_ZAI]) &&
	      !((long)RDB[loc0 + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_DBRC))
	    {
	      /* Pointer to elastic cross section */

	      ptr = (long)RDB[loc0 + NUCLIDE_PTR_ELAXS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      /* Link reaction channels */

	      WDB[ptr + REACTION_PTR_0K_REA] = (double)rea0;
	      WDB[ptr + REACTION_PTR_0K_MAJORANT] = (double)rea1;
	    }

	  /* Next nuclide */
	  
	  loc0 = NextItem(loc0);
	}

      /* Next nuclide */

      nuc = NextItem(nuc);
    }

  /***************************************************************************/
}

/*****************************************************************************/
