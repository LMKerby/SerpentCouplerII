/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : nearestboundary.c                              */
/*                                                                           */
/* Created:       2010/10/10 (JLe)                                           */
/* Last modified: 2011/11/10 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Finds distance to the nearest boundary surface               */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "NearestBoundary:"

/*****************************************************************************/

double NearestBoundary(long id)
{
  long lvl0, lvl, reg, lat, cell, pbd, pbl, surf, type, n, np, ptr, loc0, idx;
  long ltype;
  double min, d, x, y, z, u, v, w, params[MAX_SURFACE_PARAMS];

  /* Reset minimum distance */

  min = INFTY;

  /* Pointer to first level */

  lvl0 = (long)RDB[DATA_PTR_LVL0];
  CheckPointer(FUNCTION_NAME, "(lvl0)", DATA_ARRAY, lvl0);

  /* Loop over levels */

  idx = 0;

  while (lvl0 > VALID_PTR)
    {
      /* Pointer to private data */

      lvl = (long)RDB[lvl0 + LVL_PTR_PRIVATE_DATA];
      CheckPointer(FUNCTION_NAME, "(lvl)", PRIVA_ARRAY, lvl);
      
      /* Get coordinates */

      x = GetPrivateData(lvl + LVL_PRIV_X, id);
      y = GetPrivateData(lvl + LVL_PRIV_Y, id);
      z = GetPrivateData(lvl + LVL_PRIV_Z, id);

      /* Get direction cosines */

      u = GetPrivateData(lvl + LVL_PRIV_U, id);
      v = GetPrivateData(lvl + LVL_PRIV_V, id);
      w = GetPrivateData(lvl + LVL_PRIV_W, id);

      /* Get level type */

      ltype = (long)GetPrivateData(lvl + LVL_PRIV_TYPE, id);
      
      /* Check type */

      switch (ltype)
	{
	case UNIVERSE_TYPE_NEST:
	  {
	    /***** Nest ******************************************************/
	    
	    /* Pointer to nest region */

	    reg = (long)GetPrivateData(lvl + LVL_PRIV_PTR_NEST_REG, id);
	    CheckPointer(FUNCTION_NAME, "(reg)", DATA_ARRAY, reg);

	    /* First surface */

	    if ((surf = (long)RDB[reg + NEST_REG_PTR_SURF_IN]) > VALID_PTR)
	      {
		/* Get type */

		type = (long)RDB[surf + SURFACE_TYPE];
		
		/* Get number of parameters */
		
		np = (long)RDB[surf + SURFACE_N_PARAMS];
		
		/* Pointer to parameter list */
		
		ptr = (long)RDB[surf + SURFACE_PTR_PARAMS];
		CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

		/* Get distance */
		
		d = SurfaceDistance(&RDB[ptr], type, np, x, y, z, u, v, w);

		/* Compare to minimum */
		
		if (d < min)
		  min = d;	      
	      }

	    /* Second surface */
	    
	    if ((surf = (long)RDB[reg + NEST_REG_PTR_SURF_OUT]) > VALID_PTR)
	      {
		/* Get type */
		
		type = (long)RDB[surf + SURFACE_TYPE];
		
		/* Get number of parameters */

		np = (long)RDB[surf + SURFACE_N_PARAMS];
		
		/* Pointer to parameter list */
		
		ptr = (long)RDB[surf + SURFACE_PTR_PARAMS];
		CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

		/* Get distance */
		
		d = SurfaceDistance(&RDB[ptr], type, np, x, y, z, u, v, w);

		/* Compare to minimum */
		
		if (d < min)
		  min = d;	      
	      }

	    /* Break case */

	    break;
	    
	    /*****************************************************************/
	  }      

	case UNIVERSE_TYPE_LATTICE:
	  {
	    /***** Lattice ***************************************************/

	    /* Pointer to lattice */

	    lat = (long)GetPrivateData(lvl + LVL_PRIV_PTR_LAT, id);
	    CheckPointer(FUNCTION_NAME, "(lat)", DATA_ARRAY, lat);

	    /* Get surface type */
	    
	    type = (long)GetPrivateData(lvl + LVL_PRIV_LAT_SURF_TYPE, id);

	    /* Get number of surface parameters */
	    
	    np = (long)GetPrivateData(lvl + LVL_PRIV_LAT_SURF_NP, id);
	    
	    /* Get parameters (noiden kerrointen pit�� olla per�kk�in) */

	    for (n = 0; n < np; n++)
	      params[n] = GetPrivateData(lvl + LVL_PRIV_LAT_SURF_C0 + n, id);

	    /* Get distance */

	    d = SurfaceDistance(params, type, np, x, y, z, u, v, w);

	    /* Compare to minimum */

	    if (d < min)
	      min = d;	      

	    /* Check if type is vertical stack */

	    if (type == SURF_PZ)
	      {
		/* Put parameter for second surface */

		params[0] = GetPrivateData(lvl + LVL_PRIV_LAT_SURF_C1, id);
		
		/* Get distance */

		d = SurfaceDistance(params, type, np, x, y, z, u, v, w);
		
		/* Compare to minimum */
		
		if (d < min)
		  min = d;	      
	      }

	    /* Break case */

	    break;

	    /*****************************************************************/
	  }
	  
	case UNIVERSE_TYPE_CELL:
	  {
	    /***** Cell ******************************************************/
	
	    /* Pointer to cell */
	
	    cell = (long)GetPrivateData(lvl + LVL_PRIV_PTR_CELL, id);
	    CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);

	    /* Pointer to surface list */

	    loc0 = (long)RDB[cell + CELL_PTR_SURF_LIST];
	    CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

	    /* Loop over list */

	    while ((surf = (long)RDB[loc0++]) > VALID_PTR)
	      {
		/* Get type */

		type = (long)RDB[surf + SURFACE_TYPE];
		
		/* Check infinite */

		if (type != SURF_INF)
		  {
		    /* Get number of parameters */
		
		    np = (long)RDB[surf + SURFACE_N_PARAMS];
		    
		    /* Pointer to parameter list */
		    
		    ptr = (long)RDB[surf + SURFACE_PTR_PARAMS];
		    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		    
		    /* Get distance */
		    
		    d = SurfaceDistance(&RDB[ptr], type, np, x, y, z, u, v, w);
		    
		    /* Compare to minimum */
		    
		    if (d < min)
		      min = d;
		  }	      
	      }

	    /* Break case */
	    
	    break;
	    
	    /*****************************************************************/
	  }      

	case UNIVERSE_TYPE_PBED:
	  {
	    /***** Explicit stochastic geometry ******************************/

	    /* Check direct pointer to pebble */

	    if ((pbl = (long)GetPrivateData(lvl + LVL_PRIV_PTR_PEBBLE, id)) > 
		VALID_PTR)
	      {
		/* Put surface parameters */

		params[0] = RDB[pbl + PEBBLE_X0];
		params[1] = RDB[pbl + PEBBLE_Y0];
		params[2] = RDB[pbl + PEBBLE_Z0];
		params[3] = RDB[pbl + PEBBLE_RAD];

		if ((x - params[0])*(x - params[0]) + 
		    (y - params[1])*(y - params[1]) + 
		    (z - params[2])*(z - params[2]) > params[3]*params[3])
		  Die(FUNCTION_NAME, "not inside");

		/* Get distance */

		d = SurfaceDistance(params, SURF_SPH, 4, x, y, z, u, v, w);
		CheckValue(FUNCTION_NAME, "d", "", d, 0.0, 2.0*params[3]);
	      }
	    else
	      {
		/* Pointer to PB geometry */
	
		pbd = (long)GetPrivateData(lvl + LVL_PRIV_PTR_PBED, id);
		CheckPointer(FUNCTION_NAME, "(pbd)", DATA_ARRAY, pbd);
		
		/* Get minimum distance */
		
		d = NearestPBSurf(pbd, x, y, z, u, v, w);
	      }

	    /* Compare to minimum */
	    
	    if (d < min)
	      min = d;
	    
	    /* Break case */
	    
	    break;

	    /*****************************************************************/
	  }

	default:
	  {
	    /* Invalid type */
	    
	    Die(FUNCTION_NAME, "Invalid universe type");
	  }
	}
      
      /* Break loop if level is last */
      
      if ((long)GetPrivateData(lvl + LVL_PRIV_LAST, id) == YES)
      	break;

      /* Next level */

      lvl0 = NextItem(lvl0);
    }

  /* Return shortest distance */

  return min;
}

/*****************************************************************************/
