/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : reducebuffer.c                                 */
/*                                                                           */
/* Created:       2010/11/12 (JLe)                                           */
/* Last modified: 2011/11/30 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Reduces data from OpenMP distributed buffer to thread 0      */
/*                                                                           */
/* Comments: - Tää liittyy sellaiseen epäilyyn että BufVal(), BufMean(), ym. */
/*             funktiot muuttuu älyttömän hitaiksi jos bufferin koko ylittää */
/*             välimuistin koon, tjsp. Ongelma ei ilmeisesti johtunutkaan    */
/*             siitä vaan ClearBuffer():in viemästä ajasta, mutta ehkä tää   */
/*             vähän selkeyttää noita rutiineja                              */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ReduceBuffer:"

/*****************************************************************************/

void ReduceBuffer()
{
  long sz, i, n, max;
  const double *buf;

  /* Check and set reduced flag */

  if ((long)RDB[DATA_BUF_REDUCED] == YES)
    return;
  else
    WDB[DATA_BUF_REDUCED] = (double)YES;

  /* Return if shared buffer */

  if ((long)RDB[DATA_OPTI_SHARED_BUF] == YES)
    return;

  /* Get buffer segment and data size */

  sz = (long)RDB[DATA_REAL_BUF_SIZE];
  max = (long)RDB[DATA_ALLOC_BUF_SIZE];

  /* Get read-only pointer to data (ei varmaan vaikuta) */

  buf = (const double *)BUF;

  /* Loop over OpenMP threads > 1 and buffer size */

  for (i = 1; i < (long)RDB[DATA_OMP_MAX_THREADS]; i++)
    for (n = 0; n < max; n++)
      BUF[n] = BUF[n] + buf[i*sz + n];

  /****************************************************************************/
}

/*****************************************************************************/
