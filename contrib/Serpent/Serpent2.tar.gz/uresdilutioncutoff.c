/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : uresdilutioncutoff.c                           */
/*                                                                           */
/* Created:       2011/11/08 (JLe)                                           */
/* Last modified: 2011/11/15 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Nuclide-wise infinite-dilution cut-off for unresolved        */
/*              resonance probability table sampling                         */
/*                                                                           */
/* Comments: - This routine operates on single nuclides. Cut-off for         */
/*             reaction lists is done in nextreaction.c                      */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "UresDilutionCutoff:"

/*****************************************************************************/

void UresDilutionCutoff()
{
  long nuc, mat, loc0, rea, nused, nacti;
  double adens, Emin, Emax;

  /* Check ures flag */

  if ((long)RDB[DATA_USE_URES] == NO)
    return;

  /* Ures energy boundaries */

  WDB[DATA_URES_EMIN] = INFTY;
  WDB[DATA_URES_EMAX] = -INFTY;

  /* Reset nuclide ures sampling flags */
  
  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Reset flag */

      WDB[nuc + NUCLIDE_URES_SAMPLING] = (double)NO;
      
      /* Next nuclide */

      nuc = NextItem(nuc);
    }

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Pointer to list */
      
      if ((loc0 = (long)RDB[mat + MATERIAL_PTR_TOT_URES_LIST]) > VALID_PTR)
	{
	  /* Rewind */
	      
	  RewindReaList(loc0, 0);
	      
	  /* Loop over reactions and add counte */
	      
	  while (NextReaction(loc0, &rea, &adens, &Emin, &Emax,0) > -1)
	    {
	      /* Check reaction pointer */
	      
	      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
		      
	      /* Pointer to nuclide */

	      nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
	      CheckPointer(FUNCTION_NAME,"(nuc)", DATA_ARRAY, nuc);

	      /* Compare to global boundaries */
	      
	      if (RDB[nuc + NUCLIDE_URES_EMIN] < RDB[DATA_URES_EMIN])
		WDB[DATA_URES_EMIN] = RDB[nuc + NUCLIDE_URES_EMIN];
		  
	      if (RDB[nuc + NUCLIDE_URES_EMAX] > RDB[DATA_URES_EMAX])
		WDB[DATA_URES_EMAX] = RDB[nuc + NUCLIDE_URES_EMAX];

	      /* Set ures sampling flag */

	      WDB[nuc + NUCLIDE_URES_SAMPLING] = (double)YES;
	    }
	}
      
      /* Next material */

      mat = NextItem(mat);
    }

  /* Count number of nuclides */
  
  nused = 0;
  nacti = 0;
  
  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Check flags */

      if ((long)RDB[nuc + NUCLIDE_URES_SAMPLING] == YES)
	nacti++;
      
      if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_URES_USED)
	nused++;

      /* Next nuclide */

      nuc = NextItem(nuc);
    }

  /* Print */

  if (nacti == 1)
    fprintf(out, "Ures ptable data used with One nuclide:\n\n");
  else if (nacti > 0)
    fprintf(out, "Ures ptable data used with %ld nuclides:\n\n", nacti);
  
  /* Loop over nuclides */
  
  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Check flag */
      
      if ((long)RDB[nuc + NUCLIDE_URES_SAMPLING] == YES)
	fprintf(out, "%12s (from %1.2E to %1.2E MeV)\n", 
		GetText(nuc + NUCLIDE_PTR_NAME), RDB[nuc + NUCLIDE_URES_EMIN], 
		RDB[nuc + NUCLIDE_URES_EMAX]);
      
      /* Next nuclide */
      
      nuc = NextItem(nuc);
    }
  
  if (nused - nacti == 1)
    fprintf(out, 
	    "\nUres ptable data excluded by cut-offs in one nuclide.\n\n");
  else if ((nacti == 0) && (nused > 0))
    fprintf(out, "All ures ptables excluded by cut-offs.\n\n");
  else if (nused - nacti > 0)
    fprintf(out,
	    "\nUres ptable data excluded by cut-offs in %ld nuclides.\n\n",
	    nused - nacti);
  else
    fprintf(out, "\n");

  /* Set count */

  WDB[DATA_URES_USED] = (double)nacti;
}

/*****************************************************************************/
