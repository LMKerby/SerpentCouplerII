/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : calculatetransmuxs.c                           */
/*                                                                           */
/* Created:       2011/04/23 (JLe)                                           */
/* Last modified: 2012/02/02 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates one-group transmutation cross sections and        */
/*              fission yields                                               */
/*                                                                           */
/* Comments: - Noita B1-spektrin kertoimia ei vielä kerrota varsinaiseen     */
/*             vuospektriin mukaan, moniryhmäreaktionopeuksiin kyllä. Homma  */
/*             vaatii vielä aika paljon säätöä. Moniryhmäreaktionopeuksille  */
/*             oletetaan myös että B1-spektri on sama (indeksointi lähtee    */
/*             nollasta). Sama ongelma koskee fissiojakaumia.                */
/*                                                                           */
/*           - Values read from RES2 data block are truncated to 6 decimals  */
/*             to avoid round-off errors in reproducible MPI mode.           */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CalculateTransmuXS:"

/*****************************************************************************/

void CalculateTransmuXS(long mat, long id)
{
  long loc0, loc1, n, dep, rea, bins, ptr, i0, ne, erg, erg0, sz, i1;
  long nuc, rea1;
  double *f, g, sum, E, E0, E1, E2, Emin, Emax, *xs, *spec, val;

  /* Check burnup mode and burn flag */

  if (((long)RDB[DATA_RUNNING_MODE] != RUNNING_MODE_INT_BURN) ||
      (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)))
    return;

  /* Check decay only mode */

  if ((long)RDB[DATA_BURN_DECAY_CALC] == YES)
    return;

  /* Number of few-group energy bins */

  bins = (long)RDB[DATA_BU_MG_EGRID_NE];
  CheckValue(FUNCTION_NAME, "ne", "", bins, 1.0, 10000.0);

  /* Allocate memory */
      
  f = (double *)Mem(MEM_ALLOC, bins, sizeof(double));
      
  /* Check if critical spectrum calculation is used */
  
  if (1 == 2)
    {
      /* Get weight factors */
      
      Die(FUNCTION_NAME, "Not there yet");
    }
  else
    {
      /* Set weight factors to one (NOTE: memset jostain syystä bugittaa */
      /* jos lukuja on vaan 1 --> selvitä). */

      for (n = 0; n < bins; n++)
	f[n] = 1.0;
    }

  /* Reset pointer to spectrum */

  spec = NULL;

  /* Pointer to unionized grid data */

  if ((erg0 = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID]) > VALID_PTR)
    {
      /* Number of grid points */

      sz = (long)RDB[erg0 + ENERGY_GRID_NE];

      /* Pointer to points */

      loc1 = (long)RDB[erg0 + ENERGY_GRID_PTR_DATA];

      /* Allocate memory for spectrum */

      if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] == YES)
	spec = Mem(MEM_ALLOC, sz, sizeof(double));  
  
      /* Get pointer to flux spectrum */

      loc0 = (long)RDB[mat + MATERIAL_PTR_FLUX_SPEC];
      CheckPointer(FUNCTION_NAME, "(loc0)", RES2_ARRAY, loc0);
      
      /* Read data */
  
      for (n = 0; n < sz; n++)
	spec[n] = Truncate(GetPrivateRes(loc0 + n), 6);
    }
  else
    {
      sz = 0;
      loc1 = -1;
    }

  /* Allocate memory for temporary array if microscopic data is not */
  /* reconstructed */

  if ((long)RDB[DATA_OPTI_RECONSTRUCT_MICROXS] == NO)
    xs = Mem(MEM_ALLOC, sz, sizeof(double));	
  else
    xs = NULL;

  /* Set energy intervals */
      
  Emin = RDB[DATA_BU_MG_EGRID_EMIN];
  Emax = RDB[DATA_BU_MG_EGRID_EMAX];

  /***************************************************************************/

  /***** Transmutation cross sections ****************************************/

  /* Pointer to depletion list (onko toi lista aina olemassa?) */
  
  dep = (long)RDB[mat + MATERIAL_PTR_DEP_TRA_LIST];
  CheckPointer(FUNCTION_NAME, "(dep)", DATA_ARRAY, dep);

  /* Loop over reactions */
      
  while (dep > VALID_PTR)
    {
      /* Pointer to reaction */
      
      rea = (long)RDB[dep + DEP_TRA_PTR_REA];
      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
      
      /* Skip total fission */
      
      if ((long)RDB[rea + REACTION_MT] < 0)
	{
	  /* Pointer to next */

	  dep = NextItem(dep);

	  /* Cycle loop */

	  continue;
	}

      /* Reset sum */
      
      sum = 0.0;
      
      /* Pointer to data */
     
      ptr = (long)RDB[dep + DEP_TRA_PTR_RESU];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      
      /* Loop over bins and add spectrum-weighted values to sum */
	  
      for (n = 0; n < bins; n++)
	{
	  /* Check coefficient */

	  if (f[n] != 1.0)
	    Die(FUNCTION_NAME, "f[%ld] = %E\n", n, f[n]);

	  /* Get value and truncate */

	  val = Truncate(GetPrivateRes(ptr + n), 6);

	  /* Add to sum */

	  sum = sum + f[n]*val;
	}

      /* Check spectrum-collapse method */

      if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] == YES)
	{
	  /* Get pointer to energy grid */
	  
	  erg = (long)RDB[rea + REACTION_PTR_EGRID];
	  CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);

	  /* Get pointer to grid data */

	  erg = (long)RDB[erg + ENERGY_GRID_PTR_DATA];
	  CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);

	  /* Get first energy point and number of points */
	  
	  i0 = (long)RDB[rea + REACTION_XS_I0];
	  ne = (long)RDB[rea + REACTION_XS_NE];
	  
	  /* Pointer to cross section data */
	  
	  ptr = (long)RDB[rea + REACTION_PTR_XS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  
	  /* Check reconstruction option */
	  
	  if ((long)RDB[DATA_OPTI_RECONSTRUCT_MICROXS] == YES)
	    {
	      /* Copy pointer */
	      
	      xs = &WDB[ptr];
	      
	      /* Set xs start index to zero */
	      
	      i1 = 0;
	    }
	  else
	    {
	      /* Check pointer */

	      CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);

	      /* Reconstruct data on new array */
	      
	      InterpolateData(&RDB[loc1], xs, sz, &RDB[erg + i0], 
			      &RDB[ptr], ne, 0, &i1, &ne);
	      
	      /* One step back if not at the beginning */
	      
	      if (i1 > 0)
		i1--;
	      
	      /* Set energy grid start index equal to xs index */
	      
	      i0 = i1;
	    }

	  /* Loop over data and add to sum (TODO: multiply by f) */
	  
	  for (n = 0; n < ne; n++)
	    {
	      /* Get energy */
	      
	      E = RDB[loc1 + n + i1];

	      /* Compare to spectrum boundaries (NOTE: Yhtäsuuruusmerkki */
	      /* tarvitaan) */
	      
	      if ((E <= Emin) || (E >= Emax))
		sum = sum + spec[i0 + n]*xs[i1 + n];
	      else if (spec[i0 + n] != 0.0)
		Die(FUNCTION_NAME, "Value should be zero");
	    }
	}

      /* Check total flux and divide by total */
      
      ptr = (long)RDB[mat + MATERIAL_PTR_FLUX_SPEC_SUM];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);

      /* Get value and truncate */

      val = Truncate(GetPrivateRes(ptr), 6);

      /* Divide sum */

      if (val > 0.0)  
	sum = sum/val;
      else if (sum > 0.0)
	Die(FUNCTION_NAME, "Error in sums");	    

      /* Store value */
      
      StoreValuePair(rea + REACTION_PTR_TRANSMUXS, mat, sum, id);

      /* Next reaction */

      dep = NextItem(dep);
    }
  
  /***************************************************************************/

  /***** Partial fission cross sections **************************************/

  /* Pointer to fission list (tätä ei välttämättä ole) */
  
  dep = (long)RDB[mat + MATERIAL_PTR_DEP_FISS_LIST];

  /* Loop over reactions */
  
  while (dep > VALID_PTR)
    {
      /* Pointer to reaction */
      
      rea = (long)RDB[dep + DEP_TRA_PTR_REA];
      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
      
      /* Pointer to nuclide data */
      
      nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
      
      /* Pointer to total fission */
      
      rea1 = (long)RDB[nuc + NUCLIDE_PTR_TOTFISS_REA];
      CheckPointer(FUNCTION_NAME, "(rea1)", DATA_ARRAY, rea1);
      
      /* Get interpolation energies */
      
      E0 = RDB[rea + REACTION_FISSY_IE0];
      E1 = RDB[rea + REACTION_FISSY_IE1];
      E2 = RDB[rea + REACTION_FISSY_IE2];
      
      /* Check values */
      
      CheckValue(FUNCTION_NAME, "E1" ,"", E1, E0, E2);
      
      /* Reset sum */
      
      sum = 0.0;
      
      /* Pointer to data */
      
      ptr = (long)RDB[dep + DEP_TRA_PTR_RESU];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      
      /* Loop over bins and add spectrum-weighted values to sum */
      
      for (n = 0; n < bins; n++)
	{
	  /* Get value and truncate */
	  
	  val = Truncate(GetPrivateRes(ptr + n), 6);
	  
	  /* Add to sum */
	  
	  sum = sum + f[n]*val;
	}
      
      /* Check spectrum-collapse method */
      
      if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] == YES)
	{
	  /* Check pointer to parent reaction */
	  
	  if ((ptr = (long)RDB[rea + REACTION_PTR_BRANCH_PARENT]) > VALID_PTR)
	    {
	      /* Get first energy point and number of points */
	      
	      i0 = (long)RDB[ptr + REACTION_XS_I0];
	      ne = (long)RDB[ptr + REACTION_XS_NE];
	      
	      /* Get pointer to energy grid */
	      
	      erg = (long)RDB[ptr + REACTION_PTR_EGRID];
	      CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);
	      
	      /* Get pointer to grid data */
	      
	      erg = (long)RDB[erg + ENERGY_GRID_PTR_DATA];
	      CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);
	      
	      /* Pointer to cross section data */
	      
	      ptr = (long)RDB[ptr + REACTION_PTR_XS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	    }
	  else
	    {
	      /* Get first energy point and number of points */
	      
	      i0 = (long)RDB[rea + REACTION_XS_I0];
	      ne = (long)RDB[rea + REACTION_XS_NE];
	      
	      /* Get pointer to energy grid */
	      
	      erg = (long)RDB[rea + REACTION_PTR_EGRID];
	      CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);
	      
	      /* Get pointer to grid data */
	      
	      erg = (long)RDB[erg + ENERGY_GRID_PTR_DATA];
	      CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);
	      
	      /* Pointer to cross section data */
	      
	      ptr = (long)RDB[rea + REACTION_PTR_XS];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	    }
	  
	  /* Check reconstruction option */
	  
	  if ((long)RDB[DATA_OPTI_RECONSTRUCT_MICROXS] == YES)
	    {
	      /* Copy pointer */
	      
	      xs = &WDB[ptr];
	      
	      /* Set xs start index to zero */
	      
	      i1 = 0;
	    }
	  else
	    {
	      /* Reconstruct data on new array */
	      
	      InterpolateData(&RDB[loc1], xs, sz, &RDB[erg + i0], 
			      &RDB[ptr], ne, 0, &i1, &ne);
	      
	      /* One step back if not at the beginning */
	      
	      if (i1 > 0)
		i1--;
	      
	      /* Set energy grid start index equal to xs index */
	      
	      i0 = i1;
	    }
	  
	  /* Loop over data and calculate sum */
	  
	  for (n = 0; n < ne; n++)
	    {
	      /* Get energy */
	      
	      E = RDB[loc1 + i1 + n];
	      
	      /* Compare to spectrum boundaries (NOTE: Yhtäsuuruusmerkki */
	      /* tarvitaan) */
	      
	      if ((E <= Emin) || (E >= Emax))
		{
		  /* Compare to interval boundaries */
		  
		  if ((E >= E0) && (E <= E2))
		    {
		      /* Calculate interpolation factor */
		      
		      if (E < E1)
			{
			  /* Below interpolation energy */
			  
			  if (E0 < 0.0)
			    g = 1.0;
			  else
			    g = (E - E0)/(E1 - E0);
			}
		      else
			{
			  /* Above interpolation energy */
			  
			  if (E2 > 1000.0)
			    g = 1.0;
			  else
			    g = (E2 - E)/(E2 - E1);
			}
		      
		      /* Check factor */
		      
		      CheckValue(FUNCTION_NAME, "f", "", g, 0.0, 1.0);
		      
		      /* Add to sum */
		      
		      sum = sum + g*spec[i0 + n]*xs[i1 + n];
		    }
		}
	      else if (spec[i0 + n] != 0.0)
		Die(FUNCTION_NAME, "Value should be zero");
	    }
	}
	
      /* Check total flux and divide by total */

      ptr = (long)RDB[mat + MATERIAL_PTR_FLUX_SPEC_SUM];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      
      /* Get value and truncate */
      
      val = Truncate(GetPrivateRes(ptr), 6);

      /* Divide sum */
      
      if (val > 0.0)	  
	sum = sum/val;
      else if (sum > 0.0)
	Die(FUNCTION_NAME, "Error in sums");	    
      
      /* Check value */
      
      CheckValue(FUNCTION_NAME, "sum2", "", sum, 0.0, 1E+6);
      
      /* Store value */
      
      StoreValuePair(rea + REACTION_PTR_TRANSMUXS, mat, sum, id);
      
      /* Add to total fission */
      
      AddValuePair(rea1 + REACTION_PTR_TRANSMUXS, mat, sum, id);
    
      /* Next reaction */

      dep = NextItem(dep);
    }

  /***************************************************************************/

  /* Free memory */

  Mem(MEM_FREE, f);

  if ((long)RDB[DATA_OPTI_RECONSTRUCT_MICROXS] == NO)
    Mem(MEM_FREE, xs);

  if (spec != NULL)
    Mem(MEM_FREE, spec);

  /***************************************************************************/
}

/*****************************************************************************/
