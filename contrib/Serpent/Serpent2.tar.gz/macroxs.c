/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : macroxs.c                                      */
/*                                                                           */
/* Created:       2011/01/02 (JLe)                                           */
/* Last modified: 2011/11/02 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Interpolates macroscopic cross section                       */
/*                                                                           */
/* Comments: - Rutiinia muutettu radikaalisti 2.11.2011 (2.0.37)             */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "MacroXS:"

/*****************************************************************************/

double MacroXS(long rea0, double E, long id)
{
  long i, ptr, rea, erg, ne, n;
  double xs0, xs1, xs, adens, f, mult, Emin, Emax;

  /* Check Pointer */

  CheckPointer(FUNCTION_NAME, "(rea0)", DATA_ARRAY, rea0);

  /* Test existing data */
  
  if ((xs = TestValuePair(rea0 + REACTION_PTR_PREV_XS, E, id)) > -INFTY)
    return xs;

  /* Reset cross sections */

  xs = 0.0;
  xs0 = 0.0;
  
  /* Get pointer to data */

  if ((ptr = (long)RDB[rea0 + REACTION_PTR_XS]) > VALID_PTR)
    {
      /***** Interpolate pre-calculated data *********************************/

      /* Get pointer to energy grid */

      erg = (long)RDB[rea0 + REACTION_PTR_EGRID];

      /* Check pointer */

      CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);

      /* Get interpolation factor */

      if ((f = GridFactor(erg, E, id)) < 0)
	xs = 0.0;
      else
	{
	  /* Check interpolation factor */

	  CheckValue(FUNCTION_NAME, "f (1)", "", f, 0.0, MAX_EGRID_NE);

	  /* Separate integer and decimal parts of interpolation factor */
      
	  i = (long)f;
	  f = f - (double)i;
      
	  /* Get number of points */
      
	  ne = (long)RDB[rea0 + REACTION_XS_NE];
      
	  /* Check value */
      
	  CheckValue(FUNCTION_NAME, "ne", "", ne, 2, MAX_EGRID_NE);
      
	  /* Check boundaries */
	  
	  if ((i < 0) || (i > ne - 1))
	    xs = 0.0;
	  else
	    {      
	      /* Get tabulated cross sections */
	  
	      xs0 = RDB[ptr + i];
	      xs1 = RDB[ptr + i + 1];
	      
	      /* Interpolate */
	      
	      if (i == ne - 1)
		xs = (1.0 - f)*xs0;
	      else
		xs = f*(xs1 - xs0) + xs0;
	    }
	}

      /* Remember non-adjusted cross section */

      xs0 = xs;

      /* Store value */

      StoreValuePair(rea0 + REACTION_PTR_PREV_XS0, E, xs0, id);
  
      /* Sample unresolved resonance probability table data */

      f = UresFactor(rea0, E, id);

      /* Check value */

      CheckValue(FUNCTION_NAME, "f (2)", "", f, -10.0, INFTY);

      /* Adjust cross section */
      
      xs = f*xs;
      
      /***********************************************************************/
    }
  else
    {
      /***** Calculate sum of partials ***************************************/

      /* Get pointer to partial list */

      ptr = (long)RDB[rea0 + REACTION_PTR_PARTIAL_LIST];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Rewind */
	      
      RewindReaList(ptr, id);

      /* Loop over reactions */
	      
      while ((n = NextReaction(ptr, &rea, &adens, &Emin, &Emax, id)) > -1)
	{
	  /* Check reaction pointer */

	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

	  /* Check threshold */

	  if (E < Emin)
	    {
	      /* Break loop if reaction was read from an ordered list */

	      if (n > 0)
		break;
	    }
	  else
	    {	      	      
	      /* Get multiplication */
	      
	      mult = RDB[rea + REACTION_WGT_F];
	      
	      /* Add to cross section */
	      
	      xs = xs + mult*adens*MicroXS(rea, E, id);
	      
	      /* Add to non-adjusted cross section */
	      
	      xs0 = xs0 + adens*TestValuePair(rea + REACTION_PTR_PREV_XS0,
					      E, id);
	    }
	}

      /* Store non-adjusted cross section */

      StoreValuePair(rea0 + REACTION_PTR_PREV_XS0, E, xs0, id);

      /* Check if ures data exists */

      if ((ptr = (long)RDB[rea0 + REACTION_PTR_URES]) > VALID_PTR)
	{
	  /* Calculate ures factor */

	  if (xs0 > 0.0)
	    f = xs/xs0;
	  else
	    f = 1.0;

	  /* Check value */

	  CheckValue(FUNCTION_NAME, "f (3)", "", f, ZERO, INFTY);

	  /* Store factor */

	  StoreValuePair(ptr + URES_PTR_PREV_FACT, E, f, id);
	}

      /***********************************************************************/
    }

  /* Store cross section */

  StoreValuePair(rea0 + REACTION_PTR_PREV_XS, E, xs, id);

  /* Return interpolated value */

  return xs;
}

/*****************************************************************************/
