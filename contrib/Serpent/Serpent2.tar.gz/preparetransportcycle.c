/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : preparetransportcycle.c                        */
/*                                                                           */
/* Created:       2011/05/23 (JLe)                                           */
/* Last modified: 2012/01/18 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calls all subroutines that need to be run before the         */
/*              transport cycle                                              */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "PrepareTransportCycle:"

/*****************************************************************************/

void PrepareTransportCycle()
{
  double mem, ptr, type;

  /* Start process timers */

  ResetTimer(TIMER_PROCESS);
  StartTimer(TIMER_PROCESS);
  StartTimer(TIMER_PROCESS_TOTAL); 

  /* Memory size before processing */

  mem = RDB[DATA_TOTAL_BYTES];
  
  /* Get burnup step type (not set in transport mode) */

  type = (long)RDB[DATA_BURN_STEP_TYPE];

  /* Normalize compositions */

  NormalizeCompositions();

  /**************** Nää siirrettiin transportcyclestä ************/
  
  /* Check step type */

  if ((type != DEP_STEP_DEC_STEP) && (type != DEP_STEP_DEC_TOT))
    {
      /* Generate reaction lists */

      ProcessReactionLists();

      /* Calculate total cross sections */

      MaterialTotals();

      /* Distribute material data from to parallel MPI tasks (burnable */
      /* material compositions are located in different position and   */
      /* distributed in CollectBurnData(), called from BurnupCycle().  */

      DistributeMaterialData();

      /* Ures ptable dilution cut-off */

      UresDilutionCutoff();

      /* Energy groups for spectrum-collapse method */
  
      ProcessBurnupEGroups();
  
      /* Calculate majorants for delta-tracking */

      CalculateDTMajorants();

      /* Plot XS data */

      XSPlotter();
    }

  /***************************************************************/

  /* Calculate masses */

  CalculateMasses();

  /* Calculate activities */

  CalculateActivities();

  /* Reset statistics */

  ClearStat(-1);

  /* Reset transmutation reaction rates etc. */

  ClearTransmuXS();  

  /* Check memory size */

  if (((long)RDB[DATA_BURN_STEP] > 0) && (mem != RDB[DATA_TOTAL_BYTES]))
    Die(FUNCTION_NAME, "Change in total memory size");

  /* Clear some counters */

  ptr = (long)RDB[DATA_PTR_OMP_HISTORY_COUNT];
  CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
  ClearPrivateData(ptr);
  
  WDB[DATA_NHIST_CYCLE] = 0.0;

  /* Stop process timers */

  StopTimer(TIMER_PROCESS);
  StopTimer(TIMER_PROCESS_TOTAL);
}

/*****************************************************************************/
