/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processmeshplots.c                             */
/*                                                                           */
/* Created:       2011/03/20 (JLe)                                           */
/* Last modified: 2012/01/24 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Processes mesh plots                                         */
/*                                                                           */
/* Comments: - Tässä varaillaan muistia vähän tarpeettomasti jos tyyppi on   */
/*             1-arvoinen jakauma.                                           */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessMeshPlots:"

/*****************************************************************************/

void ProcessMeshPlots()
{
  long mpl, nx, ny, ptr, n, det, ax, type;
  double xmin, xmax, ymin, ymax, zmin, zmax;
  char tmpstr[MAX_STR];

  /* Reset counter */

  n = 1;

  /* Loop over plots */

  mpl = (long)RDB[DATA_PTR_MPL0];
  while(mpl > VALID_PTR)
    {
      /* Get limits */

      if ((xmin = RDB[mpl + MPL_XMIN]) == -INFTY)
	xmin = RDB[DATA_GEOM_MINX];

      if ((xmax = RDB[mpl + MPL_XMAX]) == INFTY)
	xmax= RDB[DATA_GEOM_MAXX];

      if ((ymin = RDB[mpl + MPL_YMIN]) == -INFTY)
	ymin = RDB[DATA_GEOM_MINY];

      if ((ymax = RDB[mpl + MPL_YMAX]) == INFTY)
	ymax= RDB[DATA_GEOM_MAXY];

      if ((zmin = RDB[mpl + MPL_ZMIN]) == -INFTY)
	zmin = RDB[DATA_GEOM_MINZ];

      if ((zmax = RDB[mpl + MPL_ZMAX]) == INFTY)
	zmax= RDB[DATA_GEOM_MAXZ];

      /* Get type */

      type = (long)RDB[mpl + MPL_TYPE];

      /* Get axis and set dimensions */

      ax = (long)RDB[mpl + MPL_AX];

      /* Check is and set coordinates */

      if (ax == 1)
	{
	  /* distribution in yz-plane */
	      
	  WDB[mpl + MPL_XMIN] = ymin;
	  WDB[mpl + MPL_XMAX] = ymax;

	  WDB[mpl + MPL_YMIN] = zmin;
	  WDB[mpl + MPL_YMAX] = zmax;

	  WDB[mpl + MPL_ZMIN] = xmin;
	  WDB[mpl + MPL_ZMAX] = xmax;
	}
      else if (ax == 2)
	{
	  /* distribution in xz-plane */
	  
	  WDB[mpl + MPL_XMIN] = xmin;
	  WDB[mpl + MPL_XMAX] = xmax;

	  WDB[mpl + MPL_YMIN] = zmin;
	  WDB[mpl + MPL_YMAX] = zmax;

	  WDB[mpl + MPL_ZMIN] = ymin;
	  WDB[mpl + MPL_ZMAX] = ymax;
	}
      else
	{
	  /* distribution in xy-plane */
	  
	  WDB[mpl + MPL_XMIN] = xmin;
	  WDB[mpl + MPL_XMAX] = xmax;

	  WDB[mpl + MPL_YMIN] = ymin;
	  WDB[mpl + MPL_YMAX] = ymax;

	  WDB[mpl + MPL_ZMIN] = zmin;
	  WDB[mpl + MPL_ZMAX] = zmax;
	}

      /* Get size */

      nx = (long)RDB[mpl + MPL_NX];
      ny = (long)RDB[mpl + MPL_NY];

      /* Allocate memory */

      ptr = CreateMesh(MESH_TYPE_CARTESIAN, MESH_CONTENT_DATA, 
		       nx, RDB[mpl + MPL_XMIN], RDB[mpl + MPL_XMAX], 
		       ny, RDB[mpl + MPL_YMIN], RDB[mpl + MPL_YMAX], 
		       1, RDB[mpl + MPL_ZMIN], RDB[mpl + MPL_ZMAX]);

      WDB[mpl + MPL_PTR_F0] = (double)ptr;

      ptr = CreateMesh(MESH_TYPE_CARTESIAN, MESH_CONTENT_DATA, 
		       nx, RDB[mpl + MPL_XMIN], RDB[mpl + MPL_XMAX], 
		       ny, RDB[mpl + MPL_YMIN], RDB[mpl + MPL_YMAX], 
		       1, RDB[mpl + MPL_ZMIN], RDB[mpl + MPL_ZMAX]);

      WDB[mpl + MPL_PTR_F1] = (double)ptr;

      ptr = CreateMesh(MESH_TYPE_CARTESIAN, MESH_CONTENT_DATA, 
		       nx, RDB[mpl + MPL_XMIN], RDB[mpl + MPL_XMAX], 
		       ny, RDB[mpl + MPL_YMIN], RDB[mpl + MPL_YMAX], 
		       1, RDB[mpl + MPL_ZMIN], RDB[mpl + MPL_ZMAX]);

      WDB[mpl + MPL_PTR_F2] = (double)ptr;

      /* Set file name */

      sprintf(tmpstr, "%s_mesh%ld", GetText(DATA_PTR_INPUT_FNAME), n++);
      WDB[mpl + MPL_PTR_FNAME] = (double)PutText(tmpstr);

      /* Link detector */

      if (((long)RDB[mpl + MPL_TYPE] == MPL_TYPE_DET) ||
	  ((long)RDB[mpl + MPL_TYPE] == MPL_TYPE_DET_IMP))
	{
	  /* Find detector */
	  
	  det = RDB[DATA_PTR_DET0];
	  CheckPointer(FUNCTION_NAME, "(det)", DATA_ARRAY, det);

	  if ((det = SeekListStr(det, DET_PTR_NAME, 
				 GetText(mpl + MPL_PTR_DET))) < VALID_PTR)
	    Error(mpl, "Detector %s not defined", GetText(mpl + MPL_PTR_DET));
	  
	  /* Set pointer */

	  WDB[mpl + MPL_PTR_DET] = (double)det;
	}

      /* Switch history lists on if importance type */

      if ((long)RDB[mpl + MPL_TYPE] == MPL_TYPE_DET_IMP)
	WDB[DATA_HIST_LIST_SIZE] = fabs(RDB[DATA_HIST_LIST_SIZE]);

      /* Next plot */

      mpl = NextItem(mpl);
    }
}

/*****************************************************************************/
