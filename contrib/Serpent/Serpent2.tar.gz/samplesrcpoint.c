/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : samplesrcpoint.c                               */
/*                                                                           */
/* Created:       2011/03/02 (JLe)                                           */
/* Last modified: 2012/02/01 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Samples neutron source point                                 */
/*                                                                           */
/* Comments: - Toi cell-haku ei toimi ihan oikein sillä whereami palauttaa   */
/*             alimman cellin. Universumihakua ei oo edes tehty vielä.       */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "SampleSrcPoint:"
#define MAX_SRC_RESAMPLE 1000000

/*****************************************************************************/

long SampleSrcPoint(long id, long np)
{
  long n, cell, mat, src, cell0, mat0, surf, lst, loc0, loc1, rea, ptr, idx;
  long type, stp, part, npmin, npmax;
  unsigned long seed;
  double rnd, mu, x, y, z, u, v, w, E, wgt, xmin, xmax, ymin, ymax, zmin, zmax;

  /***************************************************************************/

  /***** Divide initial criticality source to MPI tasks **********************/

  /* Check simulation mode and number of tasks */
  
  if (((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT) && 
      (mpitasks > 1))
    {
      /* Calculate number of particles per task */

      npmax = (long)(RDB[DATA_NBATCH]/((double)mpitasks));

      /* Calculate minimum and maximum particle index for this task */

      npmin = mpiid*npmax;
      
      if (mpiid < mpitasks - 1)
	npmax = (mpiid + 1)*npmax;
      else
	npmax = (long)RDB[DATA_NBATCH];

      /* Check with task number */
      
      if ((np < npmin) || (np > npmax - 1))
	return -1;
    }

  /***************************************************************************/
  
  /***** Source sampling starts here *****************************************/

  /* Avoid compiler warning */

  idx = -1;

  /* Reset material pointer */

  mat = -1;

  /* Check simulation mode */

  if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC)
    {
      Die(FUNCTION_NAME, "ei pelaa");

#ifdef OPEN_MP
#pragma omp critical
#endif
      {
	/* Init random number sequence */
	
	seed = ReInitRNG(np);
	
	/* Put seed in private data */

	ptr = (long)RDB[DATA_PTR_RNG_SEED];
	PutPrivateData(ptr, seed, id);

	/* Get particle index */

	idx = np;

	/* Increase counter */

	WDB[DATA_NHIST_CYCLE] = RDB[DATA_NHIST_CYCLE] + 1.0;
      }
    }
  else
    {
      /* Init random number sequence */
      
      seed = ReInitRNG(np);
      
      /* Put seed in private data */
      
      ptr = (long)RDB[DATA_PTR_RNG_SEED];
      PutPrivateData(ptr, seed, id);

      /* Add to simulated batch size (this is different from DATA_NBATCH in */
      /* MPI mode, and may be different for each parallel task) */

      WDB[DATA_SIMUL_BATCH_SIZE] = WDB[DATA_SIMUL_BATCH_SIZE] + 1.0;
    }

  /* Check if souce definition exist */

  if ((long)RDB[DATA_PTR_SRC0] < VALID_PTR)
    {
      /***********************************************************************/

      /***** Default uniform fission source **********************************/
      
      /* Loop until neutron is in fissile material */

      for (n = 0; n < MAX_SRC_RESAMPLE; n++)
	{
	  /* Sample coordinates */
		  
	  x = RandF(id)*(RDB[DATA_GEOM_MAXX] - RDB[DATA_GEOM_MINX])
	    + RDB[DATA_GEOM_MINX];
	  y = RandF(id)*(RDB[DATA_GEOM_MAXY] - RDB[DATA_GEOM_MINY])
	    + RDB[DATA_GEOM_MINY];
		  
	  if ((long)RDB[DATA_GEOM_DIM] == 3)
	    z = RandF(id)*(RDB[DATA_GEOM_MAXZ] - RDB[DATA_GEOM_MINZ])
	      + RDB[DATA_GEOM_MINZ];
	  else
	    z = 0.0;
		
	  /* Find location */
	  
	  if ((cell = WhereAmI(x, y, z, u, v, w, id)) > VALID_PTR)
	    {
	      /* Test boundary conditions */
	      
	      if (BoundaryConditions(&x, &y, &z, &u, &v, &w, id) == YES)
		cell = WhereAmI(x, y, z, u, v, w, id);
		
	      /* Check if cell contains fissile material */

	      if ((mat = (long)RDB[cell + CELL_PTR_MAT]) > VALID_PTR)
		if (((long)RDB[mat + MATERIAL_OPTIONS] & OPT_FISSILE_MAT) ||
		    ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC))
		  {
		    /* Sample isotropic direction */
		    
		    IsotropicDirection(&u, &v, &w, id);

		    /* Energy from a maxwellian distribution */

		    E = MaxwellEnergy(1.2895, id);

		    /* Set weight to unity */

		    wgt = 1.0;

		    /* Break loop */

		    break;
		  }
	    }
	}
      
      /* Set type to neutron */

      type = PARTICLE_TYPE_NEUTRON;

      /* Check error */
      
      if (n == MAX_SRC_RESAMPLE)
	Error(0, "Unable to sample fission source - try explicit definition");
      
      /***********************************************************************/
    }
  else
    {
      /***** Source from user-defined distribution ***************************/

      /* Sample source definition */
      
      rnd = RandF(id);
      
      /* loop over sources */
      
      src = (long)RDB[DATA_PTR_SRC0];
      while (src > VALID_PTR)
	{
	  /* Compare to weight */
	  
	  if ((rnd = rnd - RDB[src + SRC_WGT]) < 0.0)
	    break;
	  
	  /* Next source definition */
	  
	  src = NextItem(src);
	}
      
      /* Check pointer */
      
      if (src < VALID_PTR)
	Die(FUNCTION_NAME, "Unable to sample source");
      
      /* NOTE: Tähän voisi lisätä sellasen moodin että noita arvotaan */
      /*       samalla todennäköisyydellä mutta eri painolla. */
      
      /* Set weight to unity */
      
      wgt = 1.0;

      /* Set type */

      type = (long)RDB[src + SRC_TYPE];

      /* Check */

      if ((type != PARTICLE_TYPE_NEUTRON) && (type != PARTICLE_TYPE_GAMMA))
	Die(FUNCTION_NAME, "Invalid particle type");
      
      /***********************************************************************/
      
      /***** Direction *******************************************************/
      
      /* Check if isotropic */
      
      if (RDB[src + SRC_U0] > 1.0)
	IsotropicDirection(&u, &v, &w, id);
      else
	{
	  /* Set values */
	  
	  u = RDB[src + SRC_U0];
	  v = RDB[src + SRC_V0];
	  w = RDB[src + SRC_W0];
	}
      
      /***********************************************************************/
      
      /***** Energy **********************************************************/

      /* Check source energy */

      if ((E = RDB[src + SRC_E]) > ZERO)
	{
	  /* Check particle type */

	  if (type == PARTICLE_TYPE_NEUTRON)
	    {
	      /* Compare to upper boundary */
	      
	      if (E > RDB[DATA_NEUTRON_EMAX])
		Error(src, "Source energy above maximum (%1.2f MeV)", 
		      RDB[DATA_NEUTRON_EMAX]);
	      
	      /* Compare to lower boundary */
	      
	      if (E < RDB[DATA_NEUTRON_EMIN])
		Error(src, "Source energy below minimum (%1.2E MeV)", 
		      RDB[DATA_NEUTRON_EMIN]);
	    }
	  else
	    {
	      /* Compare to upper boundary */
	      
	      if (E > RDB[DATA_PHOTON_EMAX])
		Error(src, "Source energy above maximum (%1.2f MeV)", 
		      RDB[DATA_PHOTON_EMAX]);
	      
	      /* Compare to lower boundary */
	      
	      if (E < RDB[DATA_PHOTON_EMIN])
		Error(src, "Source energy below minimum (%1.2E MeV)", 
		      RDB[DATA_PHOTON_EMIN]);
	    }
	}
            
      /* Check type */
      
      if ((lst = (long)RDB[src + SRC_PTR_EBINS]) > VALID_PTR)
	{
	  /* Bin structure, sample bin */
	  
	  n = (long)(RandF(id)*(ListSize(lst) - 1.0)) + 1;
	  
	  /* Get bin pointers */
	  
	  loc0 = ListPtr(lst, n - 1);
	  loc1 = ListPtr(lst, n);
	  
	  /* Put weight */
	  
	  wgt = wgt*RDB[loc1 + SRC_EBIN_WGT];
	  
	  /* Sample energy between boundaries */
	  
	  E = RandF(id)*(RDB[loc1 + SRC_EBIN_EMAX] - RDB[loc0 + SRC_EBIN_EMAX])
	    + RDB[loc0 + SRC_EBIN_EMAX];
	}
      else if ((rea = (long)RDB[src + SRC_PTR_REA]) > VALID_PTR)
	{
	  /* Put incident energy */
	  
	  if ((E = RDB[src + SRC_E]) < ZERO)
	    E = 1.000001*RDB[rea + REACTION_EMIN];
	  
	  /* Init cosine (-1.0, 0.0 and 1.0 case dubious error) */
	  
	  mu = 0.5;
	  
	  /* Sample energy and direction */
	  
	  SampleENDFLaw(rea, -1, E, &E, &mu, id);
	  
	  /* Check if cosine is changed */
	  
	  if (mu != 0.5)
	    AziRot(mu, &u, &v, &w, id);
	}
      else if ((E = RDB[src + SRC_E]) < ZERO)
	E = 1.0;
      
      /***********************************************************************/
	  
      /***** Position ********************************************************/

      /* Pointer to cell and material */
      
      cell0 = (long)RDB[src + SRC_PTR_CELL];
      mat0 = (long)RDB[src + SRC_PTR_MAT];
      
      /* Re-sampling loop */
      
      for (n = 0; n < MAX_SRC_RESAMPLE; n++)
	{
	  /* Check type */
	  
	  if ((RDB[src + SRC_X0] > -INFTY) && 
	      (RDB[src + SRC_Y0] > -INFTY) &&
	      (RDB[src + SRC_Z0] > -INFTY))
	    {
	      /* Point source, set coordinates */
	      
	      x = RDB[src + SRC_X0];
	      y = RDB[src + SRC_Y0];
	      z = RDB[src + SRC_Z0];
	    }
	  else if ((surf = (long)RDB[src + SRC_PTR_SURF]) > VALID_PTR)
	    {
	      /* Sample point on surface */
	      
	      SurfaceSrc(src, surf, &x, &y, &z, &u, &v, &w, id);
	    }
	  else
	    {
	      /* Get boundaries */

	      if ((xmin = RDB[src + SRC_XMIN]) == -INFTY)
		xmin = RDB[DATA_GEOM_MINX];

	      if ((xmax = RDB[src + SRC_XMAX]) == INFTY)
		xmax = RDB[DATA_GEOM_MAXX];

	      if ((ymin = RDB[src + SRC_YMIN]) == -INFTY)
		ymin = RDB[DATA_GEOM_MINY];

	      if ((ymax = RDB[src + SRC_YMAX]) == INFTY)
		ymax = RDB[DATA_GEOM_MAXY];

	      if ((zmin = RDB[src + SRC_ZMIN]) == -INFTY)
		zmin = RDB[DATA_GEOM_MINZ];

	      if ((zmax = RDB[src + SRC_ZMAX]) == INFTY)
		zmax = RDB[DATA_GEOM_MAXZ];

	      /* Sample coordinates */
	      
	      x = RandF(id)*(xmax - xmin) + xmin;
	      y = RandF(id)*(ymax - ymin) + ymin;
	      
	      if ((long)RDB[DATA_GEOM_DIM] == 3)
		z = RandF(id)*(zmax - zmin) + zmin;
	      else
		z = 0.0;
	    }
	  
	  /* Check boundaries */
	  
	  if ((x > RDB[src + SRC_XMAX]) || (x < RDB[src + SRC_XMIN]) ||
	      (y > RDB[src + SRC_YMAX]) || (y < RDB[src + SRC_YMIN]) ||
	      (z > RDB[src + SRC_ZMAX]) || (z < RDB[src + SRC_ZMIN]))
	    {
	      /* Not within boundaries */
	      
	      Die(FUNCTION_NAME, "Source point outside boundaries");
	    }
	  else if ((cell = WhereAmI(x, y, z, u, v, w, id)) > VALID_PTR)
	    {
	      /* Check cell */
	      
	      if ((cell0 > VALID_PTR) && (cell == cell0))
		break;
	      
	      /* Get material pointer */
	      
	      mat = (long)RDB[cell + CELL_PTR_MAT];
	      
	      /* Check material */
	      
	      if ((mat0 > VALID_PTR) && (mat == mat0))
		break;
	      
	      /* Check if only surface or point source is used */
	      
	      if ((cell0 < VALID_PTR) && (mat0 < VALID_PTR) &&
		  ((long)RDB[cell + CELL_TYPE] != CELL_TYPE_OUTSIDE))
		break;

	      /* Material may be renamed for burnup calculation */

	      if (mat > VALID_PTR)
		if ((mat = (long)RDB[mat + MATERIAL_PTR_DIV_PARENT]) > 
		    VALID_PTR)
		  if ((mat0 > VALID_PTR) && (mat == mat0))
		    break;
	    }
	}

      /* Check failure */
      
      if (n == MAX_SRC_RESAMPLE)
	Error(0, "Source sampling failed because of low efficiency");

      /***********************************************************************/ 
    }

  /* Adjust minimum and maximum energy */

  if (type == PARTICLE_TYPE_NEUTRON)
    {
      if (E < 1.0000001*RDB[DATA_NEUTRON_EMIN])
	E = 1.000001*RDB[DATA_NEUTRON_EMIN];
      else if (E > 0.999999*RDB[DATA_NEUTRON_EMAX])
	E = 0.999999*RDB[DATA_NEUTRON_EMAX];
    }
  else
    {
      if (E < 1.0000001*RDB[DATA_PHOTON_EMIN])
	E = 1.000001*RDB[DATA_PHOTON_EMIN];
      else if (E > 0.999999*RDB[DATA_PHOTON_EMAX])
	E = 0.999999*RDB[DATA_PHOTON_EMAX];
    }

  /* Get particle from stack */

  part = FromStack(type, id);

  /* Put values */

  WDB[part + PARTICLE_X] = x;
  WDB[part + PARTICLE_Y] = y;
  WDB[part + PARTICLE_Z] = z;

  WDB[part + PARTICLE_U] = u;
  WDB[part + PARTICLE_V] = v;
  WDB[part + PARTICLE_W] = w;

  WDB[part + PARTICLE_E] = E;
  WDB[part + PARTICLE_WGT] = wgt;
  WDB[part + PARTICLE_PTR_MAT] = (double)mat;

  /* Check simulation mode */

  if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC)
    {
      /* Score source rate */
  
      stp = (long)RDB[RES_TOT_SRCRATE];
      AddBuf(1.0, wgt, stp, id, 0);

      /* Score source reate in fissile and non-fissile materials */
      
      if (mat > VALID_PTR)
	{
	  if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	    AddBuf(1.0, wgt, stp, id, 1);
	  else
	    AddBuf(1.0, wgt, stp, id, 2);
	}

      /* Put particle index */
      
      WDB[part + PARTICLE_IDX] = idx;
      
      /* Put particle in que */
      
      ToQue(part, id);
    }
  else
    {
      /* Reset particle index */

      WDB[part + PARTICLE_IDX] = (double)np;

      /* Put particle in initial source */

      ToSrc(part);
    }

  /* Return pointer */

  return part;
}


/*****************************************************************************/
