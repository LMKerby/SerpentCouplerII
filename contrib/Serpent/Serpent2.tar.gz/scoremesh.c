/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : scoremesh.c                                    */
/*                                                                           */
/* Created:       2011/03/25 (JLe)                                           */
/* Last modified: 2012/01/24 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Scores distributions for mesh plot                           */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ScoreMesh:"

/*****************************************************************************/

void ScoreMesh(long part, long mat, double flx, double x0, double y0, 
	       double z0, double E, double wgt, long id)
{
  long mpl, ax, mode, ptr, rea, det, hst0, hst;
  double x, y, z, fissxs, H, f, flx0, wgt0, T;

  /* Mesh plots are not scored in void */

  if (mat < VALID_PTR)
    return;

  /* Loop over plots */

  mpl = (long)RDB[DATA_PTR_MPL0];
  while(mpl > VALID_PTR)
    {
      /* Get axis */

      ax = (long)RDB[mpl + MPL_AX];

      /* Check is and set coordinates */

      if (ax == 1)
	{
	  /* distribution in yz-plane */
	      
	  x = y0;
	  y = z0;
	  z = x0;
	}
      else if (ax == 2)
	{
	  /* distribution in xz-plane */
	  
	  x = x0;
	  y = z0;
	  z = y0;
	}
      else
	{
	  /* distribution in xy-plane */
	  
	  x = x0;
	  y = y0;
	  z = z0;
	}

      /* Get mode */

      mode = (long)RDB[mpl + MPL_TYPE];

      /* Check mode */

      if (mode == MPL_TYPE_FLUXPOW)
	{
	  /*******************************************************************/

	  /**** Thermal flux / fission rate mesh *****************************/

	  /* Check material pointer */

	  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

	  /* Fission rate */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_FISSXS]) > VALID_PTR)
	    {
	      /* Get total fission cross section */
	      
	      fissxs = MacroXS(rea, E, id);

	      /* Pointer to data */
	      
	      ptr = (long)RDB[mpl + MPL_PTR_F1];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      /* Add value to mesh */
 
	      AddMesh(ptr, fissxs*wgt*flx, x, y, z, id);
	    }	  
	  
	  /* Thermal flux */
	  
	  else if (E < 0.625E-6)
	    {		 
	      /* Pointer to data */
	      
	      ptr = (long)RDB[mpl + MPL_PTR_F0];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      /* Add value to mesh */
 
	      AddMesh(ptr, wgt*flx, x, y, z, id);
	    }

	  /*******************************************************************/
	}
      else if (mode == MPL_TYPE_FLUXTEMP)
	{
	  /*******************************************************************/

	  /**** Thermal flux / temperature mesh ******************************/

	  /* NOTE: Tähän tulee nyt joku ihan kummallinen painotus */

	  /* Get temperature */
	  
	  if ((T = GetTemp(mat, id)) > 0.0)
	    {	  
	      /* Pointer to data */
	      
	      ptr = (long)RDB[mpl + MPL_PTR_F1];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      
	      /* Add value to mesh */
	      
	      AddMesh(ptr, T*flx*wgt, x, y, z, id);

	      /* Pointer to weight distribution */

	      ptr = (long)RDB[mpl + MPL_PTR_F2];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      
	      /* Add value to mesh */
	      
	      AddMesh(ptr, flx*wgt, x, y, z, id);
	    }	  
	  
	  /* Thermal flux */
	  
	  else if (E < 0.625E-6)
	    {		 
	      /* Pointer to data */
	      
	      ptr = (long)RDB[mpl + MPL_PTR_F0];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      /* Add value to mesh */
 
	      AddMesh(ptr, wgt*flx, x, y, z, id);
	    }

	  /*******************************************************************/
	}
      else if (mode == MPL_TYPE_GAMMAHEAT)
	{
	  /*******************************************************************/
	  
	  /***** Photon energy deposition ************************************/

	  /* Pointer to heating cross section */

	  if ((rea = (long)RDB[mat + MATERIAL_PTR_HEATPHOTXS]) > VALID_PTR)
	    {
	      /* Get heating value */

	      H = PhotonMacroXS(rea, E, id);

	      /* Pointer to data */
	      
	      ptr = (long)RDB[mpl + MPL_PTR_F0];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      /* Add value to mesh */
 
	      AddMesh(ptr, wgt*H*flx, x, y, z, id);
	    }

	  /*******************************************************************/
	}
      else if (mode == MPL_TYPE_COLPT)
	{
	  /*******************************************************************/
	  
	  /***** Number of collisions ****************************************/

	  /* Pointer to data */
	      
	  ptr = (long)RDB[mpl + MPL_PTR_F0];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  /* Add value to mesh */

	  AddMesh(ptr, 1.0, x, y, z, id);

	  /*******************************************************************/
	}
      else if (mode == MPL_TYPE_COLWGT)
	{
	  /*******************************************************************/
	  
	  /***** Collided weight *********************************************/

	  /* Pointer to data */
	      
	  ptr = (long)RDB[mpl + MPL_PTR_F0];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  /* Add value to mesh */

	  AddMesh(ptr, wgt, x, y, z, id);

	  /*******************************************************************/
	}
      else if ((mode == MPL_TYPE_DET) || (mode == MPL_TYPE_DET_IMP))
	{
	  /*******************************************************************/
	  
	  /***** Detector or detector importance *****************************/

	  /* Pointer to detector */

	  det = (long)RDB[mpl + MPL_PTR_DET];

	  /* Get value of response function */

	  if (DetBin(det, mat, x0, y0, z0, E, 0, id) > -1)
	    f = DetResponse((long)RDB[det + DET_PTR_RBINS], mat, E, id);
	  else
	    f = 0.0;

	  /* Add value to mesh */
	  
	  if (mode == MPL_TYPE_DET)
	    {
	      /* Pointer to data */

	      ptr = (long)RDB[mpl + MPL_PTR_F0];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  
	      /* Score responce function */
	      
	      if (f != 0.0)
		AddMesh(ptr, wgt*flx*f, x, y, z, id);
	    }
	  else
	    {
	      /* Pointer to flux distribution */

	      ptr = (long)RDB[mpl + MPL_PTR_F0];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	      /* Score flux */
	      
	      AddMesh(ptr, wgt*flx, x, y, z, id);

	      /* Check response function */
	      
	      if (f != 0.0)
		{
		  /* Pointer to data */

		  ptr = (long)RDB[mpl + MPL_PTR_F1];
		  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		  
		  /* Pointer to particle history */
		  
		  hst0 = (long)RDB[part + PARTICLE_PTR_HIST];
		  
		  /* Loop over history */
		  
		  hst = hst0;
		  while ((hst = PrevItem(hst)) != hst0)
		    {
		      /* Break at unassigned point */
		      
		      if ((wgt0 = RDB[hst + HIST_WGT]) < 0.0)
			break;
		      
		      /* Get coordinates of previous collision point */
		      
		      if (ax == 1)
			{
			  /* distribution in yz-plane */
			  
			  x = RDB[hst + HIST_Y];
			  y = RDB[hst + HIST_Z];
			  z = RDB[hst + HIST_X];
			}
		      else if (ax == 2)
			{
			  /* distribution in xz-plane */
			  
			  x = RDB[hst + HIST_X];
			  y = RDB[hst + HIST_Z];
			  z = RDB[hst + HIST_Y];
			}
		      else
			{
			  /* distribution in xy-plane */
			  
			  x = RDB[hst + HIST_X];
			  y = RDB[hst + HIST_Y];
			  z = RDB[hst + HIST_Z];
			}
		      
		      /* Get flux */
		      
		      flx0 = RDB[hst + HIST_FLX];
		      
		      /* Score responce function */
		      
		      if (wgt0*flx0 > 0.0)
			AddMesh(ptr, wgt*flx*f*wgt0*flx0, x, y, z, id);
		    }
		}
	    }

	  /*******************************************************************/
	}
      else
	Die(FUNCTION_NAME, "Invalid mesh type");

      /* Next plot */

      mpl = NextItem(mpl);
    }
}

/*****************************************************************************/
