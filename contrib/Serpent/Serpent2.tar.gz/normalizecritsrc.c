/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : normalizecritsrc.c                             */
/*                                                                           */
/* Created:       2011/03/10 (JLe)                                           */
/* Last modified: 2011/12/27 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Sets up normalized fission source for criticality source     */
/*              simulation                                                   */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "NormalizeCritSrc:"

/*****************************************************************************/

void NormalizeCritSrc()
{
  long ptr, n, mat, stp, nsrc, nbatch, id;
  double wgt, w0, keff;

  /***************************************************************************/

  /***** Calculate source size and weight ************************************/

  /* Get pointer to target buffer */

  ptr = (long)RDB[DATA_PART_PTR_SRC_READ];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  
  /* Check that target buffer is empty */

  if (ListSize(ptr) != 1)
    Die(FUNCTION_NAME, "Target buffer is not empty");

  /* Reset total weight and source size */

  wgt = 0.0;
  nsrc = 0;

  /* Loop over buffer */

  while (1 != 2)
    {
      /* Pointer to source buffer */

      ptr = (long)RDB[DATA_PART_PTR_SRC_WRITE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
  
      /* Pointer to first item after dummy */

      if ((ptr = NextItem(ptr)) < VALID_PTR)
	break;

      /* Check type */

      if ((long)RDB[ptr + PARTICLE_TYPE] != PARTICLE_TYPE_NEUTRON)
	Die(FUNCTION_NAME, "Invalid particle type");

      /* Add to total weight and source size */

      wgt = wgt + RDB[ptr + PARTICLE_WGT];
      nsrc = nsrc + 1;

      /* Remove item */

      RemoveItem(ptr);      

      /* Add item to target */
      
      AddItem(DATA_PART_PTR_SRC_READ, ptr);
    }

  /* Check weight */

  if (wgt == 0.0)
    Error(0, "Not enough fissile material to sustain chain reaction");

  /* Get data from MPI parallel tasks */

  Rendezvous(&nsrc, &wgt);

  /* Set batch size */

  if ((long)RDB[DATA_OPTI_MPI_REPRODUCIBILITY] == NO)
    nbatch = (long)RDB[DATA_SIMUL_BATCH_SIZE];
  else
    nbatch = (long)RDB[DATA_NBATCH];
  
  /* Calculate cycle-wise estimate of k-eff */

  keff = wgt*RDB[DATA_CYCLE_KEFF]/((double)nbatch);

  /* Store keff */

  ptr = (long)RDB[RES_ANA_KEFF];
  AddStat(keff, ptr, 0);
      
  /* Put cycle-wise k-eff */
      
  WDB[DATA_CYCLE_KEFF] = keff;
  
  /* Set cycle batch size */

  WDB[DATA_CYCLE_BATCH_SIZE] = (double)nsrc;

  /* Score mean population size */

  ptr = (long)RDB[RES_MEAN_POP_SIZE];
  AddStat(nsrc, ptr, 0); 

  /***************************************************************************/

  /***** Normalize source ****************************************************/

  /* Pointer to first item after dummy */

  ptr = (long)RDB[DATA_PART_PTR_SRC_READ];
  ptr = NextItem(ptr);

  /* Normalize weights */

  while(ptr > VALID_PTR)
    {
      /* Normalize */

      WDB[ptr + PARTICLE_WGT] = 
	RDB[ptr + PARTICLE_WGT]*((double)nbatch)/wgt;

      /* Get weight and material pointer */

      w0 = RDB[ptr + PARTICLE_WGT];

      mat = (long)RDB[ptr + PARTICLE_PTR_MAT];
      CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

      /* Score source rate */
      
      if ((mpiid == 0) || ((long)RDB[DATA_OPTI_MPI_REPRODUCIBILITY] == NO))
	{
	  stp = (long)RDB[RES_TOT_SRCRATE];
	  AddBuf(1.0, w0, stp, 0, 0);

	  /* Score source rate in fissile and non-fissile materials */
	  
	  if (mat > VALID_PTR)
	    {
	      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
		AddBuf(1.0, w0, stp, 0, 1);
	      else
		AddBuf(1.0, w0, stp, 0, 2);
	    }
	}

      /* Next */
      
      ptr = NextItem(ptr);
    }

  /* Calculate entropies */

  CalculateEntropies();
 
  /***************************************************************************/

  /***** Set particle indexes ************************************************/

  /* Pointer to source buffer */

  ptr = (long)RDB[DATA_PART_PTR_SRC_READ];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Check reproducibility option and sort buffer */

  if ((long)RDB[DATA_OPTI_OMP_REPRODUCIBILITY] == YES)
    SortList(ptr, PARTICLE_IDX, SORT_MODE_ASCEND);
 
  /* Get history index */

  n = (long)RDB[DATA_NHIST_TOT];

  /* Reset MPI index counter */

  id = 0;

  /* Get pointer to last particle */

  ptr = LastItem(ptr);

  /* Loop over list and set indexes */

  while(1 != 2)
    {
      /* Break if dummy */

      if ((long)RDB[ptr + PARTICLE_TYPE] == PARTICLE_TYPE_DUMMY)
	break;

      /* Put index */

      WDB[ptr + PARTICLE_IDX] = (double)(++n);

      /* Put MPI id */

      if ((long)RDB[DATA_OPTI_MPI_REPRODUCIBILITY] == NO)
	WDB[ptr + PARTICLE_MPI_ID] = (double)mpiid;
      else
	WDB[ptr + PARTICLE_MPI_ID] = (double)(id++);

      /* Check id */

      if (id == mpitasks)
	id = 0;

      /* Update number of histories */

      WDB[DATA_NHIST_CYCLE] = WDB[DATA_NHIST_CYCLE] + 1.0;

      /* Next particle */

      ptr = PrevItem(ptr);
    }

  /* Put number of histories */

  WDB[DATA_NHIST_TOT] = (double)n;

  /***************************************************************************/
}

/*****************************************************************************/
