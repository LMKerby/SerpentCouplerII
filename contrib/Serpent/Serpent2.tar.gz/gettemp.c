/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : gettemp.c                                      */
/*                                                                           */
/* Created:       2012/01/11 (JLe)                                           */
/* Last modified: 2012/01/24 (VVa)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Returns material temperature at given location               */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "GetTemp:"

/*****************************************************************************/

double GetTemp(long mat, long id)
{
  long ptr, ncol, tfb, nst, reg, uni;
  double T, x, y, z, r;

  /***************************************************************************/

  /***** Temperature from feedback iteration *********************************/

  /* Check if feedback is in use */

  if ((long)RDB[DATA_USE_TFB] == YES)
    {
      /* Get collision number */

      ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
      CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
      ncol = (long)GetPrivateData(ptr, id);
      
      /* Loop over temperature feedbacks */
      
      tfb = (long)RDB[DATA_PTR_TFB0];
      while (tfb > VALID_PTR)
	{
	  /* Pointer to nest */
	  
	  nst = (long)RDB[tfb + TFB_PTR_NST];
	  CheckPointer(FUNCTION_NAME, "(nst)", DATA_ARRAY, nst);
	  
	  /* Get pointer to region */
	  
	  if ((reg = (long)TestValuePair(nst + NEST_PTR_COL_REG, ncol, id))
	      > VALID_PTR)
	    {
	      /* Pointer to feedback region */
	      
	      if ((reg = (long)RDB[reg + NEST_REG_PTR_TFB_REG]) > VALID_PTR)
		{
		  /* Pointer to universe */

		  uni = (long)RDB[nst + NEST_PTR_UNI];
		  CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);
		  
		  /* Get coordinates */
		  
		  ptr = RDB[uni + UNIVERSE_PTR_PRIVA_X];
		  x = GetPrivateData(ptr, id);

		  ptr = RDB[uni + UNIVERSE_PTR_PRIVA_Y];
		  y = GetPrivateData(ptr, id);

		  ptr = RDB[uni + UNIVERSE_PTR_PRIVA_Z];
		  z = GetPrivateData(ptr, id);		  
	      
		  /* Get temperature (tähän voi sitten lyödä sen mallin */
		  /* joka laskee pinnin säteestä riippuvan lämpötilan.  */
		  /* Noi koordinaatit on suhteessa pinnin origoon.) */

                  r= sqrt(x*x + y*y);
		  
		  T = RDB[reg + TFB_REG_ITER_C0]*r*r +
		    RDB[reg + TFB_REG_ITER_C1]*log(r) + 
		    RDB[reg + TFB_REG_ITER_C2];
		  
		  /* Check value */

		  if (T < 0.0)
		    Die(FUNCTION_NAME, "Negative temperature in %s",
			GetText(mat + MATERIAL_PTR_NAME));
		  else if (T > RDB[mat + MATERIAL_TEMP])
		    {
		      Warn(FUNCTION_NAME, 
			   "Temperature %E exceeds maximum (%E) (%s) ",
			   T, RDB[mat + MATERIAL_TEMP],
			   GetText(mat + MATERIAL_PTR_NAME));

		      /* Set limiting value */

		      T = WDB[mat + MATERIAL_TEMP];
		    }

		  /* Return value */
		  
		  return T;
		}
	      else
		{
		  /* Break loop */
		  
		  break;
		}
	    }

	  /* Next feedback */

	  tfb = NextItem(tfb);
	}
    }

  /***************************************************************************/

  /***** Temperature from material *******************************************/
  
  /* Get Temperature */

  if (mat > VALID_PTR)
    T = RDB[mat + MATERIAL_TEMP];
  else
    T = 0.0;

  /* Return value */

  return T;

  /***************************************************************************/
}

/*****************************************************************************/
