/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : b1solver.c                                     */
/*                                                                           */
/* Created:       2011/06/11 (JLe)                                           */
/* Last modified: 2012/01/06 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Forms and solves B1 equations                                */
/*                                                                           */
/* Comments: - Chi should match infinite spectrum calculation?               */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "B1Solver:"

/* Setting maximum iterations to zero should reproduce infinite */
/* spectrum results. */

#define MAX_ITER  20

/*****************************************************************************/

void B1Solver()
{
  long ptr, nmg, nfg, gcu, n, m, i, j, iter, nnz;
  double *flx0, *tot, *fiss, *abs, *nsf, *mubar, *x, *alpha;
  const double *imap;
  double **p0, **p1, norm, flx, sum1, sum2, val, kinf, L2, B2, B, err, kb1;
  complex theta0, *ei, *di, **D, *chi, *flx1,*LUval, *chival;
  struct ccsMatrix *Dinv, *Dinv2, *A; 
  FILE *mfile; /* debuggausta varten... */

  /* Check option */

  if ((long)RDB[DATA_OPTI_FUM_CALC] == NO)
    return;

  Die(FUNCTION_NAME, "Not working at the moment");

  /* Get pointer to micro-group structure */
  
  ptr = (long)RDB[DATA_FUM_PTR_EGRID];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Check active cycle and corrector step */

  if ((RDB[DATA_CYCLE_IDX] < RDB[DATA_SKIP]) ||
      ((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP))
    return;

  /* Check if group constants are generated */

  if((long)RDB[DATA_OPTI_GC_CALC] == NO)
    return;

  /* Number of groups */

  nmg = (long)RDB[ptr + ENERGY_GRID_NE] - 1;
  nfg = (long)RDB[DATA_ERG_FG_NG];

  /* Index map */

  ptr = (long)RDB[DATA_FUM_PTR_IDX_MAP];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  imap = &RDB[ptr];

  /* Get flux normalization factor */

  /*  norm = NormCoef();*/
  norm = 1.0;

  /* Mark scoring buffer unreduced (tän pitäisi toimia koska  */
  /* käsitellään sellasia muuttujia joita ei lisätä bufferiin */
  /* muualla). */

  WDB[DATA_BUF_REDUCED] = (double)NO;

  /* Reduce results buffer */

  WDB[DATA_RES2_REDUCED] = (double)NO;
  ReducePrivateRes();

  /* Allocate memory for matrix p0 */

  p0 = (double **)Mem(MEM_ALLOC, nmg, sizeof(double *));

  for(n = 0; n < nmg; n++)
    p0[n] = (double *)Mem(MEM_ALLOC, nmg, sizeof(double));

  /* Allocate memory for matrix p1 */

  p1 = (double **)Mem(MEM_ALLOC, nmg, sizeof(double *));

  for(n = 0; n < nmg; n++)
    p1[n] = (double *)Mem(MEM_ALLOC, nmg, sizeof(double));

  /* Allocate memory for temporary variables */

  x = (double *)Mem(MEM_ALLOC, nmg, sizeof(double));
  alpha = (double *)Mem(MEM_ALLOC, nmg, sizeof(double));
  
  /* Ei tartte kopioida koko LU-matriisia vaan ainoastaan values joka kerta*/

  LUval   = (complex *)Mem(MEM_ALLOC, nmg*nmg, sizeof(complex));

  /* Allocate memory for matrix etc. */

  Dinv  = ccsMatrixNew(nmg, nmg, nmg*nmg);
  Dinv2 = ccsMatrixNew(nmg, nmg, nmg*nmg);
  A     = ccsMatrixNew(nmg, nmg, nmg*nmg);
  ei    = (complex *)Mem(MEM_ALLOC, nmg, sizeof(complex));   
  di    = (complex *)Mem(MEM_ALLOC, nmg, sizeof(complex));   
  chi   = (complex *)Mem(MEM_ALLOC, nmg, sizeof(complex));  
  chival = (complex *)Mem(MEM_ALLOC, nmg, sizeof(complex));  
  flx1  = (complex *)Mem(MEM_ALLOC, nmg, sizeof(complex));   

  /* Matriisi D kannattaa tallentaa suoraan taulukkona */

  D     = (complex **)Mem(MEM_ALLOC, nmg, sizeof(complex *)); 

  for(n = 0; n < nmg; n++)
    D[n] = (complex *)Mem(MEM_ALLOC, nmg, sizeof(complex));

  /***************************************************************************/

  /***** Perform B1 calculation **********************************************/

  /* Loop over universes */

  gcu = (long)RDB[DATA_PTR_GCU0];
  while (gcu > VALID_PTR)
    {
      /***********************************************************************/

      /***** Calculate cross sections ****************************************/
      
      /* Get pointers cross section data */

      ptr = (long)RDB[gcu + GCU_FUM_PTR_FLX];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);

      flx0 = &RES2[ptr];

      ptr = (long)RDB[gcu + GCU_FUM_PTR_TOT];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);

      tot = &RES2[ptr];

      ptr = (long)RDB[gcu + GCU_FUM_PTR_FISS];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);

      fiss = &RES2[ptr];

      ptr = (long)RDB[gcu + GCU_FUM_PTR_ABS];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);

      abs = &RES2[ptr];

      ptr = (long)RDB[gcu + GCU_FUM_PTR_NSF];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);

      nsf = &RES2[ptr];

      ptr = (long)RDB[gcu + GCU_FUM_PTR_MUBAR];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);

      mubar = &RES2[ptr];

      /* Read data to scattering matrixes */

      ptr = (long)RDB[gcu + GCU_FUM_PTR_SCATT_MTX];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);

      for (n = 0; n < nmg; n++)
	for (m = 0; m < nmg; m++)
	  p0[n][m] = RES2[ptr + m*nmg + n];

      /* Read fission spectrum */

      ptr = (long)RDB[gcu + GCU_FUM_PTR_CHI];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      
      for (n = 0; n < nmg; n++)
	{
	  chi[n].re = RES2[ptr + n];
	  chi[n].im = 0.0;
	}

      /* TEST NORMITUS */

      for(n=0; n < nmg; n++)
	fprintf(out, "n=%ld, flx0[n]=%e, nsf[n]=%e\n", n+1, flx0[n], nsf[n]); 

      /* Loop over grid */
      
      for (n = 0; n < nmg; n++)
	{
	  /* Scattering mubar */

	  if (tot[n] - abs[n] > 0.0)
	    mubar[n] = mubar[n]/(tot[n] - abs[n]);
	  else
	    mubar[n] = 0.0;

	  /* Check zero flux */

	  if (flx0[n] > 0.0)
	    {
	      /* Homogenize cross sections */

	      tot[n] = tot[n]/flx0[n];
	      fiss[n] = fiss[n]/flx0[n];
	      abs[n] = abs[n]/flx0[n];
	      nsf[n] = nsf[n]/flx0[n];
	    }
	  else
	    {
	      tot[n] = 0.0;
	      fiss[n] = 0.0;
	      abs[n] = 0.0;
	      nsf[n] = 0.0;
	    }
	}

      /* Scattering matrices */
      
      for (n = 0; n < nmg; n++)
	for (m = 0; m < nmg; m++)
	  {
	    if (flx0[m] > 0.0)
	      {
		p0[n][m] = p0[n][m]/flx0[m];
		p1[n][m] = mubar[m]*p0[n][m];		  
	      }
	    else
	      {
		p0[n][m] = 0.0;
		p1[n][m] = 0.0;
	      }
	  }

      /* Fission spectrum */

      sum1 = 0.0;

      for (n = 0; n < nmg; n++)
	sum1 = sum1 + chi[n].re;

      for (n = 0; n < nmg; n++)
	if (sum1 > 0.0)
	  chi[n].re = chi[n].re/sum1;

      /* Normalize flux */

      for (n = 0; n < nmg; n++)
	flx0[n] = flx0[n]*norm;

      /***********************************************************************/

      /***** Calculate initial guess for kinf and B2 *************************/

      /* Calculate source term and loss terms (NOTE: approximate removal */
      /* by absorption). */

      sum1 = 0.0;
      sum2 = 0.0;

      for (n = 0; n < nmg; n++)
	{
	  sum1 = sum1 + flx0[n]*nsf[n];
	  fprintf(out, "n=%ld, flx0 = %e, nsf = %e\n", n+1, flx0[n], nsf[n]); 
	  sum2 = sum2 + flx0[n]*abs[n];
	}

      /* Check values */

      CheckValue(FUNCTION_NAME, "sum1", "", sum1, ZERO, INFTY);
      CheckValue(FUNCTION_NAME, "sum2", "", sum2, ZERO, INFTY);

      /* Calculate k-inf */

      kinf = sum1/sum2;

      /* Calculate absorption xs */

      sum1 = 0.0;
      sum2 = 0.0;

      for (n = 0; n < nmg; n++)
	{
	  sum1 = sum1 + flx0[n]*abs[n];
	  sum2 = sum2 + flx0[n];
	}

      /* Check values */

      CheckValue(FUNCTION_NAME, "sum1", "", sum1, ZERO, INFTY);
      CheckValue(FUNCTION_NAME, "sum2", "", sum2, ZERO, INFTY);
      
      val = sum1/sum2;

      /* Calculate diffusion coefficient */

      sum1 = 0.0;
      sum2 = 0.0;

      for (n = 0; n < nmg; n++)
	{
	  sum1 = sum1 + flx0[n];
	  sum2 = sum2 + 3.0*flx0[n]*(tot[n] - mubar[n]*(tot[n] - abs[n]));
	}

      /* Check values */

      CheckValue(FUNCTION_NAME, "sum1", "", sum1, ZERO, INFTY);
      CheckValue(FUNCTION_NAME, "sum2", "", sum2, ZERO, INFTY);

      /* Migration area */

      L2 = sum1/sum2/val;

      /* Buckling (tää ei ehkä mee oikein) */

      /* B2 = (kinf - 1.0)/L2; */ 

      fprintf(out, "%E\n", (kinf - 1.0)/L2);

      /* Eiks tässä pitäis olla vaan alkuarvaus? MPu */

      /* Toi ylläoleva on materiaalin kupevuus, jonka pitäisi olla vähän */
      /* lähempänä geometrista kupevuutta johon iteraatio konvergoituu */
      /* kuin kiinnitetyn alkuarvauksen, joka saattaa olla monta */
      /* kertaluokkaa pielessä. Toimii ainakin Serpent 1:ssä. Jos tämä */
      /* rutiini toteutetaan niin että sitä kutsutaan jokaisen sukupolven */
      /* jälkeen, niin alkuarvauksena kannattaa käyttää edellisen sukupolven */
      /* konvergoitunutta arvoa (JLe). */
      
      /* Asetetaan alkuarvaus s.e. 0 <= x <= 1*/

      if (kinf >= 1.0)
	{
	B2 = 1e-5;
	val = B2; 
	for (n=0; n < nmg; n++)
	  if (tot[n]*tot[n] < val)
	    val = tot[n]*tot[n]; 
	B2 = val; 
	}
      else
	{
	B2 = -1e-5;
	val = -B2; 
	for (n=0; n < nmg; n++)
	  if (tot[n]*tot[n] < val)
	    val = tot[n]*tot[n]; 
	B2 = -val; 	
	}

      fprintf(out, "Alkuarvaus B2 = %e\n", B2);
				    

      /***********************************************************************/


      /**********************************************************/
      /* m-file debuggausta varten */


      mfile = fopen("b1_super.m", "w");
      if (mfile == NULL)
	Die(FUNCTION_NAME, "Could not open m-file\n"); 


      fprintf(mfile, "kinf = %e\n", kinf);
      fprintf(mfile, "B2 = %e;\n",B2);
      fprintf(mfile, "nG = %ld;\n", nmg);

      for (n=0; n < nmg; n++)
	fprintf(mfile, "tot(%ld) = %e;\n", n+1, tot[n]);


      for (n=0; n < nmg; n++)
	for (m=0; m < nmg; m++)
	  fprintf(mfile, "p0(%ld, %ld) = %e;\n", n+1,m+1,p0[n][m]);
      
      for (n=0; n < nmg; n++)
	for (m=0; m < nmg; m++)
	  fprintf(mfile, "p1(%ld, %ld) = %e;\n", n+1,m+1,p1[n][m]);

      for (n=0; n < nmg; n++)
	fprintf(mfile, "ch(%ld) = %e;\n", n+1, chi[n].re);
      
      for (n=0; n < nmg; n++)
	fprintf(mfile, "nf(%ld) = %e;\n", n+1, nsf[n]);
      
      fprintf(mfile, "nf = nf'\n;");
      fprintf(mfile, "ch = ch'\n;");

      for (n=0; n < nmg; n++)
	fprintf(mfile, "flx0(%ld) = %e;\n", n+1, flx0[n]); 
	  

      fclose(mfile);


      /**********************************************************/


      /***** Main loop *******************************************************/

      /* Reset temporary variables */

      memset(x, 0.0, nmg*sizeof(double));
      memset(alpha, 0.0, nmg*sizeof(double));

      /* Reset error */

      err = 1.0;

      /* Iteration loop */

      /* Kaikki varsinainen laskenta tapahtuu tän silmukan sisällä.    */
      /* MAX_ITER on nyt asetetettu nollaksi, eli silmukkaa ei käydä   */
      /* ollenkaan läpi. Tuloksena saadut ryhmävakiot ovat tällöin     */
      /* NSF:ää lukuunottamatta numeroarvoltaan samat kuin infinite-   */
      /* spectrum -laskussa, mitä voi hyvin käyttää myöhemmin tehtävän */
      /* uudelleenhomogenisoinnin tarkastamiseen. Toi silmukan sisällä */
      /* tehtävä laskenta on vielä vähän mitä sattuu. Pääsin alkuun,   */
      /* mutta en saanut kaikista osista tolkkua. */


      for (iter = 0; iter < MAX_ITER; iter++)
	{
	  /*******************************************************************/

	  /***** Set temporary variables *************************************/

	  /* Square root of buckling */

	  if (B2 >= 0.0)
	    B = sqrt(B2);
	  else
	    B = sqrt(-B2);


	  /* Calculate temporary variable x */

	  for (n = 0; n < nmg; n++)
	    {
	    x[n] = B/tot[n];
	    CheckValue(FUNCTION_NAME, "x[n]", "", x[n], 0.0, 1.0);
	    }
       

	  /* Calculate alpha  */
	  
	  if (B2 > 0.0)
	    { 	   
	      for (n = 0; n < nmg; n++)
		{
		  alpha[n] = x[n]*x[n];
		  alpha[n] = alpha[n]*atan(x[n])/(x[n] - atan(x[n])); 
		  CheckValue(FUNCTION_NAME, "alpha[n] (1)", "", alpha[n], 
			     -INFTY, INFTY);
		}
	    }
	  else if(B2 < 0.0)
	    {
	      for (n = 0; n < nmg; n++)
		{
		  alpha[n] = x[n]*x[n];
		  alpha[n] = alpha[n]*log((1.0 + x[n])/(1.0 - x[n]))/ 
		    (log((1.0 + x[n])/(1.0 - x[n])) - 2.0*x[n]);

		  CheckValue(FUNCTION_NAME, "alpha[n] (2)", "", alpha[n], 
			     -INFTY, INFTY);
		}
	    }
	  else
	    {
	      for (n = 0; n < nmg; n++)
		alpha[n] = 3.0; 
	    }

	  /*******************************************************************/

	  /***** Form matrix Dinv ********************************************/
	  /*
	  for (n = 0; n < nmg; n++)
	    {
	      for (m = 0; m < nmg; m++)
		{
		  if (n != m)
		    fprintf(out, "%1.3E ", -3.0*p1[n][m]);
		  else
		    fprintf(out, "%1.3E ", -3.0*p1[n][m] + alpha[n]*tot[n]);
		}

	      fprintf(out, "\n");
	    }
	  */

	  /* Reset size and pointer to first column */

	  nnz = 0;
	  Dinv->colptr[0] = 0 ;

	  /* Loop over columns */

	  for (m = 0; m < nmg; m++)
	    {
	      /* Loop over rows */

	      for (n = 0; n < nmg; n++)
		{
		  /* Check that element is non-zero */
		  
		  CheckValue(FUNCTION_NAME, "p1[n][m]", "", p1[n][m], -INFTY,
			     INFTY);

		  /* Set value */

		  Dinv->values[nnz].re = -3.0*p1[n][m];

		  /* Add diagonal */
		  
		  if (n == m)
		    {
		      CheckValue(FUNCTION_NAME, "alpha[n]", "", alpha[n], 
				 -INFTY, INFTY);
		      CheckValue(FUNCTION_NAME, "tot[m]", "", tot[m], 
				 -INFTY, INFTY);
		      Dinv->values[nnz].re = Dinv->values[nnz].re +
			alpha[n]*tot[m];
		    }
		  
		  /* Reset imagynary part */
		  
		  Dinv->values[nnz].im = 0.0;
		  
		  CheckValue(FUNCTION_NAME, "Dinv->values[nnz].re", "", 
			     Dinv->values[nnz].re, -INFTY, INFTY);
		  CheckValue(FUNCTION_NAME, "Dinv->values[nnz].im", "", 
			     Dinv->values[nnz].im, 0.0, 0.0);
		  
		  /* Put row index */
		  
		  Dinv->rowind[nnz] = n;
		  
		  /* Update size */
		  
		  nnz++;
		}	
	      
	      /* Put column index */
	      
	      Dinv->colptr[m + 1] = nnz;
	    }	  
	  
	  /*******************************************************************/
	  
	  /***** Form matrix D ***********************************************/
	
#ifdef DEBUG

	  for (i=0; i < Dinv->nnz; i++)
	    {
	      CheckValue(FUNCTION_NAME, "Dinv->values[i].re", "", 
			 Dinv->values[i].re, -INFTY, INFTY);
	      CheckValue(FUNCTION_NAME, "Dinv->values[i].im", "", 
			 Dinv->values[i].im, 0.0, 0.0);
	    }

#endif

	  /* Ota values talteen */
	
	  memcpy(LUval, Dinv->values, (Dinv->nnz) * sizeof(complex));

#ifdef DEBUG

	  for (i=0; i < Dinv->nnz; i++)
	    {
	      CheckValue(FUNCTION_NAME, "LUval.re", "", LUval[i].re, 
			 -INFTY, INFTY);
	      CheckValue(FUNCTION_NAME, "LUval.im", "", LUval[i].im, 
			 0.0, 0.0);
	    }

#endif

	  /* Set theta to zero */
	  
	  theta0.re = 0.0; 
	  theta0.im = 0.0; 

	  FindRowIndexes(Dinv);

	  /* Loop over energy groups */
	  
	  for (n = 0; n < nmg; n++)
	    {
	      /* Form ei */
	      
	      memset(ei, 0.0, nmg*sizeof(complex));
	      ei[n].re = 1.0; 
	      
	      memcpy(Dinv->values, LUval, (Dinv->nnz) * sizeof(complex));
	      
	      /* D:n sarakkeille varattu tila valmiiksi, Gauss ei */
	      /* varaa mitään ! */
	      
	      NumericGauss(Dinv, ei, theta0, D[n]); 

	    }

#ifdef PRINT	  

	  for (n=0; n < nmg; n++)
	    for (m=0; m < nmg; m++)
	      fprintf(out, "D(%ld, %ld) = %e\n", n+1,m+1, D[n][m].re);

#endif
	  
	  /*******************************************************************/
	  
	  /***** Form matrix A ***********************************************/
	  
	  /* Reset size and pointer to first column */
	  
	  nnz = 0;
	  A->colptr[0] = 0 ;
	  
	  /* Loop over columns */
	  
	  for (m = 0; m < nmg; m++)
	    {
	      /* Loop over rows */
	      
	      for (n = 0; n < nmg; n++)
		{
		  /* Check that element is non-zero */
		  
		  /* if ((n == m) || (p0[n][m] != 0.0) || D[m][n].re != 0.0)*/
		  
		  /* Set value */
		  
		  A->values[nnz].re = -p0[n][m] + B2*D[m][n].re; /* D^T*/
		  
		  /* Add diagonal */
		  
		  if (n == m)
		    A->values[nnz].re = A->values[nnz].re + tot[n];
		  
		  /* Reset imaginary part */
		  
		  A->values[nnz].im = 0.0;
		  
		  /* Put row index */
		  
		  A->rowind[nnz] = n;
		  
		  /* Update size */
		  
		  nnz++;
		}

	      /* Put column index */
	      
	      A->colptr[m + 1] = nnz;
	    }
	  
	  /* Set size */
	  
	  A->nnz = nnz;
	  
#ifdef PRINT	
	  
	  ccsMatrixPrint(A); 
	  
	  for (n=0; n < nmg; n++)
	    fprintf(out, "chi(%ld) = %e\n", n, chi[n].re);

#endif	  
	  
	  /*******************************************************************/
	  
	  /***** Solve equation **********************************************/
	  
	  /* Solve flux */
	  
	  FindRowIndexes(A);
	  memcpy(chival, chi, nmg*sizeof(complex));

	  /* HUOM! Myös chival gaussataan... */ 

	  NumericGauss(A, chival, theta0, flx1); 
	  
#ifdef PRINT
	  
	  for (n = 0; n < nmg; n++)
	    fprintf(out, "%E %E %E\n", nsf[n], flx0[n], flx1[n].re);

#endif
	  
	  /*B1 keff */
	  
	  kb1 = 0.0;
	  
	  for (n = 0; n < nmg; n++)
	    kb1 = kb1 + nsf[n]*flx1[n].re; 
	  
	  /* Interpolointi */
	  
	  val = B2/(1.0/kb1 - 1.0/kinf); 
	  B2 = B2 + val - val/kb1; 
	  
	  fprintf(out, "Iter = %ld, k = %f, B2 = %E\n", iter+1, kb1, B2);
	  
	  /*******************************************************************/
	}

      /* TÄHÄN LOPPUU */
      
      /***********************************************************************/
      
      /***** Re-homogenize cross sections ************************************/
      
      /* Calculate few-group reaction rates */
      
      for (n = 0; n < nmg; n++)
	{
	  /* Get few-group index */
	  
	  i = (long)imap[n];
	  
	  /* Add reaction rates to buffers */

	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_FLUX];

	  AddBuf(flx0[n], 1.0, ptr, 0, i + 1);
	  AddBuf(flx0[n], 1.0, ptr, 0, 0);

	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_TOTXS];
	  AddBuf(flx0[n]*tot[n], 1.0, ptr, 0, i + 1);
	  AddBuf(flx0[n]*tot[n], 1.0, ptr, 0, 0);

	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_ABSXS];
	  AddBuf(flx0[n]*abs[n], 1.0, ptr, 0, i + 1);
	  AddBuf(flx0[n]*abs[n], 1.0, ptr, 0, 0);

	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_FISSXS];
	  AddBuf(flx0[n]*fiss[n], 1.0, ptr, 0, i + 1);
	  AddBuf(flx0[n]*fiss[n], 1.0, ptr, 0, 0);

	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_NSF];
	  AddBuf(flx0[n]*nsf[n], 1.0, ptr, 0, i + 1);
	  AddBuf(flx0[n]*nsf[n], 1.0, ptr, 0, 0);

	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_CHI];
	  AddBuf(chi[n].re, 1.0, ptr, 0, i);

	  /* Scattering matrix */

	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_SCATTXS];
	  
	  for (m = 0; m < nmg; m++)
	    {
	      j = (long)imap[m];
	      AddBuf(flx0[n]*p0[n][m], 1.0, ptr, 0, -1, j, i);
	    }
	}
    
      /* k-inf and B2 */

      ptr = (long)RDB[gcu + GCU_FUM_FG_B1_KINF];
      AddBuf(kinf, 1.0, ptr, 0, 0);

      ptr = (long)RDB[gcu + GCU_FUM_FG_B1_BUCKLING];
      AddBuf(B2, 1.0, ptr, 0, 0);

      /***********************************************************************/

      /***** Reset data ******************************************************/

      /* Reset vectors */

      memset(flx0, 0.0, nmg*sizeof(double));
      memset(tot, 0.0, nmg*sizeof(double));
      memset(fiss, 0.0, nmg*sizeof(double));
      memset(abs, 0.0, nmg*sizeof(double));
      memset(nsf, 0.0, nmg*sizeof(double));
      memset(mubar, 0.0, nmg*sizeof(double));

      /* Reset scattering matrix */

      ptr = (long)RDB[gcu + GCU_FUM_PTR_SCATT_MTX];
      memset(&RES2[ptr], 0.0, nmg*nmg*sizeof(double));

      for (n = 0; n < nmg; n++)
	for (m = 0; m < nmg; m++)
	  {
	    p0[n][m] = 0.0;
	    p1[n][m] = 0.0;
	  }

      /* Reset fission spectrum */

      ptr = (long)RDB[gcu + GCU_FUM_PTR_CHI];
      memset(&RES2[ptr], 0.0, nmg*sizeof(double));

      /***********************************************************************/

      /* Next universe */

      gcu = NextItem(gcu);

      /***********************************************************************/
    }
  
  /***************************************************************************/

  /***** Add to statistics ***************************************************/

  /* Reduce buffer */

  ReduceBuffer();

  /* Loop over universes */

  gcu = (long)RDB[DATA_PTR_GCU0];
  while (gcu > VALID_PTR)
    {
      /***********************************************************************/

      /***** Data from buffer to  statistics *********************************/

      /* Reset sum for total removal xs */

      sum1 = 0.0;

      /* Calculate few-group cross sections */

      for (i = 0; i < nfg;  i++)
	{
	  /* Reset sum for group removal xs */

	  sum2 = 0.0;

	  /* Few-group flux */

	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_FLUX];
	  flx = BufVal(ptr, i + 1);
	  AddStat(flx, ptr, i + 1);

	  /* Divide reaction rates by flux */

	  if (flx > 0.0)
	    {
	      ptr = (long)RDB[gcu + GCU_FUM_FG_B1_TOTXS];
	      val = BufVal(ptr, i + 1);
	      AddStat(val/flx, ptr, i + 1);

	      sum1 = sum1 + val;
	      sum2 = sum2 + val;
	      
	      ptr = (long)RDB[gcu + GCU_FUM_FG_B1_ABSXS];
	      val = BufVal(ptr, i + 1);
	      AddStat(val/flx, ptr, i + 1);

	      ptr = (long)RDB[gcu + GCU_FUM_FG_B1_FISSXS];
	      val = BufVal(ptr, i + 1);
	      AddStat(val/flx, ptr, i + 1);

	      ptr = (long)RDB[gcu + GCU_FUM_FG_B1_NSF];
	      val = BufVal(ptr, i + 1);
	      AddStat(val/flx, ptr, i + 1);
	      
	      /* Scattering matrix */

	      ptr = (long)RDB[gcu + GCU_FUM_FG_B1_SCATTXS];
	  
	      for (j = 0; j < nfg; j++)
		{
		  val = BufVal(ptr, i, j);
		  AddStat(val/flx, ptr, j, i);
		  
		  sum1 = sum1 - val;

		  if (j == i)
		    sum2 = sum2 - val;
		}

	      /* Removal cross section */

	      ptr = (long)RDB[gcu + GCU_FUM_FG_B1_REMXS];
	      AddStat(sum2/flx, ptr, i + 1);
	    }
	  
	  /* Chi */
	  
	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_CHI];
	  val = BufVal(ptr, i);
	  AddStat(val, ptr, i);
	}

      /* Total flux */

      ptr = (long)RDB[gcu + GCU_FUM_FG_B1_FLUX];
      flx = BufVal(ptr, 0);
      AddStat(flx, ptr, 0);

      /* Divide total reaction rates by flux */
      
      if (flx > 0.0)
	{
	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_TOTXS];
	  val = BufVal(ptr, 0);
	  AddStat(val/flx, ptr, 0);
	  
	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_ABSXS];
	  val = BufVal(ptr, 0);
	  AddStat(val/flx, ptr, 0);
	  
	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_FISSXS];
	  val = BufVal(ptr, 0);
	  AddStat(val/flx, ptr, 0);
	  
	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_NSF];
	  val = BufVal(ptr, 0);
	  AddStat(val/flx, ptr, 0);

	  ptr = (long)RDB[gcu + GCU_FUM_FG_B1_REMXS];
	  AddStat(sum1/flx, ptr, 0);
	}

      /* Store k-inf and B2 */

      ptr = (long)RDB[gcu + GCU_FUM_FG_B1_KINF];
      kinf = BufVal(ptr, 0);
      AddStat(kinf, ptr, 0);

      ptr = (long)RDB[gcu + GCU_FUM_FG_B1_BUCKLING];
      B2 = BufVal(ptr, 0);
      AddStat(B2, ptr, 0);

      /* Next universe */

      gcu = NextItem(gcu);

      /***********************************************************************/
    }

  /***************************************************************************/

  /* Free allocated memory */

  for(n = 0; n < nmg; n++)
    Mem(MEM_FREE, p0[n]);
  
  Mem(MEM_FREE, p0);
  
  for(n = 0; n < nmg; n++)
    Mem(MEM_FREE, p1[n]);

  Mem(MEM_FREE, p1);

  ccsMatrixFree(Dinv);
  ccsMatrixFree(Dinv2);
  ccsMatrixFree(A);

  Mem(MEM_FREE, ei); 
  Mem(MEM_FREE, di); 
  Mem(MEM_FREE, D); 
  Mem(MEM_FREE, flx1); 
  Mem(MEM_FREE, chi);
  Mem(MEM_FREE, x);
  Mem(MEM_FREE, alpha);
}

/*****************************************************************************/
