/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : rewindrealist.c                                */
/*                                                                           */
/* Created:       2011/11/02 (JLe)                                           */
/* Last modified: 2011/11/08 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Sets reaction list pointers to beginning of the list         */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "RewindReaList:"

/*****************************************************************************/

void RewindReaList(long loc0, long id)
{
  long type, ptr, mat, iso, nuc, rea;

  /* Check reaction list pointer */

  CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

  /* Get list type */

  type = (long)RDB[loc0 + LIST_ROOT_LIST_TYPE];

  /* Check type */

  if (type == REA_LIST_TYPE_REAL)
    {
      /* Get pointer to list */

      ptr = (long)RDB[loc0 + LIST_ROOT_PTR_REA_LIST];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Put pointers */

      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_LST, 0.0, (double)ptr, id);
      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_REA, 0.0, -1.0, id);
      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO, 0.0, -1.0, id);
    }
  else if ((type == REA_LIST_TYPE_EMULATED) || 
	   (type == REA_LIST_TYPE_NOCUTOFF))
    {
      /* Get pointer to material */

      mat = (long)RDB[loc0 + LIST_ROOT_PTR_MAT];
      CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

      /* Get pointer to first nuclide */

      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
      CheckPointer(FUNCTION_NAME, "(iso)", DATA_ARRAY, iso);

      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

      /* Get pointer to first reaction */

      rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
      
      /* Put pointers */

      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_LST, 0.0, -1.0, id);
      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO, 0.0, (double)iso, id);

      /* Reaction pointer is NULL for lost nuclide in burnup calculation */

      if (rea > VALID_PTR)
	StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_REA, 0.0, (double)rea, id);
      else
	StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_REA, 0.0, -1.0, id);
    }
  else
    Die(FUNCTION_NAME, "invalid list type");

}

/*****************************************************************************/
