/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : initpartstacks.c                               */
/*                                                                           */
/* Created:       2011/04/01 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Initializes particle stacks, ques and source buffers for     */
/*              transport simulation                                         */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "InitPartStacks:"

/*****************************************************************************/

void InitPartStacks()
{
  long ptr, n;
  long loc0;

  /* Reset collision counters */

  ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];

  for (n = 0; n < (long)RDB[DATA_OMP_MAX_THREADS]; n++)
    PutPrivateData(ptr, 0, n);

  /* Check if particle lists are already defined */

  if ((long)RDB[DATA_PART_PTR_NSTACK] > VALID_PTR)
    return;

#ifdef OPEN_MP

  /***** Private lists for each omp thread ***********************************/

  /* Neutron stack */

  loc0 = ReallocMem(DATA_ARRAY, (long)RDB[DATA_OMP_MAX_THREADS]);
  WDB[DATA_PART_PTR_NSTACK] = (double)loc0;

  for (n = 0; n < (long)RDB[DATA_OMP_MAX_THREADS]; n++)
    {
      ptr = NewItem(loc0++, PARTICLE_BLOCK_SIZE);
      WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
      WDB[ptr + PARTICLE_IDX] = -1.0;
    }

  /* Gamma stack */

  loc0 = ReallocMem(DATA_ARRAY, (long)RDB[DATA_OMP_MAX_THREADS]);
  WDB[DATA_PART_PTR_GSTACK] = (double)loc0;

  for (n = 0; n < (long)RDB[DATA_OMP_MAX_THREADS]; n++)
    {
      ptr = NewItem(loc0++, PARTICLE_BLOCK_SIZE);
      WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
      WDB[ptr + PARTICLE_IDX] = -1.0;
    }

  /* Particle que */

  loc0 = ReallocMem(DATA_ARRAY, (long)RDB[DATA_OMP_MAX_THREADS]);
  WDB[DATA_PART_PTR_QUE] = (double)loc0;

  for (n = 0; n < (long)RDB[DATA_OMP_MAX_THREADS]; n++)
    {
      ptr = NewItem(loc0++, PARTICLE_BLOCK_SIZE);
      WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
      WDB[ptr + PARTICLE_IDX] = -1.0;
    }

  /* Check running mode */

  if ((long)WDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT)
    {
      /* Read source */
      
      ptr = NewItem(DATA_PART_PTR_SRC_READ, PARTICLE_BLOCK_SIZE);
      WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
      WDB[ptr + PARTICLE_IDX] = -1.0;

      /* Write source */
      
      ptr = NewItem(DATA_PART_PTR_SRC_WRITE, PARTICLE_BLOCK_SIZE);
      WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
      WDB[ptr + PARTICLE_IDX] = -1.0;
    }

  /***************************************************************************/

#else
  
  /***** Simple pointers *****************************************************/

  /* Avoid compiler warning */

  loc0 = 0;
  n = 0;

  /* Neutron stack */

  ptr = NewItem(DATA_PART_PTR_NSTACK, PARTICLE_BLOCK_SIZE);
  WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
  WDB[ptr + PARTICLE_IDX] = -1.0;

  /* Gamma stack */

  ptr = NewItem(DATA_PART_PTR_GSTACK, PARTICLE_BLOCK_SIZE);
  WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
  WDB[ptr + PARTICLE_IDX] = -1.0;

  /* Particle que */

  ptr = NewItem(DATA_PART_PTR_QUE, PARTICLE_BLOCK_SIZE);
  WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
  WDB[ptr + PARTICLE_IDX] = -1.0;

  /* Check running mode */

  if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT)
    {
      /* Read source */
      
      ptr = NewItem(DATA_PART_PTR_SRC_READ, PARTICLE_BLOCK_SIZE);
      WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
      WDB[ptr + PARTICLE_IDX] = -1.0;

      /* Write source */
      
      ptr = NewItem(DATA_PART_PTR_SRC_WRITE, PARTICLE_BLOCK_SIZE);
      WDB[ptr + PARTICLE_TYPE] = (double)PARTICLE_TYPE_DUMMY;
      WDB[ptr + PARTICLE_IDX] = -1.0;
    }

  /***************************************************************************/

#endif
}

/*****************************************************************************/
