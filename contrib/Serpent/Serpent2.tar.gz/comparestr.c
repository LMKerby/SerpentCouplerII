/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : comparestr.c                                   */
/*                                                                           */
/* Created:       2010/11/21 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Compares two strings in DATA structure                       */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CompareStr:"

/*****************************************************************************/

long CompareStr(long ptr1, long ptr2)
{
  /* Check pointers */
 
  CheckPointer(FUNCTION_NAME, "(ptr1)", DATA_ARRAY, ptr1);
  CheckPointer(FUNCTION_NAME, "(ptr2)", DATA_ARRAY, ptr2);

  /* Compare */
  
  return !strcmp(GetText(ptr1), GetText(ptr2));
}

/*****************************************************************************/
