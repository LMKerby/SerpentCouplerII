/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : scoretransmuxs.c                               */
/*                                                                           */
/* Created:       2011/04/21 (JLe)                                           */
/* Last modified: 2012/02/01 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Scores transmutation cross sections and fission product      */
/*              yield weights for burnup calculation                         */
/*                                                                           */
/* Comments: TODO: add isomeric br calculation                               */
/*                                                                           */
/*           - Noi CheckValue() -funktiot pitää sit kattoa joka rutiinissa   */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ScoreTransmuXS:"

/*****************************************************************************/

void ScoreTransmuXS(double flx, long mat, double E, double wgt, long id)
{
  long rea, loc0, ptr, pte, erg, i, dep, bin;
  double val, E0, E1, E2, f, g, Emin, Emax;

  /* Check material pointer */

  if (mat < VALID_PTR)
    return;

  /* Check material burn flag */

  if (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT))
    return;  

  /* Check flux */

  CheckValue(FUNCTION_NAME, "flx", "", flx, ZERO, INFTY);

  /* Score burn flux */

  ptr = (long)RDB[mat + MATERIAL_PTR_BURN_FLUX];
  AddBuf(flx, wgt, ptr, id, 0);

  /* Pointer to few-group structure */

  pte = (long)RDB[DATA_BU_MG_PTR_GRID];
  CheckPointer(FUNCTION_NAME, "(pte)", DATA_ARRAY, pte);

  /* Get minimum and maximum energy */

  Emin = RDB[DATA_BU_MG_EGRID_EMIN];
  Emax = RDB[DATA_BU_MG_EGRID_EMAX];

  /***************************************************************************/

  /***** Score spectrum ******************************************************/

  /* Add to total flux */

  ptr = (long)RDB[mat + MATERIAL_PTR_FLUX_SPEC_SUM];
  CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
  AddPrivateRes(ptr, flx*wgt, id);

  /* Check spectrum-collapse mode and energy interval */
  
  if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] == YES)
    if ((E < Emin) || (E > Emax))
      {
	/* Pointer to unionized grid */
	
	erg = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID];
	CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);
	
	/* Get interpolation factor */
	
	f = GridFactor(erg, E, id);
	
	/* Separate integer and decimal parts */
	
	i = (long)f;
	f = f - (double)i;
	
	/* Check values */
	
	CheckValue(FUNCTION_NAME, "f", "", f, 0.0, 1.0);
	CheckValue(FUNCTION_NAME, "i", "", i, 0, 
		   (long)RDB[erg + ENERGY_GRID_NE] - 1);
	
	/* Score flux (NOTE: toi jälkimmäinen voi kosahtaa?) */
	
	ptr = (long)RDB[mat + MATERIAL_PTR_FLUX_SPEC];
	CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);

	AddPrivateRes(ptr + i, (1.0 - f)*flx*wgt, id);
	AddPrivateRes(ptr + i + 1, f*flx*wgt, id);

	/* Exit subroutine */

	return;
      }

  /* Get few-group bin */
  
  if ((bin = GridSearch(pte, E)) < 0)
    Die(FUNCTION_NAME, "Error in few-group bin");

  /***************************************************************************/

  /***** Score transmutation rates *******************************************/

  /* Score cross sections */
  
  loc0 = (long)RDB[mat + MATERIAL_PTR_DEP_TRA_LIST];
  CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

  /* Loop over reactions */

  i = 0;
  while ((dep = ListPtr(loc0, i++)) > VALID_PTR)
    {
      /* Check energy */
      
      if (E < RDB[dep + DEP_TRA_EMIN])
	break;
      
      /* Pointer to reaction data */
      
      rea = (long)RDB[dep + DEP_TRA_PTR_REA];
      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

      /* Skip total fission */
      
      if ((long)RDB[rea + REACTION_MT] < 0)
	continue;
      
      /* Get cross section */
      
      val = MicroXS(rea, E, id);
      
      /* Score */
      
      ptr = (long)RDB[dep + DEP_TRA_PTR_RESU];
      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
      AddPrivateRes(ptr + bin, val*flx*wgt, id);
    }
  
  /***************************************************************************/

  /***** Score fission yields ************************************************/

  /* Pointer to fission yields */

  if ((loc0 = (long)RDB[mat + MATERIAL_PTR_DEP_FISS_LIST]) > VALID_PTR)
    {
      /* Loop over reactions */
      
      i = 0;
      while ((dep = ListPtr(loc0, i++)) > VALID_PTR)
	{
	  /* Check energy */
	  
	  if (E < RDB[dep + DEP_TRA_EMIN])
	    break;

	  /* Pointer to reaction data */

	  rea = (long)RDB[dep + DEP_TRA_PTR_REA];
	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

	  /* Get interpolation energies (noi meni kai jotenkin ihan oudossa */
	  /* järjestyksessä?) */

	  E0 = RDB[rea + REACTION_FISSY_IE0];
	  E1 = RDB[rea + REACTION_FISSY_IE1];
	  E2 = RDB[rea + REACTION_FISSY_IE2];

	  /* Check values */

	  CheckValue(FUNCTION_NAME, "E1" ,"", E1, E0, E2);
	  CheckValue(FUNCTION_NAME, "E" ,"", E, E0, INFTY);

	  /* Check interval */

	  if (E < E2)
	    {
	      /* Interpolation factor */

	      if (E < E1)
		{
		  /* Below interpolation energy */
		  
		  if (E0 < 0.0)
		    g = 1.0;
		  else
		    g = (E - E0)/(E1 - E0);
		}
	      else
		{
		  /* Above interpolation energy */
		  
		  if (E2 > 1000.0)
		    g = 1.0;
		  else
		    g = (E2 - E)/(E2 - E1);
		}
	      
	      /* Check factor */
	      
	      CheckValue(FUNCTION_NAME, "g", "", g, 0.0, 1.0);
	      
	      /* Get cross section */

	      if ((ptr = (long)RDB[rea + REACTION_PTR_BRANCH_PARENT]) 
		  > VALID_PTR)
		val = MicroXS(ptr, E, id);
	      else
		val = MicroXS(rea, E, id);

	      /* Pointer to data */

	      ptr = (long)RDB[dep + DEP_TRA_PTR_RESU];
	      CheckPointer(FUNCTION_NAME, "(ptr)", RES2_ARRAY, ptr);
	      AddPrivateRes(ptr + bin, g*val*flx*wgt, id);
	    }
	}
    }
  
  /***************************************************************************/
}

/*****************************************************************************/
