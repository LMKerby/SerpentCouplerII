/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : collision.c                                    */
/*                                                                           */
/* Created:       2011/02/28 (JLe)                                           */
/* Last modified: 2012/01/06 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Samples reaction, updates coordinates and scores estimators  */
/*                                                                           */
/* Comments: - Tosta f:stä voi ehkä hankkiutua eroon? Kaikki noissa          */
/*             rutiineissa tapahtuva laskenta on wgt*f.                      */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Collision:"

/*****************************************************************************/

long Collision(long mat, long part, long type, double *x, double *y, double *z,
	       double *u, double *v, double *w, double *E, double *wgt, 
	       long id)
{
  long rea, ptr, mt, scatt;
  double f, totxs, absxs, E0, u0, v0, w0, mu, wgt0;

  /* Check material pointer */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /* Check cosines */

  CheckValue(FUNCTION_NAME, "r", "", *u**u+*v**v+*w**w - 1.0, -1E-5, 1E-5);

  /* Check coordinates, energy and weight */

  CheckValue(FUNCTION_NAME, "x", "", *x, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "y", "", *y, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "z", "", *z, -INFTY, INFTY);
  CheckValue(FUNCTION_NAME, "E", "", *E, ZERO, INFTY);
  CheckValue(FUNCTION_NAME, "wgt", "", *wgt, ZERO, INFTY);

  /* Get pointer to total xs */

  if (type == PARTICLE_TYPE_NEUTRON)
    ptr = (long)RDB[mat + MATERIAL_PTR_TOTXS];
  else
    ptr = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
    
  /* Get total xs */

  totxs = TotXS(ptr, *E, id);
  
  /* Score collision for source biasing */

  if ((ptr = (long)RDB[DATA_SBIAS_PTR_COL_MESH]) > VALID_PTR)
    AddMesh(ptr, *wgt, *x, *y, *z, id);

  /* Sample reaction */

  if ((rea = SampleReaction(mat, type, *E, *wgt, id)) < VALID_PTR)
    return part;

  /* Weight reduction by implicit capture */

  if (((long)RDB[DATA_OPT_IMPL_CAPT] == YES) && 
      (type == PARTICLE_TYPE_NEUTRON))
    {
      /* Get material total absorption xs (may be zero for He) */
      
      if ((ptr = (long)RDB[mat + MATERIAL_PTR_ABSXS]) > VALID_PTR)
	absxs = MacroXS(ptr, *E, id);
      else
	absxs = 0.0;
      
      /* Calculate weight reduction */
      
      f = 1.0 - absxs/totxs;
    }
  else
    f = 1.0;

  /* Remember values before collision */

  E0 = *E;
  wgt0 = *wgt;
  u0 = *u;
  v0 = *v;
  w0 = *w;

  /* Get reaction mt */

  mt = (long)RDB[rea + REACTION_MT];

  /* Check particle type */

  if (type == PARTICLE_TYPE_NEUTRON)
    {
      /***** Neutron reactions ***********************************************/

      /* Reset scattering flag */

      scatt = NO;

      /* Check reaction type */
      
      if (mt == 2)
	{
	  /* Elastic scattering */
	  
	  ElasticScattering(rea, E, u, v, w, id);
	  scatt = YES;
	}
      else if ((mt == 1002) || (mt == 1004))
	{
	  /* Scattering by S(a,b) laws */ 
	  
	  SabScattering(rea, E, u, v, w, id);
	  scatt = YES;
	}
      else if (RDB[rea + REACTION_TY] == 0.0)
	{
	  /* Capture */
	  
	  if ((long)RDB[DATA_OPT_IMPL_CAPT] == YES)
	    Die(FUNCTION_NAME, "Capture reaction in implicit mode");
	  else
	    {
	      /* Score capture reaction */

	      ScoreCapture(mat, rea, *wgt, id);

	      /* Put particle back in stack */
	      
	      ToStack(part, id);
	      
	      /* Exit subroutine */

	      return -1;
	    }
	}
      else if (((mt > 17) && (mt < 22)) || (mt == 38))
	{
	  /* Fission */
	  
	  Fission(mat, rea, part, E, *x, *y, *z, u, v, w, wgt, f, id);
	  
	  /* Check explicit fission and criticality source mode */
	  
	  if (((long)RDB[DATA_OPT_IMPL_FISS] == NO) ||
	      ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT))
	    {
	      /* Put particle back in stack */
	      
	      ToStack(part, id);
	      
	      /* Exit subroutine */

	      return -1;
	    }	    
	}
      else if ((mt > 50) && (mt < 91))
	{
	  /* Inelastic level scattering */

	  LevelScattering(rea, E, u, v, w, id);
	  scatt = YES;
	}
      else if (RDB[rea + REACTION_WGT_F] > 1.0)
	{
	  /* Multiplying scattering reaction */

	  Nxn(rea, part, E, *x, *y, *z, u, v, w, wgt, f, id);
	  scatt = YES;
	}
      else if (mt < 100)
	{
	  /* Continuum single neutron reactions */

	  InelasticScattering(rea, E, u, v, w, id);
	  scatt = YES;
	}
      else
	{
	  /* Unknown reaction mode */
	  
	  Die(FUNCTION_NAME, "Unknown reaction mode %ld sampled", mt);
	}

      /* Check scattering flag */

      if (scatt == YES)
	{
	  /* Calculate scattering cosine */

	  mu = *u*u0 + *v*v0 + *w*w0;

	  /* Score scattering */

	  ScoreScattering(mat, rea, mu, E0, *E, wgt0, id);
	}

      /***********************************************************************/
    }
  else
    {
      /***** Photon reactions ************************************************/

      if (mt == 504)
	{
	  /* Incoherent (Compton) scattering */

	  ComptonScattering(E, u, v, w, id);
	}
      else if (mt == 502)
	{
	  /* Coherent (Thompson) scattering */

	  ThompsonScattering(rea, *E, u, v, w, id);
	}
      else if (mt == 522)
	{
	  /* Photoelectric effect */

	  PhotoElectric(rea, part, *E, *x, *y, *z, *u, *v, *w, id);

	  /* Incident photon is killed */

	  return -1;
	}
      else if (mt == 516)
	{
	  /* Pair production */

	  PairProduction(rea, part, *x, *y, *z, *wgt, id);

	  /* Incident photon is killed */

	  return -1;
	}
      else
	Die(FUNCTION_NAME, "Invalid reaction mode %ld sampled", mt);

      /***********************************************************************/
    }

  /* Adjust weight */
  
  *wgt = *wgt*f; 
  
  /* Russian roulette */
  
  if (*wgt < RDB[DATA_OPT_ROULETTE_W0])
    {
      if (RandF(id) < RDB[DATA_OPT_ROULETTE_P0])
	*wgt = *wgt/RDB[DATA_OPT_ROULETTE_P0];
      else
	{
	  /* Put particle back in stack */
	  
	  ToStack(part, id);
	  
	  /* Exit subroutine */

	  return -1;
	}
    }

  /* Check energy, weight and cosines */

  CheckValue(FUNCTION_NAME, "E", "", *E, ZERO, INFTY);
  CheckValue(FUNCTION_NAME, "wgt", "", *wgt, ZERO, INFTY);
  CheckValue(FUNCTION_NAME, "r", "", *u**u+*v**v+*w**w - 1.0, -1E-5, 1E-5);

  /* Check with boundaries */

  if (type == PARTICLE_TYPE_NEUTRON)
    {
      /* Adjust neutron energy */

      if (*E < 1.0000001*RDB[DATA_NEUTRON_EMIN])
	*E = 1.000001*RDB[DATA_NEUTRON_EMIN];
      else if (*E > 0.999999*RDB[DATA_NEUTRON_EMAX])
	*E = 0.999999*RDB[DATA_NEUTRON_EMAX];
    }
  else
    {
      /* Do energy cut-off for photons or adjust upper boundary */

      if (*E < RDB[DATA_PHOTON_EMIN])
	{
	  /* Put particle back in stack */
	  
	  ToStack(part, id);
	  
	  /* Exit subroutine */

	  return -1;
	}
      else if (*E > 0.999999*RDB[DATA_PHOTON_EMAX])
	*E = 0.999999*RDB[DATA_PHOTON_EMAX];
    }

  /* Particle is not killed */

  return part;
  
  /***************************************************************************/
}

/*****************************************************************************/
