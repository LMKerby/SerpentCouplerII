/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : detectoroutput.c                               */
/*                                                                           */
/* Created:       2011/03/03 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Prints detector output                                       */
/*                                                                           */
/* Comments: - Time binejä ei pidä sallia classic lookin kanssa              */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "DetectorOutput:"

/*****************************************************************************/

void DetectorOutput()
{
  long det0, det1, erg, ptr, n0, n1;
  long ebins0, ubins0, cbins0, mbins0, lbins0, rbins0, zbins0, ybins0, xbins0;
  long tbins0, ebins1, ubins1, cbins1, mbins1, lbins1, rbins1, zbins1, ybins1;
  long xbins1, tbins1, eb0, ub0, cb0, mb0, lb0, rb0, zb0, yb0, xb0, tb0, eb1;
  long ub1, cb1, mb1, lb1, rb1, zb1, yb1, xb1, tb1, idx0, idx1;
  FILE *fp;
  char tmpstr[MAX_STR];

  /* Check detector definitions */

  if ((long)RDB[DATA_PTR_DET0] < VALID_PTR)
    return;

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* Check corrector step */

  if ((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP) 
    return;

  /* Open file for writing */
  
  sprintf(tmpstr, "%s_det%ld.m", GetText(DATA_PTR_INPUT_FNAME),
	  (long)RDB[DATA_BURN_STEP]);
  
  if ((fp = fopen(tmpstr, "w")) == NULL) 
    Die(FUNCTION_NAME, "Unable to open file for writing");

  /* Time bins are not used */

  tb0 = 0;
  tb1 = 0;

  /* Loop over detectors */
  
  det0 = (long)RDB[DATA_PTR_DET0];
  while(det0 > VALID_PTR)
    {
      /* Check mode */

      if (1 != 2)
	{
	  /*******************************************************************/

	  /***** Serpent 1 type output ***************************************/

	  /* Get number of bins */
	  
	  ebins0 = (long)RDB[det0 + DET_N_EBINS];
	  ubins0 = (long)RDB[det0 + DET_N_UBINS];
	  cbins0 = (long)RDB[det0 + DET_N_CBINS];
	  mbins0 = (long)RDB[det0 + DET_N_MBINS];
	  lbins0 = (long)RDB[det0 + DET_N_LBINS];
	  rbins0 = (long)RDB[det0 + DET_N_RBINS];
	  zbins0 = (long)RDB[det0 + DET_MESH_NZ];
	  ybins0 = (long)RDB[det0 + DET_MESH_NY];
	  xbins0 = (long)RDB[det0 + DET_MESH_NX];
	  tbins0 = (long)RDB[det0 + DET_N_TBINS];

	  fprintf(fp, "\n");

	  fprintf(fp, "DET%s = [\n", GetText(det0 + DET_PTR_NAME));

	  /* Pointer to statistics */
	  
	  ptr = (long)RDB[det0 + DET_PTR_STAT];
	  
	  /* Pointer to adjoint detector */
	  
	  if ((det1 = (long)RDB[det0 + DET_PTR_ADJOINT]) < VALID_PTR)
	    {
	      /* Loop over bins */

	      n0 = 0;

	      for (eb0 = 0; eb0 < ebins0; eb0++)
	      for (ub0 = 0; ub0 < ubins0; ub0++)
	      for (cb0 = 0; cb0 < cbins0; cb0++)
	      for (mb0 = 0; mb0 < mbins0; mb0++)
	      for (lb0 = 0; lb0 < lbins0; lb0++)
	      for (rb0 = 0; rb0 < rbins0; rb0++)
	      for (zb0 = 0; zb0 < zbins0; zb0++)
	      for (yb0 = 0; yb0 < ybins0; yb0++)
	      for (xb0 = 0; xb0 < xbins0; xb0++)
		{
		  /* Print indexes */
		  
		  fprintf(fp, "%5ld ", n0 + 1);
		  fprintf(fp, "%4ld ", eb0 + 1);
		  fprintf(fp, "%4ld ", ub0 + 1);
		  fprintf(fp, "%4ld ", cb0 + 1);
		  fprintf(fp, "%4ld ", mb0 + 1);
		  fprintf(fp, "%4ld ", lb0 + 1);
		  fprintf(fp, "%4ld ", rb0 + 1);
		  fprintf(fp, "%4ld ", zb0 + 1);
		  fprintf(fp, "%4ld ", yb0 + 1);
		  fprintf(fp, "%4ld ", xb0 + 1);

		  /* Get index */

		  idx0 = DetIdx(det0, eb0, ub0, cb0, mb0, lb0, rb0, zb0, yb0, 
				xb0, tb0);

		  /* Print mean */
		  
		  fprintf(fp, "%12.5E ", Mean(ptr, idx0));
		  
		  /* Print relative statistical error */
		  
		  fprintf(fp, "%7.5f ", RelErr(ptr, idx0));
		  
		  /* Print total number of scores */
		  
		  fprintf(fp, "%ld ", StatN(ptr, idx0));

		  /* Print newline */

		  fprintf(fp, "\n");

		  /* Update index */
		  
		  n0++;
		}
	    }
	  else
	    {
	      /* Get number of bins for second detector */
	      
	      ebins1 = (long)RDB[det1 + DET_N_EBINS];
	      ubins1 = (long)RDB[det1 + DET_N_UBINS];
	      cbins1 = (long)RDB[det1 + DET_N_CBINS];
	      mbins1 = (long)RDB[det1 + DET_N_MBINS];
	      lbins1 = (long)RDB[det1 + DET_N_LBINS];
	      rbins1 = (long)RDB[det1 + DET_N_RBINS];
	      zbins1 = (long)RDB[det1 + DET_MESH_NZ];
	      ybins1 = (long)RDB[det1 + DET_MESH_NY];
	      xbins1 = (long)RDB[det1 + DET_MESH_NX];
	      tbins1 = (long)RDB[det1 + DET_N_TBINS];

	      /* Loop over bins */

	      n0 = 0;

	      for (eb0 = 0; eb0 < ebins0; eb0++)
	      for (ub0 = 0; ub0 < ubins0; ub0++)
	      for (cb0 = 0; cb0 < cbins0; cb0++)
	      for (mb0 = 0; mb0 < mbins0; mb0++)
	      for (lb0 = 0; lb0 < lbins0; lb0++)
	      for (rb0 = 0; rb0 < rbins0; rb0++)
	      for (zb0 = 0; zb0 < zbins0; zb0++)
	      for (yb0 = 0; yb0 < ybins0; yb0++)
	      for (xb0 = 0; xb0 < xbins0; xb0++)
		{
		  /* Loop over second bins */

		  n1 = 0;

		  for (eb1 = 0; eb1 < ebins1; eb1++)
		  for (ub1 = 0; ub1 < ubins1; ub1++)
		  for (cb1 = 0; cb1 < cbins1; cb1++)
		  for (mb1 = 0; mb1 < mbins1; mb1++)
		  for (lb1 = 0; lb1 < lbins1; lb1++)
		  for (rb1 = 0; rb1 < rbins1; rb1++)
		  for (zb1 = 0; zb1 < zbins1; zb1++)
		  for (yb1 = 0; yb1 < ybins1; yb1++)
		  for (xb1 = 0; xb1 < xbins1; xb1++)
		      {
			/* Print indexes */
			
			fprintf(fp, "%5ld ", n0 + 1);
			fprintf(fp, "%4ld ", eb0 + 1);
			fprintf(fp, "%4ld ", ub0 + 1);
			fprintf(fp, "%4ld ", cb0 + 1);
			fprintf(fp, "%4ld ", mb0 + 1);
			fprintf(fp, "%4ld ", lb0 + 1);
			fprintf(fp, "%4ld ", rb0 + 1);
			fprintf(fp, "%4ld ", zb0 + 1);
			fprintf(fp, "%4ld ", yb0 + 1);
			fprintf(fp, "%4ld ", xb0 + 1);

			fprintf(fp, "%5ld ", n1 + 1);
			fprintf(fp, "%4ld ", eb1 + 1);
			fprintf(fp, "%4ld ", ub1 + 1);
			fprintf(fp, "%4ld ", cb1 + 1);
			fprintf(fp, "%4ld ", mb1 + 1);
			fprintf(fp, "%4ld ", lb1 + 1);
			fprintf(fp, "%4ld ", rb1 + 1);
			fprintf(fp, "%4ld ", zb1 + 1);
			fprintf(fp, "%4ld ", yb1 + 1);
			fprintf(fp, "%4ld ", xb1 + 1);
			
			/* Get indexes */

			idx0 = DetIdx(det0, eb0, ub0, cb0, mb0, lb0, rb0, zb0, 
				      yb0, zb0, tb0);

			idx1 = DetIdx(det1, eb1, ub1, cb1, mb1, lb1, rb1, zb1, 
				      yb1, zb1, tb1);

			/* Print mean */
		  
			fprintf(fp, "%12.5E ", Mean(ptr, idx0, idx1));
			
			/* Print relative statistical error */
			
			fprintf(fp, "%7.5f ", RelErr(ptr, idx0, idx1));
			
			/* Print total number of scores */
			
			fprintf(fp, "%ld ", StatN(ptr, idx0, idx1));
			
			/* Print newline */
			
			fprintf(fp, "\n");
			
			/* Update index */
		  
			n1++;
		      }
		  
		  /* Update index */
		  
		  n0++;		  
		}
	    }

	  fprintf(fp, "];\n\n");

	  /*******************************************************************/
	}
      
      /***** Print energy intervals ******************************************/

      if ((erg = (long)RDB[det0 + DET_PTR_EGRID]) > VALID_PTR)
	{
	  /* Pointer to values */
	  
	  ptr = (long)RDB[erg + ENERGY_GRID_PTR_DATA];
	  
	  /* Loop over energy bins and print values */
	  
	  fprintf(fp, "DET%sE = [\n", GetText(det0 + DET_PTR_NAME));
	  
	  for (n0 = 0; n0 < (long)RDB[erg + ENERGY_GRID_NE] - 1; n0++)
	    fprintf(fp, "%12.5E %12.5E %12.5E\n", RDB[ptr + n0],
		    RDB[ptr + n0 + 1], 
		    (RDB[ptr + n0] + RDB[ptr + n0 + 1])/2.0);
	  
	  fprintf(fp, "];\n");
	}
      
      /***********************************************************************/
      
      /* Next detector */
      
      det0 = NextItem(det0);
    }
      
  /* Close file */

  fclose(fp);
}

/*****************************************************************************/
