/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : surfacedistance.c                              */
/*                                                                           */
/* Created:       2010/10/10 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates minimum distance to a surface                     */
/*                                                                           */
/* Comments: From Serpent 1.1.14                                             */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "SurfaceDistance:"

/*****************************************************************************/

double SurfaceDistance(const double *params, long type, long np, 
		       double x, double y, double z,
		       double u, double v, double w)
{
  long n;
  double r, l, h, r0, r1, min, x0, y0, z0, a, b, c, d, d0, d1, k, th1, th2;
  double A, B, C, D, E, F, G, H, J, K, L, M, N, S;
  double tmp[MAX_SURFACE_PARAMS];

  /* Check pointer */

#ifdef DEBUG

  if (params == NULL)
    Die(FUNCTION_NAME, "Null pointer");

#endif

  /* Remember original co-ordinates */

  x0 = x;
  y0 = y;
  z0 = z;

  /* Reset parameter index */

  n = 0;

  /* Set minimum distance to infinity */

  min = INFTY;

  /* Check surface type */

  switch (type)
    {
      /***********************************************************************/
      
    case SURF_INF:
      {
	return INFTY;
      }

      /***********************************************************************/

    case SURF_PX:
      {
	/* shift origin */

	x = x - params[n];

	if (u == 0.0)
	  return INFTY;
	else if ((d = -x/u) < 0)
	  return INFTY;
	else
	  return d;
      }

      /***********************************************************************/

    case SURF_PY:
      {
	/* shift origin */

	y = y - params[n];
	
	if (v == 0.0)
	  return INFTY;
	else if ((d = -y/v) < 0)
	  return INFTY;
	else
	  return d;
      }

      /***********************************************************************/

    case SURF_PZ:
      {
	/* shift origin */

	z = z - params[n];

	if (w == 0.0)
	  return INFTY;
	else if ((d = -z/w) < 0)
	  return INFTY;
	else
	  return d;
      }

      /***********************************************************************/

    case SURF_SQC:
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];

	/* Get radius */

	r = params[n++];

	/* Calculate minimum distance */

	if (u != 0.0)
	  {
	    if (((d = -(x - r)/u) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(x + r)/u) > 0.0) && (d < min))
	      min = d;
	  }

	if (v != 0.0)
	  {
	    if (((d = -(y - r)/v) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(y + r)/v) > 0.0) && (d < min))
	      min = d;
	  }
	
	/* Rounded corners */

	if (n < np)
	  {
	    /* Get radius */

	    r0 = params[n];
	    tmp[2] = r0;

	    /* Check each corner */

	    tmp[0] = -r + r0; 
	    tmp[1] = -r + r0;

	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[0] =  r - r0; 
	    tmp[1] = -r + r0;

	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[0] =  r - r0;
	    tmp[1] =  r - r0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[0] = -r + r0;
	    tmp[1] =  r - r0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;
	  }

	/* Return distance */

	return min;
      }
      
      /***********************************************************************/
      
    case SURF_CUBE:
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];
	z = z - params[n++];

	/* Get radius */

	r = params[n];

	/* Calculate minimum distance */

	if (u != 0.0)
	  {
	    if (((d = -(x - r)/u) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(x + r)/u) > 0.0) && (d < min))
	      min = d;
	  }
	
	if (v != 0.0)
	  {
	    if (((d = -(y - r)/v) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(y + r)/v) > 0.0) && (d < min))
	      min = d;
	  }

	if (w != 0.0)
	  {
	    if (((d = -(z - r)/w) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(z + r)/w) > 0.0) && (d < min))
	      min = d;
	  }
	
	/* Return distance */

	return min;
      }

      /***********************************************************************/

    case SURF_CUBOID:
      {
	/* Calculate minimum distance */

	if (u != 0.0)
	  {
	    if (((d = -(x - params[n])/u) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(x - params[n + 1])/u) > 0.0) && (d < min))
	      min = d;
	  }
	
	if (v != 0.0)
	  {
	    if (((d = -(y - params[n + 2])/v) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(y - params[n + 3])/v) > 0.0) && (d < min))
	      min = d;
	  }

	if (w != 0.0)
	  {
	    if (((d = -(z - params[n + 4])/w) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(z - params[n + 5])/w) > 0.0) && (d < min))
	      min = d;
	  }
	
	/* Return distance */

	return min;
      }

      /***********************************************************************/

    case SURF_HEXYC:
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];
      
	/* Get radius */

	r = params[n++];

	/* Calculate minimum distance */
	
	if (v != 0.0)
	  {
	    if (((d = -(y - r)/v) > 0) && (d < min))
	      min = d;
	    if (((d = -(y + r)/v) > 0) && (d < min))
	      min = d;
	  }

	if ((v - SQRT3*u) != 0.0)
	  {
	    if (((d = (-y + SQRT3*x + 2*r)/(v - SQRT3*u)) > 0) && (d < min))
	      min = d;
	    
	    if (((d = (-y + SQRT3*x - 2*r)/(v - SQRT3*u)) > 0) && (d < min))
	      min = d;
	  }
	
	if ((v + SQRT3*u) != 0.0)
	  {
	    if (((d = (-y - SQRT3*x + 2*r)/(v + SQRT3*u)) > 0) && (d < min))
	      min = d;
	    if (((d = (-y - SQRT3*x - 2*r)/(v + SQRT3*u)) > 0) && (d < min))
	      min = d;
	  }

	/* Rounded corners */

	if (n < np)
	  {
	    /* Get radius */

	    r0 = params[n];
	    tmp[2] = r0;

	    /* Check each corner */

	    tmp[0] = (-r + r0)/(2.0*COS30);
	    tmp[1] =  -r + r0;

	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[0] = (r - r0)/(2.0*COS30); 
	    tmp[1] = -r + r0;

	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[0] = (r - r0)/(2.0*COS30);
	    tmp[1] =  r - r0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[0] = (-r + r0)/(2.0*COS30);
	    tmp[1] =   r - r0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[0] = (-r + r0)/(COS30);
	    tmp[1] =  0.0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[0] = (r - r0)/(COS30);
	    tmp[1] =  0.0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;
	  }

	/* Return distance */

	return min;
      }

      /***********************************************************************/
      
    case SURF_HEXXC:      
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];
	
	/* Get radius */

	r = params[n++];

	/* Calculate minimum distance */
	
	if (u != 0.0)
	  {
	    if (((d = -(x - r)/u) > 0) && (d < min))
	      min = d;
	    if (((d = -(x + r)/u) > 0) && (d < min))
	      min = d;
	  }

	if ((u - SQRT3*v) != 0.0)
	  {
	    if (((d = (-x + SQRT3*y + 2*r)/(u - SQRT3*v)) > 0) && (d < min))
	      min = d;

	    if (((d = (-x + SQRT3*y - 2*r)/(u - SQRT3*v)) > 0) && (d < min))
	      min = d;
	  }

	if ((u + SQRT3*v) != 0.0)
	  {
	    if (((d = (-x - SQRT3*y + 2*r)/(u + SQRT3*v)) > 0) && (d < min))
	      min = d;
	    if (((d = (-x - SQRT3*y - 2*r)/(u + SQRT3*v)) > 0) && (d < min))
	      min = d;
	  }

	/* Rounded corners */

	if (n < np)
	  {
	    /* Get radius */

	    r0 = params[n];
	    tmp[2] = r0;

	    /* Check each corner */

	    tmp[1] = (-r + r0)/(2.0*COS30);
	    tmp[0] =  -r + r0;

	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[1] = (r - r0)/(2.0*COS30); 
	    tmp[0] = -r + r0;

	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[1] = (r - r0)/(2.0*COS30);
	    tmp[0] =  r - r0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[1] = (-r + r0)/(2.0*COS30);
	    tmp[0] =   r - r0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[1] = (-r + r0)/(COS30);
	    tmp[0] =  0.0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[1] = (r - r0)/(COS30);
	    tmp[0] =  0.0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;
	  }

	/* Return distance */

	return min;
      }

      /***********************************************************************/

    case SURF_HEXYPRISM:
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];
      
	/* Get radius */

	r = params[n++];

	/* Calculate minimum distance */
	
	if (v != 0.0)
	  {
	    if (((d = -(y - r)/v) > 0) && (d < min))
	      min = d;
	    if (((d = -(y + r)/v) > 0) && (d < min))
	      min = d;
	  }

	if ((v - SQRT3*u) != 0.0)
	  {
	    if (((d = (-y + SQRT3*x + 2*r)/(v - SQRT3*u)) > 0) && (d < min))
	      min = d;
	    
	    if (((d = (-y + SQRT3*x - 2*r)/(v - SQRT3*u)) > 0) && (d < min))
	      min = d;
	  }
	
	if ((v + SQRT3*u) != 0.0)
	  {
	    if (((d = (-y - SQRT3*x + 2*r)/(v + SQRT3*u)) > 0) && (d < min))
	      min = d;
	    if (((d = (-y - SQRT3*x - 2*r)/(v + SQRT3*u)) > 0) && (d < min))
	      min = d;
	  }

	if (w != 0.0)
	  {
	    if (((d = -(z - params[n++])/w) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(z - params[n++])/w) > 0.0) && (d < min))
	      min = d;
	  }


	/* Return distance */

	return min;
      }

      /***********************************************************************/

    case SURF_HEXXPRISM:
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];
	
	/* Get radius */

	r = params[n++];

	/* Calculate minimum distance */
	
	if (u != 0.0)
	  {
	    if (((d = -(x - r)/u) > 0) && (d < min))
	      min = d;
	    if (((d = -(x + r)/u) > 0) && (d < min))
	      min = d;
	  }

	if ((u - SQRT3*v) != 0.0)
	  {
	    if (((d = (-x + SQRT3*y + 2*r)/(u - SQRT3*v)) > 0) && (d < min))
	      min = d;

	    if (((d = (-x + SQRT3*y - 2*r)/(u - SQRT3*v)) > 0) && (d < min))
	      min = d;
	  }

	if ((u + SQRT3*v) != 0.0)
	  {
	    if (((d = (-x - SQRT3*y + 2*r)/(u + SQRT3*v)) > 0) && (d < min))
	      min = d;
	    if (((d = (-x - SQRT3*y - 2*r)/(u + SQRT3*v)) > 0) && (d < min))
	      min = d;
	  }

	if (w != 0.0)
	  {
	    if (((d = -(z - params[n++])/w) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(z - params[n++])/w) > 0.0) && (d < min))
	      min = d;
	  }


	/* Return distance */

	return min;
      }

      /***********************************************************************/

    case SURF_CYL:
    case SURF_CYLZ:
      {
	/* NOTE: Tähän lisättiin katkaisu z-suunnassa 3.12.2009 (JLE) */

	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];
	
	/* Get radius */

	r = params[n++];

	/* Check if cylinder is cut */

	if (np == 5)
	  {
	    /* First surface */

	    if (w == 0.0)
	      d0 = INFTY;
	    else if ((d0 = -(z - params[n++])/w) < 0)
	      d0 = INFTY;

	    /* Second surface */
	    
	    if (w == 0.0)
	      d1 = INFTY;
	    else if ((d1 = -(z - params[n++])/w) < 0)
	      d1 = INFTY;

	    /* Compare */

	    if (d0 < d1)
	      min = d0;
	    else
	      min = d1;
	  }
	else
	  min = INFTY;

	/* Calculate constants */

	if ((a = 1.0 - w*w) == 0.0)
	  return min;
	
	b = u*x + v*y;      
	c = x*x + y*y - r*r;

	if ((d0 = b*b - a*c) < 0.0)
	  {
	    /* No line-of-sight */

	    return INFTY;
	  }
	else if (c < 0)
	  {
	    /* Point is inside, only one root possible */

	    d = -(b - sqrt(d0))/a;
	  }
	else if ((d = -(b + sqrt(d0))/a) < 0.0)
	  {
	    /* Point is outside, line-of-sight, opposite direction */

	    return INFTY;
	  }
	
	/* Compare to minimum */

	if (d < min)
	  min = d;

	/* Return distance */

	return min;
      }	
      
      /***********************************************************************/

    case SURF_CYLX:
      {
	/* Shift origin */
	
	y = y - params[n++];
	z = z - params[n++];
	
	/* Get radius */

	r = params[n++];

	/* Check if cylinder is cut */

	if (np == 5)
	  {
	    /* First surface */

	    if (u == 0.0)
	      d0 = INFTY;
	    else if ((d0 = -(x - params[n++])/u) < 0)
	      d0 = INFTY;

	    /* Second surface */
	    
	    if (u == 0.0)
	      d1 = INFTY;
	    else if ((d1 = -(x - params[n++])/u) < 0)
	      d1 = INFTY;

	    /* Compare */

	    if (d0 < d1)
	      min = d0;
	    else
	      min = d1;
	  }
	else
	  min = INFTY;

	/* Calculate constants */

	if ((a = 1.0 - u*u) == 0.0)
	  return min;
	
	b = v*y + w*z;      
	c = y*y + z*z - r*r;

	if ((d0 = b*b - a*c) < 0.0)
	  {
	    /* No line-of-sight */

	    return INFTY;
	  }
	else if (c < 0)
	  {
	    /* Point is inside, only one root possible */

	    d = -(b - sqrt(d0))/a;
	  }
	else if ((d = -(b + sqrt(d0))/a) < 0.0)
	  {
	    /* Point is outside, line-of-sight, opposite direction */

	    return INFTY;
	  }
	
	/* Compare to minimum */

	if (d < min)
	  min = d;

	/* Return distance */

	return min;
      }	
      
      /***********************************************************************/

    case SURF_CYLY:
      {
	/* Shift origin */
	
	x = x - params[n++];
	z = z - params[n++];
	
	/* Get radius */

	r = params[n++];

	/* Check if cylinder is cut */

	if (np == 5)
	  {
	    /* First surface */

	    if (v == 0.0)
	      d0 = INFTY;
	    else if ((d0 = -(y - params[n++])/v) < 0)
	      d0 = INFTY;

	    /* Second surface */
	    
	    if (v == 0.0)
	      d1 = INFTY;
	    else if ((d1 = -(y - params[n++])/v) < 0)
	      d1 = INFTY;

	    /* Compare */

	    if (d0 < d1)
	      min = d0;
	    else
	      min = d1;
	  }
	else
	  min = INFTY;

	/* Calculate constants */

	if ((a = 1.0 - v*v) == 0.0)
	  return min;
	
	b = u*x + w*z;      
	c = x*x + z*z - r*r;

	if ((d0 = b*b - a*c) < 0.0)
	  {
	    /* No line-of-sight */

	    return INFTY;
	  }
	else if (c < 0)
	  {
	    /* Point is inside, only one root possible */

	    d = -(b - sqrt(d0))/a;
	  }
	else if ((d = -(b + sqrt(d0))/a) < 0.0)
	  {
	    /* Point is outside, line-of-sight, opposite direction */

	    return INFTY;
	  }
	
	/* Compare to minimum */

	if (d < min)
	  min = d;

	/* Return distance */

	return min;
      }	
      
      /***********************************************************************/

    case SURF_CONE:
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];
	z = z - params[n++];
	
	/* Get radius */

	r = params[n++];

	/* Get height */

	h = params[n];

	/* Simplify calculation by coordinate substitution */

	z = r*(1 - z/h);
	w = -r*w/h;

	/* Calculate constants */

	a = u*u + v*v - w*w;
	b = x*u + v*y - w*z;
	c = x*x + y*y - z*z;

	/* Calculate discriminant */

	if ((d = b*b - a*c) < 0.0)
	  {
	    /* No line-of-sight */

	    return INFTY;
	  }
	else
	  d = sqrt(d);

	/* Calculate roots */

	d0 = -(b + d)/a;
	d1 = -(b - d)/a;

	/* Check different possibilities */

	if ((d0 < 0.0) && (d1 < 0.0))
	  {
	    /* Both negative, no line-of-sight */

	    return INFTY;
	  }
	else if ((d0 > 0.0) && (d1 > 0.0))
	  {
	    /* Both positive, pick shortest */

	    if (d0 > d1)
	      return d1;
	    else
	      return d0;
	  }
	else
	  {
	    /* One positive, one negative, pick positive */
	    
	    if (d0 > 0.0)
	      return d0;
	    else
	      return d1;
	  }
      }	
      
      /***********************************************************************/

    case SURF_SPH:
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];
	z = z - params[n++];
	
	/* Get radius */

	r = params[n];

	/* Calculate constants */

	b = u*x + v*y + w*z;      
	c = x*x + y*y + z*z - r*r;

	if ((d0 = b*b - c) < 0.0)
	  {
	    /* No line-of-sight */

	    return INFTY;
	  }
	else if (c < 0)
	  {
	    /* Point is inside, only one root possible */

	    min = -(b - sqrt(d0));
	  }
	else if ((d = -(b + sqrt(d0))) < 0.0)
	  {
	    /* Point is outside, line-of-sight, opposite direction */

	    return INFTY;
	  }
	else
	  {
	    /* Point is outside, line-of-sight, towards surface */

	    min = d;
	  }

	/* Return distance */

	return min;
      }	
      
      /***********************************************************************/

    case SURF_PAD:
      {
	/* Get parameters */

	r0 = params[n++];
	r1 = params[n++];
	th1 = PI*params[n++]/180.0;
	th2 = PI*params[n]/180.0;

	/* Distance from inner ring */

	tmp[0] = 0.0;
	tmp[1] = 0.0;
	tmp[2] = r0;

	if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
	     > 0.0) && (d < min))
	  min = d;

	/* Distance from outer ring */

	tmp[0] = 0.0;
	tmp[1] = 0.0;
	tmp[2] = r1;

	if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
	     > 0.0) && (d < min))
	  min = d;

	/* Check sector width */

	if (th1 - th2 < 2.0*PI)
	  {
	    /* Distance from sectors */
	    
	    k = -sin(th1)/cos(th1);
	    
	    if (((v - k*u) != 0.0) &&
		((d = (k*x - y)/(v - k*u)) > 0.0) && (d < min))
	      min = d;
	    
	    /* Distance from sectors */
	    
	    k = -sin(th2)/cos(th2);
	    
	    if (((v - k*u) != 0.0) &&
		((d = (k*x - y)/(v - k*u)) > 0.0) && (d < min))
	      min = d;
	  }

	/* Return distance */
	
	return min;
      }

      /***********************************************************************/
      
    case SURF_CROSS:
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];

	/* Get length and width */

	l = params[n++];
	r = params[n++];

	/* Calculate minimum distance */

	if (u != 0.0)
	  {
	    if (((d = -(x - l)/u) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(x - r)/u) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(x + r)/u) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(x + l)/u) > 0.0) && (d < min))
	      min = d;
	  }
	
	if (v != 0.0)
	  {
	    if (((d = -(y - l)/v) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(y - r)/v) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(y + r)/v) > 0.0) && (d < min))
	      min = d;
	    if (((d = -(y + l)/v) > 0.0) && (d < min))
	      min = d;
	  }

	/* Rounded corners */

	if (n < np)
	  {
	    /* Get radius (use width) */

	    r0 = r;
	    tmp[2] = r0;

	    /* Check each corner */

	    tmp[0] = 0.0;
	    tmp[1] = -l + r0;

	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[0] = 0.0;
	    tmp[1] = l - r0;

	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[0] = l - r0;
	    tmp[1] = 0.0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;

	    tmp[0] = -l + r0;
	    tmp[1] = 0.0;
	    
	    if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
		 > 0.0) && (d < min))
	      min = d;
	  }

	/* Return distance */

	return min;
      }

      /***********************************************************************/
      
    case SURF_DODE:
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];
      
	/* Get radius */
	
	r = params[n++];

	if (np == 4)
	  l = params[n++];
	else
	  l = r;	
	
	/* Calculate minimum distance */
	
	if (v != 0.0)
	  {
	    /* Yläreuna (y-suunta) pinta 1 */
	    
	    if (((d = -(y - l)/v) > 0) && (d < min))
	      min = d;
	    
	    /* Alareuna (y-suunta) pinta 7 */
	    
	    if (((d = -(y + l)/v) > 0) && (d < min))
	      min = d;
	  }
	
	if (u != 0.0)
	  {
	    /* Oikea reuna (x-suunta) pinta 10 */
		
	    if (((d = -(x - r)/u) > 0) && (d < min))
	      min = d;
		
	    /* Vasen reuna (x-suunta) pinta 4 */
	    
	    if (((d = -(x + r)/u) > 0) && (d < min))
	      min = d;
	  }

	/* Yläpinnasta alkaen positiiviseen kiertosuuntaan pinnat 3 ja 9 */
	
	if ((v - SQRT3*u) != 0.0)
	  {
	    if (((d = (-y + SQRT3*x + 2*l)/(v - SQRT3*u)) > 0) && (d < min))
	      min = d;
	    
	    if (((d = (-y + SQRT3*x - 2*l)/(v - SQRT3*u)) > 0) && (d < min))
	      min = d;
	  }

	/* Yläpinnasta alkaen positiiviseen kiertosuuntaan pinnat 5 ja 11 */
	
	if ((v + SQRT3*u) != 0.0)
	  {
	    if (((d = (-y - SQRT3*x + 2*l)/(v + SQRT3*u)) > 0) && (d < min))
	      min = d;
	    
	    if (((d = (-y - SQRT3*x - 2*l)/(v + SQRT3*u)) > 0) && (d < min))
	      min = d;
	  }

	/* Yläpinnasta alkaen positiiviseen kiertosuuntaan pinnat 2 ja 8 */
	
	if ((u - SQRT3*v) != 0.0)
	  {
	    if (((d = (-x + SQRT3*y + 2*r)/(u - SQRT3*v)) > 0) && (d < min))
	      min = d;
	    
	    if (((d = (-x + SQRT3*y - 2*r)/(u - SQRT3*v)) > 0) && (d < min))
	      min = d;
	  }
	
	/* Yläpinnasta alkaen positiiviseen kiertosuuntaan pinnat 6 ja 12 */
	
	if ((u + SQRT3*v) != 0.0)
	  {
	    if (((d = (-x - SQRT3*y + 2*r)/(u + SQRT3*v)) > 0) && (d < min))
	      min = d;
	    
	    if (((d = (-x - SQRT3*y - 2*r)/(u + SQRT3*v)) > 0) && (d < min))
	      min = d;
	  }
	
	/* Return distance */
	
	return min;
      }

      /***********************************************************************/

    case SURF_OCTA:
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];
      
	/* Get radius */
	
	r = params[n++];

	if (np == 4)
	  l = params[n++];
	else
	  l = r;	
	
	/* Calculate minimum distance */
	
	if (v != 0.0)
	  {
	    /* Yläreuna (y-suunta) pinta 1 */
	    
	    if (((d = -(y - r)/v) > 0) && (d < min))
	      min = d;
	    
	    /* Alareuna (y-suunta) pinta 5 */
	    
	    if (((d = -(y + r)/v) > 0) && (d < min))
	      min = d;
	  }
	
	if (u != 0.0)
	  {
	    /* Oikea reuna (x-suunta) pinta 7 */
		
	    if (((d = -(x - r)/u) > 0) && (d < min))
	      min = d;
		
	    /* Vasen reuna (x-suunta) pinta 3 */
	    
	    if (((d = -(x + r)/u) > 0) && (d < min))
	      min = d;
	  }

	/* Yläpinnasta alkaen positiiviseen kiertosuuntaan pinnat 2 ja 6 */
	
	if ((v - u) != 0.0)
	  {
	    if (((d = (-y + x + SQRT2*l)/(v - u)) > 0) && (d < min))
	      min = d;
	    
	    if (((d = (-y + x - SQRT2*l)/(v - u)) > 0) && (d < min))
	      min = d;
	  }

	/* Yläpinnasta alkaen positiiviseen kiertosuuntaan pinnat 4 ja 8 */
	
	if ((v + u) != 0.0)
	  {
	    if (((d = (-y - x + SQRT2*l)/(v + u)) > 0) && (d < min))
	      min = d;
	    
	    if (((d = (-y - x - SQRT2*l)/(v + u)) > 0) && (d < min))
	      min = d;
	  }

	/* Return distance */
	
	return min;
      }
	  
      /***********************************************************************/
 
    case SURF_ASTRA:
      {
	/* Shift origin */
	
	x = x - params[n++];
	y = y - params[n++];
      
	/* Get radius */
	
	r = params[n++];
	l = params[n++];
	
	/* Calculate minimum distance */
	
	if (v != 0.0)
	  {
	    /* Yläreuna (y-suunta) pinta 1 */
	    
	    if (((d = -(y - r)/v) > 0) && (d < min))
	      min = d;
	    
	    /* Alareuna (y-suunta) pinta 5 */
	    
	    if (((d = -(y + r)/v) > 0) && (d < min))
	      min = d;
	  }
	
	if (u != 0.0)
	  {
	    /* Oikea reuna (x-suunta) pinta 7 */
		
	    if (((d = -(x - r)/u) > 0) && (d < min))
	      min = d;
		
	    /* Vasen reuna (x-suunta) pinta 3 */
	    
	    if (((d = -(x + r)/u) > 0) && (d < min))
	      min = d;
	  }

	/* Yläpinnasta alkaen positiiviseen kiertosuuntaan pinnat 2 ja 6 */
	
	if ((v - u) != 0.0)
	  {
	    if (((d = (-y + x + SQRT2*l)/(v - u)) > 0) && (d < min))
	      min = d;
	    
	    if (((d = (-y + x - SQRT2*l)/(v - u)) > 0) && (d < min))
	      min = d;
	  }

	/* Yläpinnasta alkaen positiiviseen kiertosuuntaan pinnat 4 ja 8 */
	
	if ((v + u) != 0.0)
	  {
	    if (((d = (-y - x + SQRT2*l)/(v + u)) > 0) && (d < min))
	      min = d;
	    
	    if (((d = (-y - x - SQRT2*l)/(v + u)) > 0) && (d < min))
	      min = d;
	  }
	
	/* Ihme pallerot */
	
	/* Get radius */

	r0 = params[n];
	tmp[2] = r0;

	/* Upper left */

	tmp[0] = 0.5*r - 0.75*SQRT2*l;
	tmp[1] = 0.5*r + 0.25*SQRT2*l;
	    
	if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
	  > 0.0) && (d < min))
	  min = d;

	tmp[0] = -0.5*r - 0.25*SQRT2*l;
	tmp[1] = -0.5*r + 0.75*SQRT2*l;
	    
	if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
	  > 0.0) && (d < min))
	  min = d;
		  
	/* Lower left */

	tmp[0] = -0.5*r - 0.25*SQRT2*l;
	tmp[1] =  0.5*r - 0.75*SQRT2*l;
	    
	if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
	  > 0.0) && (d < min))
	  min = d;
		  
	tmp[0] =  0.5*r - 0.75*SQRT2*l;
	tmp[1] = -0.5*r - 0.25*SQRT2*l;
	    
	if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
	  > 0.0) && (d < min))
	  min = d;
		
	/* Lower right */
		  
	tmp[0] = -0.5*r + 0.75*SQRT2*l;
	tmp[1] = -0.5*r - 0.25*SQRT2*l;

	if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
	  > 0.0) && (d < min))
	  min = d;

	tmp[0] =  0.5*r + 0.25*SQRT2*l;
	tmp[1] =  0.5*r - 0.75*SQRT2*l;
	    
	if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
	  > 0.0) && (d < min))
	  min = d;
		  
	/* Upper right */
		
	tmp[0] =  0.5*r + 0.25*SQRT2*l;
	tmp[1] = -0.5*r + 0.75*SQRT2*l;

	if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
	  > 0.0) && (d < min))
	  min = d;

	tmp[0] = -0.5*r + 0.75*SQRT2*l;
	tmp[1] =  0.5*r + 0.25*SQRT2*l;

	if (((d = SurfaceDistance(tmp, SURF_CYL, 3, x, y, z, u, v, w))
	  > 0.0) && (d < min))
	  min = d;		  

	/* Return distance */

	return min;
      }
      
      /***********************************************************************/
      
    case SURF_PLANE:
      {
	/* Reset optional parameters */

	B = 0.0;
	C = 0.0;
	D = 0.0;

	/* Get parameters */
	
	A = params[n++];

	if (n < np)
	  B = params[n++];

	if (n < np)
	  C = params[n++];
	
	if (n < np)
	  D = params[n++];

	/* Calculate first constant */

	M = A*u + B*v + C*w;

	/* Check */

	if (M == 0.0)
	  return INFTY;

	/* Calculate second constant */

	L = A*x + B*y + C*z - D;

	/* Calculate distance */

	d = -L/M;

	/* Check sign */

	if (d > 0.0)
	  return d;
	else
	  return INFTY;
      }
      
      /***********************************************************************/

    case SURF_QUADRATIC:
      {
	/* Reset optional parameters */

	B = 0.0;
	C = 0.0;
	D = 0.0;
	E = 0.0;
	F = 0.0;
	G = 0.0;
	H = 0.0;
	J = 0.0;
	K = 0.0;

	/* Get parameters */
	
	A = params[n++];

	if (n < np)
	  B = params[n++];

	if (n < np)
	  C = params[n++];
	
	if (n < np)
	  D = params[n++];

	if (n < np)
	  E = params[n++];

	if (n < np)
	  F = params[n++];

	if (n < np)
	  G = params[n++];

	if (n < np)
	  H = params[n++];

	if (n < np)
	  J = params[n++];

	if (n < np)
	  K = params[n++];

	/* Calculate constants */
	
	N = A*u*u + B*v*v + C*w*w + D*u*v + E*v*w + F*u*w;
	M = 2*A*u*x + 2*B*v*y + 2*C*w*z + D*(v*x + u*y) + E*(w*y + v*z) + 
	  F*(w*x + u*z) + G*u + H*v + J*w;
	L = A*x*x + B*y*y + C*z*z + D*x*y + E*y*z + F*x*z + G*x + H*y + J*z 
	  + K;

	/* Check number of roots */

	if (N == 0.0)
	  {
	    /* Single root */

	    if (M == 0.0)
	      return INFTY;
	    else if ((d = -L/M) < 0.0)
	      return INFTY;
	    else 
	      return d;
	  }

	/* Two roots */

	if ((S = M*M - 4 * N * L) < 0.0)
	  return INFTY;
	else
	  S = sqrt(S);
	
	/* Get solutions */
	
	d0 = (-M + S)/(2*N);
	d1 = (-M - S)/(2*N);
      
	/* Choose smallest positive */

	if ((d0 < 0.0) && (d1 < 0.0))
	  {
	    /* Both negative, no line-of-sight */
	    
	    return INFTY;
	  }
	else if ((d0 > 0.0) && (d1 > 0.0))
	  {
	    /* Both positive, pick shortest */

	    if (d0 > d1)
	      return d1;
	    else
	      return d0;
	  }
	else
	  {
	    /* One positive, one negative, pick positive */
	    
	    if (d0 > 0.0)
	      return d0;
	    else
	      return d1;
	  }
      }
      
      /***********************************************************************/
      
      
    default:
      Die(FUNCTION_NAME, "Surface type %d not supported", type);	
      
      /***********************************************************************/
    }
  
  /* Something wrong */
  
  fprintf(err, "%s WTF?\n", FUNCTION_NAME);

  exit(-1);
}

/****************************************************************************/
