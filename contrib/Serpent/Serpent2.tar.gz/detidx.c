/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : detidx.c                                       */
/*                                                                           */
/* Created:       2011/07/11 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Returns stat index for detectors                             */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "DetIdx:"

/*****************************************************************************/

long DetIdx(long det, long ebin, long ubin, long cbin, long mbin, long lbin,
	    long rbin, long zbin, long ybin, long xbin, long tbin)
{
  long ne, nu, nc, nm, nl, nr, nz, ny, nx, nt, nmax, idx;

  /* Get number of bins */
  
  ne = (long)RDB[det + DET_N_EBINS];
  nu = (long)RDB[det + DET_N_UBINS];
  nc = (long)RDB[det + DET_N_CBINS];
  nm = (long)RDB[det + DET_N_MBINS];
  nl = (long)RDB[det + DET_N_LBINS];
  nr = (long)RDB[det + DET_N_RBINS];
  nt = (long)RDB[det + DET_N_TBINS];
  nz = (long)RDB[det + DET_MESH_NZ];
  ny = (long)RDB[det + DET_MESH_NY];
  nx = (long)RDB[det + DET_MESH_NX];
      
  /* Check bins */
  
  if ((ebin < 0) || (ebin > ne))
    Die(FUNCTION_NAME, "Invalid ebin");
  if ((ubin < 0) || (ubin > nu))
    Die(FUNCTION_NAME, "Invalid ubin");
  if ((cbin < 0) || (cbin > nc))
    Die(FUNCTION_NAME, "Invalid cbin");
  if ((mbin < 0) || (mbin > nm))
    Die(FUNCTION_NAME, "Invalid mbin");
  if ((lbin < 0) || (lbin > nl))
    Die(FUNCTION_NAME, "Invalid lbin");
  if ((rbin < 0) || (rbin > nr))
    Die(FUNCTION_NAME, "Invalid rbin");
  if ((zbin < 0) || (zbin > nz))
    Die(FUNCTION_NAME, "Invalid zbin");
  if ((ybin < 0) || (ybin > ny))
    Die(FUNCTION_NAME, "Invalid ybin");
  if ((xbin < 0) || (xbin > nx))
    Die(FUNCTION_NAME, "Invalid xbin");
  if ((tbin < 0) || (tbin > ny))
    Die(FUNCTION_NAME, "Invalid tbin");
  
  /* Calculate index */
  
  nmax = 1;
  idx = 0;
  
  idx = idx + ebin*nmax;
  nmax = nmax*ne;
  
  idx = idx + ubin*nmax;
  nmax = nmax*nu;
  
  idx = idx + cbin*nmax;
  nmax = nmax*nc;
  
  idx = idx + mbin*nmax;
  nmax = nmax*nm;
  
  idx = idx + lbin*nmax;
  nmax = nmax*nl;
  
  idx = idx + rbin*nmax;
  nmax = nmax*nr;
  
  idx = idx + zbin*nmax;
  nmax = nmax*nz;
  
  idx = idx + ybin*nmax;
  nmax = nmax*ny;
  
  idx = idx + xbin*nmax;
  nmax = nmax*nx;
  
  idx = idx + tbin*nmax;
  nmax = nmax*nt;

  /* Check index */

  if ((idx < 0) || (idx > (long)RDB[det + DET_N_TOT_BINS]))
    Die(FUNCTION_NAME, "Error in idx");

  /* Return index */

  return idx;
}

/*****************************************************************************/
