/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : readpbgeometry.c                               */
/*                                                                           */
/* Created:       2010/10/22 (JLe)                                           */
/* Last modified: 2012/01/17 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Reads explicit stochastic geometry                           */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ReadPBGeometry:"

/*****************************************************************************/

void ReadPBGeometry()
{  
  long pbl, loc0, loc1, msh, nx, ny, nz;
  double x, y, z, r, xmin, xmax, ymin, ymax, zmin, zmax, rmax;
  char uni[MAX_STR];
  FILE *fp;

  /* Check pointer */

  if ((loc0 = (long)RDB[DATA_PTR_PB0]) < 0)
    return;
  
  fprintf(out, "Reading pebble bed type geometry:\n\n");
  
  /* Loop over definitions */
  
  while (loc0 > 0)
    {
      /* Test file format */
      
      TestDOSFile(GetText(loc0 + PBED_PTR_FNAME));
      
      /* Open file for reading */
      
      if ((fp = fopen(GetText(loc0 + PBED_PTR_FNAME), "r")) == NULL)
	Error(loc0, "PB geometry file \"%s\" does not exist",
	      GetText(loc0 + PBED_PTR_FNAME));
      else
	fprintf(out, "Reading data from file \"%s\"...\n",
	       GetText(loc0 + PBED_PTR_FNAME));

      /* Reset limiting values */
      
      xmin =  INFTY;
      xmax = -INFTY;
      ymin =  INFTY;
      ymax = -INFTY;
      zmin =  INFTY;
      zmax = -INFTY;
      
      rmax = 0.0;
      
      /* Reset pointer */
      
      loc1 = NULLPTR;
      
      /* Loop over file */
      
      while (fscanf(fp, "%lf %lf %lf %lf %s\n", &x, &y, &z, &r, uni) != EOF)
	{
	  /* Update counter */

	  WDB[loc0 + PBED_N_PEBBLES] = RDB[loc0 + PBED_N_PEBBLES] + 1.0;

	  /* Create new pebble */

	  pbl = NewItem(loc0 + PBED_PTR_PEBBLES, PEBBLE_BLOCK_SIZE);
	  
	  /* Set values */

	  WDB[pbl + PEBBLE_X0] =  x;
	  WDB[pbl + PEBBLE_Y0] = y;
	  WDB[pbl + PEBBLE_Z0] = z;

	  WDB[pbl + PEBBLE_RAD] = r;
	  WDB[pbl + PEBBLE_PTR_UNIV] = (double)PutText(uni);
	  
	  /* Compare to limiting values */
	  
	  if (x + r > xmax)
	    xmax = x + r;
	  if (x - r < xmin)
	    xmin = x - r;
	  if (y + r > ymax)
	    ymax = y + r;
	  if (y - r < ymin)
	    ymin = y - r;
	  if (z + r > zmax)
	    zmax = z + r;
	  if (z - r < zmin)
	    zmin = z - r;
	  if (r > rmax)
	    rmax = r;
	}
      
      /* Calculate mesh size */
      
      nx = (long)(xmax - xmin)/(2.0*rmax);
      ny = (long)(ymax - ymin)/(2.0*rmax);
      nz = (long)(zmax - zmin)/(2.0*rmax);
      
      /* Check cut-offs */
      
      if (nx < 5)
	nx = 5;
      else if (nx > 500)
	nx = 500;
      
      if (ny < 5)
	ny = 5;
      else if (ny > 500)
	ny = 500;
      
      if (nz < 5)
	nz = 5;
      else if (nz > 500)
	nz = 500;

      /* Create mesh */
      
      msh = CreateMesh(MESH_TYPE_CARTESIAN, MESH_CONTENT_PTR, nx, xmin, xmax,
		       ny, ymin, ymax, nz, zmin, zmax);

      /* Put pointer */

      WDB[loc0 + PBED_PTR_MESH] = (double)msh;

      /* Close file */
      
      fclose(fp);
    
      /* Next geometry */

      loc0 = NextItem(loc0);
    }

  /* Done */

  fprintf(out, "\n");
}

/*****************************************************************************/
