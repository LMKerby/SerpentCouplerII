/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : setprecursorgroups.c                           */
/*                                                                           */
/* Created:       2011/08/31 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Sets global precursor group structure                        */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "SetPrecursorGroups:"

/*****************************************************************************/

void SetPrecursorGroups()
{
  long nuc, ace, ptr, ng;

  /* Loop over nuclides */

  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Set initial composition flag */

      if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_INITIAL)
	{
	  /* Pointer to ACE data */

	  ace = (long)RDB[nuc + NUCLIDE_PTR_ACE];

	  /* Pointer to NXS array */

	  ptr = (long)ACE[ace + ACE_PTR_NXS];

	  /* Get number of groups */

	  ng = (long)ACE[ptr + 7];
	  
	  /* Check number */

	  if ((ng == 6) || (ng == 8))
	    {
	      /* Set number of groups */

	      WDB[DATA_PRECURSOR_GROUPS] = (double)ng;

	      /* Break loop */

	      break;
	    }
	}

      /* Next nuclide */

      nuc = NextItem(nuc);
    }
}

/*****************************************************************************/
