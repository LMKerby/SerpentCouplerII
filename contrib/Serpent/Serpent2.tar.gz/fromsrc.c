/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : fromsrc.c                                      */
/*                                                                           */
/* Created:       2011/03/10 (JLe)                                           */
/* Last modified: 2011/11/14 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Retrieves neutron from souce                                 */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "FromSrc:"

/*****************************************************************************/

long FromSrc(long id)
{
  long ptr, pts;
  unsigned long seed;
  
  /* Check simulation mode */
    
  if ((long)RDB[DATA_SIMULATION_MODE] != SIMULATION_MODE_CRIT)
    Die(FUNCTION_NAME, "Invalid simulation mode");
    
#ifdef OPEN_MP
#pragma omp critical
#endif
  
  {
    /* Get pointer to source distribution */
  
    ptr = (long)RDB[DATA_PART_PTR_SRC_READ];
    CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

    /* Get pointer to last item */
    
    ptr = LastItem(ptr);
    
    /* Check type */
    
    if ((long)RDB[ptr + PARTICLE_TYPE] == PARTICLE_TYPE_DUMMY)
      ptr = -1;
    else if ((long)RDB[ptr + PARTICLE_TYPE] != PARTICLE_TYPE_NEUTRON)
      Die(FUNCTION_NAME, "Invalid particle type");
    else
      {
	/* Remove particle from source */
	
	RemoveItem(ptr);
      }
  }

  /* Check pointer */

  if (ptr > VALID_PTR)
    {
      /* Init random number sequence */
      
      seed = ReInitRNG((long)RDB[ptr + PARTICLE_IDX]);
      
      /* Put seed in private data */
      
      pts = (long)RDB[DATA_PTR_RNG_SEED];
      PutPrivateData(pts, seed, id);
      
      /* Put neutron in que */
      
      ToQue(ptr, id);   
    }

  /* Return pointer */
  
  return ptr;
}

/*****************************************************************************/
