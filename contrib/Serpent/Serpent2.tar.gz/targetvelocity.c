/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : targetvelocity.c                               */
/*                                                                           */
/* Created:       2011/02/28 (JLe)                                           */
/* Last modified: 2011/11/15 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Samples velocity of target nuclide with or withoutd DBRC     */
/*                                                                           */
/* Comments: - From Serpent 1.1.14 (15.11.2010)                              */
/*                                                                           */
/*           - DBRC methodology based on reference:                          */
/*                                                                           */
/*             B. Becker, R. Dagan and G. Lohnert. "Proof and implementation */
/*             of the stochastic formula for ideal gas, energy dependent     */
/*             scattering kernel." Ann. Nucl. Energy, 36 (2009) 470-474.     */
/*                                                                           */
/*           - Routine uses 400*kT as the threshold value for compatibility  */
/*             with MCNP. Dagan defines the limit to 210 eV, which has a     */
/*             noticeable impact on the results.                             */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "TargetVelocity:"

#define FREEGAS_THRESHOLD  400.0

/*****************************************************************************/

void TargetVelocity(long rea, double E0, double *Vx, double *Vy, double *Vz,
		    double u, double v, double w, double kT, long id)
{
  double awr, V, ar, ycn, r1, z2, rnd1, rnd2, s, z, c, x2, E, max, xs;
  long ptr, nuc, ncol;

  /* Check reaction pointer */

  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

  /* Get pointer to nuclide */
  
  nuc = (long)RDB[rea + REACTION_PTR_NUCLIDE];
  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

  /* Get atomic weight ratio */

  awr = RDB[nuc + NUCLIDE_AWR];

  ar = awr/kT;
  ycn = sqrt(E0*ar);
  
  /* Get collision number */

  ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
  ncol = (long)GetPrivateData(ptr, id);

  /* Check if velocity is already sampled for this collision */

  if ((z2 = TestValuePair(nuc + NUCLIDE_PREV_COL_Z2, ncol, id)) > 0.0)
    {
      /* Get cosine */

      c = TestValuePair(nuc + NUCLIDE_PREV_COL_COS, ncol, id);

      /* Rotate direction cosines */
      
      AziRot(c, &u, &v, &w, id);
      
      /* Calculate velocity components */
      
      V = sqrt(z2/ar);
      
      *Vx =  u*V;
      *Vy =  v*V;
      *Vz =  w*V;

      /* Check (tohon jotkut järkevämmät rajat) */

      CheckValue(FUNCTION_NAME, "Vx", "", *Vx, -INFTY, INFTY);
      CheckValue(FUNCTION_NAME, "Vy", "", *Vy, -INFTY, INFTY);
      CheckValue(FUNCTION_NAME, "Vz", "", *Vz, -INFTY, INFTY);

      /* Exit subroutine */

      return;
    }

  /* Reset DBRC maximum cross section */

  max = 0.0;

  /* Check if dbrc is used and get maximum cross section */

  if ((long)RDB[DATA_USE_DBRC] == YES)
    if ((ptr = (long)RDB[rea + REACTION_PTR_0K_MAJORANT]) > VALID_PTR)
      if ((E0 > RDB[DATA_DBRC_EMIN]) && (E0 < RDB[DATA_DBRC_EMAX]))
	max = MajorantXS(ptr, E0, id);
  
  /* Compare to free-gas threshold criteria */

  if ((max == 0.0) && (E0 > FREEGAS_THRESHOLD*kT) && (awr > 1.0))
    {
      /* Target velocity insignificant, set components to zero */

      *Vx = 0.0;
      *Vy = 0.0;
      *Vz = 0.0;

      /* Exit subroutine */

      return;
    }
  
  /* Rejection sampling loop */

  while(1 != 2)
    {
      /***********************************************************************/

      /***** Rejection by target velocity ************************************/
      
      /* Algorithm copied from MCNP5 tgtvel subroutine. Samples target  */
      /* energy z2/ar and cosine c between target and neutron velocity. */
            
      do
	{
	  if (RandF(id)*(ycn + 1.12837917) > ycn)
	    {
	      r1 = RandF(id);
	      z2 = -log(r1*RandF(id));
	    }
	  else
	    {
	      do 
		{
		  rnd1 = RandF(id);
		  rnd2 = RandF(id);
		  
		  r1 = rnd1*rnd1;
		  s = r1 + rnd2*rnd2;
		}
	      while (s > 1.0);
	      
	      z2 = -r1*log(s)/s - log(RandF(id));
	    }
	  
	  z = sqrt(z2);
	  c = 2.0*RandF(id) - 1.0;
	  
	  x2 = ycn*ycn + z2 - 2*ycn*z*c;
	  
	  rnd1 = RandF(id)*(ycn + z);
	}
      while (rnd1*rnd1 > x2);

      /* Break loop if no DBRC */

      if (max == 0.0)
	break;

      /***********************************************************************/

      /***** Doppler-broadening rejection correction *************************/

      /* Energy relative to target nuclide */

      E = x2/ar;

      /* Get pointer to zero kelvin data */
	    
      ptr = (long)RDB[rea + REACTION_PTR_0K_REA];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Get zero kelvin cross section */

      xs = MicroXS(ptr, E, id);

      /* Add to total count */

      ptr = (long)RDB[DATA_PTR_DBRC_COUNT];
      CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
      AddPrivateData(ptr, 1.0, id);

      /* Check value and add error count */

      if (xs > max)
	{
	  ptr = (long)RDB[DATA_PTR_DBRC_EXCEED_COUNT];
	  CheckPointer(FUNCTION_NAME, "(ptr)", PRIVA_ARRAY, ptr);
	  AddPrivateData(ptr, 1.0, id);
	}

      /* Sample (voiko tää jäädä ikuiseen luuppiin?) */

      if (RandF(id) < xs/max)
	break;

      /***********************************************************************/
    }
  
  /* Rotate direction cosines */
  
  AziRot(c, &u, &v, &w, id);

  /* Calculate velocity components */

  V = sqrt(z2/ar);

  *Vx =  u*V;
  *Vy =  v*V;
  *Vz =  w*V;
}

/*****************************************************************************/
