/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : printcycleoutput.c                             */
/*                                                                           */
/* Created:       2011/04/03 (JLe)                                           */
/* Last modified: 2012/01/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Prints cycle-wise data & info to standard output             */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "PrintCycleOutput:"

/*****************************************************************************/

void PrintCycleOutput()
{
  long i, cycles, skip, pop, ptr;
  double estimt, tott;
  char tmpstr[MAX_STR];

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* Get cycle index, number of cycles and population */
  
  i = (long)RDB[DATA_CYCLE_IDX] + 1;
  skip = (long)RDB[DATA_SKIP];
  cycles = (long)RDB[DATA_CYCLES];
  pop = (long)RDB[DATA_NBATCH];

  /* Get estimater running time */

  EstimateRuntime();
  
  estimt = RDB[DATA_ESTIM_CYCLE_TIME];
  tott = RDB[DATA_ESTIM_TOT_TIME];

  /***************************************************************************/
	 
  /***** Print inactive cycle output *****************************************/

  if (i < (long)RDB[DATA_SKIP] + 1)
    fprintf(out, "Inactive cycle %3ld / %3ld: k-eff = %1.5f\n", i, skip,
	   RDB[DATA_CYCLE_KEFF]);

  /***************************************************************************/

  /***** Print active cycle output *******************************************/

  if (((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT) &&
      (i == (long)RDB[DATA_SKIP] + 1))
    fprintf(out, "\n----- Begin active cycles -----\n\n");

  if (i > (long)RDB[DATA_SKIP])
    {    
      fprintf(out, "------------------------------------------------------------\n");

      fprintf(out, "\nSerpent %s", CODE_VERSION);

      if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT)
	fprintf(out, " -- Neutron criticality source simulation\n");
      else
	fprintf(out, " -- Neutron external source simulation\n");

      if ((long)RDB[DATA_PTR_TITLE] > VALID_PTR)
	fprintf(out, "\nTitle: \"%s\"\n", GetText(DATA_PTR_TITLE));
      else
	fprintf(out, "\nInput file: \"%s\"\n", GetText(DATA_PTR_INPUT_FNAME));

      if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_INT_BURN)
	{
	  fprintf(out, "\nTransport calculation: step = %ld / %ld ", 
		 (long)RDB[DATA_BURN_STEP] + 1, 
		 (long)RDB[DATA_BURN_TOT_STEPS] + 1);
	  
	  if ((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_NONE)
	    fprintf(out, "\n");
	  else if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
	    fprintf(out, "(predictor)\n");
	  else
	    fprintf(out, "(corrector)\n");
	  
	  if (RDB[DATA_INI_FMASS] > 0.0)
	    fprintf(out, "                       BU   = %1.2f MWd/kgU\n", 
		   RDB[DATA_BURN_CUM_BURNUP]);
	  
	  if (RDB[DATA_BURN_CUM_BURNTIME] == 0.0)    
	    fprintf(out, "                       time = 0.00 days\n");
	  else
	    fprintf(out, "                       time = %s\n", 
		   TimeIntervalStr(RDB[DATA_BURN_CUM_BURNTIME]));
	}

      if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT)
	fprintf(out, "\nActive cycle %4ld / %ld  Source neutrons : %5ld\n\n", 
		   i - skip, cycles, (long)RDB[DATA_CYCLE_BATCH_SIZE]);
      else
	fprintf(out, "\nSource batch %2ld / %ld (%ld neutrons per batch)\n\n", 
		   i, cycles, pop);
	      
      
      /* Print running time */
      
      fprintf(out, "Running time :                %9s\n", 
	     TimeStr((long)TimerVal(TIMER_RUNTIME)));

      if (tott > 0.0)
	{
	  if (TimerVal(TIMER_TRANSPORT_ACTIVE) > 2.0)
	    {
	      strcpy(tmpstr, TimeStr((long)tott));
	      fprintf(out, "Estimated running time :      %9s %9s\n", 
		     TimeStr((long)estimt), tmpstr);

	      strcpy(tmpstr, TimeStr((long)(tott- TimerVal(TIMER_RUNTIME))));
	      fprintf(out, "Estimated running time left : %9s %9s\n", 
		     TimeStr((long)(estimt - TimerVal(TIMER_RUNTIME))),
		     tmpstr);
	    }
	  else
	    {
	      fprintf(out, "Estimated running time :        -:--:--   -:--:--\n");
	      fprintf(out, "Estimated running time left :   -:--:--   -:--:--\n");
	    }
	}
      else
	{
	  if (TimerVal(TIMER_TRANSPORT_ACTIVE) > 2.0)
	    {
	      fprintf(out, "Estimated running time :      %9s\n", 
		     TimeStr((long)estimt));
	      fprintf(out, "Estimated running time left : %9s\n", 
		     TimeStr((long)(estimt - TimerVal(TIMER_RUNTIME))));
	    }
	  else
	    {
	      fprintf(out, "Estimated running time :        -:--:--\n");
	      fprintf(out, "Estimated running time left :   -:--:--\n");
	    }
	}

      fprintf(out, "\nEstimated relative CPU usage : %7.1f%%\n", 
	     100.0*TimerCPUVal(TIMER_TRANSPORT_CYCLE)/
	     TimerVal(TIMER_TRANSPORT_CYCLE));

      /* K-eff estimates */

      if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC)
	{
	  /* Don't print if no fissions */
	  /*
	  if ((long)RDB[DATA_REA_FISS_N] > 0)
	  */  

	  if (RDB[DATA_INI_FMASS] > 0.0)
	    {
	    ptr = (long)RDB[RES_ANA_KEFF];
	    fprintf(out, "\nk-eff (analog)   = %1.5f +/- %1.5f  [%1.5f  %1.5f]\n",
		   Mean(ptr, 0), StdDev(ptr, 0),
		   Mean(ptr, 0) - 1.96*StdDev(ptr, 0),
		   Mean(ptr, 0) + 1.96*StdDev(ptr, 0));
	      /*
		ptr = (long)RDB[RES_EXT_KEFF];
	      fprintf(out, "k0    (source)   = %1.5f +/- %1.5f  [%1.5f  %1.5f]\n",
		     Mean(ptr, 0), 
		     StdDev(ptr, 0),
		     Mean(ptr, 0) - 1.96*StdDev(ptr, 0),
		     Mean(ptr, 0) + 1.96*StdDev(ptr, 0));
	      */
	    }
	}
      else
	{
	  ptr = (long)RDB[RES_ANA_KEFF];
	  fprintf(out, "\nk-eff (analog)    = %1.5f +/- %1.5f  [%1.5f  %1.5f]\n",
		 Mean(ptr, 0), StdDev(ptr, 0),
		 Mean(ptr, 0) - 1.96*StdDev(ptr, 0),
		 Mean(ptr, 0) + 1.96*StdDev(ptr, 0));
	  
	  if ((long)RDB[DATA_OPTI_IMPLICIT_RR] == YES)
	    {
	      ptr = (long)RDB[RES_IMP_KEFF];
	      fprintf(out, "k-eff (implicit)  = %1.5f +/- %1.5f  [%1.5f  %1.5f]\n",
		     Mean(ptr, 0), StdDev(ptr, 0),
		     Mean(ptr, 0) - 1.96*StdDev(ptr, 0),
		     Mean(ptr, 0) + 1.96*StdDev(ptr, 0));
	    }
	  else
	    {
	      ptr = (long)RDB[RES_COL_KEFF];
	      fprintf(out, "k-eff (collision) = %1.5f +/- %1.5f  [%1.5f  %1.5f]\n",
		     Mean(ptr, 0), StdDev(ptr, 0),
		     Mean(ptr, 0) - 1.96*StdDev(ptr, 0),
		     Mean(ptr, 0) + 1.96*StdDev(ptr, 0));
	    }
	}

      fprintf(out, "\n");

      /* Options */

      fprintf(out, "Options : ");

#ifdef DEBUG

      fprintf(out, "(DBG) ");

#endif

      if ((long)RDB[DATA_OPTI_REPLAY] == YES)
	fprintf(out, "(R) ");

      fprintf(out, "(O%ld) ", (long)RDB[DATA_OPTI_MODE]);

      if ((long)RDB[DATA_OPT_USE_DT] == YES)
	fprintf(out, "(DT) ");
      else
	fprintf(out, "(TLE) ");

      if ((long)RDB[DATA_OPT_IMPL_CAPT] == YES)
	fprintf(out, "(IC) ");

      if ((long)RDB[DATA_OPT_IMPL_NXN] == YES)
	fprintf(out, "(IX) ");

      if ((long)RDB[DATA_OPT_IMPL_FISS] == YES)
	fprintf(out, "(IF) ");

      if ((long)RDB[DATA_USE_URES] == YES)
	fprintf(out, "(UNR) ");

      if ((long)RDB[DATA_USE_DBRC] == YES)
	fprintf(out, "(DBRC) ");

      if ((long)RDB[DATA_USE_TFB] == YES)
	fprintf(out, "(TFB) ");
      else if ((long)RDB[DATA_DOPPLER_MODE] > 0)
	fprintf(out, "(DOP%ld) ", (long)RDB[DATA_DOPPLER_MODE]);
      
#ifdef MPI
      
      fprintf(out, "(MPI=%d) ", mpitasks);
      
#endif
      
#ifdef OPEN_MP

      fprintf(out, "(OMP=%ld) ", (long)RDB[DATA_OMP_MAX_THREADS]);

#endif
      
      if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_INT_BURN)
	{
	  if ((long)RDB[DATA_BURN_PRED_TYPE] == PRED_TYPE_CONSTANT)
	    fprintf(out, "(CE");
	  else
	    fprintf(out, "(LE");

	  if ((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_LINEAR)
	    fprintf(out, "/LI");
	  else if ((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_QUADRATIC)
	    fprintf(out, "/QI");

	  if (((long)RDB[DATA_BURN_PRED_NSS] > 1) && 
	      ((long)RDB[DATA_BURN_CORR_NSS] < 1))
	    fprintf(out, " + %ld SS) ", (long)RDB[DATA_BURN_PRED_NSS]);
	  else if (((long)RDB[DATA_BURN_PRED_NSS] == 1) && 
		   ((long)RDB[DATA_BURN_CORR_NSS] > 1))
	    fprintf(out, " + %ld SS) ", (long)RDB[DATA_BURN_CORR_NSS]);
	  else if (((long)RDB[DATA_BURN_PRED_NSS] > 1) && 
		   ((long)RDB[DATA_BURN_CORR_NSS] > 1))
	    fprintf(out, " + %ld/%ld SS) ", (long)RDB[DATA_BURN_PRED_NSS],
		   (long)RDB[DATA_BURN_CORR_NSS]);
	  else
	    fprintf(out, ") ");
	}

      fprintf(out, "\n");

      fprintf(out, "------------------------------------------------------------\n");
    }

  /***************************************************************************/



  /* Tää sinne collectparalleldataan, tms */










  /***** Maximum number of cycles reached ************************************/

  if (i == cycles + skip)
    {
      if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_CRIT)
	{
	  fprintf(out, "\nFinished after %ld active ", cycles);
	  fprintf(out, "cycles of %ld source neutrons.\n", pop);
	  fprintf(out, "Total calculation time %1.2f minutes.\n\n", 
		 TimerVal(TIMER_RUNTIME)/60.0);
	}
      else
	{
	  fprintf(out, "\nFinished after %ld neutron histories ", cycles*pop);
	  fprintf(out, "divided into\n%ld source batches. ", cycles);
	  fprintf(out, "Total calculation time %1.2f minutes.\n\n", 
	     TimerVal(TIMER_RUNTIME)/60.0);
      	}
    }
  
  /***************************************************************************/
}

/*****************************************************************************/
