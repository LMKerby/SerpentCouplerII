/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : nextlistrea.c                                  */
/*                                                                           */
/* Created:       2011/07/17 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Returns pointer to next reaction in list                     */
/*                                                                           */
/* Comments: - Used when reaction lists are not actually defined             */ 
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "NextListRea:"

/*****************************************************************************/

long NextListRea(long mat, long mode, long *iso, long *rea)
{
  long nuc, ures, mt, ty, ptr;

  /* Check material pointer */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /***** Special types *******************************************************/

  /* NOTE: Nää on myös tuolla alempana, mutta tää on uusi implementaatio */

  /* Total cross section */
  
  if (mode == MATERIAL_PTR_TOT_REA_LIST)
    {
      /* Get pointer to next transport nuclide */

      while (1 != 2)
	{
	  /* Get pointer to first nuclide if nuclide is not given */
	  
	  if (*iso < VALID_PTR)
	    *iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	  else
	    *iso = NextItem(*iso);

	  /* Check pointer */

	  if (*iso < VALID_PTR)
	    return -1;

	  /* Pointer to nuclide data */
	  
	  nuc = (long)RDB[*iso + COMPOSITION_PTR_NUCLIDE];

	  /* Check type */

	  if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT)
	    break;
	}

      /* Check nuclide pointer */

      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
      
      /* Return pointer */

      ptr = (long)RDB[nuc + NUCLIDE_PTR_TOTXS];
      return ptr;
    }

  /***************************************************************************/

  /* Avoid compiler warning */

  nuc = -1;

  /* Loop over composition */

  while (1 != 2)
    {
      /***********************************************************************/

      /***** Update nuclide and reaction pointer *****************************/

      /* Check if first reaction or get pointer to next */
      
      if (*iso < VALID_PTR)
	{
	  /* Get pointer to first nuclide in composition */
	  
	  *iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	  CheckPointer(FUNCTION_NAME, "(iso)", DATA_ARRAY, *iso);

	  /* Pointer to nuclide data */
	  
	  nuc = (long)RDB[*iso + COMPOSITION_PTR_NUCLIDE];

	  /* Check type */

	  if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT) ||
	      ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_SAB) ||
	      ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_PHOTON))
	    {
	      /* Pointer to reaction data */
	      
	      *rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
	      CheckPointer(FUNCTION_NAME, "(rea1)", DATA_ARRAY, *rea);
	    }
	  else
	    *rea = -1;
	}
      else if (*rea < VALID_PTR)
	{
	  /* Pointer to next nuclide */
	  
	  if ((*iso = NextItem(*iso)) < VALID_PTR)
	    {
	      /* No more reactions, put null pointer */
	  
	      *rea = -1;

	      /* Exit subroutine */
	      
	      return -1;
	    }

	  /* Pointer to nuclide data */
	  
	  nuc = (long)RDB[*iso + COMPOSITION_PTR_NUCLIDE];

	  /* Check type */

	  if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT) ||
	      ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_SAB) ||
	      ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_PHOTON))
	    {
	      /* Pointer to reaction data */

	      *rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
	      CheckPointer(FUNCTION_NAME, "(rea2)", DATA_ARRAY, *rea);	      
	    }
	  else
	    *rea = -1;
	}
      else
	{
	  /* Pointer to nuclide data */
	  
	  nuc = (long)RDB[*iso + COMPOSITION_PTR_NUCLIDE];

	  /* Next reaction */

	  *rea = NextItem(*rea);
	}
      
      /* Set pointer to null if not partial type */
      
      if (*rea > VALID_PTR)
	if ((long)RDB[*rea + REACTION_TYPE] != REACTION_TYPE_PARTIAL)
	  *rea = -1;

      /* Check nuclide data */

      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

      /* Get ures-flag */

      ures = ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_URES_USED);
      
      /***********************************************************************/

      /***** Check special reaction types ************************************/

      /* Check data type */

      if ((long)RDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_PHOTON)
	{
	  /* Total cross section */

	  if (mode == MATERIAL_PTR_TOT_REA_LIST)
	    {
	      *rea = -1;
	  
	      if ((ptr = (long)RDB[nuc + NUCLIDE_PTR_TOTXS]) > VALID_PTR)
		return ptr;
	    }
	  
	  /* Total for ures data */
      
	  if (mode == MATERIAL_PTR_TOT_URES_LIST)
	    {
	      *rea = -1;	
	      
	      if (ures && 
		  (ptr = (long)RDB[nuc + NUCLIDE_PTR_TOTXS]) > VALID_PTR)
		return ptr;
	    }
	  
	  /* Elastic for ures data */
	  
	  if (mode == MATERIAL_PTR_ELA_URES_LIST)
	    {
	      *rea = -1;
	      
	      if (ures && 
		  (ptr = (long)RDB[nuc + NUCLIDE_PTR_ELAXS]) > VALID_PTR)
		return ptr;
	    }
	  
	  /* Capture for ures data */
	  
	  if (mode == MATERIAL_PTR_ABS_URES_LIST)
	    {
	      *rea = -1;
	      
	      if (ures && 
		  (ptr = (long)RDB[nuc + NUCLIDE_PTR_NGAMMAXS]) > VALID_PTR)
		return ptr;
	    }
	  
	  /* Fission for ures data */
	  
	  if (mode == MATERIAL_PTR_FISS_URES_LIST) 
	    {
	      *rea = -1;	
	      
	      if (ures && 
		  (ptr = (long)RDB[nuc + NUCLIDE_PTR_FISSXS]) > VALID_PTR)
		return ptr;
	    }
	}
      else
	{
	  /* Photon total xs */
	  
	  if (mode == MATERIAL_PTR_PHOT_TOT_LIST)
	    {
	      *rea = -1;
	      
	      if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_PHOTON) &&
		  ((ptr = (long)RDB[nuc + NUCLIDE_PTR_TOTXS]) > VALID_PTR))
		return ptr;
	    }
	  
	  /* Photon heating xs */
	  
	  if (mode == MATERIAL_PTR_PHOT_HEAT_LIST)
	    {
	      *rea = -1;
	      
	      if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_PHOTON) &&
		  ((ptr = (long)RDB[nuc + NUCLIDE_PTR_PHOTON_HEATPRODXS]) 
		   > VALID_PTR))
		return ptr;
	    }
	}
      
      /***********************************************************************/
      
      /***** Partial reactions ***********************************************/
      
      if ((*rea > VALID_PTR) && 
	  ((long)RDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_PHOTON))
	{
	  /* Get mt and ty */
	  
	  mt = (long)RDB[*rea + REACTION_MT];
	  ty = (long)RDB[*rea + REACTION_TY];
	  
	  /* Absorption */
	  
	  if (mode == MATERIAL_PTR_ABS_REA_LIST)  
	    if (ty == 0)
	      return *rea;	    
	      
	  /* Elastic */
	  
	  if (mode == MATERIAL_PTR_ELA_REA_LIST)
	    if ((mt == 2) || (mt == 1002) || (mt == 1004))
	      return *rea;
		  
	  /* Fission */
	  
	  if (mode == MATERIAL_PTR_FISS_REA_LIST)
	    if (((mt > 17) && (mt < 22)) || (mt == 38))
	      return *rea;
	  
	  /* Inelastic scattering multiplication */
	  
	  if (mode == MATERIAL_PTR_NUXN_REA_LIST)
	    if ((ty != 0) && (ty != 19) && (mt != 2) && (mt != 1002) && 
		(mt != 1004))
	      return *rea;
	}
      
      /***********************************************************************/
    }
}

/*****************************************************************************/
