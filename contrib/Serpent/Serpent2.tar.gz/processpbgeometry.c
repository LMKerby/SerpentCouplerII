/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processbgeometry.c                             */
/*                                                                           */
/* Created:       2010/11/09 (JLe)                                           */
/* Last modified: 2012/01/17 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Processes explicit stochastic geometry                       */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessPBGeometry:"

/*****************************************************************************/

void ProcessPBGeometry()
{  
  long pbl, loc0, loc1, loc2, ptr, nx, ny, nz, i0, j0, k0, i, j, k;
  long i1, j1, k1, nb, pid, msh;
  double x, y, z, r, xmin, xmax, ymin, ymax, zmin, zmax;
  double px, py, pz, dx1, dx2, dy1, dy2, dz1, dz2;

  /* Check pointer */

  if ((loc0 = (long)RDB[DATA_PTR_PB0]) < 0)
    return;
  
  /* Loop over definitions */

  while (loc0 > VALID_PTR)
    {
      /* Pointer to mesh */

      msh = (long)RDB[loc0 + PBED_PTR_MESH];
      CheckPointer(FUNCTION_NAME, "(msh)", DATA_ARRAY, msh);

      /* Get mesh boundaries */
      
      xmin = RDB[msh + MESH_MIN0];
      xmax = RDB[msh + MESH_MAX0];
      ymin = RDB[msh + MESH_MIN1];
      ymax = RDB[msh + MESH_MAX1];
      zmin = RDB[msh + MESH_MIN2];
      zmax = RDB[msh + MESH_MAX2];

      /* Get mesh size */

      nx = (long)RDB[msh + MESH_N0];
      ny = (long)RDB[msh + MESH_N1];
      nz = (long)RDB[msh + MESH_N2];
      
      /* Calculate pitches */

      px = (xmax - xmin)/((double)nx);
      py = (ymax - ymin)/((double)ny);
      pz = (zmax - zmin)/((double)nz);
           
      /* Reset pebble index */

      pid = 0;
      
      /* Allocate memory for collision pointer */

      AllocValuePair(loc0 + PBED_PTR_COL_PEBBLE);

      /* Loop over pebbles */
      
      pbl = (long)RDB[loc0 + PBED_PTR_PEBBLES];      
      while (pbl > VALID_PTR)
	{
	  /* Put pebble index */

	  WDB[pbl + PEBBLE_IDX] = (double)(pid++);

	  /* Get co-ordinates */
	  
	  x = RDB[pbl + PEBBLE_X0];
	  y = RDB[pbl + PEBBLE_Y0];
	  z = RDB[pbl + PEBBLE_Z0];

	  /* Get radius */

	  r = RDB[pbl + PEBBLE_RAD];

	  /* Calculate mesh indexes */
	  
	  i0 = (long)((x - r - xmin)/px);
	  i1 = (long)((x + r - xmin)/px);
	  j0 = (long)((y - r - ymin)/py);
	  j1 = (long)((y + r - ymin)/py);
	  k0 = (long)((z - r - zmin)/pz);
	  k1 = (long)((z + r - zmin)/pz);

	  /* Limit values (NOTE: yläreunojen määrittävät partikkelit */
	  /* pyöristyy reunan yli. */

	  if (i0 < 0)
	    i0 = 0;
	  if (i1 > nx - 1)
	    i1 = nx - 1;

	  if (j0 < 0)
	    j0 = 0;
	  if (j1 > ny - 1)
	    j1 = ny - 1;

	  if (k0 < 0)
	    k0 = 0;
	  if (k1 > nz - 1)
	    k1 = nz - 1;

	  /* Loop over possible cells */
	  
	  for (i = i0; i <= i1; i++)
	    for (j = j0; j <= j1; j++)
	      for (k = k0; k <= k1; k++)
		{
		  /* Calculate distances */

		  dx1 = i*px + xmin - (x + r);
		  dx2 = (i + 1)*px + xmin - (x - r);

		  dy1 = j*py + ymin - (y + r);
		  dy2 = (j + 1)*py + ymin - (y - r);

		  dz1 = k*pz + zmin - (z + r);
		  dz2 = (k + 1)*pz + zmin - (z - r);
		      
		  /* Check */
		  
		  if ((dx1 < 0.0) && (dx2 > 0.0) && 
		      (dy1 < 0.0) && (dy2 > 0.0) && 
		      (dz1 < 0.0) && (dz2 > 0.0))
		    {
		      /* Get pointer to mesh */
		      
		      loc1 = ReadMeshPtr(msh, i, j, k);

		      /* Allocate memory */

		      loc2 = NewItem(loc1, PBED_LIST_BLOCK_SIZE);

		      /* Put pebble pointer */

		      WDB[loc2 + PBED_LIST_PTR_PEBBLE] = (double)pbl;
		    }
		}
	  
	  /* Next pebble */
	  
	  pbl = NextItem(pbl);
	}
      
      /***********************************************************************/

      /***** Allocate memory for power distribution '*************************/

      /* Check if results are requested */

      if ((long)RDB[loc0 + PBED_CALC_RESULTS] == YES)
	{
	  /* Get number of pebbles */

	  nb = (long)RDB[loc0 + PBED_N_PEBBLES];

	  /* Allocate memory */

	  ptr = NewStat("PBED_POW", 1, nb); 
	  WDB[loc0 + PBED_PTR_POW] = (double)ptr;
	}
      
      /***********************************************************************/

      /* Next geometry */

      loc0 = NextItem(loc0);
    }
}

/*****************************************************************************/
