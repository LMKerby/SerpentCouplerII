/*****************************************************************************/

/***** Main data array (direct pointers) *************************************/

/* Data sizes */

#define DATA_ASCII_DATA_SIZE              0
#define DATA_ALLOC_MAIN_SIZE              1
#define DATA_REAL_MAIN_SIZE               3
#define DATA_ALLOC_ACE_SIZE               4
#define DATA_REAL_ACE_SIZE                5
#define DATA_ALLOC_PRIVA_SIZE             6
#define DATA_REAL_PRIVA_SIZE              7
#define DATA_ALLOC_RES1_SIZE              8
#define DATA_REAL_RES1_SIZE               9
#define DATA_ALLOC_RES2_SIZE             10
#define DATA_REAL_RES2_SIZE              11
#define DATA_ALLOC_BUF_SIZE              12
#define DATA_REAL_BUF_SIZE               13

#define DATA_TOTAL_BYTES                 14
#define DATA_REAL_BYTES                  15
#define DATA_BURN_MAT_BYTES              16

/* Cpu name and memory size */

#define DATA_CPU_MEM                     17
#define DATA_PTR_CPU_NAME                18
#define DATA_CPU_MHZ                     19

/* Date */

#define DATA_PTR_DATE                    20

/* Title */

#define DATA_PTR_TITLE                   25

/* CPU time */

#define DATA_CPU_T0                      30
#define DATA_CPU_TIME                    35

/* List pointers */

#define DATA_PTR_S0                     101
#define DATA_PTR_T0                     102
#define DATA_PTR_M0                     103
#define DATA_PTR_NUC0                   104
#define DATA_PTR_ACE0                   105
#define DATA_PTR_DECAY_ACE0             106
#define DATA_PTR_C0                     107
#define DATA_PTR_NST0                   108
#define DATA_PTR_TR0                    109
#define DATA_PTR_GPL0                   110
#define DATA_PTR_MPL0                   111
#define DATA_PTR_PB0                    112
#define DATA_PTR_L0                     113
#define DATA_PTR_USYM0                  114
#define DATA_PTR_LVL0                   115
#define DATA_PTR_SCORE0                 116
#define DATA_PTR_U0                     117
#define DATA_PTR_SRC0                   118
#define DATA_PTR_DET0                   119
#define DATA_PTR_ENE0                   120
#define DATA_PTR_GCU0                   121
#define DATA_PTR_TFB0                   122

/* File names and paths */

#define DATA_PTR_ACEDATA_FNAME_LIST     130
#define DATA_PTR_INPUT_FNAME            131
#define DATA_PTR_DECDATA_FNAME_LIST     132
#define DATA_PTR_NFYDATA_FNAME_LIST     133
#define DATA_PTR_SFYDATA_FNAME_LIST     134
#define DATA_PTR_IBR_FNAME              135

/* Running mode */

#define DATA_RUNNING_MODE               140

/* Stuff for burnup calculation */

#define DATA_BU_SPECTRUM_COLLAPSE       141
#define DATA_BU_MG_EGRID_NE             142
#define DATA_BU_MG_PTR_GRID             143
#define DATA_BU_MG_EGRID_EMIN           144
#define DATA_BU_MG_EGRID_EMAX           145

/* Nuclide counters */

#define DATA_N_TOT_NUCLIDES             150
#define DATA_N_TRANSPORT_NUCLIDES       151
#define DATA_N_DOSIMETRY_NUCLIDES       152
#define DATA_N_DECAY_NUCLIDES           153
#define DATA_N_PHOTON_NUCLIDES          154

/* Geometry level data */

#define DATA_PTR_ROOT_UNIVERSE          160
#define DATA_GEOM_LEVELS                161

/* Geometry dimensions */

#define DATA_GEOM_MINX                  162
#define DATA_GEOM_MAXX                  163
#define DATA_GEOM_MINY                  164
#define DATA_GEOM_MAXY                  165
#define DATA_GEOM_MINZ                  166
#define DATA_GEOM_MAXZ                  167

#define DATA_GEOM_DIM                   168

/* ACE data pointers */

#define DATA_PTR_ACE_NFY_DATA           170
#define DATA_PTR_ACE_SFY_DATA           171

/* Fission product lists. (These are used to find the  */
/* ace data for FP nuclides in CombineFissionYields()) */

#define DATA_TOT_FP_NUCLIDES            180
#define DATA_PTR_FP_LIB_ID_LIST         181
#define DATA_PTR_FP_ZAI_LIST            182

/* Pointer to lost nuclide data */

#define DATA_PTR_NUCLIDE_LOST           185

/* Reaction counters */

#define DATA_N_TRANSPORT_REA            190
#define DATA_N_SPECIAL_REA              191
#define DATA_N_DECAY_REA                192
#define DATA_N_TRANSMUTATION_REA        193
#define DATA_N_TRANSPORT_BRANCH         194
#define DATA_N_DECAY_BRANCH             195
#define DATA_N_DEAD_PATH                196
#define DATA_N_TRANSMUTATION_PATH       197

/* Delayed neutron precursor groups */

#define DATA_PRECURSOR_GROUPS           210

/* Counters */

#define DATA_N_GEOM_PLOTS               220
#define DATA_N_PBED                     225
#define DATA_N_MATERIALS                226

/*
#define DATA_N_CELLS                      0
#define DATA_N_SURFACES                   0
#define DATA_N_UNIVERSES                  0
#define DATA_N_LEVELS                     0

#define DATA_N_DETECTORS                  0
#define DATA_N_DEP                        0
#define DATA_N_MESH_PLOTS                 0
#define DATA_N_ISO                        0
#define DATA_N_TRANSP_ISO                 0
#define DATA_N_DECAY_ISO                  0
#define DATA_N_TOT_REA                    0 
#define DATA_N_BURN_MAT                   0
#define DATA_N_TRANSMU_REA                0
*/

/* Global and unionized energy grid data */

#define DATA_ERG_TOL                    242
#define DATA_ERG_INITIAL_PTS            243
#define DATA_ERG_IMPORTANT_PTS          244
#define DATA_ERG_PTR_UNIONIZED_GRID     245
#define DATA_ERG_PTR_UNIONIZED_PGRID    246

/* Minimum and maximum energy allowed in transport calculation */

#define DATA_NEUTRON_EMIN               247
#define DATA_NEUTRON_EMAX               248

#define DATA_PHOTON_EMIN                249
#define DATA_PHOTON_EMAX                250

#define DATA_NEUTRON_XS_EMIN            251
#define DATA_NEUTRON_XS_EMAX            252

#define DATA_PHOTON_XS_EMIN             253
#define DATA_PHOTON_XS_EMAX             254

/* Minimum macroscopic cross section */

#define DATA_MIN_NMACROXS               255
#define DATA_MIN_PMACROXS               256

/* Boundary condition and albedo */

#define DATA_GEOM_BC0                   257
#define DATA_GEOM_BC1                   258
#define DATA_GEOM_BC2                   259
#define DATA_GEOM_BC3                   260
#define DATA_GEOM_ALBEDO                261

/* Cut-offs */

#define DATA_DEP_TTA_CUTOFF             262
#define DATA_DEP_HALF_LIFE_CUTOFF       263
#define DATA_DEP_FP_YIELD_CUTOFF        264
#define DATA_MIN_TOTXS                  265
#define DATA_URES_DILU_CUT              266

/* Equilibrium Xe-135 calculation */

#define DATA_XE135_DC                   270
#define DATA_I135_DC                    271

/* Warning messages */

#define DATA_WARN_NFY_SUM               280
#define DATA_WARN_SFY_SUM               281
#define DATA_WARN_ERROR_AWR             282
#define DATA_WARN_ERROR_BRANCH          283

/* Dummy variable (used by GetText(), etc.) */

#define DATA_DUMMY                      300

/* Geometry plotter */

#define DATA_STOP_AFTER_PLOT            310
#define DATA_PLOTTER_MODE               311

/* Monte Carlo volume calculation */

#define DATA_VOLUME_MC_NMAX             320
#define DATA_VOLUME_MC_TMAX             321
#define DATA_VOLUME_MC_EMAX             322

/* URES variables */

#define DATA_URES_AVAIL                 327
#define DATA_USE_URES                   328
#define DATA_URES_PTR_USE_LIST          329
#define DATA_URES_USED                  330
#define DATA_URES_EMIN                  331
#define DATA_URES_EMAX                  332

/* DBRC */

#define DATA_USE_DBRC                   335
#define DATA_PTR_DBRC                   336
#define DATA_DBRC_EMIN                  337
#define DATA_DBRC_EMAX                  338
#define DATA_PTR_DBRC_COUNT             339
#define DATA_PTR_DBRC_EXCEED_COUNT      340

/* Normalization */

#define DATA_PTR_NORM                   341
#define DATA_NORM_U235_FISSE            342
#define DATA_NORM_INCLUDE_DH            343
#define DATA_NORM_BURN                  344
#define DATA_INI_FMASS                  345
#define DATA_INI_BURN_FMASS             346
#define DATA_TOT_FMASS                  347
#define DATA_TOT_BURN_FMASS             348

/* Isomeric branching ratio data */

#define DATA_PTR_IBR_LIST               349

/* Majorants */

#define DATA_PTR_MAJORANT               350
#define DATA_PTR_PHOTON_MAJORANT        351

/* Optimization and memory/data options */

#define DATA_OPTI_MODE                  352
#define DATA_OPTI_UNIONIZE_GRID         353
#define DATA_OPTI_MACRO_REA_LISTS       354
#define DATA_OPTI_RECONSTRUCT_MICROXS   355
#define DATA_OPTI_RECONSTRUCT_MACROXS   356
#define DATA_OPTI_INCLUDE_SPECIALS      357
#define DATA_OPTI_MODE0_INCLUDE_TOTAL   358
#define DATA_OPTI_IMPLICIT_RR           359
#define DATA_OPTI_GC_CALC               360
#define DATA_OPTI_MG_MODE               361
#define DATA_OPTI_FUM_CALC              362
#define DATA_OPTI_SHARED_BUF            363
#define DATA_OPTI_SHARED_RES2           364
#define DATA_OPTI_OMP_REPRODUCIBILITY   365
#define DATA_OPTI_REPLAY                366
#define DATA_OPTI_ENTROPY_CALC          367
#define DATA_OPTI_PRINT_HIS             368
#define DATA_OPTI_MPI_REPRODUCIBILITY   369

#define DATA_MPI_TOT_PARTICLES          370

/* Delta-tracking */

#define DATA_OPT_USE_DT                 375
#define DATA_DT_THRESH                  376

/* Implicit Monte Carlo (TODO: ota toi OPT pois nimest�) */

#define DATA_OPT_IMPL_CAPT              380
#define DATA_OPT_IMPL_FISS              381
#define DATA_OPT_IMPL_NXN               382
#define DATA_OPT_ROULETTE_W0            383
#define DATA_OPT_ROULETTE_P0            384

/* Cross section plotter */

#define DATA_XSPLOT_NE                  400
#define DATA_XSPLOT_EMIN                401
#define DATA_XSPLOT_EMAX                402

/* Run parameters */

#define DATA_NBATCH                     410
#define DATA_CYCLES                     411
#define DATA_SKIP                       412
#define DATA_CYCLE_BATCH_SIZE           413
#define DATA_SIMUL_BATCH_SIZE           414
#define DATA_SIMULATION_MODE            415
#define DATA_CYCLE_IDX                  416
#define DATA_SIMULATION_COMPLETED       419
#define DATA_COLLECT_INTERVAL           420

#define DATA_OMP_MAX_THREADS            421
#define DATA_PTR_OMP_HISTORY_COUNT      422

/* Storage space for neutrons and gammas */

#define DATA_PART_PTR_NSTACK            430
#define DATA_PART_PTR_GSTACK            431
#define DATA_PART_PTR_QUE               432
#define DATA_PART_PTR_SRC_READ          433
#define DATA_PART_PTR_SRC_WRITE         434
#define DATA_PART_STACK_SIZE            435

/* Size of history list */

#define DATA_HIST_LIST_SIZE             437

/* Run-time variables */

#define DATA_CYCLE_KEFF                 440
#define DATA_NHIST_CYCLE                442
#define DATA_NHIST_TOT                  443

/* Estimated running times */

#define DATA_ESTIM_CYCLE_TIME           445
#define DATA_ESTIM_TOT_TIME             446

/* Radioactivity data */

#define DATA_TOT_ACTIVITY               450
#define DATA_TOT_SFRATE                 451
#define DATA_TOT_DECAY_HEAT             452
#define DATA_BURN_SFRATE                453
#define DATA_BURN_DECAY_HEAT            454
#define DATA_ACT_ACTIVITY               455
#define DATA_ACT_DECAY_HEAT             456
#define DATA_FP_ACTIVITY                457
#define DATA_FP_DECAY_HEAT              458

/* Group constant generation */

#define DATA_ERG_FG_NG                  460
#define DATA_ERG_FG_PTR_GRID            461
#define DATA_GCU_PTR_UNI                464

/* Core power distribution */

#define DATA_CORE_PDE_DEPTH             470
#define DATA_CORE_PDE_NZ                471
#define DATA_CORE_PDE_ZMIN              472
#define DATA_CORE_PDE_ZMAX              473
#define DATA_CORE_PDE_PTR_CORE          474
#define DATA_CORE_PDE_PTR_ASS           475
#define DATA_CORE_PDE_PTR_RES0          476
#define DATA_CORE_PDE_PTR_RES1          477
#define DATA_CORE_PDE_PTR_RES2          478
#define DATA_CORE_PDE_N0                479
#define DATA_CORE_PDE_N1                480
#define DATA_CORE_PDE_N2                481

/* Source biasing */

#define DATA_SBIAS_MODE                 482
#define DATA_SBIAS_PTR_COL_MESH         483
#define DATA_SBIAS_ORD                  484

/* Fission source entropy */

#define DATA_ENTROPY_NX                 486
#define DATA_ENTROPY_NY                 487
#define DATA_ENTROPY_NZ                 488
#define DATA_ENTROPY_XMIN               489
#define DATA_ENTROPY_XMAX               490
#define DATA_ENTROPY_YMIN               491
#define DATA_ENTROPY_YMAX               492
#define DATA_ENTROPY_ZMIN               493
#define DATA_ENTROPY_ZMAX               494
#define DATA_ENTROPY_PTR_SPT_STAT       499
#define DATA_ENTROPY_PTR_SWG_STAT       500

/* Burnup calculation stuff */

#define DATA_BURN_DECAY_CALC            502
#define DATA_BURN_STEP_PC               503
#define DATA_BURN_BUMODE                504
#define DATA_BURN_CRAM_K                505
#define DATA_BURN_STEP                  506
#define DATA_BURN_TIME_INTERVAL         507
#define DATA_BURN_BURNUP_INTERVAL       508
#define DATA_BURN_PTR_DEP               509
#define DATA_BURN_CUM_BURNTIME          510
#define DATA_BURN_CUM_BURNUP            511
#define DATA_BURN_PTR_INVENTORY         512
#define DATA_BURN_INVENTORY_NUCLIDES    513
#define DATA_BURN_PRINT_DEPMTX          514
#define DATA_BURN_ENECUT                515
#define DATA_BURN_TOT_STEPS             516
#define DATA_BURN_PRED_STEP             517
#define DATA_BURN_CORR_STEP             518
#define DATA_BURN_PRINT_COMP            519
#define DATA_BURN_PRINT_COMP_LIM        520
#define DATA_BURN_STEP_TYPE             521

/* Counters needed for burnup calculation */

#define DATA_TOT_NUCLIDES               522
#define DATA_BURN_MATERIALS             523
#define DATA_PRED_TRANSPORT_TIME        524
#define DATA_CORR_TRANSPORT_TIME        525
#define DATA_BURN_MATERIALS_THREAD0     526
#define DATA_MATERIALS_THREAD0          527

/* Fundamental mode calculation */

#define DATA_PTR_FUM                    529
#define DATA_FUM_PTR_EGRID              530
#define DATA_FUM_PTR_IDX_MAP            531

/* lengths of the previous step and preceding predictor (AIs) */

#define DATA_BURN_PS1_LENGTH            534
#define DATA_BURN_PRED_LENGTH           535

/* Old total powers, used in SetDepStepSize only. (AIs) */

#define DATA_BURN_POW_PS1               536
#define DATA_BURN_POW_BOS               537
#define DATA_BURN_POW_EOS               538

/* weights in the coefficients of 2. order poly fit for burnup calculation */
/* see depletionpolyfit.c for more (AIs)*/

#define DATA_BURN_FIT_C2W1              540
#define DATA_BURN_FIT_C2W2              541
#define DATA_BURN_FIT_C2W3              542
#define DATA_BURN_FIT_C1W1              543
#define DATA_BURN_FIT_C1W2              544
#define DATA_BURN_FIT_C1W3              545
#define DATA_BURN_FIT_C0W1              546
#define DATA_BURN_FIT_C0W2              547
#define DATA_BURN_FIT_C0W3              548
#define DATA_BURN_FIT_TYPE              549

#define DATA_BURN_PRED_TYPE             551
#define DATA_BURN_PRED_NSS              552
#define DATA_BURN_CORR_TYPE             553
#define DATA_BURN_CORR_NSS              554

/* Energy grid for coarse multi-group cross sections */

#define DATA_COARSE_MG_NE               555
#define DATA_COARSE_MG_PTR_GRID         556

/* Delayed nubar option */

#define DATA_USE_DELNU                  558

/* Doppler-broadening mode and temperature feedback */

#define DATA_DOPPLER_MODE               580
#define DATA_USE_TFB                    581

/* RNG seed (updated) and tracking collison counter */

#define DATA_PTR_RNG_SEED               590
#define DATA_PTR_COLLISION_COUNT        591

/* Buffer and RES2 reduced flag */

#define DATA_BUF_REDUCED                592
#define DATA_RES2_REDUCED               593

/* Last value in data block */

#define DATA_LAST_VALUE                 600

/*****************************************************************************/

/***** Statistical variables *************************************************/

#define RES_ANA_NUBAR                   DATA_LAST_VALUE + 1
#define RES_ANA_FISSE                   DATA_LAST_VALUE + 2
#define RES_TOT_FISSRATE                DATA_LAST_VALUE + 3
#define RES_TOT_CAPTRATE                DATA_LAST_VALUE + 4
#define RES_TOT_N2NRATE                 DATA_LAST_VALUE + 5
#define RES_TOT_LEAKRATE                DATA_LAST_VALUE + 6
#define RES_TOT_LOSSRATE                DATA_LAST_VALUE + 7
#define RES_TOT_SRCRATE                 DATA_LAST_VALUE + 8
#define RES_TOT_ELARATE                 DATA_LAST_VALUE + 9 
#define RES_TOT_ABSRATE                 DATA_LAST_VALUE + 9 
#define RES_TOT_POWDENS                 DATA_LAST_VALUE + 10
#define RES_TOT_RR                      DATA_LAST_VALUE + 11
#define RES_IMP_KEFF                    DATA_LAST_VALUE + 13
#define RES_IMP_KINF                    DATA_LAST_VALUE + 14
#define RES_ANA_KEFF                    DATA_LAST_VALUE + 15
#define RES_COL_KEFF                    DATA_LAST_VALUE + 16
#define RES_MEAN_POP_SIZE               DATA_LAST_VALUE + 17
#define RES_TOT_FLUX                    DATA_LAST_VALUE + 18
#define RES_TOT_POWER                   DATA_LAST_VALUE + 19
#define RES_TOT_GENRATE                 DATA_LAST_VALUE + 20
#define RES_TOT_RECIPVEL                DATA_LAST_VALUE + 26
#define RES_IMPL_REPROD_TIME            DATA_LAST_VALUE + 27
#define RES_ANA_REPROD_TIME             DATA_LAST_VALUE + 28
#define RES_IMPL_PROMPT_LIFETIME        DATA_LAST_VALUE + 29
#define RES_ANA_PROMPT_LIFETIME         DATA_LAST_VALUE + 30
#define RES_ANA_FISS_FRAC               DATA_LAST_VALUE + 31
#define RES_ANA_CONV_RATIO              DATA_LAST_VALUE + 32
#define RES_CYCLE_RUNTIME               DATA_LAST_VALUE + 33
#define RES_CPU_USAGE                   DATA_LAST_VALUE + 34
#define RES_REA_SAMPLE_REAL             DATA_LAST_VALUE + 35
#define RES_REA_SAMPLE_ACC              DATA_LAST_VALUE + 36
#define RES_REA_SAMPLE_REJ              DATA_LAST_VALUE + 37
#define RES_REA_SAMPLE_FAIL             DATA_LAST_VALUE + 38
#define RES_REA_SAMPLE_VIRT             DATA_LAST_VALUE + 39
#define RES_REA_SAMPLE_EFF              DATA_LAST_VALUE + 40
#define RES_TRACK_DT                    DATA_LAST_VALUE + 41
#define RES_TRACK_ST                    DATA_LAST_VALUE + 42
#define RES_DT_EFF                      DATA_LAST_VALUE + 43
#define RES_DT_FRAC                     DATA_LAST_VALUE + 44
#define RES_STAT_VARIABLES              44

/* Size of fixed data block and minimum acceptable pointer (NOTE: tossa */
/* pit�� nyt olla + 1 koska noi viittaa samaan blokkiin. Sin�ns� turhan */
/* monimutkaisesti tehty. */

#define DATA_FIXED_BLOCK_SIZE           DATA_LAST_VALUE + RES_STAT_VARIABLES + 1
#define VALID_PTR                       DATA_FIXED_BLOCK_SIZE - 1

/*****************************************************************************/

/***** List data *************************************************************/

/* This is data stored for every item */

#define LIST_DATA_SIZE   4

#define LIST_PTR_NEXT    0
#define LIST_PTR_PREV    1
#define LIST_PTR_COMMON  2
#define LIST_PTR_DIRECT  3

/* This is common data in a separate structure */

#define LIST_COMMON_DATA_SIZE  5

#define LIST_COMMON_ITEM_SIZE      0
#define LIST_COMMON_PTR_ROOT       1
#define LIST_COMMON_N_ITEMS        2
#define LIST_COMMON_PTR_FIRST      3
#define LIST_COMMON_PTR_LAST       4

/*****************************************************************************/

/***** Common variables for input parameters *********************************/

/* PARAM_N_COMMON:iin ei lis�t� LIST_DATA_SIZE:a */

#define PARAM_N_COMMON   3

#define PARAM_PTR_NAME   LIST_DATA_SIZE + 0
#define PARAM_PTR_FNAME  LIST_DATA_SIZE + 1
#define PARAM_LINE       LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** Material block ********************************************************/

/* TODO: N�it� nimi� pit�� seriously j�rkev�itt�� !!! */

#define MATERIAL_BLOCK_SIZE            LIST_DATA_SIZE + PARAM_N_COMMON + 56

#define MATERIAL_OPTIONS               LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define MATERIAL_PTR_NAME              LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define MATERIAL_PTR_COMP              LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define MATERIAL_PTR_MIX               LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define MATERIAL_TEMP                  LIST_DATA_SIZE + PARAM_N_COMMON + 4
#define MATERIAL_RGB                   LIST_DATA_SIZE + PARAM_N_COMMON + 5
#define MATERIAL_VOLUME                LIST_DATA_SIZE + PARAM_N_COMMON + 6
#define MATERIAL_VOLUME_GIVEN          LIST_DATA_SIZE + PARAM_N_COMMON + 7
#define MATERIAL_MASS                  LIST_DATA_SIZE + PARAM_N_COMMON + 8
#define MATERIAL_INI_FMASS             LIST_DATA_SIZE + PARAM_N_COMMON + 9
#define MATERIAL_TOT_FMASS             LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define MATERIAL_PTR_MC_VOLUME         LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define MATERIAL_BURN_RINGS            LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define MATERIAL_COLOUR_IDX            LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define MATERIAL_ADENS                 LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define MATERIAL_MDENS                 LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define MATERIAL_PTR_TOT_REA_LIST      LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define MATERIAL_PTR_ELA_REA_LIST      LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define MATERIAL_PTR_ABS_REA_LIST      LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define MATERIAL_PTR_FISS_REA_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define MATERIAL_PTR_NUXN_REA_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define MATERIAL_PTR_PHOT_TOT_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 21
#define MATERIAL_PTR_PHOT_HEAT_LIST    LIST_DATA_SIZE + PARAM_N_COMMON + 22
#define MATERIAL_PTR_TOT_URES_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 24
#define MATERIAL_PTR_ABS_URES_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 25
#define MATERIAL_PTR_ELA_URES_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 26
#define MATERIAL_PTR_FISS_URES_LIST    LIST_DATA_SIZE + PARAM_N_COMMON + 27
#define MATERIAL_PTR_TOTXS             LIST_DATA_SIZE + PARAM_N_COMMON + 28
#define MATERIAL_PTR_ELAXS             LIST_DATA_SIZE + PARAM_N_COMMON + 29
#define MATERIAL_PTR_ABSXS             LIST_DATA_SIZE + PARAM_N_COMMON + 30
#define MATERIAL_PTR_FISSXS            LIST_DATA_SIZE + PARAM_N_COMMON + 31
#define MATERIAL_PTR_NUXNXS            LIST_DATA_SIZE + PARAM_N_COMMON + 32
#define MATERIAL_PTR_TOTPHOTXS         LIST_DATA_SIZE + PARAM_N_COMMON + 33
#define MATERIAL_PTR_HEATPHOTXS        LIST_DATA_SIZE + PARAM_N_COMMON + 34
#define MATERIAL_MEM_SIZE              LIST_DATA_SIZE + PARAM_N_COMMON + 35
#define MATERIAL_PTR_SAB               LIST_DATA_SIZE + PARAM_N_COMMON + 36
#define MATERIAL_PTR_DEP_TRA_LIST      LIST_DATA_SIZE + PARAM_N_COMMON + 37
#define MATERIAL_PTR_DEP_FISS_LIST     LIST_DATA_SIZE + PARAM_N_COMMON + 38
#define MATERIAL_ACTIVITY              LIST_DATA_SIZE + PARAM_N_COMMON + 39
#define MATERIAL_SFRATE                LIST_DATA_SIZE + PARAM_N_COMMON + 40
#define MATERIAL_DECAY_HEAT            LIST_DATA_SIZE + PARAM_N_COMMON + 41
#define MATERIAL_PTR_FLUX_SPEC         LIST_DATA_SIZE + PARAM_N_COMMON + 42
#define MATERIAL_PTR_FLUX_SPEC_SUM     LIST_DATA_SIZE + PARAM_N_COMMON + 43
#define MATERIAL_PTR_BURN_FLUX         LIST_DATA_SIZE + PARAM_N_COMMON + 44
#define MATERIAL_BURN_FLUX_PS1         LIST_DATA_SIZE + PARAM_N_COMMON + 45
#define MATERIAL_BURN_FLUX_BOS         LIST_DATA_SIZE + PARAM_N_COMMON + 46
#define MATERIAL_BURN_FLUX_EOS         LIST_DATA_SIZE + PARAM_N_COMMON + 47
#define MATERIAL_BURN_FLUX_SSA         LIST_DATA_SIZE + PARAM_N_COMMON + 48
#define MATERIAL_PTR_DIV_PARENT        LIST_DATA_SIZE + PARAM_N_COMMON + 49
#define MATERIAL_BURNUP                LIST_DATA_SIZE + PARAM_N_COMMON + 50
#define MATERIAL_OMP_ID                LIST_DATA_SIZE + PARAM_N_COMMON + 51
#define MATERIAL_DIV_IDX               LIST_DATA_SIZE + PARAM_N_COMMON + 52
#define MATERIAL_MPI_ID                LIST_DATA_SIZE + PARAM_N_COMMON + 53
#define MATERIAL_PTR_DATA_BLOCK        LIST_DATA_SIZE + PARAM_N_COMMON + 54
#define MATERIAL_DATA_BLOCK_SIZE       LIST_DATA_SIZE + PARAM_N_COMMON + 55

/*****************************************************************************/

/***** Nuclide composition in material ***************************************/

/* TODO: muuta tän nimi ISO:ksi? */

#define COMPOSITION_BLOCK_SIZE   LIST_DATA_SIZE + 3

#define COMPOSITION_PTR_NUCLIDE  LIST_DATA_SIZE + 0
#define COMPOSITION_ADENS        LIST_DATA_SIZE + 1
#define COMPOSITION_ADENS_BOS    LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** Mixture composition ***************************************************/

/* TODO: muuta tän nimi ISO:ksi? */

#define MIXTURE_BLOCK_SIZE  LIST_DATA_SIZE + 3

#define MIXTURE_PTR_MAT     LIST_DATA_SIZE + 0
#define MIXTURE_VFRAC       LIST_DATA_SIZE + 1
#define MIXTURE_MFRAC       LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** XS data array *********************************************************/

#define NUCLIDE_BLOCK_SIZE             LIST_DATA_SIZE + 67

#define NUCLIDE_PTR_NAME               LIST_DATA_SIZE +  0
#define NUCLIDE_TYPE                   LIST_DATA_SIZE +  1
#define NUCLIDE_OPTIONS                LIST_DATA_SIZE +  2
#define NUCLIDE_TYPE_FLAGS             LIST_DATA_SIZE +  3
#define NUCLIDE_ZAI                    LIST_DATA_SIZE +  4
#define NUCLIDE_ZA                     LIST_DATA_SIZE +  5
#define NUCLIDE_Z                      LIST_DATA_SIZE +  6
#define NUCLIDE_A                      LIST_DATA_SIZE +  7
#define NUCLIDE_I                      LIST_DATA_SIZE +  8
#define NUCLIDE_AW                     LIST_DATA_SIZE +  9
#define NUCLIDE_AWR                    LIST_DATA_SIZE + 10
#define NUCLIDE_TEMP                   LIST_DATA_SIZE + 11
#define NUCLIDE_XS_TEMP                LIST_DATA_SIZE + 12
#define NUCLIDE_MAX_TEMP               LIST_DATA_SIZE + 13
#define NUCLIDE_PTR_LIB_ID             LIST_DATA_SIZE + 14
#define NUCLIDE_PTR_ACE                LIST_DATA_SIZE + 15
#define NUCLIDE_PTR_DECAY_ACE          LIST_DATA_SIZE + 16
#define NUCLIDE_PTR_PHOTON_ACE         LIST_DATA_SIZE + 17
#define NUCLIDE_PTR_REA                LIST_DATA_SIZE + 18
#define NUCLIDE_N_TRANSPORT_REA        LIST_DATA_SIZE + 19
#define NUCLIDE_N_SPECIAL_REA          LIST_DATA_SIZE + 20
#define NUCLIDE_N_DECAY_REA            LIST_DATA_SIZE + 21
#define NUCLIDE_N_TRANSPORT_BRANCH     LIST_DATA_SIZE + 22
#define NUCLIDE_N_DECAY_BRANCH         LIST_DATA_SIZE + 23
#define NUCLIDE_N_TRANSMUTATION_REA    LIST_DATA_SIZE + 24
#define NUCLIDE_N_DEAD_PATH            LIST_DATA_SIZE + 25
#define NUCLIDE_N_TRANSMUTATION_PATH   LIST_DATA_SIZE + 26
#define NUCLIDE_LAMBDA                 LIST_DATA_SIZE + 27
#define NUCLIDE_DECAY_E                LIST_DATA_SIZE + 28
#define NUCLIDE_SFBR                   LIST_DATA_SIZE + 29
#define NUCLIDE_PTR_NFY_DATA           LIST_DATA_SIZE + 30
#define NUCLIDE_PTR_SFY_DATA           LIST_DATA_SIZE + 31
#define NUCLIDE_NFY_NE                 LIST_DATA_SIZE + 32
#define NUCLIDE_PATH_LEVEL             LIST_DATA_SIZE + 33
#define NUCLIDE_PTR_EGRID              LIST_DATA_SIZE + 34
#define NUCLIDE_EGRID_NE               LIST_DATA_SIZE + 35
#define NUCLIDE_EMIN                   LIST_DATA_SIZE + 36
#define NUCLIDE_EMAX                   LIST_DATA_SIZE + 37
#define NUCLIDE_MAX_TOTXS              LIST_DATA_SIZE + 38
#define NUCLIDE_PTR_TOTXS              LIST_DATA_SIZE + 39
#define NUCLIDE_PTR_SUM_ABSXS          LIST_DATA_SIZE + 40
#define NUCLIDE_PTR_ELAXS              LIST_DATA_SIZE + 41
#define NUCLIDE_PTR_FISSXS             LIST_DATA_SIZE + 42
#define NUCLIDE_PTR_NGAMMAXS           LIST_DATA_SIZE + 43
#define NUCLIDE_PTR_PHOTON_INCOHEXS    LIST_DATA_SIZE + 44
#define NUCLIDE_PTR_PHOTON_COHEXS      LIST_DATA_SIZE + 45
#define NUCLIDE_PTR_PHOTON_PHOTOELXS   LIST_DATA_SIZE + 46
#define NUCLIDE_PTR_PHOTON_PAIRPRODXS  LIST_DATA_SIZE + 47
#define NUCLIDE_PTR_PHOTON_HEATPRODXS  LIST_DATA_SIZE + 48
#define NUCLIDE_PTR_SAMPLE_REA_LIST    LIST_DATA_SIZE + 49
#define NUCLIDE_URES_EMIN              LIST_DATA_SIZE + 50
#define NUCLIDE_URES_EMAX              LIST_DATA_SIZE + 51
#define NUCLIDE_PTR_URES_RND           LIST_DATA_SIZE + 52
#define NUCLIDE_PTR_MATRIX_IDX         LIST_DATA_SIZE + 53
#define NUCLIDE_MEMSIZE                LIST_DATA_SIZE + 54
#define NUCLIDE_PTR_PHOTON_LINE_SPEC   LIST_DATA_SIZE + 55
#define NUCLIDE_IDX                    LIST_DATA_SIZE + 56
#define NUCLIDE_INVENTORY_IDX          LIST_DATA_SIZE + 57
#define NUCLIDE_PTR_TOTFISS_REA        LIST_DATA_SIZE + 58
#define NUCLIDE_SPEC_ING_TOX           LIST_DATA_SIZE + 59
#define NUCLIDE_SPEC_INH_TOX           LIST_DATA_SIZE + 60
#define NUCLIDE_ACE_PREC_GROUPS        LIST_DATA_SIZE + 61
#define NUCLIDE_PREV_COL_Z2            LIST_DATA_SIZE + 62
#define NUCLIDE_PREV_COL_COS           LIST_DATA_SIZE + 63
#define NUCLIDE_MIN_AFRAC              LIST_DATA_SIZE + 64
#define NUCLIDE_MAX_AFRAC              LIST_DATA_SIZE + 65
#define NUCLIDE_URES_SAMPLING          LIST_DATA_SIZE + 66

/*****************************************************************************/

/****** FP identifier ********************************************************/

#define FP_IDENT_BLOCK_SIZE  LIST_DATA_SIZE + 2

#define FP_IDENT_PTR_ID      LIST_DATA_SIZE + 0
#define FP_IDENT_TEMP        LIST_DATA_SIZE + 1

/*****************************************************************************/

/***** Photon spectrum *******************************************************/

#define PHOTON_LINE_SPEC_BLOCK_SIZE  LIST_DATA_SIZE + 2

#define PHOTON_LINE_SPEC_E           LIST_DATA_SIZE + 0
#define PHOTON_LINE_SPEC_RI          LIST_DATA_SIZE + 1

/*****************************************************************************/

/***** Statistical variable **************************************************/

/* T�h�n ei voi laittaa LIST_DATA_SIZE:a? */

#define STAT_BLOCK_SIZE                4

#define STAT_N                         0
#define STAT_X                         1
#define STAT_X2                        2
#define STAT_SCOREN                    3

#define BUF_BLOCK_SIZE                 3

#define BUF_VAL                        0
#define BUF_WGT                        1
#define BUF_N                          2

/*****************************************************************************/

/***** ACE data array ********************************************************/

/* T�ss� ei tarvita list dataa koska pointterit viittaa ACE taulukkoon */

#define ACE_BLOCK_SIZE                22

#define ACE_PTR_ALIAS                  0
#define ACE_PTR_NAME                   1
#define ACE_TYPE                       2
#define ACE_AW                         3
#define ACE_AWR                        4
#define ACE_ZAI                        5
#define ACE_ZA                         6
#define ACE_I                          7
#define ACE_TEMP                       8
#define ACE_PTR_LIB_ID                 9
#define ACE_PTR_NXS                   10
#define ACE_PTR_JXS                   11
#define ACE_PTR_XSS                   12
#define ACE_PTR_FILE                  13
#define ACE_LAMBDA                    14
#define ACE_DECAY_E                   15
#define ACE_PTR_DECAY_LIST            16
#define ACE_SFBR                      17
#define ACE_DECAY_NDK                 18
#define ACE_BOUND_ZA                  19
#define ACE_PTR_RAD_SPEC              20
#define ACE_PTR_NEXT                  21

/*****************************************************************************/

/***** Energy grid structure *************************************************/

/* NOTE: T�m� on bin��ripuurakenne joka ei k�yt� linkitetyn listan */
/*       pointtereita tai rutiineja. */

#define ENERGY_GRID_BLOCK_SIZE    16

#define ENERGY_GRID_NE             0
#define ENERGY_GRID_I0             1
#define ENERGY_GRID_EMIN           2
#define ENERGY_GRID_EMAX           3
#define ENERGY_GRID_EMID           4
#define ENERGY_GRID_PTR_LOW        5
#define ENERGY_GRID_PTR_HIGH       6
#define ENERGY_GRID_PTR_DATA       7
#define ENERGY_GRID_NB             8
#define ENERGY_GRID_PTR_BINS       9
#define ENERGY_GRID_LOG_EMIN      10
#define ENERGY_GRID_LOG_EMAX      11
#define ENERGY_GRID_TYPE          12
#define ENERGY_GRID_PTR_PREV_VAL  13
#define ENERGY_GRID_INTERP_MODE   14
#define ENERGY_GRID_ALLOC_NE      15

/*****************************************************************************/

/***** Reaction data array ***************************************************/

#define REACTION_BLOCK_SIZE             LIST_DATA_SIZE + 52

#define REACTION_TYPE                   LIST_DATA_SIZE +  0
#define REACTION_NR                     LIST_DATA_SIZE +  1
#define REACTION_MT                     LIST_DATA_SIZE +  2
#define REACTION_BR                     LIST_DATA_SIZE +  3
#define REACTION_RFS                    LIST_DATA_SIZE +  4
#define REACTION_AWR                    LIST_DATA_SIZE +  5
#define REACTION_Q                      LIST_DATA_SIZE +  6
#define REACTION_TY                     LIST_DATA_SIZE +  7
#define REACTION_WGT_F                  LIST_DATA_SIZE +  8
#define REACTION_EMIN                   LIST_DATA_SIZE +  9
#define REACTION_EMAX                   LIST_DATA_SIZE + 10
#define REACTION_PTR_EGRID              LIST_DATA_SIZE + 11
#define REACTION_PTR_XS                 LIST_DATA_SIZE + 12
#define REACTION_XS_I0                  LIST_DATA_SIZE + 13
#define REACTION_XS_NE                  LIST_DATA_SIZE + 14
#define REACTION_TGT_ZAI                LIST_DATA_SIZE + 15
#define REACTION_PTR_TGT                LIST_DATA_SIZE + 16
#define REACTION_PTR_BRANCH_PARENT      LIST_DATA_SIZE + 17
#define REACTION_BRANCH_MT              LIST_DATA_SIZE + 18
#define REACTION_PTR_FISSY              LIST_DATA_SIZE + 19
#define REACTION_PTR_PARTIAL_LIST       LIST_DATA_SIZE + 20
#define REACTION_PTR_PARTIAL_URES_LIST  LIST_DATA_SIZE + 21
#define REACTION_PTR_NUCLIDE            LIST_DATA_SIZE + 22
#define REACTION_PTR_MAT                LIST_DATA_SIZE + 23
#define REACTION_PTR_PREV_XS            LIST_DATA_SIZE + 24
#define REACTION_PTR_PREV_XS0           LIST_DATA_SIZE + 25
#define REACTION_PTR_MAJORANT_XS        LIST_DATA_SIZE + 26
#define REACTION_PTR_URES               LIST_DATA_SIZE + 27
#define REACTION_PTR_ANG                LIST_DATA_SIZE + 28
#define REACTION_PTR_PHOTON_DIST        LIST_DATA_SIZE + 29
#define REACTION_URES_EMIN              LIST_DATA_SIZE + 30
#define REACTION_URES_EMAX              LIST_DATA_SIZE + 31
#define REACTION_PTR_ANA_RATE           LIST_DATA_SIZE + 32
#define REACTION_ITP                    LIST_DATA_SIZE + 33
#define REACTION_SAB_EMAX               LIST_DATA_SIZE + 34
#define REACTION_SAB_FRAC               LIST_DATA_SIZE + 35
#define REACTION_PTR_IBR                LIST_DATA_SIZE + 36
#define REACTION_PTR_TNUBAR             LIST_DATA_SIZE + 37
#define REACTION_PTR_DNUBAR             LIST_DATA_SIZE + 38
#define REACTION_PTR_PREC_LIST          LIST_DATA_SIZE + 39
#define REACTION_PTR_ERG                LIST_DATA_SIZE + 40
#define REACTION_PTR_0K_REA             LIST_DATA_SIZE + 41
#define REACTION_PTR_0K_MAJORANT        LIST_DATA_SIZE + 42
#define REACTION_PTR_TRANSMUXS          LIST_DATA_SIZE + 43
#define REACTION_FISSY_IE0              LIST_DATA_SIZE + 44
#define REACTION_FISSY_IE1              LIST_DATA_SIZE + 45
#define REACTION_FISSY_IE2              LIST_DATA_SIZE + 46
#define REACTION_MODE                   LIST_DATA_SIZE + 47
#define REACTION_PTR_MGXS               LIST_DATA_SIZE + 48
#define REACTION_PTR_URES_MAX           LIST_DATA_SIZE + 49
#define REACTION_URES_MAX_N0            LIST_DATA_SIZE + 50
#define REACTION_URES_MAX_NP            LIST_DATA_SIZE + 51

/*****************************************************************************/

/***** Reaction list array ***************************************************/

/* TODO: muuta noi nimet */

#define LIST_ROOT_BLOCK_SIZE          LIST_DATA_SIZE + 9

#define LIST_ROOT_PTR_MAT             LIST_DATA_SIZE + 0
#define LIST_ROOT_REA_MODE            LIST_DATA_SIZE + 1
#define LIST_ROOT_N_REA               LIST_DATA_SIZE + 2
#define LIST_ROOT_N_MAX               LIST_DATA_SIZE + 3
#define LIST_ROOT_PTR_REA_LIST        LIST_DATA_SIZE + 4
#define LIST_ROOT_PTR_NEXT_REA        LIST_DATA_SIZE + 5
#define LIST_ROOT_PTR_NEXT_ISO        LIST_DATA_SIZE + 6
#define LIST_ROOT_PTR_NEXT_LST        LIST_DATA_SIZE + 7
#define LIST_ROOT_LIST_TYPE           LIST_DATA_SIZE + 8

#define REA_LIST_BLOCK_SIZE           LIST_DATA_SIZE + 5

#define REA_LIST_PTR_REA              LIST_DATA_SIZE + 0
#define REA_LIST_ADENS                LIST_DATA_SIZE + 1
#define REA_LIST_EMIN                 LIST_DATA_SIZE + 2
#define REA_LIST_EMAX                 LIST_DATA_SIZE + 3
#define REA_LIST_PTR_COUNT            LIST_DATA_SIZE + 4

/*****************************************************************************/

/***** Nubar data ************************************************************/

#define NUBAR_BLOCK_SIZE              LIST_DATA_SIZE + 5

#define NUBAR_DATA_TYPE               LIST_DATA_SIZE + 0
#define NUBAR_PTR_POLY_DATA           LIST_DATA_SIZE + 1
#define NUBAR_PTR_EGRID               LIST_DATA_SIZE + 2
#define NUBAR_PTR_PTS                 LIST_DATA_SIZE + 3
#define NUBAR_PTR_PREV_VAL            LIST_DATA_SIZE + 4

/*****************************************************************************/

/***** Precursor data ********************************************************/

#define PREC_BLOCK_SIZE               LIST_DATA_SIZE + 5

#define PREC_IDX                      LIST_DATA_SIZE + 0
#define PREC_LAMBDA                   LIST_DATA_SIZE + 1
#define PREC_PTR_EGRID                LIST_DATA_SIZE + 2
#define PREC_PTR_PTS                  LIST_DATA_SIZE + 3
#define PREC_PTR_ERG                  LIST_DATA_SIZE + 4

/*****************************************************************************/

/***** Energy distribution data **********************************************/

#define ERG_BLOCK_SIZE                LIST_DATA_SIZE + 7

#define ERG_PTR_EGRID                 LIST_DATA_SIZE + 0
#define ERG_PTR_PROB                  LIST_DATA_SIZE + 1
#define ERG_LAW                       LIST_DATA_SIZE + 2
#define ERG_INTERP                    LIST_DATA_SIZE + 3
#define ERG_PTR_DATA                  LIST_DATA_SIZE + 4
#define ERG_NR                        LIST_DATA_SIZE + 5
#define ERG_PTR_INTERP                LIST_DATA_SIZE + 6

/*****************************************************************************/

/***** Photon distribution data **********************************************/

#define PHOTON_DIST_BLOCK_SIZE        LIST_DATA_SIZE + 12

#define PHOTON_DIST_MCOH              LIST_DATA_SIZE + 0
#define PHOTON_DIST_PTR_WCO           LIST_DATA_SIZE + 1
#define PHOTON_DIST_PTR_COH_FFINT     LIST_DATA_SIZE + 2
#define PHOTON_DIST_PTR_COH_FF        LIST_DATA_SIZE + 3
#define PHOTON_DIST_MINC              LIST_DATA_SIZE + 4
#define PHOTON_DIST_PTR_VIC           LIST_DATA_SIZE + 5
#define PHOTON_DIST_PTR_INC_FF        LIST_DATA_SIZE + 6
#define PHOTON_DIST_FLO_N             LIST_DATA_SIZE + 7
#define PHOTON_DIST_PTR_FLO_E         LIST_DATA_SIZE + 8
#define PHOTON_DIST_PTR_FLO_PHI       LIST_DATA_SIZE + 9
#define PHOTON_DIST_PTR_FLO_Y         LIST_DATA_SIZE + 10
#define PHOTON_DIST_PTR_FLO_F         LIST_DATA_SIZE + 11

/*****************************************************************************/

/***** Isomeric branching ratio data *****************************************/

#define IBR_LIST_BLOCK_SIZE           LIST_DATA_SIZE + 6

#define IBR_LIST_ZAI                  LIST_DATA_SIZE + 0
#define IBR_LIST_MT                   LIST_DATA_SIZE + 1
#define IBR_LIST_BR                   LIST_DATA_SIZE + 2
#define IBR_LIST_NE                   LIST_DATA_SIZE + 3
#define IBR_LIST_PTR_EGRID            LIST_DATA_SIZE + 4
#define IBR_LIST_PTR_DATA             LIST_DATA_SIZE + 5

/*****************************************************************************/

/***** Depletion transmutation list ******************************************/

#define DEP_TRA_BLOCK_SIZE            LIST_DATA_SIZE + 6

#define DEP_TRA_PTR_REA               LIST_DATA_SIZE + 0
#define DEP_TRA_EMIN                  LIST_DATA_SIZE + 1
#define DEP_TRA_PTR_RESU              LIST_DATA_SIZE + 2
#define DEP_TRA_PS1                   LIST_DATA_SIZE + 3
#define DEP_TRA_BOS                   LIST_DATA_SIZE + 4
#define DEP_TRA_EOS                   LIST_DATA_SIZE + 5

/*****************************************************************************/

/***** Fission yield data array **********************************************/

/* Data block */

#define FISSION_YIELD_BLOCK_SIZE       LIST_DATA_SIZE + 6

#define FISSION_YIELD_PARENT_ZAI       LIST_DATA_SIZE + 0
#define FISSION_YIELD_E                LIST_DATA_SIZE + 1
#define FISSION_YIELD_NFP              LIST_DATA_SIZE + 2
#define FISSION_YIELD_ORIG_NFP         LIST_DATA_SIZE + 3
#define FISSION_YIELD_PTR_DISTR        LIST_DATA_SIZE + 4
#define FISSION_YIELD_PTR_NEXT         LIST_DATA_SIZE + 5

/* Yield entry */

#define FY_BLOCK_SIZE                  LIST_DATA_SIZE + 4

#define FY_TGT_ZAI                     LIST_DATA_SIZE + 0
#define FY_PTR_TGT                     LIST_DATA_SIZE + 1
#define FY_INDEPENDENT_FRAC            LIST_DATA_SIZE + 2
#define FY_CUMULATIVE_FRAC             LIST_DATA_SIZE + 3

/*****************************************************************************/

/***** Decay array ***********************************************************/

#define DECAY_BLOCK_SIZE               LIST_DATA_SIZE + 4

#define DECAY_RTYP                     LIST_DATA_SIZE + 0
#define DECAY_RFS                      LIST_DATA_SIZE + 1
#define DECAY_Q                        LIST_DATA_SIZE + 2
#define DECAY_BR                       LIST_DATA_SIZE + 3

/*****************************************************************************/

/***** Radiation spectrum block size *****************************************/

#define RAD_SPEC_BLOCK_SIZE            LIST_DATA_SIZE + 9

#define RAD_SPEC_TYPE                  LIST_DATA_SIZE + 0
#define RAD_SPEC_DISC_NORM             LIST_DATA_SIZE + 1
#define RAD_SPEC_DISC_NE               LIST_DATA_SIZE + 2
#define RAD_SPEC_PTR_DISC_E            LIST_DATA_SIZE + 3
#define RAD_SPEC_PTR_DISC_RI           LIST_DATA_SIZE + 4
#define RAD_SPEC_CONT_NORM             LIST_DATA_SIZE + 5
#define RAD_SPEC_CONT_NE               LIST_DATA_SIZE + 6
#define RAD_SPEC_PTR_CONT_E            LIST_DATA_SIZE + 7
#define RAD_SPEC_PTR_CONT_RI           LIST_DATA_SIZE + 8

/*****************************************************************************/

/***** Thermal scattering library data ***************************************/

/* TODO: Muuta t�n nimi SAB:ksi */

#define THERM_BLOCK_SIZE              LIST_DATA_SIZE + PARAM_N_COMMON + 12

#define THERM_OPTIONS                 LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define THERM_PTR_ALIAS               LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define THERM_ZA                      LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define THERM_T                       LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define THERM_PTR_ISO1                LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define THERM_T1                      LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define THERM_FRAC1                   LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define THERM_PTR_ISO2                LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define THERM_T2                      LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define THERM_FRAC2                   LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define THERM_PTR_THERM               LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define THERM_PTR_COMP                LIST_DATA_SIZE + PARAM_N_COMMON + 11

/*****************************************************************************/

/***** Unresolved resonance probability table data ***************************/

#define URES_BLOCK_SIZE               LIST_DATA_SIZE + 8

#define URES_PTR_EGRID                LIST_DATA_SIZE + 0
#define URES_NP                       LIST_DATA_SIZE + 1
#define URES_PTR_PROB                 LIST_DATA_SIZE + 2
#define URES_IFF                      LIST_DATA_SIZE + 3
#define URES_PTR_FACT                 LIST_DATA_SIZE + 4
#define URES_PTR_MAXF                 LIST_DATA_SIZE + 5
#define URES_PTR_RND                  LIST_DATA_SIZE + 6
#define URES_PTR_PREV_FACT            LIST_DATA_SIZE + 7

/*****************************************************************************/

/***** Angular distribution **************************************************/

#define ANG_BLOCK_SIZE                LIST_DATA_SIZE + 5

#define ANG_PTR_EGRID                 LIST_DATA_SIZE + 0
#define ANG_TYPE                      LIST_DATA_SIZE + 1
#define ANG_PTR_D0                    LIST_DATA_SIZE + 2
#define ANG_BINS                      LIST_DATA_SIZE + 3
#define ANG_INTT                      LIST_DATA_SIZE + 4

/*****************************************************************************/

/***** Surface ***************************************************************/

/* Surface types */

#define SURFACE_TYPES   25

#define SURF_CYL         1
#define SURF_PX          2
#define SURF_PY          3
#define SURF_PZ          4
#define SURF_INF         5
#define SURF_SQC         6
#define SURF_HEXYC       7
#define SURF_HEXXC       8
#define SURF_SPH         9
#define SURF_CROSS      10
#define SURF_PAD        11
#define SURF_CUBE       12
#define SURF_CONE       13
#define SURF_SVC        14
#define SURF_CUBOID     15
#define SURF_HEXYPRISM  16
#define SURF_HEXXPRISM  17
#define SURF_DODE       18
#define SURF_OCTA       19
#define SURF_ASTRA      20
#define SURF_PLANE      21
#define SURF_QUADRATIC  22
#define SURF_CYLX       23
#define SURF_CYLY       24
#define SURF_CYLZ       25

/* Data block */

#define SURFACE_BLOCK_SIZE  LIST_DATA_SIZE + PARAM_N_COMMON + 5

#define SURFACE_PTR_NAME    LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define SURFACE_OPTIONS     LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define SURFACE_TYPE        LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define SURFACE_PTR_PARAMS  LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define SURFACE_N_PARAMS    LIST_DATA_SIZE + PARAM_N_COMMON + 4

/*****************************************************************************/

/***** Cell ******************************************************************/

/* Cell types */

#define CELL_TYPE_MAT      1
#define CELL_TYPE_VOID     2
#define CELL_TYPE_OUTSIDE  3
#define CELL_TYPE_FILL     4

/* Data block */

#define CELL_BLOCK_SIZE     LIST_DATA_SIZE + PARAM_N_COMMON + 12

#define CELL_PTR_NAME       LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define CELL_TYPE           LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define CELL_OPTIONS        LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define CELL_PTR_UNI        LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define CELL_PTR_MAT        LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define CELL_PTR_FILL       LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define CELL_PTR_SURF_LIST  LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define CELL_PTR_SURF_COMP  LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define CELL_PTR_SURF_INSC  LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define CELL_COL_COUNT      LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define CELL_VOLUME         LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define CELL_VOL_COUNT      LIST_DATA_SIZE + PARAM_N_COMMON + 11

/* Universe cell list */

#define CELL_LIST_BLOCK_SIZE  LIST_DATA_SIZE + 2

#define CELL_LIST_PTR_CELL    LIST_DATA_SIZE + 0
#define CELL_LIST_PTR_COUNT   LIST_DATA_SIZE + 1

/* List of intersections */

#define CELL_INSC_BLOCK_SIZE      LIST_DATA_SIZE + 3

#define CELL_INSC_PTR_SURF        LIST_DATA_SIZE + 0
#define CELL_INSC_SIDE            LIST_DATA_SIZE + 1
#define CELL_INSC_PTR_OUT_COUNT   LIST_DATA_SIZE + 2

/*****************************************************************************/

/***** Nest ******************************************************************/

#define NEST_BLOCK_SIZE         LIST_DATA_SIZE + PARAM_N_COMMON + 7

#define NEST_PTR_NAME           LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define NEST_OPTIONS            LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define NEST_PTR_UNI            LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define NEST_PTR_REGIONS        LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define NEST_TYPE               LIST_DATA_SIZE + PARAM_N_COMMON + 4
#define NEST_PTR_COL_REG        LIST_DATA_SIZE + PARAM_N_COMMON + 5
#define NEST_COUNT              LIST_DATA_SIZE + PARAM_N_COMMON + 6

#define NEST_REG_BLOCK_SIZE     LIST_DATA_SIZE + 6

#define NEST_REG_PTR_FILL       LIST_DATA_SIZE + 0
#define NEST_REG_PTR_MAT        LIST_DATA_SIZE + 1
#define NEST_REG_PTR_SURF_IN    LIST_DATA_SIZE + 2
#define NEST_REG_PTR_SURF_OUT   LIST_DATA_SIZE + 3
#define NEST_REG_PTR_CELL       LIST_DATA_SIZE + 4
#define NEST_REG_PTR_TFB_REG    LIST_DATA_SIZE + 5

/*****************************************************************************/

/***** Coordinate transformation *********************************************/

#define TRANS_BLOCK_SIZE  LIST_DATA_SIZE + PARAM_N_COMMON + 33

#define TRANS_PTR_UNI     LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define TRANS_OPTIONS     LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define TRANS_ROT         LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define TRANS_X0          LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define TRANS_Y0          LIST_DATA_SIZE + PARAM_N_COMMON + 4
#define TRANS_Z0          LIST_DATA_SIZE + PARAM_N_COMMON + 5
#define TRANS_RX1         LIST_DATA_SIZE + PARAM_N_COMMON + 6
#define TRANS_RX2         LIST_DATA_SIZE + PARAM_N_COMMON + 7
#define TRANS_RX3         LIST_DATA_SIZE + PARAM_N_COMMON + 8
#define TRANS_RX4         LIST_DATA_SIZE + PARAM_N_COMMON + 9
#define TRANS_RX5         LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define TRANS_RX6         LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define TRANS_RX7         LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define TRANS_RX8         LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define TRANS_RX9         LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define TRANS_RY1         LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define TRANS_RY2         LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define TRANS_RY3         LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define TRANS_RY4         LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define TRANS_RY5         LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define TRANS_RY6         LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define TRANS_RY7         LIST_DATA_SIZE + PARAM_N_COMMON + 21
#define TRANS_RY8         LIST_DATA_SIZE + PARAM_N_COMMON + 22
#define TRANS_RY9         LIST_DATA_SIZE + PARAM_N_COMMON + 23
#define TRANS_RZ1         LIST_DATA_SIZE + PARAM_N_COMMON + 24
#define TRANS_RZ2         LIST_DATA_SIZE + PARAM_N_COMMON + 25
#define TRANS_RZ3         LIST_DATA_SIZE + PARAM_N_COMMON + 26
#define TRANS_RZ4         LIST_DATA_SIZE + PARAM_N_COMMON + 27
#define TRANS_RZ5         LIST_DATA_SIZE + PARAM_N_COMMON + 28
#define TRANS_RZ6         LIST_DATA_SIZE + PARAM_N_COMMON + 29
#define TRANS_RZ7         LIST_DATA_SIZE + PARAM_N_COMMON + 30
#define TRANS_RZ8         LIST_DATA_SIZE + PARAM_N_COMMON + 31
#define TRANS_RZ9         LIST_DATA_SIZE + PARAM_N_COMMON + 32

/*****************************************************************************/

/***** Geometry plotter ******************************************************/

#define GPL_BLOCK_SIZE  LIST_DATA_SIZE + PARAM_N_COMMON + 12

#define GPL_IDX         LIST_DATA_SIZE + PARAM_N_COMMON + 0
#define GPL_PTR_FNAME   LIST_DATA_SIZE + PARAM_N_COMMON + 1
#define GPL_TYPE        LIST_DATA_SIZE + PARAM_N_COMMON + 2
#define GPL_PIX_X       LIST_DATA_SIZE + PARAM_N_COMMON + 3
#define GPL_PIX_Y       LIST_DATA_SIZE + PARAM_N_COMMON + 4
#define GPL_POS         LIST_DATA_SIZE + PARAM_N_COMMON + 5
#define GPL_XMIN        LIST_DATA_SIZE + PARAM_N_COMMON + 6
#define GPL_XMAX        LIST_DATA_SIZE + PARAM_N_COMMON + 7
#define GPL_YMIN        LIST_DATA_SIZE + PARAM_N_COMMON + 8
#define GPL_YMAX        LIST_DATA_SIZE + PARAM_N_COMMON + 9
#define GPL_ZMIN        LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define GPL_ZMAX        LIST_DATA_SIZE + PARAM_N_COMMON + 11

/*****************************************************************************/

/***** Pebble bed geometry ***************************************************/

#define PBED_BLOCK_SIZE               LIST_DATA_SIZE + PARAM_N_COMMON + 22

#define PBED_OPTIONS                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define PBED_PTR_FNAME                LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define PBED_N_PEBBLES                LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define PBED_PTR_NAME                 LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define PBED_PTR_UNI                  LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define PBED_PTR_PEBBLES              LIST_DATA_SIZE + PARAM_N_COMMON +  5

/*
#define PBED_MESH_MINX                LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define PBED_MESH_MAXX                LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define PBED_MESH_MINY                LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define PBED_MESH_MAXY                LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define PBED_MESH_MINZ                LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define PBED_MESH_MAXZ                LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define PBED_MESH_NX                  LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define PBED_MESH_NY                  LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define PBED_MESH_NZ                  LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define PBED_MESH_PTR_CELLS           LIST_DATA_SIZE + PARAM_N_COMMON + 16
*/

#define PBED_PTR_MESH                 LIST_DATA_SIZE + PARAM_N_COMMON +  6

#define PBED_PTR_BG_UNIV              LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define PBED_CALC_RESULTS             LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define PBED_PTR_COL_PEBBLE           LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define PBED_PTR_PEBBLE_TYPES         LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define PBED_PTR_POW                  LIST_DATA_SIZE + PARAM_N_COMMON + 21

#define PEBBLE_BLOCK_SIZE              LIST_DATA_SIZE + 6

#define PEBBLE_PTR_UNIV                LIST_DATA_SIZE + 0
#define PEBBLE_X0                      LIST_DATA_SIZE + 1
#define PEBBLE_Y0                      LIST_DATA_SIZE + 2
#define PEBBLE_Z0                      LIST_DATA_SIZE + 3
#define PEBBLE_RAD                     LIST_DATA_SIZE + 4
#define PEBBLE_IDX                     LIST_DATA_SIZE + 5

#define PEBTYPE_BLOCK_SIZE             LIST_DATA_SIZE + 2

#define PEBTYPE_PTR_UNIV               LIST_DATA_SIZE + 0
#define PEBTYPE_COUNT                  LIST_DATA_SIZE + 1

/* List for search mesh */

#define PBED_LIST_BLOCK_SIZE           LIST_DATA_SIZE + 1

#define PBED_LIST_PTR_PEBBLE           LIST_DATA_SIZE + 0

/*****************************************************************************/

/***** Lattice ***************************************************************/

#define LATTICE_TYPES    9

#define LAT_TYPE_S       1
#define LAT_TYPE_HX      2
#define LAT_TYPE_HY      3
#define LAT_TYPE_CLU     4
#define LAT_TYPE_RND     5  
#define LAT_TYPE_INFS    6
#define LAT_TYPE_INFHY   7
#define LAT_TYPE_INFHX   8
#define LAT_TYPE_ZSTACK  9

#define LAT_BLOCK_SIZE                LIST_DATA_SIZE + PARAM_N_COMMON + 14

#define LAT_PTR_NAME                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define LAT_PTR_UNI                   LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define LAT_OPTIONS                   LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define LAT_TYPE                      LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define LAT_ORIG_X0                   LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define LAT_ORIG_Y0                   LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define LAT_PITCH                     LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define LAT_NX                        LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define LAT_NY                        LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define LAT_NTOT                      LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define LAT_N_RINGS                   LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define LAT_PTR_FILL                  LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define LAT_PTR_Z                     LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define LAT_COL_COUNT                 LIST_DATA_SIZE + PARAM_N_COMMON + 13

#define RING_BLOCK_SIZE                LIST_DATA_SIZE + 5
#define RING_N_SEC                     LIST_DATA_SIZE + 0
#define RING_RAD                       LIST_DATA_SIZE + 1
#define RING_RLIM                      LIST_DATA_SIZE + 2
#define RING_TILT                      LIST_DATA_SIZE + 3
#define RING_PTR_FILL                  LIST_DATA_SIZE + 4

/*****************************************************************************/

/***** Universe symmetry *****************************************************/

#define USYM_BLOCK_SIZE               LIST_DATA_SIZE + PARAM_N_COMMON +  4

#define USYM_PTR_UNIV                 LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define USYM_SYM                      LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define USYM_X0                       LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define USYM_Y0                       LIST_DATA_SIZE + PARAM_N_COMMON +  3

/*****************************************************************************/

/***** Depletion history *****************************************************/

/* Depletion step types */

#define DEP_STEP_BU_STEP   1
#define DEP_STEP_BU_TOT    2
#define DEP_STEP_DAY_STEP  3
#define DEP_STEP_DAY_TOT   4
#define DEP_STEP_DEC_STEP  5
#define DEP_STEP_DEC_TOT   6

/* predictor and corrector types available for burnup calculations (AIs) */

#define PRED_TYPE_CONSTANT   10
#define PRED_TYPE_LINEAR     11 
#define CORR_TYPE_NONE       20
#define CORR_TYPE_LINEAR     21
#define CORR_TYPE_QUADRATIC  22

#define DEP_HIS_BLOCK_SIZE            LIST_DATA_SIZE + PARAM_N_COMMON +  8

#define DEP_HIS_STEP_TYPE             LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define DEP_HIS_N_STEPS               LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define DEP_HIS_PTR_STEPS             LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define DEP_HIS_PTR_NORM              LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define DEP_HIS_PRED_TYPE             LIST_DATA_SIZE + PARAM_N_COMMON +  4 
#define DEP_HIS_PRED_NSS              LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define DEP_HIS_CORR_TYPE             LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define DEP_HIS_CORR_NSS              LIST_DATA_SIZE + PARAM_N_COMMON +  7

/*****************************************************************************/

/***** Source array **********************************************************/

#define SRC_BLOCK_SIZE                LIST_DATA_SIZE + PARAM_N_COMMON + 24

#define SRC_PTR_NAME                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define SRC_TYPE                      LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define SRC_WGT                       LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define SRC_E                         LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define SRC_PTR_XSDATA                LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define SRC_PTR_REA                   LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define SRC_PTR_MAT                   LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define SRC_PTR_CELL                  LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define SRC_PTR_UNIV                  LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define SRC_PTR_EBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define SRC_PTR_SURF                  LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define SRC_SURF_SIDE                 LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define SRC_X0                        LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define SRC_Y0                        LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define SRC_Z0                        LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define SRC_U0                        LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define SRC_V0                        LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define SRC_W0                        LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define SRC_XMIN                      LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define SRC_XMAX                      LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define SRC_YMIN                      LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define SRC_YMAX                      LIST_DATA_SIZE + PARAM_N_COMMON + 21
#define SRC_ZMIN                      LIST_DATA_SIZE + PARAM_N_COMMON + 22
#define SRC_ZMAX                      LIST_DATA_SIZE + PARAM_N_COMMON + 23

/* Source energy bin */

#define SRC_EBIN_BLOCK_SIZE           LIST_DATA_SIZE + 2

#define SRC_EBIN_EMAX                 LIST_DATA_SIZE + 0
#define SRC_EBIN_WGT                  LIST_DATA_SIZE + 1

/*****************************************************************************/

/***** Detector array ********************************************************/

#define DET_BLOCK_SIZE                LIST_DATA_SIZE + PARAM_N_COMMON + 30

#define DET_PTR_NAME                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define DET_TYPE                      LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define DET_PTR_EGRID                 LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define DET_PTR_RBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define DET_PTR_UBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define DET_PTR_LBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define DET_PTR_MBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define DET_PTR_CBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define DET_PTR_SBINS                 LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define DET_N_EBINS                   LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define DET_N_UBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define DET_N_CBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define DET_N_MBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define DET_N_LBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define DET_N_RBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define DET_N_TBINS                   LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define DET_N_TOT_BINS                LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define DET_PTR_STAT                  LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define DET_VOL                       LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define DET_PTR_MUL                   LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define DET_PTR_ADJOINT               LIST_DATA_SIZE + PARAM_N_COMMON + 20
#define DET_MESH_NX                   LIST_DATA_SIZE + PARAM_N_COMMON + 21
#define DET_MESH_XMIN                 LIST_DATA_SIZE + PARAM_N_COMMON + 22
#define DET_MESH_XMAX                 LIST_DATA_SIZE + PARAM_N_COMMON + 23
#define DET_MESH_NY                   LIST_DATA_SIZE + PARAM_N_COMMON + 24
#define DET_MESH_YMIN                 LIST_DATA_SIZE + PARAM_N_COMMON + 25
#define DET_MESH_YMAX                 LIST_DATA_SIZE + PARAM_N_COMMON + 26
#define DET_MESH_NZ                   LIST_DATA_SIZE + PARAM_N_COMMON + 27
#define DET_MESH_ZMIN                 LIST_DATA_SIZE + PARAM_N_COMMON + 28
#define DET_MESH_ZMAX                 LIST_DATA_SIZE + PARAM_N_COMMON + 29

/* Detector reaction bin */

#define DET_RBIN_BLOCK_SIZE           LIST_DATA_SIZE + 3

#define DET_RBIN_PTR_MAT              LIST_DATA_SIZE + 0
#define DET_RBIN_MT                   LIST_DATA_SIZE + 1
#define DET_RBIN_PTR_REA              LIST_DATA_SIZE + 2

/* Detector universe bin */

#define DET_UBIN_BLOCK_SIZE           LIST_DATA_SIZE + 1

#define DET_UBIN_PTR_UNI              LIST_DATA_SIZE + 0

/* Detector lattice bin */

#define DET_LBIN_BLOCK_SIZE           LIST_DATA_SIZE + 1

#define DET_LBIN_PTR_LAT              LIST_DATA_SIZE + 0

/* Detector material bin */

#define DET_MBIN_BLOCK_SIZE           LIST_DATA_SIZE + 1

#define DET_MBIN_PTR_MAT              LIST_DATA_SIZE + 0

/* Detector cell bin */

#define DET_CBIN_BLOCK_SIZE           LIST_DATA_SIZE + 1

#define DET_CBIN_PTR_CELL             LIST_DATA_SIZE + 0

/* Detector surface current */

#define DET_SBIN_BLOCK_SIZE           LIST_DATA_SIZE + 4

#define DET_SBIN_PTR_SURF             LIST_DATA_SIZE + 0
#define DET_SBIN_SURF_NORM            LIST_DATA_SIZE + 1
#define DET_SBIN_PTR_UNI              LIST_DATA_SIZE + 2
#define DET_SBIN_PREV_COL             LIST_DATA_SIZE + 3

/*****************************************************************************/

/***** User-defined energy grid **********************************************/

#define ENE_BLOCK_SIZE                LIST_DATA_SIZE + PARAM_N_COMMON +  7

#define ENE_PTR_NAME                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define ENE_TYPE                      LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define ENE_NB                        LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define ENE_EMIN                      LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define ENE_EMAX                      LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define ENE_PTR_GRID                  LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define ENE_PTR_PREDEF                LIST_DATA_SIZE + PARAM_N_COMMON +  6

/*****************************************************************************/

/***** Geometry levels *******************************************************/

/* Data stored in common array */

#define LVL_BLOCK_SIZE        LIST_DATA_SIZE + 1

#define LVL_PTR_PRIVATE_DATA  LIST_DATA_SIZE + 0

/* Data stored in private array */

#define LVL_PRIV_BLOCK_SIZE     22

#define LVL_PRIV_TYPE            0
#define LVL_PRIV_PTR_NEST_REG    1
#define LVL_PRIV_PTR_LAT         2
#define LVL_PRIV_PTR_CELL        3
#define LVL_PRIV_PTR_PBED        4
#define LVL_PRIV_PTR_PEBBLE      5
#define LVL_PRIV_X               6
#define LVL_PRIV_Y               7
#define LVL_PRIV_Z               8
#define LVL_PRIV_U               9
#define LVL_PRIV_V              10
#define LVL_PRIV_W              11
#define LVL_PRIV_LAST           12
#define LVL_PRIV_PTR_MAT        13
#define LVL_PRIV_LAT_SURF_TYPE  14
#define LVL_PRIV_LAT_SURF_NP    15
#define LVL_PRIV_LAT_SURF_C0    16
#define LVL_PRIV_LAT_SURF_C1    17
#define LVL_PRIV_LAT_SURF_C2    18
#define LVL_PRIV_LAT_SURF_C3    19
#define LVL_PRIV_LAT_SURF_C4    20
#define LVL_PRIV_PTR_UNIV       21

/*****************************************************************************/

/***** Score block ***********************************************************/

#define SCORE_BLOCK_SIZE  LIST_DATA_SIZE + 7

#define SCORE_PTR_NAME    LIST_DATA_SIZE + 0
#define SCORE_DIM         LIST_DATA_SIZE + 1
#define SCORE_PTR_NMAX    LIST_DATA_SIZE + 2
#define SCORE_PTR_DATA    LIST_DATA_SIZE + 3
#define SCORE_PTR_BUF     LIST_DATA_SIZE + 4
#define SCORE_STAT_SIZE   LIST_DATA_SIZE + 5
#define SCORE_PTR_HIS     LIST_DATA_SIZE + 6

/*****************************************************************************/

/***** Universe **************************************************************/

/* Universe types */

#define UNIVERSE_TYPE_CELL     1
#define UNIVERSE_TYPE_NEST     2
#define UNIVERSE_TYPE_LATTICE  3
#define UNIVERSE_TYPE_PBED     4
#define UNIVERSE_TYPE_SUPER    5

/* Data block */

#define UNIVERSE_BLOCK_SIZE     LIST_DATA_SIZE + 22

#define UNIVERSE_PTR_NAME       LIST_DATA_SIZE +  0
#define UNIVERSE_OPTIONS        LIST_DATA_SIZE +  1
#define UNIVERSE_TYPE           LIST_DATA_SIZE +  2
#define UNIVERSE_PTR_CELL_LIST  LIST_DATA_SIZE +  3
#define UNIVERSE_PTR_NEST       LIST_DATA_SIZE +  4
#define UNIVERSE_PTR_LAT        LIST_DATA_SIZE +  5
#define UNIVERSE_PTR_PBED       LIST_DATA_SIZE +  6
#define UNIVERSE_PTR_TRANS      LIST_DATA_SIZE +  7
#define UNIVERSE_PTR_SYM        LIST_DATA_SIZE +  8
#define UNIVERSE_MINX           LIST_DATA_SIZE +  9
#define UNIVERSE_MAXX           LIST_DATA_SIZE + 10
#define UNIVERSE_MINY           LIST_DATA_SIZE + 11
#define UNIVERSE_MAXY           LIST_DATA_SIZE + 12
#define UNIVERSE_MINZ           LIST_DATA_SIZE + 13
#define UNIVERSE_MAXZ           LIST_DATA_SIZE + 14
#define UNIVERSE_DIM            LIST_DATA_SIZE + 15
#define UNIVERSE_COL_COUNT      LIST_DATA_SIZE + 16
#define UNIVERSE_PTR_GCU        LIST_DATA_SIZE + 17
#define UNIVERSE_LEVEL          LIST_DATA_SIZE + 18
#define UNIVERSE_PTR_PRIVA_X    LIST_DATA_SIZE + 19
#define UNIVERSE_PTR_PRIVA_Y    LIST_DATA_SIZE + 20
#define UNIVERSE_PTR_PRIVA_Z    LIST_DATA_SIZE + 21

/*****************************************************************************/

/***** Particle (neutron / photon) *******************************************/

/* Particle types (indeksit pit�� menn� noin ett� sorttaus tyypin mukaan */
/* menee oikein) */

#define PARTICLE_TYPE_DUMMY    0
#define PARTICLE_TYPE_GAMMA    1
#define PARTICLE_TYPE_NEUTRON  2

/* Data block */

#define PARTICLE_BLOCK_SIZE     LIST_DATA_SIZE + 18

#define PARTICLE_IDX            LIST_DATA_SIZE +  0
#define PARTICLE_TYPE           LIST_DATA_SIZE +  1
#define PARTICLE_X              LIST_DATA_SIZE +  2
#define PARTICLE_Y              LIST_DATA_SIZE +  3
#define PARTICLE_Z              LIST_DATA_SIZE +  4
#define PARTICLE_U              LIST_DATA_SIZE +  5
#define PARTICLE_V              LIST_DATA_SIZE +  6
#define PARTICLE_W              LIST_DATA_SIZE +  7
#define PARTICLE_E              LIST_DATA_SIZE +  8
#define PARTICLE_WGT            LIST_DATA_SIZE +  9
#define PARTICLE_PREV_IMP       LIST_DATA_SIZE + 10
#define PARTICLE_PREV_IDX       LIST_DATA_SIZE + 11
#define PARTICLE_PREV_X         LIST_DATA_SIZE + 12
#define PARTICLE_PREV_Y         LIST_DATA_SIZE + 13
#define PARTICLE_PREV_Z         LIST_DATA_SIZE + 14
#define PARTICLE_PTR_HIST       LIST_DATA_SIZE + 15
#define PARTICLE_PTR_MAT        LIST_DATA_SIZE + 16
#define PARTICLE_MPI_ID         LIST_DATA_SIZE + 17

/* History data */

#define HIST_BLOCK_SIZE         LIST_DATA_SIZE + 13

#define HIST_X                  LIST_DATA_SIZE +  0
#define HIST_Y                  LIST_DATA_SIZE +  1
#define HIST_Z                  LIST_DATA_SIZE +  2
#define HIST_U                  LIST_DATA_SIZE +  3
#define HIST_V                  LIST_DATA_SIZE +  4
#define HIST_W                  LIST_DATA_SIZE +  5
#define HIST_E                  LIST_DATA_SIZE +  6
#define HIST_WGT                LIST_DATA_SIZE +  7
#define HIST_FLX                LIST_DATA_SIZE +  8
#define HIST_PTR_REA            LIST_DATA_SIZE +  9
#define HIST_PTR_MAT            LIST_DATA_SIZE + 10
#define HIST_START              LIST_DATA_SIZE + 11
#define HIST_IDX                LIST_DATA_SIZE + 12

/*****************************************************************************/

/***** Mesh plot *************************************************************/

#define MPL_BLOCK_SIZE          LIST_DATA_SIZE + PARAM_N_COMMON + 21

#define MPL_AX                  LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define MPL_NX                  LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define MPL_NY                  LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define MPL_SYM                 LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define MPL_XMIN                LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define MPL_XMAX                LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define MPL_YMIN                LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define MPL_YMAX                LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define MPL_ZMIN                LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define MPL_ZMAX                LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define MPL_FMIN                LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define MPL_FMAX                LIST_DATA_SIZE + PARAM_N_COMMON + 11
#define MPL_PMIN                LIST_DATA_SIZE + PARAM_N_COMMON + 12
#define MPL_PMAX                LIST_DATA_SIZE + PARAM_N_COMMON + 13
#define MPL_PTR_F0              LIST_DATA_SIZE + PARAM_N_COMMON + 14
#define MPL_PTR_F1              LIST_DATA_SIZE + PARAM_N_COMMON + 15
#define MPL_PTR_F2              LIST_DATA_SIZE + PARAM_N_COMMON + 16
#define MPL_PTR_FNAME           LIST_DATA_SIZE + PARAM_N_COMMON + 17
#define MPL_TYPE                LIST_DATA_SIZE + PARAM_N_COMMON + 18
#define MPL_COLMAP              LIST_DATA_SIZE + PARAM_N_COMMON + 19
#define MPL_PTR_DET             LIST_DATA_SIZE + PARAM_N_COMMON + 20

/*****************************************************************************/

/***** Temperature feedback **************************************************/

#define TFB_BLOCK_SIZE          LIST_DATA_SIZE + PARAM_N_COMMON + 12

#define TFB_PTR_REG_LIST        LIST_DATA_SIZE + PARAM_N_COMMON +  0
#define TFB_TLIM                LIST_DATA_SIZE + PARAM_N_COMMON +  1
#define TFB_PTR_NST             LIST_DATA_SIZE + PARAM_N_COMMON +  2
#define TFB_N_REG               LIST_DATA_SIZE + PARAM_N_COMMON +  3
#define TFB_PTR_MEAN_POW        LIST_DATA_SIZE + PARAM_N_COMMON +  4
#define TFB_PTR_MEAN_VTEMP      LIST_DATA_SIZE + PARAM_N_COMMON +  5
#define TFB_PTR_MAX_TEMP        LIST_DATA_SIZE + PARAM_N_COMMON +  6
#define TFB_PTR_MIN_TEMP        LIST_DATA_SIZE + PARAM_N_COMMON +  7
#define TFB_PTR_MEAN_FTEMP      LIST_DATA_SIZE + PARAM_N_COMMON +  8
#define TFB_PTR_FLUX            LIST_DATA_SIZE + PARAM_N_COMMON +  9
#define TFB_PTR_MEAN_MDENS      LIST_DATA_SIZE + PARAM_N_COMMON + 10
#define TFB_PTR_MEAN_RAD        LIST_DATA_SIZE + PARAM_N_COMMON + 11

#define TFB_REG_BLOCK_SIZE      LIST_DATA_SIZE + 11

#define TFB_REG_IDX             LIST_DATA_SIZE + 0
#define TFB_REG_PTR_MAT         LIST_DATA_SIZE + 1
#define TFB_REG_TMAX            LIST_DATA_SIZE + 2
#define TFB_REG_ITER_TEMP       LIST_DATA_SIZE + 3 
#define TFB_REG_ITER_POW        LIST_DATA_SIZE + 4
#define TFB_REG_HC              LIST_DATA_SIZE + 5
#define TFB_REG_R0              LIST_DATA_SIZE + 6
#define TFB_REG_R1              LIST_DATA_SIZE + 7
#define TFB_REG_ITER_C0         LIST_DATA_SIZE + 8
#define TFB_REG_ITER_C1         LIST_DATA_SIZE + 9 
#define TFB_REG_ITER_C2         LIST_DATA_SIZE + 10

/*****************************************************************************/

/***** Normalization *********************************************************/

#define NORM_BLOCK_SIZE         LIST_DATA_SIZE + 9

#define NORM_POWER              LIST_DATA_SIZE + 0
#define NORM_POWDENS            LIST_DATA_SIZE + 1
#define NORM_GENRATE            LIST_DATA_SIZE + 2
#define NORM_FISSRATE           LIST_DATA_SIZE + 3
#define NORM_ABSRATE            LIST_DATA_SIZE + 4
#define NORM_LOSSRATE           LIST_DATA_SIZE + 5
#define NORM_FLUX               LIST_DATA_SIZE + 6
#define NORM_SRCRATE            LIST_DATA_SIZE + 7
#define NORM_SFRATE             LIST_DATA_SIZE + 8

/*****************************************************************************/

/***** Mesh ******************************************************************/

#define MESH_BLOCK_SIZE         LIST_DATA_SIZE + 13

#define MESH_TYPE               LIST_DATA_SIZE +  0
#define MESH_CONTENT            LIST_DATA_SIZE +  1
#define MESH_N0                 LIST_DATA_SIZE +  2
#define MESH_N1                 LIST_DATA_SIZE +  3
#define MESH_N2                 LIST_DATA_SIZE +  4
#define MESH_MIN0               LIST_DATA_SIZE +  5
#define MESH_MAX0               LIST_DATA_SIZE +  6
#define MESH_MIN1               LIST_DATA_SIZE +  7
#define MESH_MAX1               LIST_DATA_SIZE +  8
#define MESH_MIN2               LIST_DATA_SIZE +  9
#define MESH_MAX2               LIST_DATA_SIZE + 10
#define MESH_PTR_RES2           LIST_DATA_SIZE + 11
#define MESH_PTR_PTR            LIST_DATA_SIZE + 12

/*****************************************************************************/

/***** Core power distribution ***********************************************/

#define CPD_BLOCK_SIZE          LIST_DATA_SIZE +  2

#define CPD_PTR_LAT             LIST_DATA_SIZE +  0
#define CPD_COL_COUNT           LIST_DATA_SIZE +  1

/*****************************************************************************/

/*****************************************************************************/

/***** Nuclide inventory list ************************************************/

#define INVENTORY_BLOCK_SIZE    LIST_DATA_SIZE +  2

#define INVENTORY_PTR_NAME      LIST_DATA_SIZE +  0
#define INVENTORY_ZAI           LIST_DATA_SIZE +  1

/*****************************************************************************/

/***** Group constant generation *********************************************/

#define GCU_BLOCK_SIZE          LIST_DATA_SIZE + 53

#define GCU_PTR_UNIV            LIST_DATA_SIZE +  0
#define GCU_RES_FG_FLX          LIST_DATA_SIZE +  1
#define GCU_RES_FG_LEAK         LIST_DATA_SIZE +  2
#define GCU_RES_FG_TOTXS        LIST_DATA_SIZE +  3
#define GCU_RES_FG_FISSXS       LIST_DATA_SIZE +  4
#define GCU_RES_FG_CAPTXS       LIST_DATA_SIZE +  5
#define GCU_RES_FG_ABSXS        LIST_DATA_SIZE +  6
#define GCU_RES_FG_ELAXS        LIST_DATA_SIZE +  7
#define GCU_RES_FG_INLXS        LIST_DATA_SIZE +  8
#define GCU_RES_FG_SCATTXS      LIST_DATA_SIZE +  9
#define GCU_RES_FG_N2NXS        LIST_DATA_SIZE + 10
#define GCU_RES_FG_REMXS        LIST_DATA_SIZE + 11
#define GCU_RES_FG_NUBAR        LIST_DATA_SIZE + 12
#define GCU_RES_FG_NSF          LIST_DATA_SIZE + 13
#define GCU_RES_FG_RECIPVEL     LIST_DATA_SIZE + 14
#define GCU_RES_FG_FISSE        LIST_DATA_SIZE + 15 
#define GCU_RES_FG_CHI          LIST_DATA_SIZE + 16 
#define GCU_RES_FG_CHIP         LIST_DATA_SIZE + 17 
#define GCU_RES_FG_CHID         LIST_DATA_SIZE + 18 
#define GCU_RES_FG_GTRANSP      LIST_DATA_SIZE + 19
#define GCU_RES_FG_GTRANSXS     LIST_DATA_SIZE + 20
#define GCU_RES_FG_SCATT0       LIST_DATA_SIZE + 21
#define GCU_RES_FG_SCATT1       LIST_DATA_SIZE + 22
#define GCU_RES_FG_SCATT2       LIST_DATA_SIZE + 23
#define GCU_RES_FG_SCATT3       LIST_DATA_SIZE + 24
#define GCU_RES_FG_SCATT4       LIST_DATA_SIZE + 25
#define GCU_RES_FG_SCATT5       LIST_DATA_SIZE + 26
#define GCU_RES_FG_P1_MUBAR     LIST_DATA_SIZE + 27

#define GCU_FUM_PTR_UNIV        LIST_DATA_SIZE + 28
#define GCU_FUM_PTR_FLX         LIST_DATA_SIZE + 29
#define GCU_FUM_PTR_TOT         LIST_DATA_SIZE + 30
#define GCU_FUM_PTR_ABS         LIST_DATA_SIZE + 32
#define GCU_FUM_PTR_MUBAR       LIST_DATA_SIZE + 34
#define GCU_FUM_PTR_FISS        LIST_DATA_SIZE + 35
#define GCU_FUM_PTR_NSF         LIST_DATA_SIZE + 36
#define GCU_FUM_PTR_CHI         LIST_DATA_SIZE + 37
#define GCU_FUM_PTR_SCATT_MTX   LIST_DATA_SIZE + 38

#define GCU_FUM_FG_B1_KINF      LIST_DATA_SIZE + 42
#define GCU_FUM_FG_B1_BUCKLING  LIST_DATA_SIZE + 43
#define GCU_FUM_FG_B1_DIFFCOEF  LIST_DATA_SIZE + 44
#define GCU_FUM_FG_B1_ABSXS     LIST_DATA_SIZE + 45
#define GCU_FUM_FG_B1_NSF       LIST_DATA_SIZE + 46
#define GCU_FUM_FG_B1_FISSXS    LIST_DATA_SIZE + 47
#define GCU_FUM_FG_B1_SCATTXS   LIST_DATA_SIZE + 48
#define GCU_FUM_FG_B1_TOTXS     LIST_DATA_SIZE + 49
#define GCU_FUM_FG_B1_FLUX      LIST_DATA_SIZE + 50
#define GCU_FUM_FG_B1_CHI       LIST_DATA_SIZE + 51
#define GCU_FUM_FG_B1_REMXS     LIST_DATA_SIZE + 52

/*****************************************************************************/
