/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : transferparticle.c                             */
/*                                                                           */
/* Created:       2012/01/17 (JLe)                                           */
/* Last modified: 2012/01/17 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Transfer source particle from one MPI task to another        */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME ""

/*****************************************************************************/

long TransferParticle(long part, long from, long to)
{
#ifdef MPI

  long sz1, sz2, nhist, tot, i0, pth, i, rc;
  MPI_Status status;
  double *src;

  /* Check MPI id */

  if ((mpiid != from) && (mpiid != to))
    return - 1;  

  /* Get size of particle and history data blocks */

  sz1 = PARTICLE_BLOCK_SIZE - LIST_DATA_SIZE;
  sz2 = HIST_BLOCK_SIZE - LIST_DATA_SIZE;

  /* Get size of history array */
  
  if ((nhist = (long)RDB[DATA_HIST_LIST_SIZE]) < 0)
    nhist = 0;

  /* Total size */

  tot = sz1 + nhist*sz2;
 
  /* Allocate memory */

  src = Mem(MEM_ALLOC, tot, sizeof(double));
  
  /* Read data */

  if (mpiid == from)
    {
      /* Check pointer */

      CheckPointer(FUNCTION_NAME, "(part)", DATA_ARRAY, part);

      /* Reset starting point */

      i0 = 0;

      /* Copy particle data */

      memcpy(&src[i0], &RDB[part + LIST_DATA_SIZE], sz1*sizeof(double));

      /* Update pointer */

      i0 = i0 + sz1;

      /* Pointer to history data */

      pth = (long)RDB[part + PARTICLE_PTR_HIST];

      /* Loop over histories */

      for (i = 0; i < nhist; i++)
	{
	  /* Check pointer */

	  CheckPointer(FUNCTION_NAME, "(pth1)", DATA_ARRAY, pth);

	  /* Copy history data */

	  memcpy(&src[i0], &RDB[pth + LIST_DATA_SIZE], sz2*sizeof(double));

	  /* Update pointer */

	  i0 = i0 + sz2;

	  /* Next */

	  pth = NextItem(pth);
	}

      /* Check pointer */

      if (i0 != tot)
	Die(FUNCTION_NAME, "Pointer error");
    }

  /* Synchronize */

  MPI_Barrier(MPI_COMM_WORLD);
  
  /* Send data */

  if (mpiid == from)
    rc = MPI_Send(src, tot, MPI_DOUBLE, to, 0, MPI_COMM_WORLD);
  else if (mpiid == to)
    rc = MPI_Recv(src, tot, MPI_DOUBLE, from, 0, MPI_COMM_WORLD, &status);
  else
    Die(FUNCTION_NAME, "Error in id");

  /* Write data back in source */

  if (mpiid == to)
    {
      /* Get new particle from stack */

      part = FromStack(PARTICLE_TYPE_NEUTRON, -1);
      CheckPointer(FUNCTION_NAME, "(part)", DATA_ARRAY, part);

      /* Reset starting point */

      i0 = 0;

      /* Copy particle data */

      memcpy(&WDB[part + LIST_DATA_SIZE], &src[i0], sz1*sizeof(double));

      /* Update pointer */

      i0 = i0 + sz1;

      /* Pointer to history data */

      pth = (long)RDB[part + PARTICLE_PTR_HIST];

      /* Loop over histories */

      for (i = 0; i < nhist; i++)
	{
	  /* Check pointer */

	  CheckPointer(FUNCTION_NAME, "(pth1)", DATA_ARRAY, pth);

	  /* Copy history data */

	  memcpy(&WDB[pth + LIST_DATA_SIZE], &src[i0], sz2*sizeof(double));

	  /* Update pointer */

	  i0 = i0 + sz2;

	  /* Next */

	  pth = NextItem(pth);
	}

      /* Check pointer */

      if (i0 != tot)
	Die(FUNCTION_NAME, "Pointer error");
    }

  /* Free temporary array */

  free(src);

#endif

  /* Return pointer to particle */

  return part;
}

/*****************************************************************************/
