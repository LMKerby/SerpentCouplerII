/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : tostack.c                                      */
/*                                                                           */
/* Created:       2011/03/09 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Stores neutron / photon to stack                             */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ToStack:"

/*****************************************************************************/

void ToStack(long ptr, long id)
{
  long type;

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Get particle type */

  type = (long)RDB[ptr + PARTICLE_TYPE];

  /* Check type and put item in list */

  if (type == PARTICLE_TYPE_NEUTRON)
    AddItem(OMPPtr(DATA_PART_PTR_NSTACK, id), ptr);
  else if (type == PARTICLE_TYPE_GAMMA)
    AddItem(OMPPtr(DATA_PART_PTR_GSTACK, id), ptr);
  else
    Die(FUNCTION_NAME, "Invalid particle type");
}

/*****************************************************************************/
