/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : fromque.c                                      */
/*                                                                           */
/* Created:       2011/03/09 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Retrieves neutron / photon from que                          */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "FromQue:"

/*****************************************************************************/

long FromQue(long id)
{
  long ptr;

  /* Get pointer */

  ptr = (long)RDB[OMPPtr(DATA_PART_PTR_QUE, id)];
  ptr = LastItem(ptr);

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Check type */

  if ((long)RDB[ptr + PARTICLE_TYPE] == PARTICLE_TYPE_DUMMY)
    {
      /* Que is empty, return null */

      return -1;
    }

  /* Remove particle from que */

  RemoveItem(ptr);

  /* Return pointer */
  
  return ptr;
}

/*****************************************************************************/
