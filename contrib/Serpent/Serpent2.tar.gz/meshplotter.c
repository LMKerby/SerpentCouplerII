/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : meshplotter.c                                  */
/*                                                                           */
/* Created:       2011/03/25 (JLe)                                           */
/* Last modified: 2012/01/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Creates png-format mesh plots                                */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#ifndef NO_GFX_MODE
#include <gd.h>
#endif

#define FUNCTION_NAME "MeshPlotter:"

#define COLOURS 127

/*****************************************************************************/

void MeshPlotter()
{

#ifndef NO_GFX_MODE

  gdImagePtr im;
  long n, m, i, j, ptrf, ptrp, ptrw, sym, type;
  long palette[COLOURS*2 + 2], R[COLOURS*2 + 2], G[COLOURS*2 + 2], 
    B[COLOURS*2 + 2];
  long sx, sy, mpl;
  double valf, valp, fmax, fmin, pmax, pmin, fave, pave;
  double **f, **p;
  char tmpstr[MAX_STR];
  FILE *fp;

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* Check corrector step */

  if ((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP) 
    return;

  /* Loop over meshes */

  mpl = (long)RDB[DATA_PTR_MPL0];

  j = 0;

  while (mpl > VALID_PTR)
    {
      /* Reduce private results */

      ReducePrivateRes();

      /* Put filename */

      if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_INT_BURN)
	sprintf(tmpstr, "%s_bstep%ld.png", GetText(mpl + MPL_PTR_FNAME),
		(long)RDB[DATA_BURN_STEP]);
      else
	sprintf(tmpstr, "%s.png", GetText(mpl + MPL_PTR_FNAME));

      /* Open file for writing */

      if ((fp = fopen(tmpstr, "w")) == NULL)
	Die(FUNCTION_NAME, "Unable to open file for writing");

      /* Get pointers to flux and power */
      
      ptrf = (long)RDB[mpl + MPL_PTR_F0];
      ptrp = (long)RDB[mpl + MPL_PTR_F1];
      ptrw = (long)RDB[mpl + MPL_PTR_F2];

      /* Check pointers */

      CheckPointer(FUNCTION_NAME, "(ptrf)", DATA_ARRAY, ptrf);
      CheckPointer(FUNCTION_NAME, "(ptrp)", DATA_ARRAY, ptrp);
      CheckPointer(FUNCTION_NAME, "(ptrw)", DATA_ARRAY, ptrw);

      /* Mesh size */

      sx = (long)RDB[mpl + MPL_NX];
      sy = (long)RDB[mpl + MPL_NY];

      /* Get type */

      type = (long)RDB[mpl + MPL_TYPE];

      /***********************************************************************/
      
      /***** Allocate memory for distribution matrices ***********************/

      f = (double **)Mem(MEM_ALLOC, sx, sizeof(double *));

      for(n = 0; n < sx; n++)
	f[n] = (double *)Mem(MEM_ALLOC, sy, sizeof(double));
      
      p = (double **)Mem(MEM_ALLOC, sx, sizeof(double *));
      
      for(n = 0; n < sx; n++)
	p[n] = (double *)Mem(MEM_ALLOC, sy, sizeof(double));
      
      /* Clear data */
      
      for (n = 0; n < sx; n++)
	for(m = 0; m < sy; m++)
	  {
	    f[n][m] = 0.0;
	    p[n][m] = 0.0;
	  }

      /***********************************************************************/

      /***** Create distributions ********************************************/

      /* Check symmetry */

      if ((sym = (long)RDB[mpl + MPL_SYM]) == 0)
	{
	  /***** No symmetry *************************************************/

	  /* Loop over values */

	  for (n = 0; n < sx; n++)
	    for(m = 0; m < sy; m++)
	      {
		/* Get values */
		
		valf = ReadMesh(ptrf, n, m, 0);
		valp = ReadMesh(ptrp, n, m, 0);

		/* NOTE: Tää ei oo nyt ihan pätevä juttu, mutta nää */
		/* pitää joka tapauksessa miettiä uudestaan. */

		if ((type == MPL_TYPE_FLUXTEMP) && (valp > 0.0))
		  valp = valp/ReadMesh(ptrw, n, m, 0);		  

		/* Write values in matrix */

		f[n][m] = f[n][m] + valf; 
		p[n][m] = p[n][m] + valp; 
	      }
	  
	  /*******************************************************************/
	}

      if (sym == 2)
	{
	  /***** 1/2 symmetry ************************************************/

	  /* Check matrix size */

	  if (sx != sy)
	    Die(FUNCTION_NAME, "Symmetry error");

	  /* Loop over values */

	  for (n = 0; n < sx; n++)
	    for(m = 0; m < sy; m++)
	      {
		/* Get values */

		valf = ReadMesh(ptrf, n, m, 0);
		valp = ReadMesh(ptrp, n, m, 0);

		/* Write values in matrix */

		f[n][m] = f[n][m] + valf; 
		f[m][n] = f[m][n] + valf; 

		p[n][m] = p[n][m] + valp; 
		p[m][n] = p[m][n] + valp; 
	      }
	  
	  /*******************************************************************/
	}

      else if (sym == 4)
	{
	  /***** 1/4 symmetry ************************************************/

	  /* Check matrix size */

	  if (sx != sy)
	    Die(FUNCTION_NAME, "Symmetry error");

	  /* Loop over values */

	  for (n = 0; n < sx; n++)
	    for(m = 0; m < sy; m++)
	      {
		/* Get values */

		valf = ReadMesh(ptrf, n, m, 0);
		valp = ReadMesh(ptrp, n, m, 0);

		/* Write values in matrix */

		f[n][m] = f[n][m] + valf; 
		f[sx - n - 1][m] = f[sx - n - 1][m] + valf; 
		f[sx - n - 1][sy - m - 1] = f[sx - n - 1][sy - m - 1] + valf; 
		f[n][sy - m - 1] = f[n][sy - m - 1] + valf; 
		
		p[n][m] = p[n][m] + valp; 
		p[sx - n - 1][m] = p[sx - n - 1][m] + valp; 
		p[sx - n - 1][sy - m - 1] = p[sx - n - 1][sy - m - 1] + valp; 
		p[n][sy - m - 1] = p[n][sy - m - 1] + valp; 
	      }
	  
	  /*******************************************************************/
	}

      else if (sym == 8)
	{
	  /***** 1/8 symmetry ************************************************/

	  /* Check matrix size */

	  if (sx != sy)
	    Die(FUNCTION_NAME, "Symmetry error");

	  /* Loop over values */

	  for (n = 0; n < sx; n++)
	    for(m = 0; m < sy; m++)
	      {
		/* Get values */

		valf = ReadMesh(ptrf, n, m, 0);
		valp = ReadMesh(ptrp, n, m, 0);

		/* Write values in matrix */

		if (valp*valf == 0.0)
		  {		
		    f[n][m] = f[n][m] + valf; 
		    f[sx-n-1][m] = f[sx-n-1][m] + valf; 
		    f[sx-n-1][sy-m-1] = f[sx-n-1][sy-m-1] + valf; 
		    f[n][sy-m-1] = f[n][sy-m-1] + valf; 
		    f[m][n] = f[m][n] + valf; 
		    f[sy-m-1][n] = f[sy-m-1][n] + valf; 
		    f[sy-m-1][sx-n-1] = f[sy-m-1][sx-n-1] + valf; 
		    f[m][sx-n-1] = f[m][sx-n-1] + valf; 
		    
		    p[n][m] = p[n][m] + valp; 
		    p[sx-n-1][m] = p[sx-n-1][m] + valp; 
		    p[sx-n-1][sy-m-1] = p[sx-n-1][sy-m-1] + valp; 
		    p[n][sy-m-1] = p[n][sy-m-1] + valp; 
		    p[m][n] = p[m][n] + valp; 
		    p[sy-m-1][n] = p[sy-m-1][n] + valp; 
		    p[sy-m-1][sx-n-1] = p[sy-m-1][sx-n-1] + valp; 
		    p[m][sx-n-1] = p[m][sx-n-1] + valp;
		  }
		else
		  {		
		    f[n][m] = 0.0;
		    f[sx-n-1][m] = 0.0;
		    f[sx-n-1][sy-m-1] = 0.0;
		    f[n][sy-m-1] = 0.0;
		    f[m][n] = 0.0;
		    f[sy-m-1][n] = 0.0;
		    f[sy-m-1][sx-n-1] = 0.0;
		    f[m][sx-n-1] = 0.0;
		    
		    p[n][m] = 0.0;
		    p[sx-n-1][m] = 0.0;
		    p[sx-n-1][sy-m-1] = 0.0;
		    p[n][sy-m-1] = 0.0;
		    p[m][n] = 0.0;
		    p[sy-m-1][n] = 0.0;
		    p[sy-m-1][sx-n-1] = 0.0;
		    p[m][sx-n-1] = 0.0;
		  }
	      }
	  
	  /*******************************************************************/
	}
    
      /***********************************************************************/

      /***** Adjust and normalize distributions ******************************/

      /* Check */

      if ((type == MPL_TYPE_FLUXPOW) || (type == MPL_TYPE_FLUXTEMP))
	{
	  /* Reset flux where power or temperature is calculated */
	  
	  for (n = 0; n < sx; n++)
	    for(m = 0; m < sy; m++)
	      if (p[n][m] > 0.0)
		f[n][m] = 0.0;
	}
      else if (type == MPL_TYPE_DET_IMP)
	{
	  /* Divide by forward flux */
	  
	  for (n = 0; n < sx; n++)
	    for(m = 0; m < sy; m++)
	      if (f[n][m] > 0.0)
		{
		  p[n][m] = p[n][m]/f[n][m];
		  f[n][m] = 0.0;
		}
	}
	
      /* Calculate average flux and get minimum */
      
      fave = 0.0;
      fmin = INFTY;
      
      i = 0;
      
      for (n = 0; n < sx; n++)
	for(m = 0; m < sy; m++)
	  if (f[n][m] > 0.0)
	    {
	      /* Add to average */
	      
	      fave = fave + f[n][m];
	      
	      /* Compare to minimum */
	      
	      if (f[n][m] < fmin)
		fmin = f[n][m];
	      
	      /* Increase counter */
	      
	      i++;
	    }
      
      /* Divide average by total */
      
      if (i > 0)
	fave = fave/i;
      else
	fave = 0.0;

      /* Calculate average power and get minimum */
      
      pave = 0.0;
      pmin = INFTY;
      
      i = 0;
      
      for (n = 0; n < sx; n++)
	for(m = 0; m < sy; m++)
	  if (p[n][m] > 0.0)
	    {
	      /* Add to average */
	      
	      pave = pave + p[n][m];
	      
	      /* Compare to minimum */
	      
	      if (p[n][m] < pmin)
		pmin = p[n][m];
	      
	      /* Increase counter */
	      
	      i++;
	    }
      
      /* Divide average by total */
      
      if (i > 0)
	pave = pave/i;
      else
	pave = 0.0;

      /* Set maximum values */
      
      fmax = 1.00*fave*2.0;
      pmax = 1.00*pave*2.0;
            
      /* Check values */

      CheckValue(FUNCTION_NAME, "fmin", "", fmin, 0.0, INFTY);
      CheckValue(FUNCTION_NAME, "fave", "", fave, 0.0, INFTY);
      CheckValue(FUNCTION_NAME, "fmax", "", fmax, 0.0, INFTY);

      CheckValue(FUNCTION_NAME, "pmin", "", pmin, 0.0, INFTY);
      CheckValue(FUNCTION_NAME, "pave", "", pave, 0.0, INFTY);
      CheckValue(FUNCTION_NAME, "pmax", "", pmax, 0.0, INFTY);

      /* Check if last cycle */

      if (RDB[DATA_SIMULATION_COMPLETED] == 1.0)
	{
	  /* Last cycle. Remember or store values */

	  if (RDB[mpl + MPL_FMIN] < 0.0)
	    WDB[mpl + MPL_FMIN] = fmin;
	  else
	    fmin = RDB[mpl + MPL_FMIN];

	  if (RDB[mpl + MPL_FMAX] < 0.0)
	    WDB[mpl + MPL_FMAX] = fmax;
	  else
	    fmax = RDB[mpl + MPL_FMAX];

	  if (RDB[mpl + MPL_PMIN] < 0.0)
	    WDB[mpl + MPL_PMIN] = pmin;
	  else
	    pmin = RDB[mpl + MPL_PMIN];

	  if (RDB[mpl + MPL_PMAX] < 0.0)
	    WDB[mpl + MPL_PMAX] = pmax;
	  else
	    pmax = RDB[mpl + MPL_PMAX];
	}

      /* Normalize */

      for (n = 0; n < sx; n++)
	for(m = 0; m < sy; m++)
	  {
	    /* Flux distribution */

	    if (f[n][m] < fmin)
	      f[n][m] = 0.0;
	    else if (f[n][m] > fmax)
	      f[n][m] = 1.0;
	    else
	      f[n][m] = (f[n][m] - fmin)/(fmax - fmin);

	    /* Power distribution */

	    if (p[n][m] < pmin)
	      p[n][m] = 0.0;
	    else if (p[n][m] > pmax)
	      p[n][m] = 1.0;
	    else
	      p[n][m] = (p[n][m] - pmin)/(pmax - pmin);
	  }
      
      /***********************************************************************/
      
      /***** Create and draw image *******************************************/

      /* Create the image */
      
      if ((im = gdImageCreate(sx, sy)) == NULL)
	Die(FUNCTION_NAME, "Unable to create image for mesh plot");
      
      /* Generate palette */
      
      MakePalette(R, G, B, COLOURS*2 + 2, (long)RDB[mpl + MPL_COLMAP]);

      palette[0] = gdImageColorAllocate(im, 0, 0, 0);  
      
      for (n = 1; n < COLOURS*2 + 2; n++)
	palette[n] = gdImageColorAllocate(im, R[n], G[n], B[n]);

      /* Draw image */
      
      for (n = 0; n < sx; n++)
	for (m = 0; m < sy; m++)
	  {
	    /* Check type */

	    if ((type == MPL_TYPE_FLUXPOW) || (type == MPL_TYPE_FLUXTEMP))
	      {
		/* Try power or temperature distribution */
		
		valp = p[n][m];
		
		if (valp > 0)
		  i = (long)((COLOURS - 1)*valp) + COLOURS + 1;
		else
		  {
		    /* Zero power -> try flux distribution */
		    
		    valf = f[n][m];
		    
		    if (valf > 0)
		      i = (long)((COLOURS - 1)*valf) + 1;
		    else
		      {
			/* Zero flux -> region is void */
			
			i = 0;
		      }
		  }
	      }
	    else
	      {
		/* Single distribution */
		
		valp = f[n][m];
		
		if (valp > 0)
		  i = (long)((2*COLOURS - 1)*valp + 1);
		else
		  i = 0;
	      }
	    
	    /* Set pixel */

	    if ((long)RDB[mpl + MPL_AX] == 3)
	      gdImageSetPixel(im, n, m, palette[i]);
	    else
	      gdImageSetPixel(im, n, sy - m - 1, palette[i]);
	  }
      
      /* Write image (png format) */
      
      gdImagePng(im, fp);

      /***********************************************************************/

      /***** Free memory etc. ************************************************/
      
      /* Free memory */
      
      gdImageDestroy(im);
      
      /* Close file */
      
      fclose(fp);

      /* Free distribution matrices */
      
      for(n = 0; n < sx; n++)
	Mem(MEM_FREE, f[n]);
      
      Mem(MEM_FREE, f);

      for(n = 0; n < sx; n++)
	Mem(MEM_FREE, p[n]);
      
      Mem(MEM_FREE, p);

      /* Next distribution */

      mpl = NextItem(mpl);

      /***********************************************************************/
    }

#endif
}

/*****************************************************************************/
