/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : mpitransfer.c                                  */
/*                                                                           */
/* Created:       2010/11/23 (JLe)                                           */
/* Last modified: 2011/11/29 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Broadcasts data block to MPI tasks                           */
/*                                                                           */
/* Comments: - From Serpent 1.1.12                                           */
/*           - Se ongelma mikä korjattiin tolla batch-jutulla saattoi johtua */
/*             siitä että luvut oli single-precision. Rutiini taisi tosin    */
/*             nopeutuakin tolla.                                            */
/*           - Serpent 2:ssa kokeillaan ilman batchaysta ja vaihdetaan       */
/*             siihen jos tulee ongelmia                                     */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "MPITransfer:"

/* Batch size (more or less arbitrary) */

#define BSIZE 10000

/*****************************************************************************/

void MPITransfer(double *dat, double *buf, long sz, long root, long meth)
{

#ifdef MPI

  long tot, sz0, rc;

  /* Synchronise */

  MPI_Barrier(MPI_COMM_WORLD);

  /* Avoid compiler warning */

  rc = 0;

  /* Check data size */
  /*
  if (sz < BSIZE)
  */

  if (1 != 2)
    {
      /***********************************************************************/

      /***** Transfer data as a single block *********************************/

      /* Broadcast or reduce block */

      if (meth == MPI_METH_BC)
	rc = MPI_Bcast(dat, sz, MPI_DOUBLE, root, MPI_COMM_WORLD);
      else if (meth == MPI_METH_RED)
	rc = MPI_Reduce(dat, buf, sz, MPI_DOUBLE, MPI_SUM, root, 
			MPI_COMM_WORLD);
      else
	Die(FUNCTION_NAME, "Invalid function type %ld", meth);

      /* Synchronise */

      MPI_Barrier(MPI_COMM_WORLD);

      /***********************************************************************/
    }
  else
    {
      /***********************************************************************/

      /***** Divide transfer into batches ************************************/

      /* Reset total transfered size */

      tot = 0;
      
      /* Loop over batches */
      
      do 
	{
	  /* Set data size */
	  
	  sz0 = BSIZE;
	  
	  /* Compare to total */
	  
	  if (tot + sz0 > sz)
	    sz0 = sz - tot;
	  
	  /* Broadcast or reduce batch */
	  
	  if (meth == MPI_METH_BC)
	    rc = MPI_Bcast(&dat[tot], sz0, MPI_DOUBLE, root, MPI_COMM_WORLD);
	  else if (meth == MPI_METH_RED)
	    rc = MPI_Reduce(&dat[tot], &buf[tot], sz0, MPI_DOUBLE, MPI_SUM, 
			    root, MPI_COMM_WORLD);
	  else
	    Die(FUNCTION_NAME, "Invalid function type %ld", meth);

	  /* Break on error */

	  if (rc != MPI_SUCCESS)
	    break;

	  /* Add to total */
	  
	  tot = tot + sz0;
	  
	  /* Synchronise */
	  
	  MPI_Barrier(MPI_COMM_WORLD);
	}
      while (tot < sz);

      /***********************************************************************/
    }

  /* Check error */
  
  if (rc != MPI_SUCCESS)
    Die(FUNCTION_NAME, "Data transfer failed with error condition %ld", rc);

#endif
}

/*****************************************************************************/
