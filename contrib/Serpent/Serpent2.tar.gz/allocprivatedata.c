/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : allocprivatedata.c                             */
/*                                                                           */
/* Created:       2011/11/10 (JLe)                                           */
/* Last modified: 2011/12/16 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Allocates and re-arranges memory for OpenMP private data     */
/*              and scoring buffers.                                         */
/*                                                                           */
/* Comments: - NOTE: memory sizes stored in DATA array are per private       */
/*                   segment.                                                */
/*                                                                           */
/*           - Jos BUF-blokin koko ylittää cachen koon niin BufVal, ym.      */
/*             funktiot jotka summaa sen yli hidastuu ihan järjettömästi.    */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "AllocPrivateData:"

/*****************************************************************************/

long AllocPrivateData(long sz, long type)
{
  long memsize, realsize, oldsize, loc0, n, blocksize, bufsize, nseg;
  double *tmp, *dat;

  /* Check OpenMP thread number */

  if (OMP_THREAD_NUM > 0)
    Die(FUNCTION_NAME, "Not allowed in threads");
  
  /* Number of segments */
  
  if ((type == BUF_ARRAY) && ((long)RDB[DATA_OPTI_SHARED_BUF] == YES))
    nseg = 1;
  else if ((type == RES2_ARRAY) && ((long)RDB[DATA_OPTI_SHARED_RES2] == YES))
    nseg = 1;
  else
    nseg = (long)RDB[DATA_OMP_MAX_THREADS];
  
  /* Avoid compiler warning */
  
  blocksize = -1;
  bufsize = -1;
  memsize = -1;
  realsize = -1;
  dat = NULL;
  
  /* Get memory, segment size and pointer */
  
  if (type == PRIVA_ARRAY)
    {
      blocksize = 100000;
      bufsize = 1000;
      
      memsize = (long)RDB[DATA_ALLOC_PRIVA_SIZE];
      realsize = (long)RDB[DATA_REAL_PRIVA_SIZE];

      dat = PRIVA;
    }
  else if (type == BUF_ARRAY)
    {
      blocksize = 1000;
      bufsize = 10;
      
      memsize = (long)RDB[DATA_ALLOC_BUF_SIZE];
      realsize = (long)RDB[DATA_REAL_BUF_SIZE];

      dat = BUF;
    }
  else if (type == RES2_ARRAY)
    {
      blocksize = 100000;
      bufsize = 1000;
      
      memsize = (long)RDB[DATA_ALLOC_RES2_SIZE];
      realsize = (long)RDB[DATA_REAL_RES2_SIZE];

      dat = RES2;
    }
  else
    Die(FUNCTION_NAME, "Invalid array type");

  /* Get pointer to free memory */
  
  loc0 = memsize;
  
  /* Check if data can fit into existing segment */
  
  if (memsize + sz + bufsize < realsize)
    {
      /***********************************************************************/
      
      /***** Sufficient segment size *****************************************/
      
      /* Update data size */
      
      memsize = memsize + sz;
      
      /***********************************************************************/
    }
  else if (nseg == 1)
    {
      /***********************************************************************/
      
      /***** Single segment, allocate more memory ****************************/
      
      /* Remember old size */
      
      oldsize = realsize;
      
      /* Calculate new size */
      
      if (sz > blocksize)
	realsize = realsize + sz + blocksize;
      else
	realsize = realsize + blocksize;
      
      /* Allocate more memory and clear data */
      
      dat = (double *)Mem(MEM_REALLOC, dat, realsize*sizeof(double));
      memset(&dat[oldsize], 0.0, (realsize - oldsize)*sizeof(double));

      /* Update size */
      
      memsize = memsize + sz;
      
      /***********************************************************************/
    }
  else
    {
      /***********************************************************************/

      /***** Allocate more memory and re-arrange data ************************/
      
      /* Allocate memory for temporary array (+1 tarvitaan koska realsize */
      /* on alussa nolla) */

      tmp = (double *)Mem(MEM_ALLOC, nseg*(realsize + 1), sizeof(double));
      
      /* Copy data */
      
      memcpy(tmp, dat, nseg*realsize*sizeof(double));
            
      /* Remember old size */
      
      oldsize = realsize;
      
      /* Calculate new size */
      
      if (sz > blocksize)
	realsize = realsize + sz + blocksize;
      else
	realsize = realsize + blocksize;
      
      /* Check */
      
      if (realsize <= oldsize)
	Die(FUNCTION_NAME, "No increase in memory size");
      
      /* Free array */
	  
      if (dat != NULL)
	Mem(MEM_FREE, dat);
	  
      /* Allocate new data */
	  
      dat = (double *)Mem(MEM_ALLOC, nseg*realsize, sizeof(double));
	  
      /* Copy data */
	  
      for (n = 0; n < nseg; n++)
	memcpy(&dat[n*realsize], &tmp[n*oldsize], memsize*sizeof(double));
      
      /* Free temporary array */
      
      Mem(MEM_FREE, tmp);
      
      /* Update data size */
      
      memsize = memsize + sz;

      /***********************************************************************/
    }
  
  /* Put new sizes and pointer */
  
  if (type == PRIVA_ARRAY)
    {
      WDB[DATA_ALLOC_PRIVA_SIZE] = (double)memsize;
      WDB[DATA_REAL_PRIVA_SIZE] = (double)realsize;
      PRIVA = dat;
    }
  else if (type == BUF_ARRAY)
    {
      WDB[DATA_ALLOC_BUF_SIZE] = (double)memsize;
      WDB[DATA_REAL_BUF_SIZE] = (double)realsize;
      BUF = dat;
    }
  else
    {
      WDB[DATA_ALLOC_RES2_SIZE] = (double)memsize;
      WDB[DATA_REAL_RES2_SIZE] = (double)realsize;
      RES2 = dat;
    }
  
  /* Check pointer */
  
  if (memsize + bufsize > realsize)
    Die(FUNCTION_NAME, "Real data size exceeded");
  else if (loc0 > memsize)
    Die(FUNCTION_NAME, "Pointer beyond memory size");
  
  /* Calculate data size */
  
  CalculateBytes();

  /* Return pointer to allocated memory */
  
  return loc0;
}

/*****************************************************************************/
