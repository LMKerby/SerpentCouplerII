/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : normcoef.c                                     */
/*                                                                           */
/* Created:       2011/05/05 (JLe)                                           */
/* Last modified: 2012/01/27 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates normalization coefficients for reaction rates     */
/*                                                                           */
/* Comments: - Coefficient can be zero in burnup calculation                 */
/*                                                                           */
/*           - Spontaaniin fissioon normeeraus menee eri tavalla kuin        */
/*             ykkösessä                                                     */
/*                                                                           */
/*           - Noi kertoimet pitää laittaa negatiivisiksi kaikista muista    */
/*             paitsi siitä mitä käytetään                                   */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "NormCoef:"

/*****************************************************************************/

double NormCoef()
{
  long loc0, ptr, i;
  double div, norm, dh, fE, fiss, capt, leak, flx, src, sf, fmass, nubar, val;

  /***************************************************************************/

  /***** Calculate reaction rates for normalization **************************/

  /* Reduce scoring buffer */

  ReduceBuffer();

  /* Avoid compiler warning */

  i = -1;
  fmass = -INFTY;
  sf = -1.0;
  dh = -1.0;

  /* Check normalization type */

  if ((long)RDB[DATA_NORM_BURN] == BURN_NORM_ALL)
    {
      fmass = RDB[DATA_INI_FMASS];
      sf = RDB[DATA_TOT_SFRATE];
      dh = RDB[DATA_TOT_DECAY_HEAT];
      i = 0;
    }
  else if ((long)RDB[DATA_NORM_BURN] == BURN_NORM_BURN)
    {
      fmass = RDB[DATA_INI_BURN_FMASS];
      sf = RDB[DATA_BURN_SFRATE];
      dh = RDB[DATA_BURN_DECAY_HEAT];
      i = 1;
    }
  else if ((long)RDB[DATA_NORM_BURN] == BURN_NORM_NOT_BURN)
    {
      fmass = RDB[DATA_INI_FMASS] - RDB[DATA_INI_BURN_FMASS];
      sf = RDB[DATA_TOT_SFRATE] - RDB[DATA_BURN_SFRATE];
      dh = RDB[DATA_TOT_DECAY_HEAT] - RDB[DATA_BURN_DECAY_HEAT];
      i = 2;
    }
  else
    Die(FUNCTION_NAME, "Invalid normalization");
  
  /* Fission rate */
  
  ptr = RDB[RES_TOT_FISSRATE];
  fiss = BufVal(ptr, i);
  
  /* Analog fission energy */
  
  ptr = (long)RDB[RES_ANA_FISSE];
  fE = BufMean(ptr, i);
  
  /* Use U235 value if analog estimator yields zero result */
  
  if (fE < ZERO)
    fE = RDB[DATA_NORM_U235_FISSE];
  
  /* Analog nubar */
  
  ptr = RDB[RES_ANA_NUBAR];
  nubar = BufMean(ptr, i);
  
  /* Use fixed value if analog estimator yields zero result */
  
  if (nubar < ZERO)
    nubar = 2.4;
  
  /* Capture rate */
  
  ptr = RDB[RES_TOT_CAPTRATE];
  capt = BufVal(ptr, i);
  
  /* Leak rate (no binning) */
  
  ptr = RDB[RES_TOT_LEAKRATE];
  leak = BufVal(ptr, 0);
  
  /* Flux */
  
  ptr = RDB[RES_TOT_FLUX];
  flx = BufVal(ptr, i);
  
  /* Source rate */
  
  ptr = RDB[RES_TOT_SRCRATE];
  src = BufVal(ptr, i);
  
  /* Reset decay heat if not used */
  
  if ((long)RDB[DATA_NORM_INCLUDE_DH] == NO)
    dh = 0.0;

  /***************************************************************************/

  /***** Calculate normalization coefficient *********************************/

  /* Avoid compiler warning */

  norm = -1.0;

  /* Check if normalization is defined */

  if ((loc0 = (long)RDB[DATA_PTR_NORM]) > VALID_PTR)
    {	    
      /* Avoid compiler warning */

      val = -1.0;
      div = 0.0;

      /* Check mode */

      if ((val = RDB[loc0 + NORM_POWER]) >= 0.0)
	{
	  /* Normalize to power */
	  
	  val = val + dh;
	  div = fiss*fE;

	  /* Check divisor */

	  if (div < ZERO)
	    Error(0, "Error in normalization: zero fission power");
	}
      else if ((val = RDB[loc0 + NORM_POWDENS]) >= 0.0)
	{
	  /* Normalize to power density */

	  val = val*fmass*1E+6 + dh;
	  div = fiss*fE;

	  /* Check divisor */

	  if (div < ZERO)
	    Error(0, "Error in normalization: zero fission power");
	}
      else if ((val = RDB[loc0 + NORM_GENRATE]) >= 0.0)
	{
	  /* Normalize to neutron generation rate */
	  
	  div = fiss*nubar;

	  /* Check divisor */

	  if (div < ZERO)
	    Error(0, "Error in normalization: zero neutron production");
	}
      else if (RDB[loc0 + NORM_SFRATE] >= 0.0)
	{
	  /* Normalize to spontaneous fission rate */
	  
	  val = sf;
	  div = src;

	  /* Check divisor */

	  if (div < ZERO)
	    Die(FUNCTION_NAME, "Zero source rate");
	}
      else if ((val = RDB[loc0 + NORM_FISSRATE]) >= 0.0)
	{
	  /* Normalize to fission rate */

	  div = fiss;

	  /* Check divisor */

	  if (div < ZERO)
	    Error(0, "Error in normalization: zero fission rate");
	}
      else if ((val = RDB[loc0 + NORM_ABSRATE]) >= 0.0)
	{
	  /* Normalize to absorption rate */

	  div = fiss + capt;

	  /* Check divisor */

	  if (div < ZERO)
	    Error(0, "Error in normalization: zero absorption rate");
	}
      else if ((val = RDB[loc0 + NORM_LOSSRATE]) >= 0.0)
	{
	  /* Normalize to loss rate */

	  div = fiss + capt + leak;

	  /* Check divisor */

	  if (div < ZERO)
	    Die(FUNCTION_NAME, "Zero loss rate");
	}
      else if ((val = RDB[loc0 + NORM_FLUX]) >= 0.0)
	{
	  /* Normalize to flux */

	  div = flx;

	  /* Check divisor */

	  if (div < ZERO)
	    Error(0, "Error in normalization: zero flux");
	}
      else if ((val = RDB[loc0 + NORM_SRCRATE]) >= 0.0)
	{
	  /* Normalize to source rate */

	  div = src;

	  /* Check divisor */

	  if (div < ZERO)
	    Die(FUNCTION_NAME, "Zero source rate");
	}
      else
	Die(FUNCTION_NAME, "Error in normalization");
    }
  else
    {
      /* If not defined, normalize to lossrate = 1 */

      val = 1.0;
      div = fiss + capt + leak;
    }

  /* Calculate coefficient */

  if (val == 0.0)
    norm = 0.0;
  else if (div > 0.0)
    norm = val/div;
  else 
    Die(FUNCTION_NAME, "Division by zero");

  /* Check value */

  if (!((norm >= 0.0) && (norm < INFTY)))
    Die(FUNCTION_NAME, "Error in normalization (norm = %E)", norm);

  /* Return coefficient */

  return norm;
}

/*****************************************************************************/
