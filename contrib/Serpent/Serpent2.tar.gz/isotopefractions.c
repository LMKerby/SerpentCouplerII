/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : isotopefractions.c                             */
/*                                                                           */
/* Created:       2010/12/28 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates isotope fractions and material densities          */
/*                                                                           */
/* Comments: - Kaikkia kombinaatioita ei oo vielä testattu                   */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "IsotopeFractions:"

/*****************************************************************************/

void IsotopeFractions(long mat)
{
  long iso, nuc;
  double sum, adens;

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "mat", DATA_ARRAY, mat);

  /* Check pointer to composition */

  if ((long)RDB[mat + MATERIAL_PTR_COMP] < VALID_PTR)
    {
      /* Check pointer to mixture */

      if ((long)RDB[mat + MATERIAL_PTR_MIX] > VALID_PTR)
	return;
      else
	Error(mat, "Material %s has no composition", 
	      GetText(mat + MATERIAL_PTR_NAME));
    }

  /***************************************************************************/

  /***** Normalize composition ***********************************************/

  /* Loop until composition is atomic (once if atomic fractions or densities */
  /* given, twice if mass fractions or densities given). */

  do
    {
      /* Calculate sum */

      sum = 0.0;

      /* Loop over composition */

      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
      while (iso > 0)
	{
	  /* Pointer to nuclide */
	  
	  nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

	  /* Set fissile material flag */

	  if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_FISSILE)
	    SetOption(mat + MATERIAL_OPTIONS, OPT_FISSILE_MAT);
	  
	  /* Get atomic density */

	  adens = RDB[iso + COMPOSITION_ADENS];
	  CheckValue(FUNCTION_NAME, "adens", "", adens, -INFTY, INFTY);

	  /* Check type and add to sum */
	  
	  if ((long)RDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_SAB)
	    sum = sum + adens;
	  
	  /* Next isotope */
	  
	  iso = NextItem(iso);
	}
      
      /* Check sum */
      
      if (sum == 0.0)
	Error(mat, "Material %s has no composition", 
	      GetText(mat + MATERIAL_PTR_NAME));
      
      /* Normalise fractions */
      
      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
            while (iso > 0)
	{
	  /* Pointer to nuclide */
	  
	  nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
      
	  /* Divide by sum */
	  
	  if ((WDB[iso + COMPOSITION_ADENS] = 
	       RDB[iso + COMPOSITION_ADENS]/sum) < 0.0)
	    Error(mat, "Mixed atomic and mass fractions in material %s",
		  GetText(mat + MATERIAL_PTR_NAME));
	  
	  /* Convert to atomic fraction if mass fraction given */
	  
	  if (sum < 0.0)
	    {
	      /* Atomic weight is zero for lost nuclide */

	      if (RDB[nuc + NUCLIDE_AW] > 0.0)
		WDB[iso + COMPOSITION_ADENS] = 
		  RDB[iso + COMPOSITION_ADENS]/RDB[nuc + NUCLIDE_AW];
	      else
		WDB[iso + COMPOSITION_ADENS] = 0.0;		
	    }

	  /* Next isotope */
	  
	  iso = NextItem(iso);
	}
    }
  while (sum < 0.0);

  /***************************************************************************/

  /***** Calculate material densities ****************************************/

  sum = 0.0;

  /* Loop over composition */
  
  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
  while (iso > 0)
    {
      /* Pointer to nuclide */
      
      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
    
      /* Check type and add to sum */
      
      if ((long)WDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_SAB)
	sum = sum + RDB[iso + COMPOSITION_ADENS]*RDB[nuc + NUCLIDE_AW];
      
      /* Next isotope */
      
      iso = NextItem(iso);
    }

  /* Check given density */

  if (RDB[mat + MATERIAL_ADENS] > 0.0)
    {
      /* Put mass density */

      WDB[mat + MATERIAL_MDENS] = sum*RDB[mat + MATERIAL_ADENS]/N_AVOGADRO;
    }
  else if (RDB[mat + MATERIAL_ADENS] < 0.0)
    {
      /* Put mass density */

      WDB[mat + MATERIAL_MDENS] = -RDB[mat + MATERIAL_ADENS];

      /* Put atomic density */

      WDB[mat + MATERIAL_ADENS] = N_AVOGADRO*RDB[mat + MATERIAL_MDENS]/sum;

    }
  else
    Error(mat, "Zero density in material %s", 
	  GetText(mat + MATERIAL_PTR_NAME));

  /***************************************************************************/

  /***** Convert atomic fractions to densities *******************************/

  /* Loop over composition */

  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
  while (iso > 0)
    {
      /* Multiply by atomic density */
      
      WDB[iso + COMPOSITION_ADENS] = 
	RDB[iso + COMPOSITION_ADENS]*RDB[mat + MATERIAL_ADENS];
	  
      /* Next isotope */
	  
      iso = NextItem(iso);
    }

  /***************************************************************************/
}

/*****************************************************************************/
