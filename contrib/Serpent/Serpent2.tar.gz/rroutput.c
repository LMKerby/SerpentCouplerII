/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : rroutput.c                                     */
/*                                                                           */
/* Created:       2011/01/20 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Writes analog reaction rate estimates into file              */
/*                                                                           */
/* Comments: - Bin arguments are temporarily used by testxs.c                */
/*                                                                           */
/*           - Tää kaataa testilaskut                                        */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "RROutput:"

/*****************************************************************************/

void RROutput(long bin1, long bin2)
{
  long nuc, rea, ptr;
  char tmpstr[MAX_STR];
  FILE *fp;

  /* !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */

  return;

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* Set filename */

  sprintf(tmpstr, "%s_rr%ld%ld.m", GetText(DATA_PTR_INPUT_FNAME), bin1, bin2);

  fprintf(out, "Printing analog reaction rates into file \"%s\"...\n", tmpstr);

  /* Open file for writing */

  if ((fp = fopen(tmpstr, "w")) == NULL)
    Die(FUNCTION_NAME, "Unable to open file for writing");

  /***************************************************************************/

  /***** Microscopic reaction rates ******************************************/

  /* Print nuclide names and mt's */

  fprintf(fp, "rea_names = [\n");

  /* Loop over nuclides */
  
  nuc = (long)RDB[DATA_PTR_NUC0];

  while (nuc > VALID_PTR)
    {
      /* Loop over reactions */

      rea = (long)RDB[nuc + NUCLIDE_PTR_REA];

      while (rea > VALID_PTR)
	{
	  /* Check tally pointer and print name */

	  if ((long)RDB[rea + REACTION_PTR_ANA_RATE] > VALID_PTR)
	    fprintf(fp, "'%10s %4ld'\n", GetText(nuc + NUCLIDE_PTR_NAME),
		    (long)RDB[rea + REACTION_MT]);
	  
	  /* Next reaction */

	  rea = NextItem(rea);
	}

      /* Next nuclide */

      nuc = NextItem(nuc);
    }
  
  fprintf(fp, "];\n\n");

  /* Print reaction rates */

  fprintf(fp, "rea_rates = [\n");

  /* Loop over nuclides */
  
  nuc = (long)RDB[DATA_PTR_NUC0];

  while (nuc > VALID_PTR)
    {
      /* Loop over reactions */

      rea = (long)RDB[nuc + NUCLIDE_PTR_REA];

      while (rea > VALID_PTR)
	{
	  /* Check tally pointer and print name */

	  if ((ptr = (long)RDB[rea + REACTION_PTR_ANA_RATE]) > VALID_PTR)
	    fprintf(fp, "%12.5E %7.5f\n", Mean(ptr, 0), RelErr(ptr, 0));
	  
	  /* Next reaction */

	  rea = NextItem(rea);
	}

      /* Next nuclide */

      nuc = NextItem(nuc);
    }

  fprintf(fp, "];\n\n");

  /***************************************************************************/

  /* Close file */

  fclose(fp);

  /* Exit */
  
  fprintf(out, "OK.\n\n");
}

/*****************************************************************************/
