/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : combinefissionyields.c                         */
/*                                                                           */
/* Created:       2010/09/12 (JLe)                                           */
/* Last modified: 2012/02/01 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Combines fission yields into a single list of nuclides       */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CombineFissionYields:"

/*****************************************************************************/

void CombineFissionYields()
{
  long nuc, rea, yld, ptr, loc0, ZAI, Z, A, nfp, n, tot;
  double *zai, *all;

  /***************************************************************************/

  /***** Read fp ID's and temperatures ***************************************/

  /* Loop over nuclides */

  nuc = (long)RDB[DATA_PTR_NUC0];

  while (nuc > VALID_PTR)
    {
      /* Check that nuclide has fission yield data */

      if (((long)RDB[nuc + NUCLIDE_PTR_NFY_DATA] > VALID_PTR) ||
	  ((long)RDB[nuc + NUCLIDE_PTR_SFY_DATA] > VALID_PTR))
	{

	  /* Check if list exists */

	  if ((ptr = (long)RDB[DATA_PTR_FP_LIB_ID_LIST]) > VALID_PTR)
	    {
	      /* Loop over list */

	      while (ptr > VALID_PTR)
		{
		  /* Compare library ID's and temperatures */
		  
		  if ((RDB[ptr + FP_IDENT_TEMP] == RDB[nuc + NUCLIDE_TEMP])
		      && CompareStr(ptr + FP_IDENT_PTR_ID, nuc + 
				    NUCLIDE_PTR_LIB_ID))
		    break;

		  /* Next */

		  ptr = NextItem(ptr);
		}
	    }

	  /* Add new if not found */

	  if (ptr < 1)
	    {
	      /* Add item */
	      
	      ptr = NewItem(DATA_PTR_FP_LIB_ID_LIST, FP_IDENT_BLOCK_SIZE);
	      
	      /* Put id and temperature */
	      
	      WDB[ptr + FP_IDENT_PTR_ID] = RDB[nuc + NUCLIDE_PTR_LIB_ID];
	      WDB[ptr + FP_IDENT_TEMP] = RDB[nuc + NUCLIDE_TEMP];
	    }
	}

      /* Next */
      
      nuc = NextItem(nuc);
    }

  /* Close list */

  if ((ptr = (long)RDB[DATA_PTR_FP_LIB_ID_LIST]) > VALID_PTR)
    CloseList(ptr);

  /***************************************************************************/

  /***** Read fission product ZAI's ******************************************/

  /* Allocate memory for vectors */

  zai = (double *)Mem(MEM_ALLOC, MAX_FP_NUCLIDES, sizeof(double));

  all = NULL;

  /* Reset count */

  tot = 0;

  /* Loop over nuclides */

  nuc = (long)RDB[DATA_PTR_NUC0];

  while (nuc > VALID_PTR)
    {
      if (((long)RDB[nuc + NUCLIDE_PTR_NFY_DATA] > VALID_PTR) ||
	  ((long)RDB[nuc + NUCLIDE_PTR_SFY_DATA] > VALID_PTR))
	{
	  /* Loop over reactions */
	  
	  rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
	  
	  while (rea > VALID_PTR)
	    {
	      /* Get pointer to yield */
	      
	      if ((yld = (long)RDB[rea + REACTION_PTR_FISSY]) > VALID_PTR)
		{
		  /* Get pointer to distribution */
		  
		  if ((yld = (long)RDB[yld + FISSION_YIELD_PTR_DISTR]) < 0)
		    Die(FUNCTION_NAME, "No pointer to distribution");
		  
		  /* Loop over yield */
		  
		  nfp = 0;
		  while ((loc0 = ListPtr(yld, nfp)) > VALID_PTR)
		    {		  
		      /* Get ZAI */
		      
		      ZAI = (long)RDB[loc0 + FY_TGT_ZAI];

		      /* Separate Z and A for check */
		      
		      Z = (long)((double)ZAI/10000.0);
		      A = (long)(ZAI/10.0 - 1000.0*Z);
		      
		      /* Check values */
		      
		      CheckValue(FUNCTION_NAME, "Z", "", Z, 1, 80);
		      CheckValue(FUNCTION_NAME, "A", "", A, 1, 210);
		      
		      /* Add to vector */
		      
		      zai[nfp++] = (double)ZAI;
		    }
		  
		  /* Sort array */
		  
		  SortArray(zai, nfp);
		  
		  /* Add nuclides to total vector */
		  
		  all = AddPts(all, &tot, zai, nfp);
		}
	      
	      /* Next reaction */
	      
	      rea = NextItem(rea);
	    }
	}
      
      /* Next nuclide */
      
      nuc = NextItem(nuc);
    }

  /* Check duplicates and order */

  for (n = 1; n < tot; n++)
    if (all[n] <= all[n - 1])
      Die(FUNCTION_NAME, "Error in list");

  /* Allocate memory for list */

  loc0 = ReallocMem(DATA_ARRAY, tot + 1);

  /* Put pointer */

  WDB[DATA_PTR_FP_ZAI_LIST] = (double)loc0;

  /* Read data */

  for (n = 0; n < tot; n++)
    WDB[loc0++] = all[n];
  
 /* Null terminator */

  WDB[loc0] = -1.0;

  /* Set size */

  WDB[DATA_TOT_FP_NUCLIDES] = (double)tot;

  /* Free memory */

  Mem(MEM_FREE, zai);
  Mem(MEM_FREE, all);
}

/*****************************************************************************/
