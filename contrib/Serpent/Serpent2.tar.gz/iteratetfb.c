/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : iteratetfb.c                                   */
/*                                                                           */
/* Created:       2012/01/11 (JLe)                                           */
/* Last modified: 2012/01/25 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates material temperatures for temperature feedback    */
/*                                                                           */
/* Comments: - Tää ei välttämättä vielä toimi reproducible MPI -moodissa     */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "IterateTFB:"

/*****************************************************************************/

void IterateTFB()
{
  long tfb, reg, nst, mat, ptr, i;
  double Tlim, Tout, Tin, r0, r1, P, k, T, PowIn, PowEff, c0, c1, c2, NPin;
  double Tp, Ti, e;
  
  /* Check flag */

  if ((long)RDB[DATA_USE_TFB] == NO)
    return;

  /* Pointer to feedbacks (CheckPointer -funktiolla pystyy helposti   */
  /* tarkistamaan että pointteri in järkevissä rajoissa, eikä esim. 0 */
  /* funktio käännetään mukaan vain DEBUG-moodissa, eikä se muuten    */
  /* vaikuta ajoaikaan.) */

  tfb = (long)RDB[DATA_PTR_TFB0];
  CheckPointer(FUNCTION_NAME, "(tfb)", DATA_ARRAY, tfb);

  /* Loop over feedbacks (perustietorakenne on linkitetty lista, jossa      */
  /* siirrytään eteen- ja taaksepäin NextItem() ja PrevItem() -funktioilla. */

  fprintf(out,"\n");
  while (tfb > VALID_PTR)
    {
      /* Get boundary condition (CheckValue -funktio toimii samaan tapaan */
      /* kuin CheckPointer, ja sillä voi tarkistaa että muuttujan arvo    */
      /* on annetuissa rajoissa.) */

      Tlim = RDB[tfb + TFB_TLIM];
      CheckValue(FUNCTION_NAME, "tfb", "", tfb, 273.15, 1E+4);

      /* Get pointer to nest ("pin" -rakenne on osa laajempaa "nest"   */
      /* -geometriatyyppiä, joka koostuu sisäkkäisistä pinnoista jotka */
      /* eivät leikkaa toisiaan. Pin on käytännössä nest, jonka kaikki */
      /* pinnat ovat origokeskisiä sylintereitä.) */

      nst = (long)RDB[tfb + TFB_PTR_NST];
      CheckPointer(FUNCTION_NAME, "(nst)", DATA_ARRAY, nst);
      NPin = RDB[nst + NEST_COUNT];

      /* Tekstistringeihin pääsee käsiksi GetText() -funktiolla */

      fprintf(out, "Pin %s, count %f.0 - Tlim = %1.2f:\n", GetText(nst + NEST_PTR_NAME), NPin,
	      Tlim);
      /* Pointer to regions */


      reg = (long)RDB[tfb + TFB_PTR_REG_LIST];
      CheckPointer(FUNCTION_NAME, "(reg)", DATA_ARRAY, reg);

      /* Get total linear power of the pin */

      PowIn = 0.0;

      while(reg > VALID_PTR)
        {
          PowIn = PowIn + RDB[reg + TFB_REG_ITER_POW];;
          reg = NextItem(reg);
        }

      PowIn = PowIn/NPin;

      /* fprintf(out, "Linear power of the pin: %.2f\n",PowIn); */

      reg = (long)RDB[tfb + TFB_PTR_REG_LIST];
      CheckPointer(FUNCTION_NAME, "(reg)", DATA_ARRAY, reg);

      /* Jos noi alueet pitää loopata päinvastaisessa järjestyksessä, niin */
      /* se onnistuu ottamalla ensin reg = LastItem(reg), ja korvaamalla   */
      /* reg = NextItem(reg) silmukan lopussa reg = PrevItem(reg):llä. */
      /* Vaihdettu järjestys (VVa) */

      /* The limit temperature is the outer temperature of the outermost */
      /* region */

      Tout = Tlim;

      /* Loop over regions */

      reg = LastItem(reg);
      while (reg > VALID_PTR)
	{
	  /* Get inner and outer radii (Toi rakenne on sortataan säteen   */
	  /* mukaan ProcessTFB():ssä, ja samalla tarkistetaan että kaikki */
	  /* alueet on annettu ja materiaali ei ole void. Eli sisemmän    */
	  /* alueen r1 == ulomman r0.) */

	  r0 = RDB[reg + TFB_REG_R0];
	  r1 = RDB[reg + TFB_REG_R1];

	  /* Get heat conductivity (en tiedä millä tota yleensä merkitään) */
          /* Unit (W/cmK)*/

	  k = RDB[reg + TFB_REG_HC];

	  /* Get power (2D-geometriassa toi on lineaariteho yksikössä W/cm) */

	  P = RDB[reg + TFB_REG_ITER_POW]/NPin;

          /* Update linear power flowing in from inner rings */

          PowIn = PowIn - RDB[reg + TFB_REG_ITER_POW]/NPin;

          if(PowIn < 0) 
	    PowIn = 0;

	  /* Pointer to material */

	  mat = (long)RDB[reg + TFB_REG_PTR_MAT];
	  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);
	  
	  /* Materiaaliominaisuudet löytyy MATERIAL_ -datablokista */
	  /* locations.h, rivi 594 eteenpäin. Esim. massatiheyteen */
	  /* pääsee kiinni RDB[mat + MATERIAL_MDENS]. */

	  /* Insert solution here */
          
          /* Different relation has to be used for the innermost region */
          /* This calculates also the constants for                     */
          /* T(r) = c0*r^2 + c1*ln(r) + c2 */
          if (PrevItem(reg) > VALID_PTR)
            {
              /* non-central region                           */

              Tin = Tout + P/(4*PI*k) + (PowIn/(2*PI*k) - 
                    (P*pow(r0,2))/((2*PI*k)*(pow(r1,2)-pow(r0,2)))) 
		*log(r1/r0);

              c0 = -P/(4*PI*k*(pow(r1,2)-pow(r0,2)));
              c1 = (P/(4*PI*k) + Tout -Tin)/log(r1/r0);
              c2 = ((Tin - c0*pow(r0,2))*log(r1) - (Tout - c0*pow(r1,2))
		    *log(r0))/log(r1/r0);

              if (RDB[mat + MATERIAL_MDENS] < 0.01)
		{
                  fprintf(out,"This seems to be a gas:\n");
                  Ti=Tout;
                  e=0.2;
                  
		  do
		    {
		      Tp=Ti;
		      PowEff = (PowIn-e*5.6704E-12*2*PI*r0*
				(pow(Ti,4)-pow(Tout,4)));
		      
		      if (PowEff < 0) 
			PowEff = 0.0;
                    
		      Ti = Tout + (PowEff/(2*PI*k) ) * log(r1/r0);
                     
		      /* printf("Tin %f",Tin); */
		    }
		  while(fabs(Tp-Ti)>1);
		  
		  /*fprintf(out, "Tin2= %1.5E\n", Ti);*/
                 
		  Tin=Ti;
		}
            }
          else
            {
              /* Central region */
              
	      Tin = Tout + P/(4*PI*k);
              c0 =-P/(4*PI*k*pow(r1,2));
              c1 = 0;
              c2 = Tout-c0*pow(r1,2);
            }
	  
	  fprintf(out, "%-8s r0 = %1.5E, r1 = %1.5E, k = %1.5E, Tout = %1.5E, Tin = %1.5E, T = %1.5E\n",
		  GetText(mat + MATERIAL_PTR_NAME), r0, r1, k, Tout, Tin, T);

	  /***********************************/
	  
	  /* Store value for next cycle (tämä on se arvo minkä */
	  /* GetTemp() -funktio lukee ja palauttaa). */

          T= 2*(c0/4*(pow(r1,4)-pow(r0,4)) + 
		c1/4*(pow(r1,2)*(2*log(r1)-1)-pow(r0,2)
		      *(2*log(r0)-1))+c2/2*(pow(r1,2)-pow(r0,2)))
	    /(pow(r1,2)-pow(r0,2));
	  
	  WDB[reg + TFB_REG_ITER_TEMP] = T;
	  WDB[reg + TFB_REG_ITER_C0] = c0;
	  WDB[reg + TFB_REG_ITER_C1] = c1;
	  WDB[reg + TFB_REG_ITER_C2] = c2;

	  /***********************************/

	  /* Materiaalin tiheys ja säteet (tallennetaan vakioarvot,  */
	  /* näitä voi käyttää suoraan jos lämpölaajeneminen otetaan */
	  /* jossain vaiheessa huomioon */
	  
	  i = (long)RDB[reg + TFB_REG_IDX];

	  /* Maximum temperature */
		  
	  ptr = (long)RDB[tfb + TFB_PTR_MAX_TEMP];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(Tin, 1.0, ptr, 0, i);

	  /* Minimum temperature */
		  
	  ptr = (long)RDB[tfb + TFB_PTR_MIN_TEMP];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(Tout, 1.0, ptr, 0, i);

	  /* Density */
		  
	  ptr = (long)RDB[tfb + TFB_PTR_MEAN_MDENS];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	  AddBuf(RDB[mat + MATERIAL_MDENS], 1.0, ptr, 0, i);
	  
	  /* Radius */

	  ptr = (long)RDB[tfb + TFB_PTR_MEAN_RAD];
	  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

	  if (i == 0)
	    AddBuf(r0, 1.0, ptr, 0, i);

	  AddBuf(r1, 1.0, ptr, 0, i + 1);

	  /***********************************/


	  
	  /* Next region */

	  reg = PrevItem(reg);

          /* The outer temperature for the next ring is Tin of this ring */
          
	  Tout=Tin;
	}
      
      /* Next feedback */
      
      tfb = NextItem(tfb);
    }
}

/*****************************************************************************/
