/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processmaterials.c                             */
/*                                                                           */
/* Created:       2010/12/28 (JLe)                                           */
/* Last modified: 2012/01/08 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Processes material compositions, sets nuclide and reaction   */
/*              lists.                                                       */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessMaterials:"

/*****************************************************************************/

void ProcessMaterials()
{
  long mat, ptr, nmat, i, n;

  /* Check burnup step */

  if ((long)RDB[DATA_BURN_STEP] > 0)
    Die(FUNCTION_NAME, "Should not be here");

  /* Pointer to material list */
  
  if ((mat = (long)RDB[DATA_PTR_M0]) < VALID_PTR)
    Error(0, "No material definitions");
  
  fprintf(out, "Normalizing compositions and processing mixtures...\n");
  
  /* Calculate fractions */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      IsotopeFractions(mat);
      mat = NextItem(mat);
    }

  /* Process mixtures */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      ProcessMixture(mat, 0);
      mat = NextItem(mat);
    }

  fprintf(out, "OK.\n\n");

  /* Process burnable materials */

  ProcessBurnMat();

  /* Close composition lists */
     
  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    { 
      ptr = (long)RDB[mat + MATERIAL_PTR_COMP];
      CloseList(ptr);
      mat = NextItem(mat);
    }

  /* Calculate number of materials */

  nmat = 0;

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Add counter */

      nmat++;
      
      /* Next material */

      mat = NextItem(mat);
    }

  /* Put to data */

  WDB[DATA_N_MATERIALS] = (double)nmat;
   
  /* Allocate memory for reaction lists and macroscopic cross sections */

  AllocMacroXS();

  /***************************************************************************/
  
  /***** Assign MPI and OpenMP numbers to materials **************************/

  /* Set MPI id's */

  i = 0;

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check burn-flag */
      
      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	{
	  /* Set id */

	  WDB[mat + MATERIAL_MPI_ID] = (double)(i++);
	  
	  /* Check id */
	  
	  if (i == mpitasks)
	    i = 0;
	}
      else
	WDB[mat + MATERIAL_MPI_ID] = -1.0;
            
      /* Next material */

      mat = NextItem(mat);
    }

  /* Reset OpenMP id's */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Reset id */

      WDB[mat + MATERIAL_OMP_ID] = -1.0;
      
      /* Next material */

      mat = NextItem(mat);
    }

  /* Get number of materials (NOTE: tähän joku fiksu tapa hoitaa */
  /* ei-poltettavat materiaalit */

  nmat = (double)RDB[DATA_N_MATERIALS];

  /* Number of materials per thread */

  nmat = (long)((double)nmat/RDB[DATA_OMP_MAX_THREADS]);

  /* Pointer to first material */

  mat = (long)RDB[DATA_PTR_M0];

  /* Loop over OpenMP threads */

  for (i = 0; i < (long)RDB[DATA_OMP_MAX_THREADS]; i++)
    {
      /* Loop over materials per thread */

      for (n = 0; n < nmat; n++)
	{
	  /* Check material pointer */

	  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

	  /* Put id */

	  WDB[mat + MATERIAL_OMP_ID] = (double)i;

	  /* Next material */

	  mat = NextItem(mat);
	}
    }

  /* Reset index */

  i = 0;

  /* Loop over remaining */

  while (mat > VALID_PTR)
    {
      /* Put id */
      
      WDB[mat + MATERIAL_OMP_ID] = (double)i;
      
      /* Increase counter */
      
      if (i++ == (long)RDB[DATA_OMP_MAX_THREADS])
	i = 0;
      
      /* Next material */
      
      mat = NextItem(mat);
    }

  /* Check id's and count materials assigned to thread 0 */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check id's */

      if ((long)RDB[mat + MATERIAL_OMP_ID] < 0)
	Die(FUNCTION_NAME, "OpenMP id not set");
      else if ((long)RDB[mat + MATERIAL_OMP_ID] == 0)
	{
	  /* Add total count */

	  WDB[DATA_MATERIALS_THREAD0] = RDB[DATA_MATERIALS_THREAD0] + 1.0;

	  /* Check burn flag and add count */

	  if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	    WDB[DATA_BURN_MATERIALS_THREAD0] = 
	      RDB[DATA_BURN_MATERIALS_THREAD0] + 1.0;
	}

      /* Next material */

      mat = NextItem(mat);
    }

  /***************************************************************************/

  /* Calculate memory allocated for burnable materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check flag */

      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	WDB[DATA_BURN_MAT_BYTES] = RDB[DATA_BURN_MAT_BYTES] +
	  RDB[mat + MATERIAL_MEM_SIZE];

      /* Next material */

      mat = NextItem(mat);
    }

  /* Print material data */
  
  PrintMaterialData();
}

/*****************************************************************************/
