/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processinventory.c                             */
/*                                                                           */
/* Created:       2011/05/24 (JLe)                                           */
/* Last modified: 2011/12/30 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Puts inventory flags in nuclides, etc.                       */
/*                                                                           */
/* Comments: - Transport-dataa ei lueta inventory-listasta samaan tapaan     */
/*             kuin ykk�sess�.                                               */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessInventory:"

/*****************************************************************************/

void ProcessInventory()
{
  long nuc, loc0, ZAI, i, n, m, ptr;
  char name[MAX_STR], *str;

  /* Get pointer */

  if ((loc0 = (long)RDB[DATA_BURN_PTR_INVENTORY]) < VALID_PTR)
    return;

  /***************************************************************************/
  
  /***** Check for all-option ************************************************/

  /* Check first entry */

  if (!strcasecmp(GetText(loc0 + INVENTORY_PTR_NAME), "all"))
    {
      fprintf(out, "Adding all nuclides in inventory list...\n");
      
      /* Reset pointer */
      
      WDB[DATA_BURN_PTR_INVENTORY] = NULLPTR;
      
      /* Reset index */
      
      i = 0;
      
      /* Loop over nuclides */
      
      nuc = (long)RDB[DATA_PTR_NUC0];
      while (nuc > VALID_PTR)
	{
	  /* Add nuclide to inventory */
	  
	  loc0 = NewItem(DATA_BURN_PTR_INVENTORY, INVENTORY_BLOCK_SIZE);
	  
	  /* Put name */
	  
	  sprintf(name, "%s", ZAItoIso((long)RDB[nuc + NUCLIDE_ZAI], 3));
	  WDB[loc0 + INVENTORY_PTR_NAME] = PutText(name);
	  
	  /* Put ZAI */
	  
	  WDB[loc0 + INVENTORY_ZAI] = RDB[nuc + NUCLIDE_ZAI];
	  
	  /* Set index */
	  
	  WDB[nuc + NUCLIDE_INVENTORY_IDX] = (double)i;
	  
	  /* Add counter */
	  
	  i++;
	  
	  /* Next nuclide */
	  
	  nuc = NextItem(nuc);
	}

      fprintf(out, "OK.\n\n");

      /* Put number of nuclides */

      WDB[DATA_BURN_INVENTORY_NUCLIDES] = (double)i;
  
      /* Exit subroutine */

      return;
    }

  /***************************************************************************/
  
  /***** Process list ********************************************************/

  fprintf(out, "Processing nuclide inventory list...\n");

  /* Reset index */

  i = 0;

  /* Loop over list */

  while (loc0 > VALID_PTR)
    {
      /* Pointer to text */

      str = &ASCII[(long)RDB[loc0 + INVENTORY_PTR_NAME]];

      /* Remove dashes */

      n = 0;
      m = 0;

      while (str[n] != '\0')
	{
	  if (str[n] != '-')
	    str[m++] = str[n];

	  n++;
	}
      
      str[m] = '\0';

      /* Get name */

      sprintf(name, "%s", GetText(loc0 + INVENTORY_PTR_NAME));

      /* TODO: Check specials */

      /* Get ZA */

      if ((ZAI = IsotoZAI(name)) < 0)
	ZAI = atoi(name);

      /* Check value */

      if (ZAI < 1)
	Error(0, "Error in inventory list: \"%s\" is not a valid entry", name);

      /* Put ZAI */

      WDB[loc0 + INVENTORY_ZAI] = (double)ZAI;

      /* Reset count */

      n = 0;

      /* Find nuclides */

      nuc = (long)RDB[DATA_PTR_NUC0];
      while (nuc > VALID_PTR)
	{
	  /* Compare ZAI and Z */
	  
	  if (((long)RDB[nuc + NUCLIDE_ZAI] == ZAI) ||
	      ((long)RDB[nuc + NUCLIDE_Z] == ZAI))
	    {
	      /* Set index */

	      WDB[nuc + NUCLIDE_INVENTORY_IDX] = (double)i;

	      /* Add counter */

	      n++;
	    }

	  /* Next nuclide */

	  nuc = NextItem(nuc);
	}

      /* Check count */

      if ((n == 0) && ((long)RDB[DATA_PTR_NUC0] > VALID_PTR))
	{
	  /* Not found */

	  Note(0, "Nuclide %s not found in compositions", name);

	  /* Copy pointer */

	  ptr = loc0;

	  /* Next item */

	  loc0 = NextItem(loc0);

	  /* Remove nuclide from list */

	  RemoveItem(ptr);
	}
      else
	{
	  /* Update index */

	  i++;

	  /* Next item */

	  loc0 = NextItem(loc0);
	}
    }

  fprintf(out, "OK.\n\n");

  /* Put number of nuclides */

  WDB[DATA_BURN_INVENTORY_NUCLIDES] = (double)i;

  /***************************************************************************/
}

/*****************************************************************************/
