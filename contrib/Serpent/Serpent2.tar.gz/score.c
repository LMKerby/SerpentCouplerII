/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : score.c                                        */
/*                                                                           */
/* Created:       2011/03/03 (JLe)                                           */
/* Last modified: 2012/01/24 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Scores general parameters needed for every calculation       */
/*                                                                           */
/* Comments: Tää ei nyt taida pelittää tle-moodissa (törmäyksetkin otetaan   */
/*           mukaan)                                                         */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Score:"

/*****************************************************************************/

void Score(double xs, double l, long mat, double E, double wgt, double x,
	   double y, double z, double u, double v, double w, long part, 
	   long id)
{
  long rea, ptr, i;
  double flx, val, spd, fiss, tot;

  /***************************************************************************/

  /***** Calculate flux estimator ********************************************/

  /* Calculate flux estimator */
  
  if ((long)RDB[DATA_OPT_USE_DT] == YES)
    {
      /* Delta-tracking in use, use collision estimator of neutron flux */
      
      if (xs > 0.0)
	flx = 1.0/xs;
      else
	return;
    }
  else
    {
      /* No delta-tracking, check track length */

      CheckValue(FUNCTION_NAME, "l", "", l, ZERO, INFTY);

      /* Use track-length estimator of neutron flux */

      flx = l;
    }
  
  /***************************************************************************/

  /****** Photon transport ***************************************************/

  if ((long)RDB[part + PARTICLE_TYPE] == PARTICLE_TYPE_GAMMA)
    {
      /* Score detectors */

      ScoreDet(part, mat, 1.0/xs, x, y, z, u, v, w, E, wgt, id);
      
      /* Score mesh */

      ScoreMesh(part, mat, 1.0/xs, x, y, z, E, wgt, id);

      /* Exit */

      return;
    }

  /***************************************************************************/

  /***** Score integral reaction rates ***************************************/

  /* Reset total and fission rate */

  tot = 0.0;
  fiss = 0.0;

  /* Flux */

  ptr = (long)RDB[RES_TOT_FLUX];
  AddBuf(flx, wgt, ptr, id, 0);
  
  /* Check material pointer */

  if (mat > VALID_PTR)
    {
      /* Additional bins for burnable and non-burnable materials */

      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	i = 1;
      else
	i = 2;
      
      /* Flux in burnable and non-burnable materials */
 
      AddBuf(flx, wgt, ptr, id, i);

      /* Check implicit mode */
      
      if ((long)RDB[DATA_OPTI_IMPLICIT_RR] == YES)
	{
	  /* Total reaction rate */

	  if ((rea = (long)RDB[mat + MATERIAL_PTR_TOTXS]) > VALID_PTR)
	    if ((tot = MacroXS(rea, E, id)*flx) >= 0.0)
	      {
		ptr = (long)RDB[RES_TOT_RR];
		AddBuf(tot, wgt, ptr, id, 0);
	      }
	  
	  /* Capture rate */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_ABSXS]) > VALID_PTR)
	    if ((val = MacroXS(rea, E, id)*flx) >= 0.0)
	      {	      
		ptr = (long)RDB[RES_TOT_CAPTRATE];
		AddBuf(val, wgt, ptr, id, 0);
		AddBuf(val, wgt, ptr, id, i);
	      }
	  
	  /* Fission rate */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_FISSXS]) > VALID_PTR)
	    if ((fiss = MacroXS(rea, E, id)*flx) > 0.0)
	      {
		ptr = (long)RDB[RES_TOT_FISSRATE];
		AddBuf(fiss, wgt, ptr, id, 0);
		AddBuf(fiss, wgt, ptr, id, i);
	      }
	  
	  /* Elastic scattering rate */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_ELAXS]) > VALID_PTR)
	    if ((val = MacroXS(rea, E, id)*flx) >= 0.0)
	      {	      
		ptr = (long)RDB[RES_TOT_ELARATE];
		AddBuf(val, wgt, ptr, id, 0);
	      }
	  
	  /* Inelastic scattering multiplication rate */
	  
	  if ((rea = (long)RDB[mat + MATERIAL_PTR_NUXNXS]) > VALID_PTR)
	    if ((val = MacroXS(rea, E, id)*flx) >= 0.0)
	      {	      
		ptr = (long)RDB[RES_TOT_N2NRATE];
		AddBuf(val, wgt, ptr, id, 0);
	      }
	}
    }

  /* Calculate neutron speed */
  
  if (E  < 0.1)
    spd = sqrt(ETOV2*E);
  else
    spd = SPD_C*sqrt(1.0 - 1.0/((E/NEUTRON_E0 + 1.0)*(E/NEUTRON_E0 + 1.0)));

  /* 1/v */

  ptr = (long)RDB[RES_TOT_RECIPVEL];
  AddBuf(flx/spd, wgt, ptr, id, 0);

  /***************************************************************************/

  /***** Score other stuff ***************************************************/
  /*
  if (tot < ZERO)
    return;
  */
  /* Check if active cycle */

  if (RDB[DATA_CYCLE_IDX] < RDB[DATA_SKIP])
    return;

  /* Score transmutation cross sections */

  ScoreTransmuXS(flx, mat, E, wgt, id);

  /* Check for corrector step */

  if ((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP)
    return;

  /* Score group constant data */

  ScoreGC(flx, mat, E, wgt, id);

  /* Check for collision estimator */

  if (xs > 0.0)
    {
      /* Score detectors */

      ScoreDet(part, mat, 1.0/xs, x, y, z, u, v, w, E, wgt, id);
      
      /* Score adjoint (tää pitää siirtää collisioniin) */
      /*
      ScoreAdjoint(part, mat, rea, flx, x, y, z, u, v, w, E, wgt, id);
      */

      /* Score mesh */

      ScoreMesh(part, mat, 1.0/xs, x, y, z, E, wgt, id);

      /* Score temperature distribution */

      ScoreTemp(mat, 1.0/xs, id, wgt);

      /* Score core power distribution */

      if (fiss > 0.0)
	ScoreCPD(fiss, wgt, z, id);

      /* Score PB power distribution */

      if (fiss > 0.0)
	ScorePB(fiss, wgt, id);
    }

  /***************************************************************************/
}

/*****************************************************************************/
