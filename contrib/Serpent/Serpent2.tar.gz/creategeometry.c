/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : creategeometry.c                               */
/*                                                                           */
/* Created:       2011/03/02 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: - Creates physical and super-imposed universes               */
/*                                                                           */
/* Comments: - Toi "level" on huono termi, kun oikeammin kyse on             */
/*             väliaikaisen datan varastoinnista tracking-rutiinin aikana    */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CreateGeometry:"

/*****************************************************************************/

void CreateGeometry()
{
  long n, src, ptr, uni, cell, lvl;
  char name[MAX_STR];

  /***** Physical universes **************************************************/

  /* Create physical universes starting from root */

  sprintf(name, "%s", GetText(DATA_PTR_ROOT_UNIVERSE));
  ptr = CreateUniverse(0, name, 0);

  /* Put pointer */

  WDB[DATA_PTR_ROOT_UNIVERSE] = (double)ptr;

  /* Create levels */

  for (n = 0; n < (long)RDB[DATA_GEOM_LEVELS]; n++)
    {
      /* Create data structure */

      lvl = NewItem(DATA_PTR_LVL0, LVL_BLOCK_SIZE);

      /* Allocate memory for private data */

      ptr = AllocPrivateData(LVL_PRIV_BLOCK_SIZE, PRIVA_ARRAY);
      WDB[lvl + LVL_PTR_PRIVATE_DATA] = (double)ptr;
    }

  /***************************************************************************/

  /***** Super-imposed universes for sources *********************************/

  /* Loop over sources */

  src = (long)RDB[DATA_PTR_SRC0];
  while (src > VALID_PTR)
    {
      /* Check universe pointer */

      if ((long)RDB[src + SRC_PTR_UNIV] > VALID_PTR)
	{
	  /* Loop over existing */

	  uni = (long)RDB[DATA_PTR_U0];
	  while (uni > VALID_PTR)
	    {
	      /* Compare names */
	      
	      if (!strcmp(GetText(src + SRC_PTR_UNIV), 
			  GetText(uni + UNIVERSE_PTR_NAME)))
		break;

		/* Next universe */

	      uni = NextItem(uni);
	    }

	  /* Check if found */

	  if (uni < VALID_PTR)
	    {
	      /* Create new universe */

	      uni = CreateUniverse(src, GetText(src + SRC_PTR_UNIV), 0);

	      /* Check type */

	      if ((long)RDB[uni + UNIVERSE_TYPE] != UNIVERSE_TYPE_CELL)
		Error(src, "Super-imposed universe must consist of cells");

	      /* Put type */

	      WDB[uni + UNIVERSE_TYPE] = (double)UNIVERSE_TYPE_SUPER;
	    }

	  /* Put pointer */

	  WDB[src + SRC_PTR_UNIV] = (double)uni;
	}

      /* Check cell pointer */

      if ((long)RDB[src + SRC_PTR_CELL] > VALID_PTR)
	{
	  /* Loop over cells to find match */
	  
	  cell = (long)RDB[DATA_PTR_C0];
	  while (cell > VALID_PTR)
	    {
	      /* Compare names */
	      
	      if (!strcmp(GetText(src + SRC_PTR_CELL), 
			  GetText(cell + CELL_PTR_NAME)))
		{
		  /* Set pointer */
		      
		  WDB[src + SRC_PTR_CELL] = (double)cell;
		      
		  /* Check used-flag */

		  if (!((long)RDB[cell + CELL_OPTIONS] & OPT_USED))
		    {
		      /* Create universe */

		      uni = CreateUniverse(src, GetText(cell + CELL_PTR_UNI), 
					   0);

		      /* Put pointer */

		      if (RDB[src + SRC_PTR_UNIV] < VALID_PTR)
			WDB[src + SRC_PTR_UNIV] = (double)uni;

		      /* Put universe type */

		      WDB[uni + UNIVERSE_TYPE] = (double)UNIVERSE_TYPE_SUPER;
		    }
		      
		  break;
		}
		  
	      /* Next cell */
		  
	      cell = NextItem(cell);
	    }
	      
	  /* Check pointer */
	      
	  if (cell < VALID_PTR)
	    Error(src, "Cell %s in source %s not defined", 
		  GetText(src + SRC_PTR_CELL),
		  GetText(src + SRC_PTR_NAME));
	}

      /* Next source */

      src = NextItem(src);
    }

  /***************************************************************************/
}

/*****************************************************************************/
