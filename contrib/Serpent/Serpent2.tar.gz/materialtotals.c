/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : materialtotals.c                               */
/*                                                                           */
/* Created:       2011/01/02 (JLe)                                           */
/* Last modified: 2012/01/10 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates material-wise total cross sections                */
/*                                                                           */
/* Comments: - Rutiinia muutettu radikaalisti 2.11.2011 (2.0.37)             */
/*                                                                           */
/*           - Toi v�liaikaisen muistin varaaminen tehd��n nyt v�h�n         */
/*             h�lm�sti, mutta rutiini on tolla tavalla selke�mpi.           */
/*                                                                           */
/*           - T�t� ei oo testattu gammavaikutusaloilla                      */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "MaterialTotals:"

/* Use local function to simplify OpenMP implementation */

void MaterialTotals0(long);

/*****************************************************************************/

void MaterialTotals()
{
  long mat, count;
  
  /* Check reconstruction */

  if (((long)RDB[DATA_OPTI_RECONSTRUCT_MACROXS] == NO) &&
      ((long)RDB[DATA_OPTI_MG_MODE] == NO))
    return;

  fprintf(out, "Calculating macroscopic cross sections:\n\n");

  /* Start parallel timer */

  StartTimer(TIMER_OMP_PARA);

  /* Different OpenMP implementation depending on mode */

  if ((long)RDB[DATA_OPTI_RECONSTRUCT_MICROXS] == YES)
    {
      /***********************************************************************/

      /***** Parallelization in for-loop *************************************/

      /* Reset count */
      
      count = 0;

      /* Loop over materials */
	
      mat = (long)RDB[DATA_PTR_M0];
      while (mat > VALID_PTR)
	  {
	    /* Check MPI id number */

	    if (((long)RDB[mat + MATERIAL_MPI_ID] == -1) ||
		((long)RDB[mat + MATERIAL_MPI_ID] == mpiid))
	      {
		/* Print */
		
		if (count < (long)RDB[DATA_N_MATERIALS])
		  fprintf(out, " %3.0f%% complete\n", 
			  100.0*(count++)/RDB[DATA_N_MATERIALS]);
		
		/* Process */
		
		MaterialTotals0(mat);
	      }

	    /* Next material */
	    
	    mat = NextItem(mat);
	  }
      
      /***********************************************************************/
    }
  else
    {
      /***** Parallelization by material *************************************/

      /* Reset thread numbers */
  
      mat = (long)RDB[DATA_PTR_M0];
      while (mat > VALID_PTR)
	{
	  /* Check thread number */
	  
	  WDB[mat + MATERIAL_OMP_ID] = -1.0;
	  
	  /* Next material */
	  
	  mat = NextItem(mat);
	}	  
      
      /* Reset count */
      
      count = 0;

#ifdef OPEN_MP
#pragma omp parallel private (mat)
#endif
      {
	/* Loop over materials */
	
	mat = (long)RDB[DATA_PTR_M0];
	while (mat > VALID_PTR)
	  {
	    /* Check MPI id number */

	    if (((long)RDB[mat + MATERIAL_MPI_ID] == -1) ||
		((long)RDB[mat + MATERIAL_MPI_ID] == mpiid))
	      {
		
#ifdef OPEN_MP
#pragma omp critical
#endif
		{
		  /* Grab material */
		  
		  if ((long)RDB[mat + MATERIAL_OMP_ID] == -1)
		    WDB[mat + MATERIAL_OMP_ID] = OMP_THREAD_NUM;
		}
		
		/* Check thread number */
		
		if ((long)RDB[mat + MATERIAL_OMP_ID] == OMP_THREAD_NUM)
		  {
		    /* Print */
		    
		    if (OMP_THREAD_NUM == 0)
		      if (count < (long)RDB[DATA_MATERIALS_THREAD0])
			fprintf(out, " %3.0f%% complete\n", 
				100.0*(count++)/RDB[DATA_MATERIALS_THREAD0]);
		    
		    /* Process */
		    
		    MaterialTotals0(mat);
		  }
	      }

	    /* Next material */
	    
	    mat = NextItem(mat);
	  }
      }
      
      /***********************************************************************/
    }

  /* Reset MPI id's of non-burnable materials to avoid processing in later */
  /* burnup steps */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check burn-flag */
      
      if (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT))
	WDB[mat + MATERIAL_MPI_ID] = -2.0;

      /* Next material */
      
      mat = NextItem(mat);
    }

  /* Stop parallel timer */

  StopTimer(TIMER_OMP_PARA);

  /* Done */

  fprintf(out, " 100%% complete\n\n"); 
}

/*****************************************************************************/

/*****************************************************************************/

void MaterialTotals0(long mat)
{
  long n, mode, rea, loc0, loc1, loc2, loc3, pte, sz, i0, m, ne, erg, id;
  long nemax;
  double Emin, Emax, adens, *xs, *tot, mult;

  /* Get OpenMP id */

  id = (long)RDB[mat + MATERIAL_OMP_ID];

  /***************************************************************************/

  /***** Multi-group total cross sections ************************************/

  /* Check mode */
  
  if ((long)RDB[DATA_OPTI_MG_MODE] == YES)
    {
      /* Get number of energy groups */

      ne = (long)RDB[DATA_COARSE_MG_NE];
      CheckValue(FUNCTION_NAME, "ne", "", ne, 10, 50000);

      /* Pointer to total xs (t�h�n voi kosahtaa jos on pelkk�� gammadataa) */
      
      loc0 = (long)RDB[mat + MATERIAL_PTR_TOTXS];
      CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);
      
      /* Pointer to data */
      
      loc0 = (long)RDB[loc0 + REACTION_PTR_MGXS];
      CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

      /* Reset data */
      
      memset(&WDB[loc0], 0.0, ne*sizeof(double));
      
      /* Pointer to total list */

      loc1 = (long)RDB[mat + MATERIAL_PTR_TOT_REA_LIST];
      CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);
      
      /* Rewind */
	      
      RewindReaList(loc1, id);
	      
      /* Loop over reactions */
	      
      while (NextReaction(loc1, &rea, &adens, &Emin, &Emax, id) > -1)
	{	      
	  /* Check reaction pointer */

	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

	  /* Get pointer to xs data */
	  
	  loc2 = (long)RDB[rea + REACTION_PTR_MGXS];
	  CheckPointer(FUNCTION_NAME, "(loc2)", DATA_ARRAY, loc2);
	      
	  /* Add to total */
	  
	  for (n = 0; n < ne; n++)
	    WDB[loc0 + n] = RDB[loc0 + n] + adens*RDB[loc2 + n];
	}
    }
  
  /***************************************************************************/

  /***** Continuous-energy cross sections ************************************/

  /* Check reconstruction */
  
  if ((long)RDB[DATA_OPTI_RECONSTRUCT_MACROXS] == NO)
    return;

  /* Get maximum unionized grid size */

  nemax = -1;

  /* Check neutron and photon grids */

  if ((erg = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID]) > VALID_PTR)
    nemax = (long)RDB[erg + ENERGY_GRID_NE];
  if ((erg = (long)RDB[DATA_ERG_PTR_UNIONIZED_PGRID]) > VALID_PTR)
    if ((long)RDB[erg + ENERGY_GRID_NE] > nemax)
      nemax = (long)RDB[erg + ENERGY_GRID_NE];

  /* Allocate memory for temporary arrays */
  
  if ((long)RDB[DATA_OPTI_RECONSTRUCT_MICROXS] == NO)
    xs = (double *)Mem(MEM_ALLOC, nemax, sizeof(double));
  else 
    xs = NULL;
  
  /* Loop over lists */

  for (n = 0; n < 7; n++)
    {
      /* Avoid compiler warning */

      mode = -1;
      loc0 = -1;
      erg = -1;

      /* Get mode */
      
      if (n == 0)
	{
	  mode = MATERIAL_PTR_TOT_REA_LIST;
	  loc0 = (long)RDB[mat + MATERIAL_PTR_TOTXS];
	  erg = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID];
	}
      else if (n == 1)
	{
	  mode = MATERIAL_PTR_ELA_REA_LIST;
	  loc0 = (long)RDB[mat + MATERIAL_PTR_ELAXS];
	  erg = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID];
	}
      else if (n == 2)
	{
	  mode = MATERIAL_PTR_ABS_REA_LIST;
	  loc0 = (long)RDB[mat + MATERIAL_PTR_ABSXS];
	  erg = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID];
	}
      else if (n == 3)
	{
	  mode = MATERIAL_PTR_FISS_REA_LIST;
	  loc0 = (long)RDB[mat + MATERIAL_PTR_FISSXS];
	  erg = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID];
	}
      else if (n == 4)
	{
	  mode = MATERIAL_PTR_NUXN_REA_LIST;
	  loc0 = (long)RDB[mat + MATERIAL_PTR_NUXNXS];
	  erg = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID];
	}
      else if (n == 5)
	{
	  mode = MATERIAL_PTR_PHOT_TOT_LIST;
	  loc0 = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
	  erg = (long)RDB[DATA_ERG_PTR_UNIONIZED_PGRID];
	}
      else if (n == 6)
	{
	  mode = MATERIAL_PTR_PHOT_HEAT_LIST;
	  loc0 = (long)RDB[mat + MATERIAL_PTR_HEATPHOTXS];
	  erg = (long)RDB[DATA_ERG_PTR_UNIONIZED_PGRID];
	}
      else
	Die(FUNCTION_NAME, "Overflow");

      /* Cycle loop if nuclide has no reactions of this type */
      
      if ((long)RDB[mat + mode] < VALID_PTR)
	continue;

      /* Check reaction and unionized grid pointer */

      CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);
      CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);
      
      /* Get number of energy points */
      
      ne = RDB[erg + ENERGY_GRID_NE];
      
      /* Pointer to cross section data */
      
      loc0 = (long)RDB[loc0 + REACTION_PTR_XS];
      CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

      tot = &WDB[loc0];

      /* Reset total array */

      memset(tot, 0.0, ne*sizeof(double));

      /* Pointer to list data (pointteri tarkistetaan tuolla ylemp�n�) */
      
      loc1 = (long)RDB[mat + mode];
      
      /* Rewind */
	      
      RewindReaList(loc1, id);
	      
      /* Loop over reactions */
	      
      while (NextReaction(loc1, &rea, &adens, &Emin, &Emax, id) > -1)
	{	      
	  /* Check reaction pointer */

	  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);

	  /* Check type */
	  
	  if (((long)RDB[rea + REACTION_TYPE] != REACTION_TYPE_SUM) &&
	      ((long)RDB[rea + REACTION_TYPE] != REACTION_TYPE_PARTIAL))
	    Die(FUNCTION_NAME, "Invalid reaction type");
	  
	  /* Get multiplier (TODO: Korvaa toi fission energialla */
	  /* sit kun se lis�t��n) */

	  mult = RDB[rea + REACTION_WGT_F];
	  
	  /* Check value */
	  
	  CheckValue(FUNCTION_NAME, "mult", "", mult, 1.0, 5.0);
	  
	  /* Pointer to data */
	  
	  loc2 = RDB[rea + REACTION_PTR_XS];

	  /* Number of points and index to first point */
	  
	  sz = (long)RDB[rea + REACTION_XS_NE];
	  i0 = (long)RDB[rea + REACTION_XS_I0];
	  
	  /* Get pointer to nuclide energy grid */

	  pte = (long)RDB[rea + REACTION_PTR_EGRID];
	  CheckPointer(FUNCTION_NAME, "(pte)", DATA_ARRAY, pte);

	  /* Check if nuclide uses unionized grid */

	  if ((long)RDB[DATA_OPTI_RECONSTRUCT_MICROXS] == YES)
	    {
	      /* Check that pointers match */

	      if (pte != erg)
		Die(FUNCTION_NAME, "Mismatch in grid pointer");

	      /* Loop over non-zero values and add to sum */

#ifdef OPEN_MP	      
#pragma omp parallel for
#endif

	      for (m = 0; m < sz; m++)
		tot[i0 + m] = tot[i0 + m] + mult*adens*RDB[loc2 + m];
	    }
	  else
	    {
	      /* Pointer to grid data */
	      
	      loc3 = (long)RDB[erg + ENERGY_GRID_PTR_DATA];
	      CheckPointer(FUNCTION_NAME, "(loc3)", DATA_ARRAY, loc3);

	      pte = (long)RDB[pte + ENERGY_GRID_PTR_DATA];
	      CheckPointer(FUNCTION_NAME, "(pte)", DATA_ARRAY, pte);
	      
	      /* Reconstruct data to temporary array */
	      
	      InterpolateData(&RDB[loc3], xs, ne, &RDB[pte + i0], 
			      &RDB[loc2], sz, 0, NULL, NULL);
	      
	      /* Add points (NOTE: T�� k�yd��n nyt nollasta asti l�pi, */
	      /* toi InterpolateData() voisi palauttaa tiedon siit�, */
	      /* mik� ensimm�inen nollasta poikkeava piste on. */
	      /* NOTE2: se palauttaa, sit� ei oo vaan otettu tossa */
	      /* seuraavassa viel� huomioon */
	      
	      for (m = 0; m < ne; m++)
		tot[m] = tot[m] + mult*adens*xs[m];
	    }
	}
    }
  
  /* Free allocated memory */
  
  if (xs != NULL)
    Mem(MEM_FREE, xs);
}

/*****************************************************************************/
