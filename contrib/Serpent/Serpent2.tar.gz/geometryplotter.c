/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : geometryplotter.c                              */
/*                                                                           */
/* Created:       2010/10/07 (JLe)                                           */
/* Last modified: 2012/01/17 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Plots geometry                                               */
/*                                                                           */
/* Comments: - Lis�� optio jolla saa valita rajapintojen vs. materiaali-     */
/*             rajojen korostuksen.                                          */
/*                                                                           */
/*           - T�� vuotaa muistia jostain?                                   */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#ifndef NO_GFX_MODE
#include <gd.h>
#endif

#define FUNCTION_NAME "GeometryPlotter:"

#define COLOURS 100

/*****************************************************************************/

void GeometryPlotter()
{
#ifndef NO_GFX_MODE

  long n, m, gpl, xp, yp, cell, mat, nerr, old, mode, id, ptr;
  long r[COLOURS], g[COLOURS], b[COLOURS], count, nplot;
  long **matrix;
  double xmin, xmax, ymin, ymax, zmin, zmax, tmp, x, y, z, u, v, w, d, pixw;
  gdImagePtr im;
  FILE *fp;
  long palette[COLOURS*2];
  unsigned long seed;

  /* Pointer to geometry plot */

  if ((gpl = RDB[DATA_PTR_GPL0]) < 1)
    return;

  fprintf(out, "Plotting geometry:\n\n");

  /* Boundary mode (1 = plot cell boundaries, 2 = plot material boundaries) */

  mode = 2;

  /* Set plotter mode */
  
  WDB[DATA_PLOTTER_MODE] = (double)YES;

  /***************************************************************************/

  /***** Create colours ******************************************************/

  /* Init random number sequence */
      
  seed = ReInitRNG(0);
      
  /* Put seed in private data */
      
  ptr = (long)RDB[DATA_PTR_RNG_SEED];
  PutPrivateData(ptr, seed, 0);

  /* Random colours */

  for(n = 4; n < COLOURS; n++)
    {
      r[n] = (long)(255.0*(RandF(0) + 1.0)/2);
      g[n] = (long)(255.0*(RandF(0) + 1.0)/2);
      b[n] = (long)(255.0*(RandF(0) + 1.0)/2);
    }
  
  /* User-defined material colours */

  n = 4;

  mat = RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check if colour is defined */

      if ((m = (long)RDB[mat + MATERIAL_RGB]) > 0)
	{
	  r[n] = (long)(m/1000000.0);
	  g[n] = (long)((m - 1000000.0*r[n])/1000.0);
	  b[n] = (long)(m - 1000000.0*r[n] - 1000.0*g[n]);

	  /* Set index */

	  WDB[mat + MATERIAL_COLOUR_IDX] = (double)n;
	}
      
      /* Next colour */
      
      if (++n == COLOURS)
	break;
      
      /* Next material */
      
      mat = NextItem(mat);
    }

  /* Put remaining colour indexes */

  m = n + 1;

  mat = RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      if (m == COLOURS)
	m = n + 1;

      /* Check if index is not already given */

      if ((long)RDB[mat + MATERIAL_COLOUR_IDX] == 0)
	WDB[mat + MATERIAL_COLOUR_IDX] = (double)m++;
	
      /* Next material */
      
      mat = NextItem(mat);
    }
  
  /* Void colour */
  
  r[0] = 0;
  g[0] = 0;
  b[0] = 0;

  /* No cell error */

  r[1] = 0;
  g[1] = 255;
  b[1] = 0;

  /* Multiple cell error */

  r[2] = 255;
  g[2] = 0;
  b[2] = 0;

  /* Pointer error */

  r[3] = 255;
  g[3] = 255;
  b[3] = 0;

  /***************************************************************************/

  /***** Plot geometry *******************************************************/

  /* Reset counter and get number of plots */

  count = 0;
  nplot = ListSize(gpl);

  /* Loop over plots */

  gpl = FirstItem(gpl);
  while (gpl > VALID_PTR)
    {
      fprintf(out, " %3.0f%% complete\n", 100.0*(count++)/((double)nplot));

      /* Reset error counter */

      nerr = 0;

      /***********************************************************************/

      /***** Set boundaries and image size ***********************************/
      
      /* Get boundaries of geometry */

      xmin = RDB[DATA_GEOM_MINX];
      xmax = RDB[DATA_GEOM_MAXX];
      ymin = RDB[DATA_GEOM_MINY];
      ymax = RDB[DATA_GEOM_MAXY];
      zmin = RDB[DATA_GEOM_MINZ];
      zmax = RDB[DATA_GEOM_MAXZ];

      /* Check if boundaries are set by user */

      if (RDB[gpl + GPL_XMIN] != -INFTY)
	xmin = RDB[gpl + GPL_XMIN];

      if (RDB[gpl + GPL_XMAX] !=  INFTY)
	xmax = RDB[gpl + GPL_XMAX];

      if (RDB[gpl + GPL_YMIN] != -INFTY)
	ymin = RDB[gpl + GPL_YMIN];

      if (RDB[gpl + GPL_YMAX] !=  INFTY)
	ymax = RDB[gpl + GPL_YMAX];

      if (RDB[gpl + GPL_ZMIN] != -INFTY)
	zmin = RDB[gpl + GPL_ZMIN];

      if (RDB[gpl + GPL_ZMAX] !=  INFTY)
	zmax = RDB[gpl + GPL_ZMAX];

      /* Check boundaries and swap */

      if (xmin > xmax)
	{
	  tmp = xmax;
	  xmax = xmin;
	  xmin = tmp;
	}

      if (ymin > ymax)
	{
	  tmp = ymax;
	  ymax = ymin;
	  ymin = tmp;
	}

      if (zmin > zmax)
	{
	  tmp = zmax;
	  zmax = zmin;
	  zmin = tmp;
	}

      /* Move limits away from boundaries to avoid numerical errors in some */
      /* systems. */

      xmin = xmin + EXTRAP_L;
      xmax = xmax - EXTRAP_L;
      ymin = ymin + EXTRAP_L;
      ymax = ymax - EXTRAP_L;
      zmin = zmin + EXTRAP_L;
      zmax = zmax - EXTRAP_L;

      /* Set image size */

      xp = (long)RDB[gpl + GPL_PIX_X];
      yp = (long)RDB[gpl + GPL_PIX_Y];

      /* Allocate memory */

      matrix = (long **)Mem(MEM_ALLOC, xp, sizeof(long *));	

      for(n = 0; n < xp; n++)
	matrix[n] = (long *)Mem(MEM_ALLOC, yp, sizeof(long));
	
      /***********************************************************************/

      /***** Draw materials **************************************************/

#ifdef OPEN_MP
#pragma omp parallel private(n, m, x, y, z, cell, mat, ptr, id)
#endif
      {
	/* Get Open MP thread id */

	id = OMP_THREAD_NUM;

	/* Avoid compiler warnings */

	x = 0;
	y = 0;
	z = 0;
	u = 0;
	v = 0;
	w = 0;
	
	/* Loop over geometry */
	
#ifdef OPEN_MP
#pragma omp for
#endif
	for (n = 0; n < xp; n++)
	  {
	  for (m = 0; m < yp; m++)
	    {
	      /* Reset pixel value */
	      
	      matrix[n][m] = 0;
	      
	      /* Calculate Co-ordinates */
	      
	      switch ((long)RDB[gpl + GPL_TYPE])
		{		
		case PLOT_MODE_YZ:
		  {
		    /* yz-plot */
		    
		    x = RDB[gpl + GPL_POS];
		    y = (n/(xp - 1.0))*(ymax - ymin) + ymin;
		    z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		    
		    u = 0.0;
		    v = 0.0;
		    w = 1.0;
		    
		    break;
		  }
		case PLOT_MODE_XZ:
		  {
		    /* xz-plot */
		    
		    x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		    y = RDB[gpl + GPL_POS];
		    z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		    
		    u = 0.0;
		    v = 0.0;
		    w = 1.0;
		    
		    break;
		  }
		case PLOT_MODE_XY:
		  {
		    
		    /* xy-plot */
		    
		    x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		    y = (m/(yp - 1.0))*(ymax - ymin) + ymin;
		    z = RDB[gpl + GPL_POS];
		    
		    u = 0.0;
		    v = 1.0;
		    w = 0.0;
		    
		    break;
		  }
		default:
		  Die(FUNCTION_NAME, "Invalid plot mode");
		}
	      
	      /* Find location */
	      
	      if ((cell = WhereAmI(x, y, z, u, v, w, id)) > VALID_PTR)
		{
		  /* Test boundary conditions */
		  
		  if (BoundaryConditions(&x, &y, &z, &u, &v, &w, id) == YES)
		    cell = WhereAmI(x, y, z, u, v, w, id);
		}
	      
	      /* Check return value */
	      
	      if (cell < 0)
		{
		  /* Put error condition */
		  
		  nerr = cell;
		  
		  /* Set colour */
		  
		  matrix[n][m] = -cell;
		}
	      else if ((mat = (long)RDB[cell + CELL_PTR_MAT]) > VALID_PTR)
		{
		  /* Set colour */
		  
		  matrix[n][m] = (long)RDB[mat + MATERIAL_COLOUR_IDX];
		}
	      
	      /***** Plot super-imposed source / detector region *************/
	      
#ifdef mmmmmmmm
	      
	      ptr = (long)RDB[DATA_PTR_SRC0];
	      while (ptr > VALID_PTR)
		{
		  if (InSuperCell((long)RDB[ptr + SRC_PTR_UNIV],
				  (long)RDB[ptr + SRC_PTR_CELL], x, y, z)
		      == YES)
		    matrix[n][m] = 3;
		  
		  /* Next */
	      
		  ptr = NextItem(ptr);
		}
#endif
	      /***************************************************************/
	    }
	  }
      }      
      
      /* Check for geometry errors */

      if (nerr < 0)
	{
	  if (nerr == GEOM_ERROR_NO_CELL)
	    fprintf(out, "Geometry errors in plot %s (no cell).\n",
		   GetText(gpl + GPL_PTR_FNAME));
	  else if (nerr == GEOM_ERROR_MULTIPLE_CELLS)
	    fprintf(out, "Geometry errors in plot %s (overlap).\n",
		   GetText(gpl + GPL_PTR_FNAME));
	  else
	    fprintf(out, "Geometry errors in plot %s (unknown).\n",
		   GetText(gpl + GPL_PTR_FNAME));
	}

      /************************************************************************/

      /***** Plot boundaries  *************************************************/
      
#ifdef OPEN_MP
#pragma omp parallel private(n, m, x, y, z, d, cell, mat, pixw, old, ptr, id)
#endif
      {
	/* Get Open MP thread id */

	id = OMP_THREAD_NUM;

	/* Avoid compiler warnings */
	
	pixw = 0;
	old = -1;
	
	/* Sweep 1 */
	
#ifdef OPEN_MP
#pragma omp for
#endif	

	for (n = 0; n < xp; n++)
	  {
	    /* Reset minimum distance */
	    
	    d = -1.0;
	    
	    for (m = 0; m < yp; m++)
	      {
		/* Calculate Co-ordinates */
		
		switch ((long)RDB[gpl + GPL_TYPE])
		  {		
		  case PLOT_MODE_YZ:
		    {
		      /* yz-plot */
		      
		      x = RDB[gpl + GPL_POS];
		      y = (n/(xp - 1.0))*(ymax - ymin) + ymin;
		      z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		      
		      pixw = (zmax - zmin)/((double)yp);
		      
		      u = 0.0;
		      v = 0.0;
		      w = 1.0;
		      
		      break;
		    }
		  case PLOT_MODE_XZ:
		    {
		      /* xz-plot */
		      
		      x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		      y = RDB[gpl + GPL_POS];
		      z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		      
		      pixw = (zmax - zmin)/((double)yp);
		      
		      u = 0.0;
		      v = 0.0;
		      w = 1.0;
		      
		      break;
		    }
		  case PLOT_MODE_XY:
		    {		      
		      /* xy-plot */
		      
		      x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		      y = (m/(yp - 1.0))*(ymax - ymin) + ymin;
		      z = RDB[gpl + GPL_POS];
		      
		      pixw = (ymax - ymin)/((double)yp);
		      
		      u = 0.0;
		      v = 1.0;
		      w = 0.0;
		      
		      break;
		    }
		  default:
		    Die(FUNCTION_NAME, "Invalid plot mode");
		  }
		
		/* Check mode */

		if (mode == 1)
		  {
		    /* Find location */
		
		    if ((cell = WhereAmI(x, y, z, u, v, w, id)) 
			> VALID_PTR)
		      {
			/* Test boundary conditions */
			
			if (BoundaryConditions(&x, &y, &z, &u, &v, &w, id) 
			    == YES)
			  cell = WhereAmI(x, y, z, u, v, w, id);
		      }		

		    /* Check pointer */
		    
		    if (cell > VALID_PTR)
		      {
			
			/* Calculate distance to boundary */
			
			d = NearestBoundary(id);
			
			/* Compare minimum distance to pixel width */
			
			if (d < pixw)
			  {
			    /* Set colour */
			    
			    matrix[n][m] = 0;
			  }
		      }
		  }
		else
		  {
		    /* Material index */
			
		    mat = matrix[n][m];
			
		    /* Compare to previous */
			
		    if (old != mat)
		      {
			/* Put colour */
			
			if (old != 0)
			  matrix[n][m] = 0;

			/* Set previous pointer */
			
			old = mat;
		      }
		  }
		
		/* Draw border */
		
		if ((m == 0) || (m == yp - 1)) 
		  matrix[n][m] = 0;
	      }
	  }
	
	/* Sweep 2 */

#ifdef OPEN_MP	
#pragma omp for
#endif
	
	for (m = 0; m < yp; m++)
	  {
	    /* Reset minimum distance */
	    
	    d = -1.0;
	    
	    for (n = 0; n < xp; n++)
	      {
		/* Calculate Co-ordinates */
		
		switch ((long)RDB[gpl + GPL_TYPE])
		  {		
		  case PLOT_MODE_YZ:
		    {
		      /* yz-plot */
		      
		      x = RDB[gpl + GPL_POS];
		      y = (n/(xp - 1.0))*(ymax - ymin) + ymin;
		      z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		      
		      pixw = (ymax - ymin)/((double)yp);
		      
		      u = 0.0;
		      v = 1.0;
		      w = 0.0;
		      
		      break;
		    }
		  case PLOT_MODE_XZ:
		    {
		      /* xz-plot */
		      
		      x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		      y = RDB[gpl + GPL_POS];
		      z = ((yp - m - 1)/(yp - 1.0))*(zmax - zmin) + zmin;
		      
		      pixw = (xmax - xmin)/((double)xp);
		      
		      u = 1.0;
		      v = 0.0;
		      w = 0.0;
		      
		      break;
		    }
		  case PLOT_MODE_XY:
		    {
		      
		      /* xy-plot */
		      
		      x = (n/(xp - 1.0))*(xmax - xmin) + xmin;
		      y = (m/(yp - 1.0))*(ymax - ymin) + ymin;
		      z = RDB[gpl + GPL_POS];
		      
		      pixw = (xmax - xmin)/((double)xp);
		      
		      u = 1.0;
		      v = 0.0;
		      w = 0.0;
		      
		      break;
		    }
		  default:
		    Die(FUNCTION_NAME, "Invalid plot mode");
		  }

		/* Check mode */

		if (mode == 1)
		  {		
		    /* Find location */
		
		    if ((cell = WhereAmI(x, y, z, u, v, w, id)) 
			> VALID_PTR)
		      {
			/* Test boundary conditions */
			
			if (BoundaryConditions(&x, &y, &z, &u, &v, &w, id) 
			    == YES)
			  cell = WhereAmI(x, y, z, u, v, w, id);
		      }
		    
		    /* Check pointer */
		    
		    if (cell > VALID_PTR)
		      {
			/* Calculate distance to boundary */
			
			d = NearestBoundary(id);
			
			/* Compare minimum distance to pixel width */
			
			if (d < pixw)
			  {
			    /* Set colour */
			    
			    matrix[n][m] = 0;
			  }
		      }
		  }
		else
		  {
		    /* Material index */
			
		    mat = matrix[n][m];
			
		    /* Compare to previous */
			
		    if (old != mat)
		      {
			/* Avoid double lines */
			
			if ((old != 0) && (n > 0) && (matrix[n - 1][m] != 0))
			  matrix[n][m] = 0;
			    
			/* Set previous pointer */
			
			old = mat;
		      }
		  }
	      		
		/* Draw border */
		
		if ((n == 0) || (n == xp - 1)) 
		  matrix[n][m] = 0;
	      }
	  }
      }

      /***********************************************************************/

      /***** Draw image ******************************************************/

      /* Create image */

      im = gdImageCreate(xp, yp);
      
      /* Colour of the outside wold */
      
      palette[0] = gdImageColorAllocate(im,55,55,55);
      
      /* Colour of no cell and multiple cells */
      
      palette[1] = gdImageColorAllocate(im, 255, 0, 0);
      palette[2] = gdImageColorAllocate(im, 0, 255, 0);
      palette[3] = gdImageColorAllocate(im, 255, 255, 0);
      
      /* Generate palette */
	  
      for(n = 0; n < COLOURS; n++)
	{
	  /* Material colours */
	  
	  palette[n] = gdImageColorAllocate(im, r[n], g[n], b[n]);
	  
	  /* Borders (shades) */
	  
	  palette[n + COLOURS] =  gdImageColorAllocate(im, 
						       (long)(0.8*r[n]), 
						       (long)(0.8*g[n]), 
						       (long)(0.8*b[n]));
	}
      
      /* Draw image */

#ifdef OPEN_MP      
#pragma omp parallel private(n, m)
#endif
      {

#ifdef OPEN_MP
#pragma omp for
#endif

	for (n = 0; n < xp; n++)
	  for (m = 0; m < yp; m++)
	    gdImageSetPixel(im, n, m, palette[matrix[n][m]]);   
      }

      /* Open file for writing */
      
      if ((fp = fopen(GetText(gpl + GPL_PTR_FNAME), "w")) == NULL)      
	Die(FUNCTION_NAME, "Unable to open file for writing"); 

      /* Write image (png format) */
      
      gdImagePng(im, fp);
      
      /***********************************************************************/

      /***** Cleanup *********************************************************/

      /* Free image */
      
      gdImageDestroy(im);

      /* Free matrix */
      
      for(n = 0; n < xp; n++)
	Mem(MEM_FREE, matrix[n]);
      
      Mem(MEM_FREE, matrix);

      /* Close file */

      fclose(fp);

      /***********************************************************************/
      
      /* Next plot */

      gpl = NextItem(gpl);
    }  

  /***************************************************************************/

  /* Reset plotter mode */
  
  WDB[DATA_PLOTTER_MODE] = (double)NO;

  /* Done */

  fprintf(out, " 100%% complete\n\n"); 

#endif
}

/*****************************************************************************/
