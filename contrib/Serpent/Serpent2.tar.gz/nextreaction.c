/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : nextreaction.c                                 */
/*                                                                           */
/* Created:       2011/11/02 (JLe)                                           */
/* Last modified: 2011/11/07 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Returns pointers and data for next reaction                  */
/*                                                                           */
/* Comments: This function serves three purposes:                            */
/*                                                                           */
/*           1) Quick access to reaction data when looping over a            */
/*              pre-generated list, to be used for reaction sampling and     */
/*              summation over multiple reactions (REA_LIST_TYPE_REAL)       */
/*                                                                           */
/*           2) Identical behaviour, including cut-offs, when pre-generated  */
/*              list doesn't exist for memory-saving purposes                */
/*              (REA_LIST_TYPE_EMULATED)                                     */
/*                                                                           */
/*           3) Looping over all reactions, excluding cut-offs, used for     */
/*              allocating memory for lists in newrealist.c                  */
/*              (REA_LIST_TYPE_NO_CUTOFF)                                    */
/*                                                                           */
/*           Return value: >  VALID_PTR -- pointer to list structure         */
/*                         0            -- valid reaction, but no list       */
/*                        -1            -- no more reactions                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "NextReaction:"

/*****************************************************************************/

long NextReaction(long loc0, long *rea, double *adens, double *Emin, 
		  double *Emax, long id)
{
  long mat, ptr, nxt, mode, iso, nuc, ures, mt, ty;
  double f;

  /* Check reaction list pointer */

  CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

  /* Pointer to material */

  mat = (long)RDB[loc0 + LIST_ROOT_PTR_MAT];
  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /* Check type */

  if ((long)RDB[loc0 + LIST_ROOT_LIST_TYPE] == REA_LIST_TYPE_REAL)
    {
      /***** Pre-generated reaction list exists ******************************/

      /* Get pointer to next reaction in list */

      ptr = TestValuePair(loc0 + LIST_ROOT_PTR_NEXT_LST, 0.0, id);

      /* Check pointer and put data */
      
      if (ptr > VALID_PTR)
	{
	  /* Put data */

	  *rea = (long)RDB[ptr + REA_LIST_PTR_REA];
	  *adens = RDB[ptr + REA_LIST_ADENS];
	  *Emin = RDB[ptr + REA_LIST_EMIN];
	  *Emax = RDB[ptr + REA_LIST_EMAX];
      
	  /* Pointer to next in list */

	  nxt = NextItem(ptr);

	  /* Update pointer */

	  StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_LST, 0.0, (double)nxt, id);
	}

      /* Check if last reaction and return pointer (list may be longer) */

      if (*rea < VALID_PTR)
	return -1;
      else
	return ptr;

      /***********************************************************************/
    }

  /***************************************************************************/

  /***** No pre-generated list ***********************************************/

  /* Get reaction mode */
  
  mode = (long)RDB[loc0 + LIST_ROOT_REA_MODE];
  
  /* Get pointer to next nuclide */
  
  iso = TestValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO, 0.0, id);
  *rea = TestValuePair(loc0 + LIST_ROOT_PTR_NEXT_REA, 0.0, id);
  
  /* Loop over composition */
  
  while (iso > VALID_PTR)
    {
      /* Get atomic density */
      
      *adens = RDB[iso + COMPOSITION_ADENS];
      
      /* Pointer to nuclide data */
      
      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
      
      /* Get ures-flag */
      
      if ((long)RDB[nuc + NUCLIDE_TYPE_FLAGS] & NUCLIDE_FLAG_URES_USED)
	ures = YES;
      else
	ures = NO;
      
      /* Skip all but neutron transport and gamma nuclides */

      if (((long)RDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_TRANSPORT) &&
	  ((long)RDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_PHOTON))
	{
	  /* Next nuclide in composition */
	  
	  iso = NextItem(iso);
	  
	  /* Cycle loop */
	  
	  continue;
	}
      
      /* Density cut-off */
      
      if ((long)RDB[loc0 + LIST_ROOT_LIST_TYPE] != REA_LIST_TYPE_NOCUTOFF)
	if (*adens*RDB[nuc + NUCLIDE_MAX_TOTXS] <
	    RDB[mat + MATERIAL_ADENS]*RDB[DATA_MIN_TOTXS])
	  {
	    /* Next nuclide in composition */
	    
	    iso = NextItem(iso);
	    
	    /* Cycle loop */
	    
	    continue;
	  }

      /* Get maximum atomic fraction */

      f = RDB[nuc + NUCLIDE_MAX_AFRAC];
      CheckValue(FUNCTION_NAME, "f", "", f, 0.0, 1.0);

      /* Ures cut-off */

      if ((long)RDB[loc0 + LIST_ROOT_LIST_TYPE] != REA_LIST_TYPE_NOCUTOFF)
	if (f < RDB[DATA_URES_DILU_CUT])
	  ures = NO;

      /* Check mode */

      if (mode == MATERIAL_PTR_TOT_REA_LIST)
	{
	  /* Neutron total cross section */
	  
	  if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT)
	    {
	      /* Get pointer to reaction data */
	      
	      *rea = (long)RDB[nuc + NUCLIDE_PTR_TOTXS];
	      CheckPointer(FUNCTION_NAME, "(*rea)", DATA_ARRAY, *rea);
	      
	      /* Get minimum and maximum energy */
	      
	      *Emin = -INFTY;
	      *Emax = INFTY;

	      /* Pointer to next nuclide */

	      iso = NextItem(iso);
	      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO, 0.0, 
			     (double)iso, id);
	      
	      /* Exit subroutine */

	      return 0;
	    }
	}
      else if (mode == MATERIAL_PTR_TOT_URES_LIST)
	{
	  /* Neutron total for ures list */
	  
	  if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT) &&
	      (ures == YES))
	    {
	      /* Get pointer to reaction data */
	      
	      *rea = (long)RDB[nuc + NUCLIDE_PTR_TOTXS];
	      CheckPointer(FUNCTION_NAME, "(*rea)", DATA_ARRAY, *rea);
	      
	      /* Get minimum and maximum energy */
	      
	      *Emin = RDB[nuc+ NUCLIDE_URES_EMIN];
	      *Emax = RDB[nuc + NUCLIDE_URES_EMAX];

	      /* Pointer to next nuclide */

	      iso = NextItem(iso);
	      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO, 0.0, 
			     (double)iso, id);

	      /* Exit subroutine */

	      return 0;
	    }
	}
      else if (mode == MATERIAL_PTR_ELA_URES_LIST)
	{
	  /* Neutron elastic for ures list */
	  
	  if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT) &&
	      (ures == YES))
	    {
	      /* Get pointer to reaction data */
	      
	      *rea = (long)RDB[nuc + NUCLIDE_PTR_ELAXS];
	      CheckPointer(FUNCTION_NAME, "(*rea)", DATA_ARRAY, *rea);
	      
	      /* Get minimum and maximum energy */
	      
	      *Emin = RDB[nuc+ NUCLIDE_URES_EMIN];
	      *Emax = RDB[nuc + NUCLIDE_URES_EMAX];

	      /* Pointer to next nuclide */

	      iso = NextItem(iso);
	      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO, 0.0, 
			     (double)iso, id);
	      
	      /* Exit subroutine */

	      return 0;
	    }
	}
      else if (mode == MATERIAL_PTR_ABS_URES_LIST)
	{
	  /* Neutron capture for ures list */
	  
	  if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT) &&
	      (ures == YES))
	    {
	      /* Get pointer to reaction data */
	      
	      *rea = (long)RDB[nuc + NUCLIDE_PTR_NGAMMAXS];
	      CheckPointer(FUNCTION_NAME, "(*rea)", DATA_ARRAY, *rea);
	      
	      /* Get minimum and maximum energy */
	      
	      *Emin = RDB[nuc+ NUCLIDE_URES_EMIN];
	      *Emax = RDB[nuc + NUCLIDE_URES_EMAX];

	      /* Pointer to next nuclide */

	      iso = NextItem(iso);
	      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO, 0.0, 
			     (double)iso, id);
	      
	      /* Exit subroutine */

	      return 0;
	    }
	}
      else if (mode == MATERIAL_PTR_FISS_URES_LIST)
	{
	  /* Neutron fission for ures list */
	  
	  if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT) &&
	      (ures == YES))
	    {
	      /* Get pointer to reaction data */
	      
	      if ((*rea = (long)RDB[nuc + NUCLIDE_PTR_FISSXS]) > VALID_PTR)
		{
		  /* Get minimum and maximum energy */
		  
		  *Emin = RDB[nuc+ NUCLIDE_URES_EMIN];
		  *Emax = RDB[nuc + NUCLIDE_URES_EMAX];

		  /* Pointer to next nuclide */

		  iso = NextItem(iso);
		  StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO, 0.0, 
				 (double)iso, id);
		  
		  /* Exit subroutine */
		  
		  return 0;
		}
	    }
	}
      else if (mode == MATERIAL_PTR_PHOT_TOT_LIST) 
	{
	  /* Photon total cross section */
	  
	  if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_PHOTON)   
	    {
	      /* Get pointer to reaction data */
	      
	      *rea = (long)RDB[nuc + NUCLIDE_PTR_TOTXS];
	      CheckPointer(FUNCTION_NAME, "(*rea)", DATA_ARRAY, *rea);
	      
	      /* Get minimum and maximum energy */
	      
	      *Emin = RDB[nuc + NUCLIDE_EMIN];
	      *Emax = RDB[nuc + NUCLIDE_EMAX];

	      /* Pointer to next nuclide */

	      iso = NextItem(iso);
	      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO, 0.0, 
			     (double)iso, id);
	      
	      /* Exit subroutine */

	      return 0;
	    }
	}
      else if (mode == MATERIAL_PTR_PHOT_HEAT_LIST)
	{
	  /* Photon heating cross section */
	  
	  if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_PHOTON)   
	    {
	      /* Get pointer to reaction data */
	      
	      *rea = (long)RDB[nuc + NUCLIDE_PTR_PHOTON_HEATPRODXS];
	      CheckPointer(FUNCTION_NAME, "(*rea)", DATA_ARRAY, *rea);
	      
	      /* Get minimum and maximum energy */
	      
	      *Emin = RDB[nuc + NUCLIDE_EMIN];
	      *Emax = RDB[nuc + NUCLIDE_EMAX];

	      /* Pointer to next nuclide */

	      iso = NextItem(iso);
	      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO, 0.0, 
			     (double)iso, id);
	      
	      /* Exit subroutine */

	      return 0;
	    }
	}
      else if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT)
	{
	  /* Other neutron reactions, check pointer */
	  
	  if (*rea < VALID_PTR)
	    *rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
	  
	  /* Loop over reactions */
	  
	  while (*rea > VALID_PTR)
	    {
	      /* Check reaction type */

	      if ((long)RDB[*rea + REACTION_TYPE] == REACTION_TYPE_PARTIAL)
		{
		  /* Get mt and ty */
	      
		  mt = (long)RDB[*rea + REACTION_MT];
		  ty = (long)RDB[*rea + REACTION_TY];
		  
		  /* Absorption */
		  
		  if (mode == MATERIAL_PTR_ABS_REA_LIST)  
		    if (ty == 0)
		      break;
		  
		  /* Elastic */
		  
		  if (mode == MATERIAL_PTR_ELA_REA_LIST)
		    if ((mt == 2) || (mt == 1002) || (mt == 1004))
		      break;
		  
		  /* Fission */
		  
		  if (mode == MATERIAL_PTR_FISS_REA_LIST)
		    if (((mt > 17) && (mt < 22)) || (mt == 38))
		      break;
		  
		  /* Inelastic scattering multiplication */
		  
		  if (mode == MATERIAL_PTR_NUXN_REA_LIST)
		    if ((ty != 0) && (ty != 19) && (mt != 2) && (mt != 1002) && 
			(mt != 1004))
		      break;
		}

	      /* Next reaction */
	      
	      *rea = NextItem(*rea);
	    }
	  
	  /* Check reaction pointer */
	  
	  if (*rea > VALID_PTR)
	    {
	      /* Get minimum and maximum energy */
	      
	      *Emin = RDB[*rea + REACTION_EMIN];
	      *Emax = RDB[*rea + REACTION_EMAX];

	      /* Pointer to next reaction */
	      
	      nxt = NextItem(*rea);
	      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_REA, 0.0, 
			     (double)nxt, id);

	      /* Check if last reaction */

	      if (nxt < VALID_PTR)
		iso = NextItem(iso);

	      /* Pointer to nuclide */

	      StoreValuePair(loc0 + LIST_ROOT_PTR_NEXT_ISO, 0.0, 
			     (double)iso, id);

	      /* Exit subroutine */

	      return 0;
	    }
	}
      
      /* Next nuclide in composition */
      
      iso = NextItem(iso);
    }
  
  /* No more reactions in list */

  return -1;
}

/*****************************************************************************/
