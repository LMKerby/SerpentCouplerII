/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processburnmat.c                               */
/*                                                                           */
/* Created:       2011/01/25 (JLe)                                           */
/* Last modified: 2012/01/27 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Additional processing for materials used in burnup           */
/*              calculation                                                  */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessBurnMat:"

/*****************************************************************************/

void ProcessBurnMat()
{
  long mat, iso, nuc, rea, ptr, sta, last, iso1, iso2, nuc1, nuc2, n, ne, n0;
  long erg, loc0;
  double tmp, mem, *E;

  /* Check transport mode */

  if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_TRANSPORT)
    return;

  /* Check burnup step */

  if ((long)RDB[DATA_BURN_STEP] > 0)
    Die(FUNCTION_NAME, "Should not be here");

  /***************************************************************************/

  /***** Few-group structure for ures calculation ****************************/

  /* Check number of nuclides with ures data and b1 mode */

  if (((long)RDB[DATA_URES_USED] > 0) && 
      ((long)RDB[DATA_OPTI_FUM_CALC] == YES))
    {
      /***** Ures data with fum calculation **********************************/

      Die(FUNCTION_NAME, "Tarkista");

      /* Get pointer to B1 energy grid */
  
      erg = (long)RDB[DATA_FUM_PTR_EGRID];
      CheckPointer(FUNCTION_NAME, "(erg)", DATA_ARRAY, erg);	

      if ((n0 = GridSearch(erg, 0.999999*RDB[DATA_URES_EMIN])) < 0)
	Die(FUNCTION_NAME, "Grid search failed");

      if ((n = GridSearch(erg, 1.000001*RDB[DATA_URES_EMAX])) < 0)
	Die(FUNCTION_NAME, "Grid search failed");

      /* Number of groups */

      ne = n - n0 + 1;

      /* Get pointer to grid data */
  
      ptr = (long)RDB[erg + ENERGY_GRID_PTR_DATA];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);	
  
      /* Make grid */

      ptr = MakeEnergyGrid(ne + 1, 0, 0, -1, &RDB[ptr + n0], 
			   EG_INTERP_MODE_LIN);
  
      /* Set number of values and pointer */

      WDB[DATA_BU_MG_EGRID_NE] = ne;
      WDB[DATA_BU_MG_PTR_GRID] = (double)ptr;
      
      /* Set limits */

      WDB[DATA_BU_MG_EGRID_EMIN] = RDB[ptr + ENERGY_GRID_EMIN];
      WDB[DATA_BU_MG_EGRID_EMAX] = RDB[ptr + ENERGY_GRID_EMAX];

      /* Check */

      CheckValue(FUNCTION_NAME, "Emin", "", RDB[DATA_URES_EMIN], 
		 RDB[DATA_BU_MG_EGRID_EMIN], RDB[DATA_URES_EMAX]);
      CheckValue(FUNCTION_NAME, "Emin", "", RDB[DATA_URES_EMAX],
		 RDB[DATA_URES_EMIN], RDB[DATA_BU_MG_EGRID_EMAX]);

      /***********************************************************************/
    }
  else if ((long)RDB[DATA_BURN_DECAY_CALC] == NO)
    {
      /***** No ures data or fum calculation *********************************/

      /* Allocate memory for temporary array */

      E = (double *)Mem(MEM_ALLOC, 2, sizeof(double));

      /* Put boundaries high to disable binning */

      if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] == YES)
	{
	  E[0] = 10*RDB[DATA_NEUTRON_EMAX];
	  E[1] = 20*RDB[DATA_NEUTRON_EMAX];
	}
      else
	{
	  E[0] = RDB[DATA_NEUTRON_EMIN];
	  E[1] = RDB[DATA_NEUTRON_EMAX];
	}

      /* Make grid */

      ptr = MakeEnergyGrid(2, 0, 0, -1, E, EG_INTERP_MODE_LIN);
  
      /* Set number of values and pointer */

      WDB[DATA_BU_MG_EGRID_NE] = 1.0;
      WDB[DATA_BU_MG_PTR_GRID] = (double)ptr;
      
      /* Set limits */

      WDB[DATA_BU_MG_EGRID_EMIN] = RDB[ptr + ENERGY_GRID_EMIN];
      WDB[DATA_BU_MG_EGRID_EMAX] = RDB[ptr + ENERGY_GRID_EMAX];

      /* Free temporary array */

      Mem(MEM_FREE, E);
      
      /***********************************************************************/
    }

  /***************************************************************************/

  /***** Calculate number of burnable materials ******************************/

  /* Reset number of burnable materials */

  WDB[DATA_BURN_MATERIALS] = 0.0;

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Reset burn-flags for non-physical materials (this is needed for */
      /* detector and source materials) */

      if (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_PHYSICAL_MAT))
	ResetOption(mat + MATERIAL_OPTIONS, OPT_BURN_MAT);

      /* Check burn flag and add count */

      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	WDB[DATA_BURN_MATERIALS] = WDB[DATA_BURN_MATERIALS] + 1.0;

      /* Next material */

      mat = NextItem(mat);
    }

  /***************************************************************************/

  /***** Allocate memory from RES2 block to speed up calculation *************/

  /* Number of transmutation reactions (tossa on ehkä branchit mukana) */

  n = (long)(RDB[DATA_N_TRANSMUTATION_REA]*RDB[DATA_BU_MG_EGRID_NE]);

  /* Flux spectrum */

  if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] == YES)
    if ((ptr = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID]) > VALID_PTR)
      n = n + (long)((RDB[ptr + ENERGY_GRID_NE] + 1.0)*
		     RDB[DATA_BURN_MATERIALS]);
  
  /* Allocate memory */

  ptr = AllocPrivateData(n, RES2_ARRAY);

  /* Put pointer back to beginning of allocated region (tässä varataan     */
  /* kerralla iso blokki ja tehdään se uudestaan käytettäväksi asettamalla */
  /* toi pointteri). */

  WDB[DATA_ALLOC_RES2_SIZE] = (double)ptr;

  /* Calculate data size */
  
  CalculateBytes();
 
  /***************************************************************************/

  /***** Process material-wise data ******************************************/

  fprintf(out, "Processing burnable materials...\n");

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check burn flag */

      if (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT))
	{
	  /* Next material */

	  mat = NextItem(mat);

	  /* Cycle loop */

	  continue;
	}

      /* Pointer to original composition */

      ptr = (long)RDB[mat + MATERIAL_PTR_COMP];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Reset pointer */

      WDB[mat + MATERIAL_PTR_COMP] = NULLPTR;
	      
      /* Loop over composition and copy */
      
      while (ptr > VALID_PTR)
	{
	  /* Create new item */

	  loc0 = NewItem(mat + MATERIAL_PTR_COMP, COMPOSITION_BLOCK_SIZE);
		  
	  /* Copy data */
	  
	  memcpy(&WDB[loc0 + LIST_DATA_SIZE], 
		 &RDB[ptr + LIST_DATA_SIZE], 
		 (COMPOSITION_BLOCK_SIZE - LIST_DATA_SIZE)
		 *sizeof(double));
	  
	  /* Next */
	  
	  ptr = NextItem(ptr);
	}

      /* Check composition */
      
      if ((long)RDB[mat + MATERIAL_PTR_COMP] < VALID_PTR)
	Die(FUNCTION_NAME, "Material %s has no nuclides", 
	    GetText(mat + MATERIAL_PTR_NAME));
      
      /* Check mixture */
      
      if ((long)RDB[mat + MATERIAL_PTR_MIX] > VALID_PTR)
	Die(FUNCTION_NAME, "Burnable mixture %s?", 
	    GetText(mat + MATERIAL_PTR_NAME));

      /* Number of energy bins in xs grid */

      ne = (long)RDB[DATA_BU_MG_EGRID_NE];
      CheckValue(FUNCTION_NAME, "ne", "", ne, 1.0, 10000.0);

      /* Get memory size */
      
      mem = RDB[DATA_TOTAL_BYTES];
      
      /* Check internal burnup mode */
      
      if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_INT_BURN)
	{
	  /*******************************************************************/
      
	  /***** Add nuclides from decay and transmutation chains ************/

	  /* Reset used-flags on nuclides (these are used to identify */
	  /* processed chains in AddChains() subroutine). */
	  
	  nuc = (long)RDB[DATA_PTR_NUC0];
	  while (nuc > VALID_PTR)
	    {
	      /* Reset used- and exists-flags */
	      
	      ResetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);
	      ResetOption(nuc + NUCLIDE_OPTIONS, OPT_EXISTS);
	      
	      /* Next nuclide */
	      
	      nuc = NextItem(nuc);
	    }
	  
	  /* Set exists-flags for nuclides initial composition */
	  
	  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	  while (iso > VALID_PTR)
	    {
	      /* Pointer to nuclide */
	      
	      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

	      /* Set flag */
	      
	      SetOption(nuc + NUCLIDE_OPTIONS, OPT_EXISTS);
	      
	      /* Next */
	      
	      iso = NextItem(iso);
	    }
	  
	  /* Get pointer to composition and last initial nuclide */
	  
	  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	  CheckPointer(FUNCTION_NAME, "(iso)", DATA_ARRAY, iso);

	  last = LastItem(iso);
	  CheckPointer(FUNCTION_NAME, "(last)", DATA_ARRAY, last);
	  
	  /* Loop over initial composition and add chains */
	  
	  while (iso > VALID_PTR)
	    {
	      /* Pointer to nuclide */
	      
	      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

	      /* Add chain to material */
	      
	      AddChains(mat, nuc, 0);
	      
	      /* Pointer to next or break if last */
	      
	      if (iso == last)
		break;
	      else
		iso = NextItem(iso);
	    }
	  
	  /*******************************************************************/

	  /***** Sort composition by ZAI and add nuclide for lost data *******/

	  /* Add nuclide for lost data (must be at the beginning to get */
	  /* matrix shape right) */

	  iso = NewItem(mat + MATERIAL_PTR_COMP, COMPOSITION_BLOCK_SIZE);
	  WDB[iso + COMPOSITION_PTR_NUCLIDE] = RDB[DATA_PTR_NUCLIDE_LOST];
	  WDB[iso + COMPOSITION_ADENS] = 0.0;

	  /* Swap nuclide ZAI and composition atomic density (nuclide ZAI */
	  /* is used as temporary storage space) */

	  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	  while (iso > VALID_PTR)
	    {
	      /* Pointer to nuclide */
	      
	      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
	      
	      /* Swap data */
	      
	      tmp = RDB[nuc + NUCLIDE_ZAI];
	      WDB[nuc + NUCLIDE_ZAI] = RDB[iso + COMPOSITION_ADENS];
	      WDB[iso + COMPOSITION_ADENS] = tmp;
	      
	      /* Next */
	      
	      iso = NextItem(iso);
	    }
	  
	  /* Sort list by ZAI stored in composition */
	  
	  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	  SortList(iso, COMPOSITION_ADENS, SORT_MODE_ASCEND);
	  
	  /* Swap nuclide ZAI and composition atomic density */
	  
	  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	  while (iso > VALID_PTR)
	    {
	      /* Pointer to nuclide */
	      
	      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);
	      
	      /* Swap data */
	      
	      tmp = RDB[nuc + NUCLIDE_ZAI];
	      WDB[nuc + NUCLIDE_ZAI] = RDB[iso + COMPOSITION_ADENS];
	      WDB[iso + COMPOSITION_ADENS] = tmp;
	      
	      /* Next */
	      
	      iso = NextItem(iso);
	    }
	  
	  /*******************************************************************/

	  /***** Check and remove duplicate ZAI's ****************************/

	  /* Loop until all duplicates are removed */
	  
	  do
	    {
	      /* Reset count */
	      
	      n = 0;
	      
	      /* Loop over composition */
	      
	      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
	      while (iso > VALID_PTR)
		{      
		  /* Copy pointers */
		  
		  iso1 = iso;
		  iso2 = NextItem(iso);
		  
		  /* Check if next exists */
		  
		  if (iso2 > VALID_PTR)
		    {
		      /* Get nuclide pointers */
		      
		      nuc1 = (long)RDB[iso1 + COMPOSITION_PTR_NUCLIDE];
		      nuc2 = (long)RDB[iso2 + COMPOSITION_PTR_NUCLIDE];

		      CheckPointer(FUNCTION_NAME, "(nuc1)", DATA_ARRAY, nuc1);
		      CheckPointer(FUNCTION_NAME, "(nuc2)", DATA_ARRAY, nuc2);

		      /* Compare ZAI's */
		      
		      if ((long)RDB[nuc1 + NUCLIDE_ZAI] >
			  (long)RDB[nuc2 + NUCLIDE_ZAI])
			Die(FUNCTION_NAME, "Composition not sorted");
		      
		      else if ((long)RDB[nuc1 + NUCLIDE_ZAI] ==
			       (long)RDB[nuc2 + NUCLIDE_ZAI])
			{
			  /* Check S(a,b) flag on first nuclide */
			  
			  if ((long)RDB[nuc1 + NUCLIDE_TYPE_FLAGS] &
			      NUCLIDE_FLAG_SAB_DATA)
			    {
			      /* Check density for second nuclide */ 
			      
			      if (RDB[iso2 + COMPOSITION_ADENS] > 0.0)
				Die(FUNCTION_NAME, "adens2 > 0");
			      
			      /* Remove second nuclide */
			      
			      RemoveItem(iso2);
			      
			      /* Add count */
			      
			      n++;
			    }
			  
			  /* Check S(a,b) flag on first nuclide */
			  
			  else if ((long)RDB[nuc2 + NUCLIDE_TYPE_FLAGS] &
				   NUCLIDE_FLAG_SAB_DATA)
			    {
			      /* Check density for first nuclide */ 
			      
			      if (RDB[iso1 + COMPOSITION_ADENS] > 0.0)
				Die(FUNCTION_NAME, "adens1 > 0");
			      
			      /* Remove first nuclide */
			      
			      Warn(FUNCTION_NAME, "removing %s", 
				   GetText(nuc1 + NUCLIDE_PTR_NAME));
			      
			      RemoveItem(iso1);
			      
			      /* Add count */
			      
			      n++;
			    } 
			  
			  /* Something wrong here */
			  
			  else
			    Die(FUNCTION_NAME, "Duplicates in %s: %s %s",
				GetText(mat + MATERIAL_PTR_NAME),
				GetText(nuc1 + NUCLIDE_PTR_NAME),
				GetText(nuc2 + NUCLIDE_PTR_NAME));
			  
			  /* Break loop */
			  
			  break;
			}
		    }
		  
		  /* Next */
		  
		  iso = iso2;
		}
	    }
	  while (n > 0);
	  
	  /*******************************************************************/
	}

      /***********************************************************************/

      /***** Create transmutation and fission lists **************************/

      iso = (long)RDB[mat + MATERIAL_PTR_COMP];
      while (iso > VALID_PTR)
	{
	  /* Pointer to nuclide */
	  
	  nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
	  CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

	  /* Loop over reactions */
	  
	  rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
	  while (rea > VALID_PTR)
	    {
	      /* Check type and target ZAI */
	      
	      if (((long)RDB[rea + REACTION_TYPE] == REACTION_TYPE_PARTIAL) &&
		  ((long)RDB[rea + REACTION_TGT_ZAI] > 0))
		{
		  /* Add to transmutation list */
		  
		  ptr  = NewItem(mat + MATERIAL_PTR_DEP_TRA_LIST, 
				 DEP_TRA_BLOCK_SIZE);
		  
		  /* Put reaction pointer and minimum energy */
		  
		  WDB[ptr + DEP_TRA_PTR_REA] = (double)rea;
		  WDB[ptr + DEP_TRA_EMIN] = RDB[rea + REACTION_EMIN];
		  
		  /* Allocate memory for results */
		      
		  sta = AllocPrivateData(ne, RES2_ARRAY);
		  WDB[ptr + DEP_TRA_PTR_RESU] = (double)sta;
		}
	      else if (((long)RDB[rea + REACTION_TYPE] 
			!= REACTION_TYPE_DECAY) &&
		       ((long)RDB[rea + REACTION_TGT_ZAI] < 0))
		{
		  /* Add to fission list */
		  
		  ptr  = NewItem(mat + MATERIAL_PTR_DEP_FISS_LIST, 
				 DEP_TRA_BLOCK_SIZE);
		  
		  /* Put reaction pointer */
		  
		  WDB[ptr + DEP_TRA_PTR_REA] = (double)rea;
		  
		  /* Put minimum energy */
		  
		  if (RDB[rea + REACTION_FISSY_IE0] 
		      < RDB[rea + REACTION_EMIN])
		    WDB[ptr + DEP_TRA_EMIN] = RDB[rea + REACTION_EMIN];
		  else
		    WDB[ptr + DEP_TRA_EMIN] = RDB[rea + REACTION_FISSY_IE0];
		  
		  /* Allocate memory for results */
		  
		  sta = AllocPrivateData(ne, RES2_ARRAY);
		  WDB[ptr + DEP_TRA_PTR_RESU] = (double)sta;
		}
	      
	      /* Next reaction */
	      
	      rea = NextItem(rea);
	    }

	  /* Add total fission */

	  if ((rea = (long)RDB[nuc + NUCLIDE_PTR_TOTFISS_REA]) > VALID_PTR)
	    {
	      /* Set target pointer to lost */

	      WDB[rea + REACTION_PTR_TGT] = RDB[DATA_PTR_NUCLIDE_LOST];

	      /* Add to transmutation list */
		  
	      ptr  = NewItem(mat + MATERIAL_PTR_DEP_TRA_LIST, 
			     DEP_TRA_BLOCK_SIZE);
		  
	      /* Put reaction pointer and minimum energy */
		  
	      WDB[ptr + DEP_TRA_PTR_REA] = (double)rea;
	      WDB[ptr + DEP_TRA_EMIN] = -INFTY;
		  
	      /* Allocate memory for results */
		  
	      sta = AllocPrivateData(ne, RES2_ARRAY);
	      WDB[ptr + DEP_TRA_PTR_RESU] = (double)sta;
	    }
	  
	  /* Next nuclide */
	  
	  iso = NextItem(iso);
	}
      
      /* Close lists and sort by energy */
      
      if ((ptr = (long)RDB[mat + MATERIAL_PTR_DEP_TRA_LIST]) > VALID_PTR)
	{
	  CloseList(ptr);
	  SortList(ptr, DEP_TRA_EMIN, SORT_MODE_ASCEND);
	}
      
      if ((ptr = (long)RDB[mat + MATERIAL_PTR_DEP_FISS_LIST]) > VALID_PTR)
	{
	  CloseList(ptr);
	  SortList(ptr, DEP_TRA_EMIN, SORT_MODE_ASCEND);
	}
      
      /* Allocate memory for flux spectrum */

      if (((long)RDB[DATA_BURN_DECAY_CALC] == NO) &&
	  ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] == YES))
	{
	  /* Pointer to unionized grid */
	  
	  if ((ptr = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID]) < VALID_PTR)
	    Die(FUNCTION_NAME, "Energy grid not unionized");
	  
	  /* Get number of points */
	  
	  n = (long)RDB[ptr + ENERGY_GRID_NE];
	  
	  /* Allocate memory */

	  ptr = AllocPrivateData(n, RES2_ARRAY);
	  WDB[mat + MATERIAL_PTR_FLUX_SPEC] = (double)ptr;      
	}
      
      /* Allocate memory for burn flux */
      
      ptr = NewStat("BURN_FLUX", 1, 1);
      WDB[mat + MATERIAL_PTR_BURN_FLUX] = (double)ptr;  

      /* Allocate memory for sum of spectrum */

      ptr = AllocPrivateData(1, RES2_ARRAY);
      WDB[mat + MATERIAL_PTR_FLUX_SPEC_SUM] = (double)ptr;      
      
      /* Update memory size */
      
      WDB[mat + MATERIAL_MEM_SIZE] = RDB[mat + MATERIAL_MEM_SIZE] + 
	RDB[DATA_TOTAL_BYTES] - mem;

      /* Next material */

      mat = NextItem(mat);
    }

  /***************************************************************************/

  fprintf(out, "OK.\n\n");
}

/*****************************************************************************/
