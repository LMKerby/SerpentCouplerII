/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : Boundaryconditions.c                           */
/*                                                                           */
/* Created:       2010/10/10 (JLe)                                           */
/* Last modified: 2011/12/19 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Reflective and periodic boundary conditions by coordinate    */
/*              transformations                                              */
/*                                                                           */
/* Comments: - From Serpent 1.1.12                                           */
/*                                                                           */
/*           - Luodaan erillinen aliohjelma reflection.c niille mieli-       */
/*             valtaisille heijastuksille.                                   */
/*                                                                           */
/*           - Toi cell pointteri on NULL lattice ja pbed -tyyppisille       */
/*             universumeille, mutta niiden ei pit�isi koskaan olla          */
/*             uloimpana, eli tarkistus OK.                                  */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "BoundaryConditions:"

/*****************************************************************************/

long BoundaryConditions(double *x, double *y, double *z, double *u, double *v,
			double *w, long id)
{
  double px, py, pz, x0, y0, z0;
  long lvl, cell, reg, surf, param, type, i, j, k, bc0, bc1, bc2, bc3;

  /* Pointer to first level */

  lvl = (long)RDB[DATA_PTR_LVL0];
  CheckPointer(FUNCTION_NAME, "(lvl)", DATA_ARRAY, lvl);

  /* Pointer to private data */

  lvl = (long)RDB[lvl + LVL_PTR_PRIVATE_DATA];
  CheckPointer(FUNCTION_NAME, "(lvl)", PRIVA_ARRAY, lvl);

  /* Get pointer to cell */

  cell = (long)GetPrivateData(lvl + LVL_PRIV_PTR_CELL, id);
  CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);

  /* Check cell type */
  
  if ((long)RDB[cell + CELL_TYPE] != CELL_TYPE_OUTSIDE)
    return NO;

  /* Check black boundary */

  if ((bc0 = (long)RDB[DATA_GEOM_BC0]) == BC_BLACK)
    return -1;

  /* Avoid compiler warning */

  surf = -1;

  /* Get level type */

  type = (long)GetPrivateData(lvl + LVL_PRIV_TYPE, id);

  /* Get pointer to surfaces */

  if (type == UNIVERSE_TYPE_NEST)
    {
      /* Pointer to region */

      reg = (long)GetPrivateData(lvl + LVL_PRIV_PTR_NEST_REG, id);
      CheckPointer(FUNCTION_NAME, "(reg)", PRIVA_ARRAY, reg);

      /* Pointer to surface */

      surf = (long)RDB[reg + NEST_REG_PTR_SURF_OUT];
    }
  else if (type == UNIVERSE_TYPE_CELL)
    {
      /* Pointer to cell */

      cell = (long)GetPrivateData(lvl + LVL_PRIV_PTR_CELL, id);
      CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);

      /* Pointer to first surface in list (must be the boundary) */

      surf = (long)RDB[cell + CELL_PTR_SURF_LIST];
      surf = (long)RDB[surf];
    }
  else
    Die(FUNCTION_NAME, "Invalid level type");

  /* Check surface pointer */

  CheckPointer(FUNCTION_NAME, "(surf)", DATA_ARRAY, surf);
  
  /* Get surface type */

  type = (long)RDB[surf + SURFACE_TYPE];

  /* Get pointer to surface parameters */

  param = (long)RDB[surf + SURFACE_PTR_PARAMS];
  CheckPointer(FUNCTION_NAME, "(param)", DATA_ARRAY, param);

  /* Avoid compiler warning */
  
  px = 0.0;
  py = 0.0;
  pz = 0.0;
  
  /* Get partial boundary conditions */

  bc1 = RDB[DATA_GEOM_BC1];
  bc2 = RDB[DATA_GEOM_BC2];
  bc3 = RDB[DATA_GEOM_BC3];

  /* Check type */
  
  if ((type = (long)RDB[surf + SURFACE_TYPE]) == SURF_SQC)
    {
      /***** Square lattice **************************************************/
      
      /* Lattice pitch */
      
      px = 2.0*RDB[param + 2];
      py = 2.0*RDB[param + 2];
      pz = INFTY;
      
      /* Centered co-ordinates */
      
      *x = *x - RDB[param];
      *y = *y - RDB[param + 1];
      
      /* Get indexes */
      
      GetLatticeIndexes(px, py, pz, *x, *y, *z, &i, &j, &k, LAT_TYPE_S);  
      
      /* Check leakage from partial boundary conditions */
      
      if ((bc1 == BC_BLACK) && i != 0)
	return -1;
      else if ((bc2 == BC_BLACK) && j != 0)
	return -1;
      
      /* Calculate new position */
      
      *x = *x - i*px;
      *y = *y - j*py;
      
      /* Handle Reflection */
      
      if ((i % 2) && (bc1 == BC_REFLECTIVE))
	{
	  /* Odd number of x-surface crossings. Swap vectors. */
	  
	  *x = -*x;
	      *u = -*u;
	}		
      if ((j % 2) && (bc2 == BC_REFLECTIVE))
	{
	  /* Odd number of y-surface crossings. Swap vectors. */
	  
	  *y = -*y;
	  *v = -*v;
	}
      
      *x = *x + RDB[param];
      *y = *y + RDB[param + 1]; 
      
      /***********************************************************************/
    }
  else if (type == SURF_CUBE)
    {
      /***** Cubical 3D-lattice **********************************************/
      
      /* Lattice pitch */
      
      px = 2.0*RDB[param + 3];
      py = 2.0*RDB[param + 3];
      pz = 2.0*RDB[param + 3];
      
      /* Centered co-ordinates */
	  
      *x = *x - RDB[param];
      *y = *y - RDB[param + 1];
      *z = *z - RDB[param + 2];
      
      /* Get indexes */
      
      GetLatticeIndexes(px, py, pz, *x, *y, *z, &i, &j, &k, LAT_TYPE_S);  
      
      /* Check leakage from partial boundary conditions */
      
      if ((bc1 == BC_BLACK) && i != 0)
	return -1;
      else if ((bc2 == BC_BLACK) && j != 0)
	return -1;
      else if ((bc3 == BC_BLACK) && k != 0)
	return -1;
      
      /* Calculate new position */
      
      *x = *x - i*px;
      *y = *y - j*py;
      *z = *z - k*pz;
      
      /* Handle Reflection */
      
      if ((i % 2) && (bc1 == BC_REFLECTIVE))
	{
	  /* Odd number of x-surface crossings. Swap vectors. */
	  
	  *x = -*x;
	  *u = -*u;
	}		
      if ((j % 2) && (bc2 == BC_REFLECTIVE))
	{
	  /* Odd number of y-surface crossings. Swap vectors. */
	  
	  *y = -*y;
	  *v = -*v;
	}
      if ((j % 2) && (bc3 == BC_REFLECTIVE))
	{
	  /* Odd number of y-surface crossings. Swap vectors. */
	  
	  *z = -*z;
	  *w = -*w;
	}
      
      *x = *x + RDB[param];
      *y = *y + RDB[param + 1]; 
      *z = *z + RDB[param + 2]; 
      
      /***********************************************************************/
    }
  else if (type == SURF_CUBOID)
    {
      /***** Cuboidal 3D-lattice *********************************************/
      
      /* Get pitches */
      
      px = (RDB[param + 1] - RDB[param]);
      py = (RDB[param + 3] - RDB[param + 2]);
      pz = (RDB[param + 5] - RDB[param + 4]);
      
      /* Center co-ordinates */
      
      x0 = (RDB[param] + RDB[param + 1])/2.0;
      y0 = (RDB[param + 2] + RDB[param + 3])/2.0;
      z0 = (RDB[param + 4] + RDB[param + 5])/2.0;
      
      /* Transfer co-ordinates */
      
      *x = *x - x0;
      *y = *y - y0;
      *z = *z - z0;
      
      /* Get indexes */
      
      GetLatticeIndexes(px, py, pz, *x, *y, *z, &i, &j, &k, LAT_TYPE_S);  
      
      /* Check leakage from partial boundary conditions */
      
      if ((bc1 == BC_BLACK) && i != 0)
	return -1;
      else if ((bc2 == BC_BLACK) && j != 0)
	return -1;
      else if ((bc3 == BC_BLACK) && k != 0)
	return -1;
	    
      /* Calculate new position */
      
      *x = *x - i*px;
      *y = *y - j*py;
      *z = *z - k*pz;
      
      /* Handle Reflection */
      
      if ((i % 2) && (bc1 == BC_REFLECTIVE))
	{
	  /* Odd number of x-surface crossings. Swap vectors. */
	  
	  *x = -*x;
	  *u = -*u;
	}		
      if ((j % 2) && (bc2 == BC_REFLECTIVE))
	{
	  /* Odd number of y-surface crossings. Swap vectors. */
	  
	  *y = -*y;
	  *v = -*v;
	}
      if ((j % 2) && (bc3 == BC_REFLECTIVE))
	{
	  /* Odd number of y-surface crossings. Swap vectors. */
	  
	  *z = -*z;
	  *w = -*w;
	}
      
      /* Transfer co-ordinates */
      
      *x = *x + x0;
      *y = *y + y0;
      *z = *z + z0;
      
      /***********************************************************************/	
    }
  else if ((type == SURF_HEXYC) || (type == SURF_HEXYPRISM))
    {
      /***** Hexagonal Y-type lattice ****************************************/
      
      /* Check boundary condition */
      
      if (bc0 < 0)
	Error(0, "Invalid boundary condition with hexagonal surface type");
      
      /* Center co-ordinates */
      
      x0 = RDB[param];
      y0 = RDB[param + 1];
      z0 = 0.0;
      
      /* Check */
      
      if ((x0 != 0.0) || (y0 != 0.0))
	Error(0, "Only centred hexagonal repeated boundaries allowed");
      
      /* Lattice pitch */
      
      px = 2.0*RDB[param + 2];
      py = 2.0*RDB[param + 2];
      
      /* Z-pitch */
      
      if (type == SURF_HEXYPRISM)
	{
	  pz = (RDB[param + 4] - RDB[param + 3]);
	  z0 = (RDB[param + 3] + RDB[param + 4])/2.0;
	}
      else
	pz = INFTY;
      
      /* Transfer */
      
      *x = *x - x0;
      *y = *y - y0;
      *z = *z - z0;
      
      /* Get indexes */
      
      GetLatticeIndexes(px, py, pz, *x, *y, *z, &i, &j, &k, LAT_TYPE_HY);
      
      /* Calculate new position */
      
      *y = *y - (i*py + COS60*j*py);
      *x = *x - SIN60*j*px;
      *z = *z - k*pz;
      
      /* Handle Reflection */
      
      if ((bc0 == BC_REFLECTIVE) && (k % 2))
	{
	  /* Odd number of z-surface crossings. Swap vectors. */
	  
	  *z = -*z;
	  *w = -*w;
	}
      
      /* Transfer */
      
      *x = *x + x0;
      *y = *y + y0;
      *z = *z + z0;

      /***********************************************************************/
    }
  else if ((type == SURF_HEXXC) || (type == SURF_HEXXPRISM))
    {
      /***** Hexagonal X-type lattice ****************************************/
      
      /* Check boundary condition */
      
      if (bc0 < 0)
	Error(0, "Invalid boundary condition with hexagonal surface type");
      
      /* Center co-ordinates */
      
      x0 = RDB[param];
      y0 = RDB[param + 1];
      z0 = 0.0;
	  
      /* Check */
      
      if ((x0 != 0.0) || (y0 != 0.0))
	Error(0, "Only centred hexagonal repeated boundaries allowed");
      
      /* Lattice pitch */
      
      px = 2.0*RDB[param + 2];
      py = 2.0*RDB[param + 2];
      
      /* Z-pitch */
      
      if (type == SURF_HEXXPRISM)
	{
	  pz = (RDB[param + 4] - RDB[param + 3]);
	  z0 = (RDB[param + 3] + RDB[param + 4])/2.0;
	}
      else
	pz = INFTY;
      
      /* Transfer */
      
      *x = *x - x0;
      *y = *y - y0;
      *z = *z - z0;
      
      /* Get indexes */
      
      GetLatticeIndexes(px, py, pz, *x, *y, *z, &i, &j, &k, LAT_TYPE_HX);
      
      /* Calculate new position */
      
      *x = *x - (i*px + COS60*j*px);
      *y = *y - SIN60*j*py;
      *z = *z - k*pz;
      
      /* Handle Reflection */
      
      if ((bc0 == BC_REFLECTIVE) && (k % 2))
	{
	  /* Odd number of z-surface crossings. Swap vectors. */
	  
	  *z = -*z;
	  *w = -*w;
	}
      
      /* Transfer */
      
      *x = *x + x0;
      *y = *y + y0;
      *z = *z + z0;
      
      /***********************************************************************/
    }
  else
    {
      /* Other surface types treated as black boundaries. */
      
      return -1;
    }
  
  /* Check that lattice indexes have been changed */

  if ((i == 0) && (j == 0) && (k == 0))
    Die(FUNCTION_NAME, "No change in lattice indexes");

  /* Potential numerical problems */
  
  if ((fabs(px/2.0 - *x) < 1E-15) || (fabs(py/2.0 - *y) < 1E-15) || 
      (fabs(pz/2.0 - *z) < 1E-15))
    Die(FUNCTION_NAME, "Infinite loop? (position too close to boudary)"); 

  /* Exit subroutine */
  
  return YES;
}

/*****************************************************************************/
