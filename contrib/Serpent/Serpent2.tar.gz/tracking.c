/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : tracking.c                                     */
/*                                                                           */
/* Created:       2011/03/10 (JLe)                                           */
/* Last modified: 2012/01/18 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Main tracking loop for single particle and secondaries       */
/*                                                                           */
/* Comments: - Fission neutrons are treated as secondaries in external       */
/*             source mode. In criticality source mode they form the         */
/*             source distribution for the next generation.                  */
/*                                                                           */
/*           - WhereAmI() must always be called before NearestBoundary()     */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Tracking:"

/*****************************************************************************/

void Tracking(long id)
{
  long part, cell, mat, rea, bc, type, loop, ptr, ncol;
  double x, y, z, u, v, w, E, wgt, l, d, totxs, majorant, minxs, xs;

  /* Add to history counter */

  ptr = (long)RDB[DATA_PTR_OMP_HISTORY_COUNT];
  AddPrivateData(ptr, 1.0, id);

  /* Main loop over particle history and secondaries */

  while ((part = FromQue(id)) > VALID_PTR)
    {    
      /* Check MPI index */

      if ((long)RDB[part + PARTICLE_MPI_ID] != mpiid)
	{
	  /* Put particle back in stack */
	      
	  ToStack(part, id);

	  /* Return */

	  return;
	}

      /* Get particle data */

      x = RDB[part + PARTICLE_X];
      y = RDB[part + PARTICLE_Y];
      z = RDB[part + PARTICLE_Z];
      
      u = RDB[part + PARTICLE_U];
      v = RDB[part + PARTICLE_V];
      w = RDB[part + PARTICLE_W];
      
      E = RDB[part + PARTICLE_E];
      wgt = RDB[part + PARTICLE_WGT];

      type = (long)RDB[part + PARTICLE_TYPE];
      
      /* Find initial location */
	      
      cell = WhereAmI(x, y, z, u, v, w, id);
      CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);

      /* Check that particle is in geometry */
      /*
      if ((long)RDB[cell + CELL_TYPE] == CELL_TYPE_OUTSIDE)
	Die(FUNCTION_NAME, "Particle started outside geometry");
      */
      /* Get material pointer */

      mat = (long)RDB[cell + CELL_PTR_MAT];

      /* Store point in history array */

      StoreHistoryPoint(part, mat, -1, x, y, z, u, v, w, E, wgt, 0.0, YES);

      /* Get minimum cross section (NOTE: toi arvo) */

      if ((long)RDB[DATA_OPT_USE_DT] == NO)
	minxs = 0.2;
      else if (type == PARTICLE_TYPE_NEUTRON)
	minxs = RDB[DATA_MIN_NMACROXS];
      else
	minxs = RDB[DATA_MIN_PMACROXS];

      /* Check value */

      CheckValue(FUNCTION_NAME, "minxs", "", minxs, ZERO, 1E+12);

      /* Reset number of loops */

      loop = 0;
      
      /* Tracking loop */
      
      do
	{
	  /* Check infinite loop */

	  if (loop++ > 1000000)
	    Die(FUNCTION_NAME, "Infinite tracking loop");

	  /* Get collision number */

	  ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
	  ncol = (long)GetPrivateData(ptr, id);

	  /* Increase value and store */

	  ncol++;
	  PutPrivateData(ptr, ncol, id);	  

	  /* Variance reduction */
	  /*
	  if (VrTester(part, x, y, z, u, v, w, E, &wgt, id) < VALID_PTR)
	    break;
	  */
	  /* Check particle type */

	  if (type == PARTICLE_TYPE_NEUTRON)
	    {
	      /* Get total neutron cross section */
      
	      if (mat > VALID_PTR)
		{
		  rea = (long)RDB[mat + MATERIAL_PTR_TOTXS];
		  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
		  totxs = TotXS(rea, E, id);
		}
	      else
		totxs = 0.0;
	      
	      /* Get neutron majorant cross section */
	      
	      if ((rea = RDB[DATA_PTR_MAJORANT]) > VALID_PTR)
		majorant = MajorantXS(rea, E, id);
	      else
		majorant = INFTY;
	    }
	  else
	    {
	      /* Get total photon cross section */

	      if (mat > VALID_PTR)
		{
		  rea = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
		  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
		  totxs = TotXS(rea, E, id);
		}
	      else
		totxs = 0.0;
	      
	      /* Get photon majorant cross section */
	      
	      if ((rea = RDB[DATA_PTR_PHOTON_MAJORANT]) > VALID_PTR)
		majorant = MajorantXS(rea, E, id);
	      else
		majorant = INFTY;
	    }

	  /* Check majorant */

	  if (majorant < ZERO)
	    Die(FUNCTION_NAME, "Majorant xs too low (E = %E, xs = %E)",
		E, majorant);

	  CheckValue(FUNCTION_NAME, "majorant", "", majorant, ZERO, INFTY);

	  /* Compare total cross section and majorant */

	  if (totxs/majorant < RDB[DATA_DT_THRESH])
	    {
	      /***************************************************************/

	      /***** Surface tracking ****************************************/

	      /* Add to count */
		
	      ptr = (long)RDB[RES_TRACK_ST];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      AddBuf(1.0, 1.0, ptr, id, 2 - type);

	      /* Set cross section for sampling path length */

	      if (totxs < minxs)
		xs = minxs;
	      else
		xs = totxs;
	      
	      /* Find location */

	      WhereAmI(x, y, z, u, v, w, id);
	      
	      /* Get distance to nearest boundary */

	      d = NearestBoundary(id);

	      /* Sample path length */

	      if (xs > 0.0)
		l = -log(RandF(id))/xs;
	      else
		l = INFTY;

	      /* Compare distances */

	      if (l < d)
		{
		  /* Move particle to collision site */
		  
		  x = x + l*u;
		  y = y + l*v;
		  z = z + l*w;

		  /* Score track length or collision */

		  Score(xs, l, mat, E, wgt, x, y, z, u, v, w, part, id);

		  /* Store point in history array */

		  StoreHistoryPoint(part, mat, rea, x, y, z, u, v, w, E, wgt, 
				    1.0/xs, NO);

		  /* Sample between real and virtual collision */
		      
		  if (RandF(id) < totxs/minxs)
		    part = Collision(mat, part, type, &x, &y, &z, &u, &v, &w, 
				     &E, &wgt, id);
		}
	      else
		{
		  /* Score track length (done before moving the neutron) */
		  
		  Score(-1.0, d, mat, E, wgt, x, y, z, u, v, w, part, id);

		  /* Move particle over the surface */

		  x = x + (d + EXTRAP_L)*u;
		  y = y + (d + EXTRAP_L)*v;
		  z = z + (d + EXTRAP_L)*w;

		  /* Find location */
	      
		  if ((cell = WhereAmI(x, y, z, u, v, w, id)) > VALID_PTR)
		    {
		      /* Test boundary conditions */
		      
		      bc = BoundaryConditions(&x, &y, &z, &u, &v, &w, id);

		      /* Check repeated and leak */
		      
		      if (bc == YES)
			cell = WhereAmI(x, y, z, u, v, w, id);
		      else if (bc < 0)
			{
			  /* Score leakage */

			  Leak(part, x, y, z, u, v, w, E, wgt, id);
			  
			  /* Break loop */

			  break;
			}
		    }
		  else
		    Die(FUNCTION_NAME, "Tracking error (st)");

		  /* Get material pointer */

		  mat = (long)RDB[cell + CELL_PTR_MAT];
		}

	      /***************************************************************/
	    }
       	  else
	    {
	      /***** Delta-tracking ******************************************/

	      /* Add to count */

	      ptr = (long)RDB[RES_TRACK_DT];
	      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
	      AddBuf(1.0, 1.0, ptr, id, 2 - type);

	      /* Sample path length */

	      l = -log(RandF(id))/majorant;
	      
	      /* Update position */
	      
	      x = x + l*u;
	      y = y + l*v;
	      z = z + l*w;
	      
	      /* Find location */
	      
	      if ((cell = WhereAmI(x, y, z, u, v, w, id)) > VALID_PTR)
		{
		  /* Test boundary conditions */
		  
		  bc = BoundaryConditions(&x, &y, &z, &u, &v, &w, id);
		  
		  /* Check repeated and leak */
		  
		  if (bc == YES)
		    cell = WhereAmI(x, y, z, u, v, w, id);
		  else if (bc < 0)
		    {
		      /* Score leakage */

		      Leak(part, x, y, z, u, v, w, E, wgt, id);
			  
		      /* Break loop */

		      break;
		    }
		}
	      else
		Die(FUNCTION_NAME, "Tracking error (dt)");
	      
	      /* Get material pointer */
	      
	      if ((mat = (long)RDB[cell + CELL_PTR_MAT]) > VALID_PTR)
		{
		  /* Get pointer to total xs */
		  
		  if (type == PARTICLE_TYPE_NEUTRON)
		    rea = (long)RDB[mat + MATERIAL_PTR_TOTXS];
		  else
		    rea = (long)RDB[mat + MATERIAL_PTR_TOTPHOTXS];
		  
		  /* Get total xs */

  		  CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
		  totxs = TotXS(rea, E, id);		  

		  /* Compare to majorant (NOTE: tää voi ylittyä jos moodi */
		  /* on < 2 ja grid thinning käytössä). */

		  if (totxs/majorant - 1.0 > 1E-6)
		    Die(FUNCTION_NAME, 
			"Total exceeds majorant (f = %E, E = %E, mat = %s)",
			totxs/majorant - 1.0, E, 
			GetText(mat + MATERIAL_PTR_NAME));
		}
	      else
		totxs = 0.0;
	      
	      /* Compare to minimum value */

	      if (totxs > minxs)
		{	
		  /* Sample between real and virtual collision */
	      
		  if (RandF(id) < totxs/majorant)
		    {
		      /* Score collision */

		      Score(totxs, -1.0, mat, E, wgt, x, y, z, u, v, w, part, 
			    id);

		      /* Store point in history array */

		      StoreHistoryPoint(part, mat, rea, x, y, z, u, v, w, E, 
					wgt, 1.0/totxs, NO);

		      /* Collision */
		      
		      part = Collision(mat, part, type, &x, &y, &z, &u, &v, &w,
				       &E, &wgt, id);
		    }
		  else
		    {
		      /* Add to count */
		      
		      ptr = (long)RDB[RES_REA_SAMPLE_VIRT];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      AddBuf(1.0, 1.0, ptr, id, 2 - type);
		    }
		}
	      else 
		{
		  /* Sample scoring */
	      
		  if (RandF(id) < minxs/majorant)
		    {
		      /* Score collision */

		      Score(minxs, -1.0, mat, E, wgt, x, y, z, u, v, w, part, 
			    id);

		      /* Store point in history array */

		      StoreHistoryPoint(part, mat, rea, x, y, z, u, v, w, E, 
					wgt, 1.0/minxs, NO);

		      /* Sample between real and virtual collision */

		      if (RandF(id) < totxs/minxs)
			{
			  /* Collision */
		      
			  part = Collision(mat, part, type, &x, &y, &z, &u, &v,
					   &w, &E, &wgt, id);		      
			}
		      else
			{
			  /* Add to count */
			  
			  ptr = (long)RDB[RES_REA_SAMPLE_VIRT];
			  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY,ptr);
			  AddBuf(1.0, 1.0, ptr, id, 2 - type);
			}
		    }
		  else
		    {
		      /* Add to count */
		      
		      ptr = (long)RDB[RES_REA_SAMPLE_VIRT];
		      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
		      AddBuf(1.0, 1.0, ptr, id, 2 - type);
		    }
		}
	      
	      /***************************************************************/
	    }
	}
      while (part > VALID_PTR);
    }
}

/*****************************************************************************/
