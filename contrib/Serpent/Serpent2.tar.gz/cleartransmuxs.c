/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : cleartransmuxs.c                               */
/*                                                                           */
/* Created:       2011/05/23 (JLe)                                           */
/* Last modified: 2012/02/01 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Clears all reaction rates etc. used for burnup calculation   */
/*                                                                           */
/* Comments: - This is done in a separate subroutine to simplify things in   */
/*             MPI mode                                                      */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ClearTransmuXS:"

/*****************************************************************************/

void ClearTransmuXS()
{
  long mat, loc0, rea, i, dep, id;

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check burn flag */

      if (!((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT))
	{
	  /* Next material */

	  mat = NextItem(mat);

	  /* Cycle loop */
	  
	  continue;
	}

      /* Pointer to depletion list */
  
      if ((loc0 = (long)RDB[mat + MATERIAL_PTR_DEP_TRA_LIST]) > VALID_PTR)
	{  
	  /* Loop over reactions */
	  
	  i = 0;
	  while ((dep = ListPtr(loc0, i++)) > VALID_PTR)
	    {
	      /* Pointer to reaction */
	  
	      rea = (long)RDB[dep + DEP_TRA_PTR_REA];
	      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	  
	      /* Put zero value */

	      for (id = 0; id < (long)RDB[DATA_OMP_MAX_THREADS]; id++)
		StoreValuePair(rea + REACTION_PTR_TRANSMUXS, mat, 0.0, id);
	    }
	}

      /* Pointer to fission list */
      
      if ((loc0 = (long)RDB[mat + MATERIAL_PTR_DEP_FISS_LIST]) > VALID_PTR)
	{  
	  /* Loop over reactions */
	  
	  i = 0;
	  while ((dep = ListPtr(loc0, i++)) > VALID_PTR)
	    {
	      /* Pointer to reaction */
	      
	      rea = (long)RDB[dep + DEP_TRA_PTR_REA];
	      CheckPointer(FUNCTION_NAME, "(rea)", DATA_ARRAY, rea);
	      
	      /* Put zero value */

	      for (id = 0; id < (long)RDB[DATA_OMP_MAX_THREADS]; id++)
		StoreValuePair(rea + REACTION_PTR_TRANSMUXS, mat, 0.0, id);
	    }
	}

      /* Next material */

      mat = NextItem(mat);
    }

  /***************************************************************************/
}

/*****************************************************************************/
