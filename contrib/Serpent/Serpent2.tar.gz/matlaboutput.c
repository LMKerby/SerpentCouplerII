/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : matlaboutput.c                                 */
/*                                                                           */
/* Created:       2011/03/13 (JLe)                                           */
/* Last modified: 2012/01/18 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Prints standard output in Matlab format file                 */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "MatlabOutput:"

/*****************************************************************************/

void MatlabOutput()
{
  long gcu, ptr, ng, n, uni;
  char outfile[MAX_STR], tmpstr[MAX_STR];
  FILE *fp;

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* Check corrector step */

  if ((long)RDB[DATA_BURN_STEP_PC] == CORRECTOR_STEP) 
    return;

  /* File name */

  sprintf(outfile, "%s_res.m", GetText(DATA_PTR_INPUT_FNAME));

  /* Open file for writing (append files if burnup calculation) */

  if (((long)RDB[DATA_RUNNING_MODE] != RUNNING_MODE_INT_BURN) ||
      (((long)RDB[DATA_BURN_STEP] == 0) &&
       ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)))
    fp = fopen(outfile, "w");
  else if ((long)RDB[DATA_SIMULATION_COMPLETED] == YES)
    fp = fopen(outfile, "a");
  else
    return;

  /* Check pointer */

  if (fp == NULL)
    Die(FUNCTION_NAME, "Unable to open file for writing");

  /* Pointer to gc universe list */

  gcu = (long)RDB[DATA_PTR_GCU0];

  /* Loop over gc universes */

  do
    {
      /* increase counter */
      
      fprintf(fp, "\n%% Increase counter:\n\n");
      
      fprintf(fp, "if (exist(\'idx\', \'var\'));\n");
      fprintf(fp, "  idx = idx + 1;\n");
      fprintf(fp, "else;\n");
      fprintf(fp, "  idx = 1;\n"); 
      fprintf(fp, "end;\n");
      
      /***********************************************************************/

      /***** Title and data **************************************************/
      
      sprintf(tmpstr, "%s %s", CODE_NAME, CODE_VERSION);
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Version, title and date:\n\n");
      
      fprintf(fp, "VERSION                   (idx, [1:%3ld])  = '%s' ;\n", 
	      (long)strlen(tmpstr), tmpstr);
      
      if ((long)RDB[DATA_PTR_TITLE] > VALID_PTR)
	fprintf(fp, "TITLE                     (idx, [1:%3ld])  = '%s' ;\n", 
		(long)strlen(GetText(DATA_PTR_TITLE)),
		GetText(DATA_PTR_TITLE));
      else
	fprintf(fp, "TITLE                     (idx, [1:%3ld])  = '%s' ;\n", 
		(long)strlen("Untitled"), "Untitled");
      
      fprintf(fp, "DATE                      (idx, [1:%3ld])  = '%s' ;\n", 
	      (long)strlen(GetText(DATA_PTR_DATE)),
	      GetText(DATA_PTR_DATE));
      
      /***********************************************************************/

      /***** Run parameters **************************************************/
    
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Run parameters:\n\n");
      
      fprintf(fp, "POP                       (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_NBATCH]);
      fprintf(fp, "CYCLES                    (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_CYCLES]);
      fprintf(fp, "SKIP                      (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_SKIP]);
      fprintf(fp, "SRC_NORM_MODE             (idx, 1)        = 2 ;\n");
      
      fprintf(fp, "SEED                      (idx, 1)        = %lu ;\n", 
	      parent_seed);
      
      /* Print optimization mode */

      fprintf(fp, "OPTIMIZATION_MODE         (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_OPTI_MODE]);

      /* Group constant calculation */

      fprintf(fp, "GROUP_CONSTANT_GENERATION (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_OPTI_GC_CALC]);

      /* B1 calculation */

      fprintf(fp, "B1_CALCULATION            (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_OPTI_FUM_CALC]);

      /* Implicit reaction rates */

      fprintf(fp, "IMPLICIT_REACTION_RATES   (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_OPTI_IMPLICIT_RR]);


      /* Print debug mode */
      
#ifdef DEBUG
      
      fprintf(fp, "DEBUG                     (idx, 1)        = 1 ;\n");
      
#else
      
      fprintf(fp, "DEBUG                     (idx, 1)        = 0 ;\n");
      
#endif
      
      /* Print cpu type */

      if ((long)RDB[DATA_PTR_CPU_NAME] > 0.0)
	fprintf(fp, "CPU_TYPE                  (idx, [1:%3ld])  = '%s' ;\n", 
		(long)strlen(GetText(DATA_PTR_CPU_NAME)),
		GetText(DATA_PTR_CPU_NAME));

      /* Print MHz */

      if (RDB[DATA_CPU_MHZ] > 0.0)
	fprintf(fp, "CPU_MHZ                   (idx, 1)        = %1.1f ;\n", 
		RDB[DATA_CPU_MHZ]);

      /* Print available memory */

      if (RDB[DATA_CPU_MEM] > 0.0)
	fprintf(fp, "AVAIL_MEM                 (idx, 1)        = %1.1f ;\n", 
		RDB[DATA_CPU_MEM]*GIGA/MEGA);

      /***********************************************************************/

      /***** Parallelization *************************************************/
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Parallelization:\n\n");

      fprintf(fp, "MPI_TASKS                 (idx, 1)        = %d ;\n", 
	      mpitasks);
      /*
      fprintf(fp, "MPI_MODE                  (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_MPI_MODE]);
      */

      fprintf(fp, "OMP_THREADS               (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_OMP_MAX_THREADS]);

      if ((long)RDB[DATA_OMP_MAX_THREADS] > 1)
	{
	  fprintf(fp, "OMP_HISTORY_FRAC          (idx, [1: %3ld]) = [ ", 
		  (long)RDB[DATA_OMP_MAX_THREADS]);
	  
	  ptr = (long)RDB[DATA_PTR_OMP_HISTORY_COUNT];
      
	  for (n = 0; n < (long)RDB[DATA_OMP_MAX_THREADS]; n++)
	    fprintf(fp, "%12.5E ", 
		    GetPrivateData(ptr, n)/SumPrivateData(ptr));
		
	  fprintf(fp, " ];\n");
	}

      /* Shared scoring buffer */

      fprintf(fp, "SHARE_BUF_ARRAY           (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_OPTI_SHARED_BUF]);

      fprintf(fp, "SHARE_RES2_ARRAY          (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_OPTI_SHARED_RES2]);
      
      /***********************************************************************/

      /***** File paths ******************************************************/
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% File paths:\n\n");
      
      /* ACE directory file (only first file printed) */

      if ((ptr = (long)RDB[DATA_PTR_ACEDATA_FNAME_LIST]) > VALID_PTR)
	sprintf(tmpstr, "%s", GetText(ptr));
      else
	sprintf(tmpstr, "N/A");      

      fprintf(fp, "XS_DATA_FILE_PATH         (idx, [1:%3ld])  = '%s' ;\n", 
	      (long)strlen(tmpstr), tmpstr);

      /* Decay data file path (only first file printed) */

      if ((ptr = (long)RDB[DATA_PTR_DECDATA_FNAME_LIST]) > VALID_PTR)
	sprintf(tmpstr, "%s", GetText(ptr));
      else
	sprintf(tmpstr, "N/A");
      
      fprintf(fp, "DECAY_DATA_FILE_PATH      (idx, [1:%3ld])  = '%s' ;\n", 
	      (long)strlen(tmpstr), tmpstr);

      /* Spontaneous fission yield data file path (only first file printed) */

      if ((ptr = (long)RDB[DATA_PTR_NFYDATA_FNAME_LIST]) > VALID_PTR)
	sprintf(tmpstr, "%s", GetText(ptr));
      else
	sprintf(tmpstr, "N/A");

      fprintf(fp, "SFY_DATA_FILE_PATH        (idx, [1:%3ld])  = '%s' ;\n", 
	      (long)strlen(tmpstr), tmpstr);

      /* Neutron-induced fission yield data file path (only first file printed) */

      if ((ptr = (long)RDB[DATA_PTR_NFYDATA_FNAME_LIST]) > VALID_PTR)
	sprintf(tmpstr, "%s", GetText(ptr));
      else
	sprintf(tmpstr, "N/A");

      fprintf(fp, "NFY_DATA_FILE_PATH        (idx, [1:%3ld])  = '%s' ;\n", 
	      (long)strlen(tmpstr), tmpstr);

      /* Isomeric branching ratio file path */

      if ((long)RDB[DATA_PTR_IBR_FNAME] > VALID_PTR)
	sprintf(tmpstr, "%s", GetText(DATA_PTR_IBR_FNAME));
      else
	sprintf(tmpstr, "N/A");

      fprintf(fp, "IBR_DATA_FILE_PATH        (idx, [1:%3ld])  = '%s' ;\n", 
	      (long)strlen(tmpstr), tmpstr);

      /***********************************************************************/

      /***** Delta-tracking parameters ***************************************/
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Delta-tracking and reaction sampling parameters:\n\n");
      
      fprintf(fp, "DT_THRESH                 (idx, 1)        = %11.5E ;\n", 
	      1.0 - RDB[DATA_DT_THRESH]);

      PrintValues(fp, "DT_FRAC", RES_DT_FRAC, 2, -1, -1, 0, 0);

      PrintValues(fp, "DT_EFF", RES_DT_EFF, 2, -1, -1, 0, 0);
      
      fprintf(fp, "MIN_MACROXS               (idx, [1:  2])  = [ %11.5E %11.5E ];\n", 
	      RDB[DATA_MIN_NMACROXS], RDB[DATA_MIN_PMACROXS]);

      PrintValues(fp, "REA_SAMPLING_ACC", 
		  RES_REA_SAMPLE_ACC, 2, -1, -1, 0, 0);

      PrintValues(fp, "REA_SAMPLING_REJ", 
		  RES_REA_SAMPLE_REJ, 2, -1, -1, 0, 0);

      PrintValues(fp, "REA_SAMPLING_FAIL", 
		  RES_REA_SAMPLE_FAIL, 2, -1, -1, 0, 0);

      /***********************************************************************/

      /***** Run statistics **************************************************/
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Run statistics:\n\n");
      
      fprintf(fp, "TOT_CPU_TIME              (idx, 1)        = %11.5E ;\n", 
	      TimerCPUVal(TIMER_RUNTIME)/60.);

      fprintf(fp, "RUNNING_TIME              (idx, 1)        = %11.5E ;\n", 
	      TimerVal(TIMER_RUNTIME)/60.0);

      fprintf(fp, "CPU_USAGE                 (idx, 1)        = %1.5f ;\n", 
	      TimerCPUVal(TIMER_RUNTIME)/TimerVal(TIMER_RUNTIME));
      
      fprintf(fp, "INIT_TIME                 (idx, 1)        = %11.5E ;\n", 
	      TimerVal(TIMER_INIT)/60.0);

      fprintf(fp, "OMP_PARALLEL_RUNTIME      (idx, 1)        = %11.5E ;\n", 
	      TimerVal(TIMER_OMP_PARA)/60.0);

      fprintf(fp, "TRANSPORT_CYCLE_TIME      (idx, [1:  2])  = [ %11.5E %11.5E ];\n", 
	      TimerVal(TIMER_TRANSPORT_TOTAL)/60.0, TimerVal(TIMER_TRANSPORT)/60.0);
    
      fprintf(fp, "BURNUP_CYCLE_TIME         (idx, [1:  2])  = [ %11.5E %11.5E ];\n", 
	      TimerVal(TIMER_BURNUP_TOTAL)/60.0, TimerVal(TIMER_BURNUP)/60.0);
      
      fprintf(fp, "PROCESS_TIME              (idx, [1:  2])  = [ %11.5E %11.5E ];\n", 
	      TimerVal(TIMER_PROCESS_TOTAL)/60.0, TimerVal(TIMER_PROCESS)/60.0);

      fprintf(fp, "BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [ %11.5E %11.5E ];\n", 
	      TimerVal(TIMER_BATEMAN_TOTAL)/60.0, TimerVal(TIMER_BATEMAN)/60.0);
    

      fprintf(fp, "ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [ %11.5E %11.5E ];\n", RDB[DATA_ESTIM_CYCLE_TIME]/60.0, RDB[DATA_ESTIM_TOT_TIME]/60.0);


      PrintValues(fp, "TRANSPORT_CPU_USAGE", RES_CPU_USAGE, 1, -1, -1, 0, 0);

      fprintf(fp, "CYCLE_IDX                 (idx, 1)        = %ld ;\n", 
	      (long)(RDB[DATA_CYCLE_IDX] - RDB[DATA_SKIP]) + 1);
      
      fprintf(fp, "SOURCE_NEUTRONS           (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_NHIST_CYCLE]);

      ptr = (long)RDB[RES_MEAN_POP_SIZE];
      fprintf(fp, "MEAN_POP_SIZE             (idx, [1:  2])  = [ %12.5E %7.5f ];\n", Mean(ptr, 0), RelErr(ptr, 0));
      
      fprintf(fp, "MEMSIZE                   (idx, 1)        = %1.2f;\n", 
	      (double)RDB[DATA_TOTAL_BYTES]/MEGA);

      fprintf(fp, "ALLOC_MEMSIZE             (idx, 1)        = %1.2f;\n", 
	      (double)RDB[DATA_REAL_BYTES]/MEGA);

      if ((long)RDB[DATA_BURN_MATERIALS] > 0)
	fprintf(fp, "BURN_MAT_MEMSIZE          (idx, 1)        = %1.2f;\n", 
		(double)RDB[DATA_BURN_MAT_BYTES]/MEGA);

      fprintf(fp, "SIMULATION_COMPLETED      (idx, 1)        = %ld ;\n",
	      (long)RDB[DATA_SIMULATION_COMPLETED]);
      
      /***********************************************************************/

      /***** Energy grid parameters ******************************************/

      /* Pointer to unionized grid */

      if ((ptr = (long)RDB[DATA_ERG_PTR_UNIONIZED_GRID]) > VALID_PTR)
	{      
	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% Unionized energy grid:\n\n");
	  
	  fprintf(fp, "ERG_TOL                   (idx, 1)        = %11.5E ;\n", 
		  RDB[DATA_ERG_TOL]);
	  
	  fprintf(fp, "ERG_NE                    (idx, 1)        = %ld ;\n", 
		  (long)RDB[ptr + ENERGY_GRID_NE]);
	}
    
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Energy boundaries:\n\n");

      fprintf(fp, "NEUTRON_EMIN              (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_NEUTRON_EMIN]); 
      
      fprintf(fp, "NEUTRON_EMAX              (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_NEUTRON_EMAX]);

      fprintf(fp, "PHOTON_EMIN               (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_PHOTON_EMIN]); 
      
      fprintf(fp, "PHOTON_EMAX               (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_PHOTON_EMAX]);

      /*
      fprintf(fp, "ERG_NE_INI                (idx, 1)        = %ld ;\n", 
	      (long)RDB[ptr + ENERGY_GRID_INITIAL_PTS]);
      
      fprintf(fp, "ERG_NE_IMP                (idx, 1)        = %ld ;\n", 
	      (long)RDB[ptr + ENERGY_GRID_IMPORTANT_PTS]);
      
      fprintf(fp, "ERG_DIX                   (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_XS_EGRID_MODE] - 1);

      if ((long)RDB[DATA_USE_DBRC] == YES)
	fprintf(fp, "USE_DBRC                  (idx, 1)        = 1 ;\n");
      else
	fprintf(fp, "USE_DBRC                  (idx, 1)        = 0 ;\n");
      */
      /***********************************************************************/
      
      /***** Unresolved resonance data ***************************************/
      /*
      fprintf(fp, "URES_MODE                 (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_URES_MODE]);
      */

      fprintf(fp, "URES_DILU_CUT             (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_URES_DILU_CUT]);

      fprintf(fp, "URES_EMIN                 (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_URES_EMIN]); 
      
      fprintf(fp, "URES_EMAX                 (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_URES_EMAX]);

      fprintf(fp, "URES_AVAIL                (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_URES_AVAIL]);

      fprintf(fp, "URES_USED                 (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_URES_USED]);
      
      /***********************************************************************/
      
      /***** Nuclides and reaction channels **********************************/
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Nuclides and reaction channels:\n\n");
      
      fprintf(fp, "TOT_NUCLIDES              (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_N_TOT_NUCLIDES]);
      
      fprintf(fp, "TOT_TRANSPORT_NUCLIDES    (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_N_TRANSPORT_NUCLIDES]);

      fprintf(fp, "TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_N_DOSIMETRY_NUCLIDES]);
      
      fprintf(fp, "TOT_DECAY_NUCLIDES        (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_N_DECAY_NUCLIDES]);

      fprintf(fp, "TOT_PHOTON_NUCLIDES       (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_N_PHOTON_NUCLIDES]);
      
      fprintf(fp, "TOT_REA_CHANNELS          (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_N_TRANSPORT_REA]);

      fprintf(fp, "TOT_TRANSMU_REA           (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_N_TRANSMUTATION_REA]);

      /***********************************************************************/
      
      /***** Phisics options *************************************************/
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Physics options:\n\n");

      fprintf(fp, "USE_DELNU                 (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_USE_DELNU]);

      fprintf(fp, "USE_URES                  (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_USE_URES]);

      fprintf(fp, "USE_DBRC                  (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_USE_DBRC]);

      fprintf(fp, "IMPL_CAPT                 (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_OPT_IMPL_CAPT]);

      fprintf(fp, "IMPL_NXN                  (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_OPT_IMPL_NXN]);

      fprintf(fp, "IMPL_FISS                 (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_OPT_IMPL_FISS]);

      fprintf(fp, "DOPPLER_MODE              (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_DOPPLER_MODE]);

      /***********************************************************************/

      /***** Radioactivity data **********************************************/

      fprintf(fp, "\n");
      
      fprintf(fp, "%% Radioactivity data:\n\n");

      fprintf(fp, "TOT_ACTIVITY              (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_TOT_ACTIVITY]);
      fprintf(fp, "TOT_DECAY_HEAT            (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_TOT_DECAY_HEAT]);

      fprintf(fp, "TOT_SF_RATE               (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_TOT_SFRATE]);

      fprintf(fp, "ACTINIDE_ACTIVITY         (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_ACT_ACTIVITY]);
      fprintf(fp, "ACTINIDE_DECAY_HEAT       (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_ACT_DECAY_HEAT]);
      
      fprintf(fp, "FISSION_PRODUCT_ACTIVITY  (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_FP_ACTIVITY]);
      fprintf(fp, "FISSION_PRODUCT_DECAY_HEAT(idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_FP_DECAY_HEAT]);

      /***********************************************************************/
          
      /***** Reaction mode counters ******************************************/

      /*      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Reaction mode counters:\n\n");

      fprintf(fp, "COLLISIONS                (idx, 1)        = %ld ;\n", 
	  (long)RDB[DATA_REA_TOT_N]);
      
      fprintf(fp, "FISSION_FRACTION          (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_REA_FISS_N]/(RDB[DATA_REA_TOT_N] + ZERO));
      
      fprintf(fp, "CAPTURE_FRACTION          (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_REA_CAPT_N]/(RDB[DATA_REA_TOT_N] + ZERO));
      
      fprintf(fp, "ELASTIC_FRACTION          (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_REA_ELA_N]/(RDB[DATA_REA_TOT_N] + ZERO));
      
      fprintf(fp, "INELASTIC_FRACTION        (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_REA_INL_N]/(RDB[DATA_REA_TOT_N] + ZERO));
      
      fprintf(fp, "ALPHA_FRACTION            (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_REA_ALPHA_N]/(RDB[DATA_REA_TOT_N] + ZERO));
      
      fprintf(fp, "BOUND_SCATTERING_FRACTION (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_REA_BOUND_N]/(RDB[DATA_REA_TOT_N] + ZERO));
      
      fprintf(fp, "NXN_FRACTION              (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_REA_NXN_N]/(RDB[DATA_REA_TOT_N] + ZERO));
      
      fprintf(fp, "UNKNOWN_FRACTION          (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_REA_UNKNOWN_N]/(RDB[DATA_REA_TOT_N] + ZERO));
      
      fprintf(fp, "VIRTUAL_FRACTION          (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_REA_VIRTUAL_N]/
	      (RDB[DATA_REA_TOT_N] + RDB[DATA_REA_VIRTUAL_N] + ZERO));
      
      fprintf(fp, "\n");
      
      fprintf(fp, "FREEGAS_FRACTION          (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_REA_FREEGAS_N]/(RDB[DATA_REA_ELA_N] + ZERO));
      
      fprintf(fp, "TOTAL_ELASTIC_FRACTION    (idx, 1)        = %11.5E ;\n", 
	      (RDB[DATA_REA_BOUND_N] + RDB[DATA_REA_ELA_N])
	      /(RDB[DATA_REA_TOT_N] + ZERO));
      
      fprintf(fp, "FISSILE_FISSION_FRACTION  (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_REA_FISS_FISS_N]/(RDB[DATA_REA_FISS_N] + ZERO));
      
      fprintf(fp, "LEAKAGE_REACTIONS         (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_REA_LEAK_N]);
      
      fprintf(fp, "\n");
      
      fprintf(fp, "REA_SAMPLING_EFF          (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_SAMPLED_REA_OK]/RDB[DATA_SAMPLED_REA_TOT]);
      */
      /***********************************************************************/
      
      /***** Slowing-down and thermalization *********************************/
      /*
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Slowing-down and thermalization:\n\n");
      
      PrintValues(fp, "COL_SLOW", RES_COL_SLOW, 1, -1);
      PrintValues(fp, "COL_THERM", RES_COL_THERM, 1, -1);
      PrintValues(fp, "COL_TOT", RES_COL_TOT, 1, -1);
          
      PrintValues(fp, "SLOW_TIME", RES_SLOW_TIME, 1, -1);
      PrintValues(fp, "THERM_TIME", RES_THERM_TIME, 1, -1);
      
      PrintValues(fp, "SLOW_DIST", RES_SLOW_DIST, 1, -1);
      PrintValues(fp, "THERM_DIST", RES_THERM_DIST, 1, -1);
      
      PrintValues(fp, "THERM_FRAC", RES_THERM_FRAC, 1, -1);
      */
      
      /***********************************************************************/
      
      /****** Parameters for burnup calculation ******************************/
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Parameters for burnup calculation:\n\n");

      fprintf(fp, "BURN_MATERIALS            (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_BURN_MATERIALS]);


      /*
      fprintf(fp, "BURN_MODE                 (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_BURN_BUMODE]);
      */
      fprintf(fp, "BURN_STEP                 (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_BURN_STEP]);
      
      /*
      fprintf(fp, "BURN_TOT_STEPS            (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_TOT_BURN_STEPS] + 1);
      */
      fprintf(fp, "BURNUP                    (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_BURN_CUM_BURNUP]);
      fprintf(fp, "BURN_DAYS                 (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_BURN_CUM_BURNTIME]/(24.0*60.0*60.0));

      /*
      fprintf(fp, "ENERGY_OUTPUT             (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_TOT_ENERGY_OUTPUT]*SECDAY/1E-6);
      
      fprintf(fp, "DEP_TTA_CUTOFF            (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_DEP_TTA_CUTOFF]);
      fprintf(fp, "DEP_STABILITY_CUTOFF      (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_DEP_STABILITY_CUTOFF]);
      fprintf(fp, "DEP_FP_YIELD_CUTOFF       (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_DEP_FP_YIELD_CUTOFF]);
      fprintf(fp, "DEP_XS_FRAC_CUTOFF        (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_DEP_XS_FRAC_CUTOFF]);
      fprintf(fp, "DEP_XS_ENERGY_CUTOFF      (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_DEP_TRANSMU_E_CUTOFF]);
      
      
      fprintf(fp, "FP_NUCLIDES_INCLUDED      (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_BURN_INCL_FP_ISO]);
      
      fprintf(fp, "FP_NUCLIDES_AVAILABLE     (idx, 1)        = %ld ;\n", 
	      (long)RDB[DATA_BURN_AVAIL_FP_ISO]);
      
      fprintf(fp, "TOT_ACTIVITY              (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_TOT_ACTIVITY]);
      fprintf(fp, "TOT_DECAY_HEAT            (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_TOT_DECAY_HEAT]);

      fprintf(fp, "TOT_SF_RATE               (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_TOT_SFRATE]);

      fprintf(fp, "ACTINIDE_ACTIVITY         (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_ACT_ACTIVITY]);
      fprintf(fp, "ACTINIDE_DECAY_HEAT       (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_ACT_DECAY_HEAT]);
      
      fprintf(fp, "FISSION_PRODUCT_ACTIVITY  (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_FP_ACTIVITY]);
      fprintf(fp, "FISSION_PRODUCT_DECAY_HEAT(idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_FP_DECAY_HEAT]);
      */
      /***********************************************************************/
      
      /***** Source entropies and centre *************************************/
      /*
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Fission source entropies:\n\n");
      
      PrintValues(fp, "ENTROPY_X", RES_ENTROPY_X, 1, -1);
      PrintValues(fp, "ENTROPY_Y", RES_ENTROPY_Y, 1, -1);
      PrintValues(fp, "ENTROPY_Z", RES_ENTROPY_Z, 1, -1);
      PrintValues(fp, "ENTROPY_TOT", RES_ENTROPY_TOT, 1, -1);
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Fission source centre:\n\n");
      
      PrintValues(fp, "SOURCE_X0", RES_SOURCE_X0, 1, -1);
      PrintValues(fp, "SOURCE_Y0", RES_SOURCE_Y0, 1, -1);
      PrintValues(fp, "SOURCE_Z0", RES_SOURCE_Z0, 1, -1);
      */
      /***********************************************************************/
      
      /***** Soluble absorber ************************************************/
      /*
      if ((long)RDB[DATA_PTR_SOLU_ABS] > 0)
	{
	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% Soluble absorber:\n\n");
	  
	  PrintValues(fp, "SOLU_ABS_AFRAC", RES_SOLU_ABS_AFRAC, 1, -1);
	  PrintValues(fp, "SOLU_ABS_MFRAC", RES_SOLU_ABS_MFRAC, 1, -1);
	}
      */
      /***********************************************************************/

      /***** Iteration *******************************************************/
      
      /* General */
      /*
      if ((long)RDB[DATA_ITER_MODE] != ITER_MODE_NONE)
	{
	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% Iteration:\n\n");
	  
	  fprintf(fp, "ITER_MODE                 (idx, 1)        = %ld ;\n", 
		  (long)RDB[DATA_ITER_MODE]);
	  fprintf(fp, "ITER_KEFF                 (idx, 1)        = %11.5E ;\n", 
		  RDB[DATA_ITER_GOAL]);
	  
	  PrintValues(fp, "ITER_VAR", RES_ITER_VAR, 1, -1);
	}
      */
      /* B1 iteration */
      /*
      if ((long)RDB[DATA_ITER_MODE] == ITER_MODE_B1)
	{
	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% B1 fundamental mode calculation:\n\n");
	  
	  fprintf(fp, "B1_MODE                   (idx, 1)        = %ld ;\n", 
		  (long)RDB[DATA_B1_SPECTRUM_MODE]);
	  
	  ng = (long)RDB[DATA_B1_SPECTRUM_NE];
	  
	  fprintf(fp, "B1_NE                     (idx, 1)        = %ld ;\n", ng);
	  
	  fprintf(fp, "B1_ERG                    (idx, [1: %3ld]) = [ ", ng);
	  
	  ptr = (long)RDB[DATA_B1_SPECTRUM_PTR_E0];
	  
	  for (n = 0; n < ng; n++)
	    fprintf(fp, "%11.5E ", RDB[ptr + n]);
	  
	  fprintf(fp, "];\n");
	  
	  fprintf(fp, "B1_SPECTR                 (idx, [1: %3ld]) = [ ", ng);
	  
	  for (n = 0; n < ng; n++)
	    fprintf(fp, "%11.5E ", Mean(RES_B1_SPECTR, n));
	  
	  fprintf(fp, "];\n");
	}
      */
      /***********************************************************************/

      /***** Equilibrium Xe-135 iteration ************************************/
      /*
      if ((long)RDB[DATA_XENON_EQUIL] == YES)
	{
	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% Equilibrium Xe-135 iteration:\n\n");
	  
	  PrintValues(fp, "XE135_EQUIL_CONC", RES_XE135_EQUIL_CONC, 1, -1);
	  PrintValues(fp, "I135_EQUIL_CONC", RES_I135_EQUIL_CONC, 1, -1);
	}
      */
      /***********************************************************************/
    
      /***** Analog reaction rate estimators *********************************/
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Analog reaction rate estimators:\n\n");
      
      PrintValues(fp, "CONVERSION_RATIO", RES_ANA_CONV_RATIO, 1, -1, -1, 0, 0);

      ptr = (long)RDB[RES_ANA_FISS_FRAC];

      if (Mean(ptr, 1) > 0.0)
	PrintValues(fp, "TH232_FISS_FRAC", RES_ANA_FISS_FRAC, 1, -1, -1, 1, 0);

      if (Mean(ptr, 2) > 0.0)
	PrintValues(fp, "U233_FISS_FRAC", RES_ANA_FISS_FRAC, 1, -1, -1, 2, 0);

      if (Mean(ptr, 3) > 0.0)
	PrintValues(fp, "U235_FISS_FRAC", RES_ANA_FISS_FRAC, 1, -1, -1, 3, 0);

      if (Mean(ptr, 4) > 0.0)
	PrintValues(fp, "U238_FISS_FRAC", RES_ANA_FISS_FRAC, 1, -1, -1, 4, 0);

      if (Mean(ptr, 5) > 0.0)
	PrintValues(fp, "PU239_FISS_FRAC", RES_ANA_FISS_FRAC, 1, -1, -1, 5, 0);

      /***********************************************************************/
    
      /***** Normalised reaction rates  **************************************/
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Normalized total reaction rates:\n\n");

      if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_TRANSPORT)
	{        
	  PrintValues(fp, "TOT_POWER", RES_TOT_POWER, 1, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_POWDENS", RES_TOT_POWDENS, 1, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_GENRATE", RES_TOT_GENRATE, 1, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_FISSRATE", RES_TOT_FISSRATE, 1, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_CAPTRATE", RES_TOT_CAPTRATE, 1, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_ABSRATE", RES_TOT_ABSRATE, 1, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_SRCRATE", RES_TOT_SRCRATE, 1, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_FLUX", RES_TOT_FLUX, 1, -1, -1, 0, 0);
	}
      else
	{
	  PrintValues(fp, "TOT_POWER", RES_TOT_POWER, 3, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_POWDENS", RES_TOT_POWDENS, 3, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_GENRATE", RES_TOT_GENRATE, 3, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_FISSRATE", RES_TOT_FISSRATE, 3, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_CAPTRATE", RES_TOT_CAPTRATE, 3, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_ABSRATE", RES_TOT_ABSRATE, 3, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_SRCRATE", RES_TOT_SRCRATE, 3, -1, -1, 0, 0);
	  PrintValues(fp, "TOT_FLUX", RES_TOT_FLUX, 3, -1, -1, 0, 0);
	}

      PrintValues(fp, "TOT_LEAKRATE", RES_TOT_LEAKRATE, 1, -1, -1, 0, 0);
      PrintValues(fp, "TOT_LOSSRATE", RES_TOT_LOSSRATE, 1, -1, -1, 0, 0);
      PrintValues(fp, "TOT_RR", RES_TOT_RR, 1, -1, -1, 0, 0);

      /* Fissile masses*/
      
      fprintf(fp, "INITIAL_FMASS             (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_INI_FMASS]); 
      fprintf(fp, "TOTAL_FMASS               (idx, 1)        = %11.5E ;\n", 
	      RDB[DATA_TOT_FMASS]); 

      if ((long)RDB[DATA_RUNNING_MODE] != RUNNING_MODE_TRANSPORT)
	{        
	  fprintf(fp, 
		  "INITIAL_BURN_FMASS        (idx, 1)        = %11.5E ;\n", 
		  RDB[DATA_INI_BURN_FMASS]); 
	  fprintf(fp, 
		  "TOTAL_BURN_FMASS          (idx, 1)        = %11.5E ;\n", 
		  RDB[DATA_TOT_BURN_FMASS]); 
	}
      
      fprintf(fp, "\n");

      /***********************************************************************/
    
      /***** Eigenvalues *****************************************************/
      
      fprintf(fp, "%% Criticality eigenvalues:\n\n");
      
      PrintValues(fp, "ANA_KEFF", RES_ANA_KEFF, 1, -1, -1, 0, 0);
      PrintValues(fp, "IMP_KEFF", RES_IMP_KEFF, 1, -1, -1, 0, 0);
      PrintValues(fp, "COL_KEFF", RES_COL_KEFF, 1, -1, -1, 0, 0);
      PrintValues(fp, "ABS_KEFF", RES_IMP_KEFF, 1, -1, -1, 0, 0);
      PrintValues(fp, "ABS_KINF", RES_IMP_KINF, 1, -1, -1, 0, 0);
	

      /*
      PrintValues(fp, "ABS_GC_KEFF", RES_ABS_GC_KEFF, 1, m);
      PrintValues(fp, "ABS_GC_KINF", RES_ABS_GC_KINF, 1, m);
      */

    
      /* External source k-eff */
      /*
      if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC)
	PrintValues(fp, "ABS_EXT_K", RES_EXT_KEFF, 
		    (long)RDB[DATA_EXT_KEFF_N], -1, -1);
      */
      /* Alpha eigenvalues */
      /*
      PrintValues(fp, "IMPL_ALPHA_EIG", RES_IMPL_ALPHA_EIG, 1, -1, -1);
      PrintValues(fp, "FIXED_ALPHA_EIG", RES_FIXED_ALPHA, 1, -1, -1);
      */
      /* Albedo */
      /*
      PrintValues(fp, "GEOM_ALBEDO", RES_GEOM_ALBEDO, 1, -1, -1);
      */
      /***********************************************************************/
    
      /***** Point-kinetic parameters ****************************************/
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Point-kinetic parameters:\n\n");
      
      PrintValues(fp, "ANA_PROMPT_LIFETIME", RES_ANA_PROMPT_LIFETIME, 1, -1, -1, 0, 0);
      PrintValues(fp, "IMPL_PROMPT_LIFETIME", RES_IMPL_PROMPT_LIFETIME, 1, -1, -1, 0, 0);

      PrintValues(fp, "ANA_REPROD_TIME", RES_ANA_REPROD_TIME, 1, -1, -1, 0, 0);
      PrintValues(fp, "IMPL_REPROD_TIME", RES_IMPL_REPROD_TIME, 1, -1, -1, 0, 0);
      /*
      PrintValues(fp, "DELAYED_EMTIME", RES_DELAYED_EMTIME, 1, -1, -1, 0, 0);
      */
      /***********************************************************************/
    
      if (gcu > VALID_PTR)
	{
	  /***** Parameters for group constant generation ********************/
	  
	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% Parameters for group constant generation\n\n");
	  
	  /* Pointer to universe */

	  uni = (long)RDB[gcu + GCU_PTR_UNIV];
	  
	  /* Print name */
	  
	  sprintf(tmpstr, "%s", GetText(uni + UNIVERSE_PTR_NAME));
	  fprintf(fp, "GC_UNIVERSE_NAME          (idx, [1:%3ld])  = '%s' ;\n", 
		  (long)strlen(tmpstr), tmpstr);
	  
	  /*
	    
	    fprintf(fp, "GC_SYM                    (idx, 1)        = %ld ;\n",
	    (long)RDB[DATA_GC_SYM]);
	  */
	  
	  
	  /* Get number of energy groups */
	  
	  ng = (long)RDB[DATA_ERG_FG_NG];
	  
	  /* Get pointer to energy group structure */
	  
	  ptr = (long)RDB[DATA_ERG_FG_PTR_GRID];
	  ptr = (long)RDB[ptr + ENERGY_GRID_PTR_DATA];
	  
	  fprintf(fp, "GC_NE                     (idx, 1)        = %ld ;\n", ng);
	  fprintf(fp, "GC_BOUNDS                 (idx, [1: %3ld]) = [ ", ng + 1);
	  
	  fprintf(fp, "%12.5E ", RDB[DATA_NEUTRON_EMAX]);
	  
	  for (n = ng - 1; n > 0; n--)
	    fprintf(fp, "%12.5E ", RDB[ptr + n]);
	  
	  fprintf(fp, "%12.5E ];\n", RDB[DATA_NEUTRON_EMIN]);
      
	  /*******************************************************************/
      
	  /***** Few-group cross sections ************************************/
	  
	  fprintf(fp, "\n");
  
	  fprintf(fp, "%% Few-group cross sections:\n\n");
	  
	  PrintValues(fp, "FLUX", gcu + GCU_RES_FG_FLX, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "LEAK", gcu + GCU_RES_FG_LEAK, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "TOTXS", gcu + GCU_RES_FG_TOTXS, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "FISSXS", gcu + GCU_RES_FG_FISSXS, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "CAPTXS", gcu + GCU_RES_FG_CAPTXS, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "ABSXS", gcu + GCU_RES_FG_ABSXS, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "ELAXS", gcu + GCU_RES_FG_ELAXS, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "INELAXS", gcu + GCU_RES_FG_INLXS, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "SCATTXS", gcu + GCU_RES_FG_SCATTXS, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "N2NXS", gcu + GCU_RES_FG_N2NXS, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "REMXS", gcu + GCU_RES_FG_REMXS, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "NUBAR", gcu + GCU_RES_FG_NUBAR, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "NSF", gcu + GCU_RES_FG_NSF, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "RECIPVEL", gcu + GCU_RES_FG_RECIPVEL, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "FISSE", gcu + GCU_RES_FG_FISSE, ng + 1, -1, -1, 0, 0);
	
	  /*******************************************************************/
      
	  /***** Fission spectra *********************************************/

	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% Fission spectra:\n\n");
	  
	  PrintValues(fp, "CHI", gcu + GCU_RES_FG_CHI, ng, -1, -1, 0, 0);
	  PrintValues(fp, "CHIP", gcu + GCU_RES_FG_CHIP, ng, -1, -1, 0, 0);
	  PrintValues(fp, "CHID", gcu + GCU_RES_FG_CHID, ng, -1, -1, 0, 0);
	  
	  /*******************************************************************/

	  /***** Group-transfer probabilities and cross sections *************/

	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% Group-transfer probabilities and cross sections:\n\n");
	  
	  PrintValues(fp, "GTRANSFP", gcu + GCU_RES_FG_GTRANSP, ng, ng, -1, 0, 0);
	  PrintValues(fp, "GTRANSFXS", gcu + GCU_RES_FG_GTRANSXS, ng, ng, -1, 0, 0);
	  
	  /*******************************************************************/

	  /***** PN scattering cross sections ********************************/

	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% PN scattering cross sections:\n\n");
	  
	  PrintValues(fp, "SCATT0", gcu + GCU_RES_FG_SCATT0, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "SCATT1", gcu + GCU_RES_FG_SCATT1, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "SCATT2", gcu + GCU_RES_FG_SCATT2, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "SCATT3", gcu + GCU_RES_FG_SCATT3, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "SCATT4", gcu + GCU_RES_FG_SCATT4, ng + 1, -1, -1, 0, 0);
	  PrintValues(fp, "SCATT5", gcu + GCU_RES_FG_SCATT5, ng + 1, -1, -1, 0, 0);
	  
	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% P1 diffusion parameters:\n\n");
	  
	  /*
	    PrintValues(fp, "P1_TRANSPXS", gcu + GCU_RES_FG_P1_TRANSPXS, ng + 1, -1, -1, 0, 0);
	    PrintValues(fp, "P1_DIFFCOEF", gcu + GCU_RES_FG_P1_DIFFCOEF, ng + 1, -1, -1, 0, 0);
	  */
	  
	  PrintValues(fp, "P1_MUBAR", gcu + GCU_RES_FG_P1_MUBAR, ng + 1, -1, -1, 0, 0);
	  
	  /*******************************************************************/
	  
	  /***** B1 critical spectrum cross sections *************************/

	  /* Check if fundamental mode calculation is performed */

	  if ((long)RDB[DATA_OPTI_FUM_CALC] == YES)
	    {
	      fprintf(fp, "\n");
	      
	      fprintf(fp, "%% B1 critical spectrum calculation:\n\n");
	      
	      PrintValues(fp, "B1_KINF", gcu + GCU_FUM_FG_B1_KINF, 1, -1, -1, 0, 0);
	      PrintValues(fp, "B1_BUCKLING", gcu + GCU_FUM_FG_B1_BUCKLING, 1, -1, -1, 0, 0);
	      PrintValues(fp, "B1_FLUX", gcu + GCU_FUM_FG_B1_FLUX, ng + 1, -1, -1, 0, 0);
	      PrintValues(fp, "B1_TOTXS", gcu + GCU_FUM_FG_B1_TOTXS, ng + 1, -1, -1, 0, 0);
	      PrintValues(fp, "B1_NSF", gcu + GCU_FUM_FG_B1_NSF, ng + 1, -1, -1, 0, 0);
	      PrintValues(fp, "B1_FISSXS", gcu + GCU_FUM_FG_B1_FISSXS, ng + 1, -1, -1, 0, 0);
	      PrintValues(fp, "B1_CHI", gcu + GCU_FUM_FG_B1_CHI, ng, -1, -1, 0, 0);
	      PrintValues(fp, "B1_ABSXS", gcu + GCU_FUM_FG_B1_ABSXS, ng + 1, -1, -1, 0, 0);
	      PrintValues(fp, "B1_REMXS", gcu + GCU_FUM_FG_B1_REMXS, ng + 1, -1, -1, 0, 0);
	      PrintValues(fp, "B1_DIFFCOEF", gcu + GCU_FUM_FG_B1_DIFFCOEF, ng + 1, -1, -1, 0, 0);
	      PrintValues(fp, "B1_SCATTXS", gcu + GCU_FUM_FG_B1_SCATTXS, ng, ng, -1, 0, 0);
	    }

	  /*******************************************************************/
	}

#ifdef mmmmm
      
      /***** Distances etc. **************************************************/
      /*
	fprintf(fp, "\n");
	
	fprintf(fp, "%% Mean distances to fission:\n\n");
	
	PrintValues(fp, "FISS_D_AX", RES_STAT_FISS_D_AX, 1);
	PrintValues(fp, "FISS_D_RAD", RES_STAT_FISS_D_RAD, 1);
	PrintValues(fp, "FISS_D_TOT", RES_STAT_FISS_D_TOT, 1);
	
	fprintf(fp, "\n%% Mean square distance to absorption:\n\n");
	
	PrintValues(fp, "ABS_R2", RES_STAT_ABS_R2, 1);
      */
      
      /***********************************************************************/
      
      /***** Six-factor formula **********************************************/
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Six-factor formula:\n\n");
      
      PrintValues(fp, "SIX_FF_ETA", RES_SIX_FF_ETA, 1, -1, 0, 0);
      PrintValues(fp, "SIX_FF_F", RES_SIX_FF_F, 1, -1, 0, 0);
      PrintValues(fp, "SIX_FF_P", RES_SIX_FF_P, 1, -1, 0, 0);
      PrintValues(fp, "SIX_FF_EPSILON", RES_SIX_FF_EPSILON, 1, -1, 0, 0);
      PrintValues(fp, "SIX_FF_LF", RES_SIX_FF_LF, 1, -1, 0, 0);
      PrintValues(fp, "SIX_FF_LT", RES_SIX_FF_LT, 1, -1, 0, 0);
      PrintValues(fp, "SIX_FF_KINF", RES_SIX_FF_KINF, 1, -1, 0, 0);
      PrintValues(fp, "SIX_FF_KEFF", RES_SIX_FF_KEFF, 1, -1, 0, 0);
      
      /***********************************************************************/

      /***** Delayed neutron parameters **************************************/
      
      ng = (long)RDB[DATA_PRECURSOR_GROUPS];
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Delayed neutron parameters:\n\n");
      
      fprintf(fp, "PRECURSOR_GROUPS          (idx, 1)        = %ld ;\n", ng);
      
      PrintValues(fp, "BETA_EFF", RES_BETA_EFF, ng + 1, -1);
      PrintValues(fp, "BETA_ZERO", RES_BETA_ZERO, ng + 1, -1);
      PrintValues(fp, "DECAY_CONSTANT", RES_LAMBDA, ng + 1, -1);
      
      /***********************************************************************/
            
      /***** Diffusion parameters ********************************************/

      fprintf(fp, "\n");
      
      fprintf(fp, "%% Diffusion parameters:\n\n");
      
      PrintValues(fp, "DIFFAREA", RES_FG_L2, ng + 1, m);
      PrintValues(fp, "DIFFCOEF", RES_FG_DIFFCOEF, ng + 1, m);
      PrintValues(fp, "TRANSPXS", RES_FG_TRANSPXS, ng + 1, m);
      PrintValues(fp, "MUBAR", RES_FG_MUBAR, ng + 1, m);
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Material buckling:\n\n");
      
      PrintValues(fp, "MAT_BUCKLING", RES_MAT_BUCKL, 1, m);
      
      fprintf(fp, "\n");
      
      fprintf(fp, "%% Leakage estimate of diffusion coefficient:\n\n");
      
      PrintValues(fp, "LEAK_DIFFCOEF", RES_LEAK_DIFFCOEF, ng + 1, m);
      
      /***********************************************************************/
          
          
      /***** B1 critical spectrum cross sections *****************************/

      fprintf(fp, "\n");
      
      fprintf(fp, "%% B1 critical spectrum calculation:\n\n");
      
      PrintValues(fp, "B1_KINF", RES_FG_B1_KINF, 1, m);
      PrintValues(fp, "B1_BUCKLING", RES_FG_B1_BUCKLING, 1, m);
      PrintValues(fp, "B1_NSF", RES_FG_B1_NSF, ng + 1, m);
      PrintValues(fp, "B1_FISSXS", RES_FG_B1_FISSXS, ng + 1, m);
      PrintValues(fp, "B1_ABSXS", RES_FG_B1_ABSXS, ng + 1, m);
      PrintValues(fp, "B1_DIFFCOEF", RES_FG_B1_DIFFCOEF, ng + 1, m);
      PrintValues(fp, "B1_SCATTXS", RES_FG_B1_SCATTXS, ng*ng, m);
      
      /***********************************************************************/

      /***** Assembly discontinuity factors **********************************/

      /* Pointer to adf data in universe */

      adf = (long)RDB[uni + UNIV_PTR_ADF_DATA];

      /* Number of values */
      
      if ((n = ng*((long)RDB[adf + ADF_DATA_VERTICES])) > 0)
	{
	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% Assembly discontinuity factors:\n\n");
	  
	  ptr = (long)RDB[adf + ADF_DATA_RES_FG_ADFS];
	  PrintValues(fp, "ADFS", -ptr, n, -1);
	  
	  ptr = (long)RDB[adf + ADF_DATA_RES_FG_ADFC];
	  PrintValues(fp, "ADFC", -ptr, n, -1);
	}
      
      /***********************************************************************/
      
      /***** Pin power distributions *****************************************/

      /* Print only for the first gcu to reduce file size (22.9.2009) */

      if (m == 0)
	{
	  /* TODO: Laske cluster arrayn pf kohta ring- ja position */
      
	  /* Pointer to lattices */
	  
	  if ((lat = (long)RDB[DATA_PTR_L0]) > 0)
	    {
	      fprintf(fp, "\n");
	      fprintf(fp, "%% Power distributions in lattices:\n");
	    }
	  
	  /* Loop over lattices */
	  
	  while (lat > 0)
	    {
	      fprintf(fp, "\n");
	      
	      /* Lattice number */
	      
	      sprintf(tmpstr, "LAT%ld", (long)RDB[lat + LAT_IDX]);
	      
	      /* Print */
	      
	      if ((long)RDB[lat + LAT_TYPE] == LAT_TYPE_CLU)
		fprintf(fp, "%-25s (idx, [1:   3]) = [ %ld %4ld %4ld ];\n", 
			tmpstr, (long)RDB[lat + LAT_TYPE], 
			(long)RDB[lat + LAT_N_RINGS],
			(long)RDB[lat + LAT_NTOT]);
	      else
		fprintf(fp, "%-25s (idx, [1:   3]) = [ %ld %4ld %4ld ];\n", 
			tmpstr, (long)RDB[lat + LAT_TYPE], 
			(long)RDB[lat + LAT_NX],
			(long)RDB[lat + LAT_NY]);
	      
	      /* Parameter name */
	      
	      sprintf(tmpstr, "POWDISTR%ld", (long)RDB[lat + LAT_IDX]);
	      
	      /* Number of values */
	      
	      n = (long)RDB[lat + LAT_NTOT];
	      
	      /* Pointer to data */
	      
	      ptr = (long)RDB[lat + LAT_PTR_POWER_DISTR];
	      
	      /* Print */
	      
	      PrintValues(fp, tmpstr, -ptr, n, -1);
	      
	      /* Get peaking factor */
	      
	      sprintf(tmpstr, "PEAKF%ld", (long)RDB[lat + LAT_IDX]);
	      
	      imax = 0;
	      jmax = 0;
	      nmax = 0;
	      
	      max = -1.0;
	      
	      if ((long)RDB[lat + LAT_TYPE] == LAT_TYPE_CLU)
		{
		  /* Loop over cluster elements */
		  
		  for (n = 0; n < (long)RDB[lat + LAT_NTOT]; n++)
		    {
		      /* Compare to maximum */
		      
		      if (Mean(-ptr, n) > max)
			{
			  max = Mean(-ptr, n);
			  nmax = n;
			}
		    }
		  
		  /* Print */
		  
		  fprintf(fp, "%-25s (idx, [1:   4]) = [ %4ld %4d %12.5E %7.5f ];\n", 
			  tmpstr, nmax + 1, 0, Mean(-ptr, nmax), 
			  RelErr(-ptr, nmax));
		}
	      else
		{
		  /* Loop over rows and columns */
		  
		  n = 0;
		  
		  for (i = 0; i < (long)RDB[lat + LAT_NX]; i++)
		    for (j = 0; j < (long)RDB[lat + LAT_NY]; j++)
		      {
			/* Compare to maximum */
			
			if (Mean(-ptr, n) > max)
			  {
			    max = Mean(-ptr, n);
			    nmax = n;
			    imax = i;
			    jmax = j;
			  }
			
			/* Increase counter */
			
			n++;
		      }
		  
		  /* Print */
		  
		  fprintf(fp, "%-25s (idx, [1:   4]) = [ %4ld %4ld %12.5E %7.5f ];\n", 
			  tmpstr, jmax + 1, imax + 1, Mean(-ptr, nmax), 
			  RelErr(-ptr, nmax));
		}
	      
	      /* Next lattice */
	      
	      lat = (long)RDB[lat + LAT_PTR_NEXT];
	    }
	}
    
      /***********************************************************************/
     
      /***** User variables **************************************************/
      
      if ((ptr = (long)RDB[DATA_PTR_VAR0]) > VALID_PTR)
	{
	  fprintf(fp, "\n");
	  
	  fprintf(fp, "%% User variables:\n\n");
	  
	  /* Loop over variables */
	  
	  while (ptr > VALID_PTR)
	    {
	      /* Check type */
	      
	      if ((long)RDB[ptr + VAR_TYPE] == VAR_TYPE_NUMERIC)
		fprintf(fp, "%-25s (idx, 1)        = %11.5E ;\n", 
			GetText(ptr + VAR_NAME), RDB[ptr + VAR_VALUE]);
	      else
		fprintf(fp, "%-25s (idx, [1:%3ld])  = '%s' ;\n", 
			GetText(ptr + VAR_NAME), 
			(long)strlen(GetText(ptr + VAR_VALUE)), 
			GetText(ptr + VAR_VALUE));
	      
	      /* Next variable */
	      
	      ptr = (long)RDB[ptr + VAR_PTR_NEXT];
	    }
	}
      
      /***********************************************************************/
#endif  
      fprintf(fp, "\n");

      /* Next universe */

      if (gcu > VALID_PTR)
	gcu = NextItem(gcu);
    }
  while (gcu > VALID_PTR);

  /* Close file and exit */

  fclose(fp);

  return;
}

/*****************************************************************************/
