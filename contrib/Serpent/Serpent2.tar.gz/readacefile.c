/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : readacefile.c                                  */
/*                                                                           */
/* Created:       2010/09/10 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Reads data from ACE format cross section library file        */
/*              into ACE data block                                          */
/*                                                                           */
/* Comments: - Converted from Serpent 1.1.12 source file "readacefiles.c"    */
/*           - Tähän optio ottaa tai jättää noi spesiaalivaikutusalat        */
/*           - Tää toimii toistaiseksi vaan transport datalle                */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ReadACEFile:"

/*****************************************************************************/

void ReadACEFile(long nuc)
{
  long ace, ptr, rea, n, sz, dum1, NXS[16], JXS[32], NES, L0, L, NTR, nr, mt;
  double *XSS, awr, Emax;
  char HZ[MAX_STR], dummy[MAX_STR], *dum2;
  FILE *fp;

  /* Check nuclide type */

  if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_DECAY)
    Die(FUNCTION_NAME, "Decay data");
  
  /* Get pointer to ACE data */

  ace = (long)RDB[nuc + NUCLIDE_PTR_ACE];
  CheckPointer(FUNCTION_NAME, "ace", ACE_ARRAY, ace);

  /* Open file for reading */

  WDB[DATA_DUMMY] = ACE[ace + ACE_PTR_FILE];	  
  fp = OpenDataFile(DATA_DUMMY, "ACE data file");

  /***************************************************************************/
  
  /***** Read data ***********************************************************/

  /* Reset HZ */
  
  *HZ = '\0';
  
  /* Read ZAID and data */
  
  while (fscanf(fp, "%s", HZ) != EOF)
    {
      /* Get atomic weight ratio. Temperature is the next entry after */
      /* AWR, but it is not used. The value is taken from the directory */
      /* file. */

      dum2 = fgets(dummy, 81, fp); 
      sscanf(dummy, "%lf", &awr);
	    
      /* Put atomic weight ratio */

      WDB[nuc + NUCLIDE_AWR] = awr;

      /* Use value read from directory file for atomic weight */

      WDB[nuc + NUCLIDE_AW] = ACE[ace + ACE_AW];

      /* Comment line */
      
      dum2 = fgets(dummy, 81, fp);
      
      /* 16 IZ AW pairs */
      
      for (n = 0; n < 32; n++)
	dum1 = fscanf(fp, "%s", dummy);
      
      /* Read the NXS array */
      
      for (n = 0; n < 16; n++)
	dum1 = fscanf(fp, "%ld", &NXS[n]);
      
      /* Get data size (NXS[0]) */
      
      sz = NXS[0];
      
      /* Read the JXS array */
      
      for (n = 0; n < 32; n++)
	dum1 = fscanf(fp, "%ld", &JXS[n]);
      
      /* Compare ZAIDs */
      
      if (!strcmp(HZ, GetText(nuc + NUCLIDE_PTR_NAME)))
	{
	  /* Allocate memory for NXS array */

	  ptr = ReallocMem(ACE_ARRAY, 16);
	  ACE[ace + ACE_PTR_NXS] = (double)ptr;	  

	  /* Copy data */

	  for (n = 0; n < 16; n++)
	    ACE[ptr++] = (double)NXS[n];

	  /* Allocate memory for JXS array */

	  ptr = ReallocMem(ACE_ARRAY, 32);
	  ACE[ace + ACE_PTR_JXS] = (double)ptr;	  

	  /* Copy data */

	  for (n = 0; n < 32; n++)
	    ACE[ptr++] = (double)JXS[n];

	  /* Allocate memory for XSS array */
	  
	  ptr = ReallocMem(ACE_ARRAY, sz);
	  
	  /* Set pointer */
	  
	  ACE[ace + ACE_PTR_XSS] = (double)ptr;

	  /* Read data */
	  
	  for (n = 0; n < sz; n++)  
	    dum1 = fscanf(fp, "%lf", &ACE[ptr + n]);
	  
	  /* Break loop */

	  break;
	}
      
      /* Seek to next header */
      
      fseek(fp, 81*sz/4 + 1, SEEK_CUR);
    }
  
  /* Check that data was found */
  
  if (strcmp(HZ, GetText(nuc + NUCLIDE_PTR_NAME)))
    Die(FUNCTION_NAME, "Unable to find isotope %s in file %s",
	GetText(nuc + NUCLIDE_PTR_NAME), GetText(DATA_DUMMY));
  
  /* Pointer to XSS array */
      
  ptr = (long)ACE[ace + ACE_PTR_XSS];
  XSS = &ACE[ptr];
  
  /* Set ures energy boundaries */

  if ((L = JXS[22] - 1) > 0)
    {
      /* Get number of energy points */

      NES = (long)XSS[L];

      /* Set minimum and maximum energies */
      
      WDB[nuc + NUCLIDE_URES_EMIN] = XSS[L + 6];
      WDB[nuc + NUCLIDE_URES_EMAX] = XSS[L + 6 + NES - 1];
    }
  else
    {
      /* Reset boundaries */
      
      WDB[nuc + NUCLIDE_URES_EMIN] = INFTY;
      WDB[nuc + NUCLIDE_URES_EMAX] = -INFTY;
    }  

  /**************************************************************************/

  /***** Add reaction channels for transport data ***************************/

  /* Check type */

  if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT) ||
      ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_DBRC))
    {
      /***** Transport nuclide **********************************************/

      /* Number of energy points */
      
      NES = NXS[2];

      /* Put pointer to nuclide energy grid and nuber of points */

      WDB[nuc + NUCLIDE_PTR_EGRID] = (double)(JXS[0] - 1);
      WDB[nuc + NUCLIDE_EGRID_NE] = NES;
     
      /* Get number of reactions (minus elastic scattering). Include */
      /* only elastic scattering for DBRC nuclides. */

      if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_DBRC)
	NTR = 0;
      else
	NTR = NXS[3]; 
      
      /* Compare minimum and maximum value to XS limits */

      if (XSS[JXS[0] - 1] < RDB[DATA_NEUTRON_XS_EMIN])
	WDB[DATA_NEUTRON_XS_EMIN] = XSS[JXS[0] - 1];
      
      if (XSS[JXS[0] + NES - 2] > RDB[DATA_NEUTRON_XS_EMAX])
	WDB[DATA_NEUTRON_XS_EMAX] = XSS[JXS[0] + NES - 2];

      /* Number of delayed neutron precursor groups */

      WDB[nuc + NUCLIDE_ACE_PREC_GROUPS] = NXS[7];
     
      /* Add elastic scattering */
      
      rea = NewItem(nuc + NUCLIDE_PTR_REA, REACTION_BLOCK_SIZE);

      /* Put nuclide pointer */

      WDB[rea + REACTION_PTR_NUCLIDE] = (double)nuc;

      /* Reaction index (used for energy distributions) */

      WDB[rea + REACTION_NR] = -1.0;

      /* Put type and MT */
      
      WDB[rea + REACTION_TYPE] = (double)REACTION_TYPE_PARTIAL;
      WDB[rea + REACTION_MT] = 2.0;

      /* Put awr */

      WDB[rea + REACTION_AWR] = RDB[nuc + NUCLIDE_AWR];

      /* Set minimum and maximum energy */

      WDB[rea + REACTION_EMIN] = XSS[JXS[0] - 1];
      WDB[rea + REACTION_EMAX] = XSS[JXS[0] + NES - 2];
      
      WDB[nuc + NUCLIDE_EMIN] = XSS[JXS[0] - 1];
      WDB[nuc + NUCLIDE_EMAX] = XSS[JXS[0] + NES - 2];

      /* Store number of energy points, pointer to grid and */
      /* index to first point */

      WDB[rea + REACTION_PTR_EGRID] = (double)(JXS[0] - 1);
      WDB[rea + REACTION_XS_NE] = (double)NES;
      WDB[rea + REACTION_XS_I0] = 0.0;

      /* Store pointer to XS data */
	      
      WDB[rea + REACTION_PTR_XS] = (double)(JXS[0] - 1 + 3*NES);

      /* Set ures energy boundaries */

      WDB[rea + REACTION_URES_EMIN] = RDB[nuc + NUCLIDE_URES_EMIN];
      WDB[rea + REACTION_URES_EMAX] = RDB[nuc + NUCLIDE_URES_EMIN];
	
      /* Set Q-value */

      WDB[rea + REACTION_Q] = 0.0;

      /* Multiplication and frame of reference */
      
      WDB[rea + REACTION_TY] = -1.0;
      WDB[rea + REACTION_WGT_F] = 1.0;

      /* Set branching fraction to 1.0 */

      WDB[rea + REACTION_BR] = 1.0;

      /* Set interpolation mode */

      WDB[rea + REACTION_ITP] = 0.0;

      /* Pointer to angular distribution (Tables F-11 and F-12) */

      if ((L = (long)XSS[JXS[7] - 1]) > 0)
	WDB[rea + REACTION_PTR_ANG] = (double)(L - 1 + JXS[8]);
      else
	WDB[rea + REACTION_PTR_ANG] = NULLPTR;

      /* Loop over reaction channels */
      
      for (nr = 0; nr < NTR; nr++)
	{
	  /* Get pointer to SIG-block (Table F-10, page F-17) */
	  
	  L = (long)XSS[JXS[5] - 1 + nr] + JXS[6] - 1;
	  
	  /* Get number of energy points */
	  
	  NES = (long)XSS[L];
	  
	  /* Pointer to energy array (tää vaikuttaa epäilyttävältä) */
	  
	  L0 = JXS[0] - 1 + NXS[2] - NES;

	  /* Tässä oli 22.8.2011 asti tarkistus > 2, mutta se jättää */
	  /* mt 37:n 94244 / endfb68 pois */	 

	  if (NES > 0)
	    {
	      /* Allocate memory */
	      
	      rea = NewItem(nuc + NUCLIDE_PTR_REA, REACTION_BLOCK_SIZE);
	      
	      /* Put nuclide pointer */

	      WDB[rea + REACTION_PTR_NUCLIDE] = (double)nuc;

	      /* Reaction index (used for energy distributions) */

	      WDB[rea + REACTION_NR] = (double)nr;

	      /* Get mt */
	      
	      mt = (long)XSS[JXS[2] + nr - 1];
	      WDB[rea + REACTION_MT] = (double)mt;

	      /* Check fissile */

	      if (((mt > 17) && (mt < 22)) || (mt == 38))
		{
		  /* Set flag */

		  SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_FISSILE);

		  /* Set default energy boundaries */

		  WDB[rea + REACTION_FISSY_IE0] = -INFTY;
		  WDB[rea + REACTION_FISSY_IE1] = 1E+6;
		  WDB[rea + REACTION_FISSY_IE2] = 1E+9;
		}

	      /* Store minimum and maximum energy */

	      WDB[rea + REACTION_EMIN] = XSS[L0];
	      WDB[rea + REACTION_EMAX] = XSS[L0 + NES - 1];

	      /* Store number of energy points, pointer to grid and */
	      /* index to first point */

	      WDB[rea + REACTION_PTR_EGRID] = (double)(JXS[0] - 1);
	      WDB[rea + REACTION_XS_NE] = (double)NES;
	      WDB[rea + REACTION_XS_I0] = (double)(NXS[2] - NES);

	      /* Store pointer to XS data */
	      
	      WDB[rea + REACTION_PTR_XS] = (double)(L + 1);

	      /* Set ures energy boundaries */

	      if ((mt == 102) || (mt == 18) || (mt == 19))
		{
		  /* Set ures energy boundaries */

		  WDB[rea + REACTION_URES_EMIN] = 
		    RDB[nuc + NUCLIDE_URES_EMIN];
		  WDB[rea + REACTION_URES_EMAX] = 
		    RDB[nuc + NUCLIDE_URES_EMIN];
		}
	      else
		{
		  /* Reset boundaries */
		  
		  WDB[rea + REACTION_URES_EMIN] = INFTY;
		  WDB[rea + REACTION_URES_EMAX] = -INFTY;
		}

	      /* Put awr */

	      WDB[rea + REACTION_AWR] = RDB[nuc + NUCLIDE_AWR];

	      /* Store Q-value */

	      WDB[rea + REACTION_Q] = XSS[JXS[3] - 1 + nr];

	      /* Multiplication and frame of reference */

	      WDB[rea + REACTION_TY] = XSS[JXS[4] - 1 + nr];

	      /* Check known error in ACE files */

	      if ((XSS[JXS[4] - 1 + nr] == 0.0) &&
		  (((mt > 17) && (mt < 22)) || (mt == 38)))
		{
		  /* Print warning */
		  
		  Warn(FUNCTION_NAME, 
		       "Conflicting reaction type for fission (%s mt %ld)", 
		       GetText(nuc + NUCLIDE_PTR_NAME), mt);

		  /* Set ty for fission */

		  WDB[rea + REACTION_TY] = 19.0;
		}

	      /* Put weight multiplicator */

	      if((RDB[rea + REACTION_TY] == 0.0) || 
		 (RDB[rea + REACTION_TY] == 19.0))
		WDB[rea + REACTION_WGT_F] = 1.0;
	      else
		WDB[rea + REACTION_WGT_F] = fabs(RDB[rea + REACTION_TY]);

	      /* Set interpolation mode */

	      WDB[rea + REACTION_ITP] = 0.0;
	      
	      /* Set branching fraction to 1.0 */
	      
	      WDB[rea + REACTION_BR] = 1.0;
      
	      /* Pointer to angular distribution (NOTE: L is re-used) */

	      if ((L = (long)XSS[JXS[7] + nr]) > 0)
		WDB[rea + REACTION_PTR_ANG] = (double)(L - 1 + JXS[8]);
	      else
		WDB[rea + REACTION_PTR_ANG] = NULLPTR;

	      /* Check type */
	      
	      if (((mt > 15) && (mt < 100)) || ((mt > 101) && (mt < 200)) ||
		  ((mt > 599) && (mt < 851)) || ((mt > 874) && (mt < 892)))
		{
		  /* Partial reaction */
		  
		  WDB[rea + REACTION_TYPE] = (double)REACTION_TYPE_PARTIAL;
		}
	      else
		{
		  /* Special */

		  WDB[rea + REACTION_TYPE] = (double)REACTION_TYPE_SPECIAL;
		}
	    }
	}
    
      /***********************************************************************/
      
      /***** URES data *******************************************************/

      /* Check if ures probability table data is available (ures data */
      /* is now read for DBRC nuclides as well). */
      
      if ((L = JXS[22] - 1) > 0)
	{
	  /* Add to ures counter */

	  WDB[DATA_URES_AVAIL] = RDB[DATA_URES_AVAIL] + 1.0;

	  /* Set available flag */

	  SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_URES_AVAIL);

	  /* Check ures option */

	  if ((long)RDB[DATA_USE_URES] == NO)
	    {
	      /* Pointer to list */

	      if ((ptr = (long)RDB[DATA_URES_PTR_USE_LIST]) < VALID_PTR)
		L = -1;
	      else
		{
		  /* Loop over list and compare */

		  while ((long)RDB[ptr] > 0)
		    {
		      if (!strcmp(GetText(ptr),
				  GetText(nuc + NUCLIDE_PTR_NAME)))
			{
			  L = -1;
			  break;
			}
		      
		      ptr++;
		    }
		}
	    }
	  else if ((ptr = (long)RDB[DATA_URES_PTR_USE_LIST]) > VALID_PTR)
	    {
	      /* Loop over list and compare */
      
	      while ((long)RDB[ptr] > 0)
		{
		  if (!strcmp(GetText(ptr), GetText(nuc + NUCLIDE_PTR_NAME)))
		    break;
		  
		  ptr++;
		}
	      
	      if ((long)RDB[ptr] < 1)
		L = -1;
	    }
	}

      /* Check if data is available and used */

      if (L > 0)
	{
	  /* Set flag */

	  SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_URES_USED);

	  /* Add counter */

	  WDB[DATA_URES_USED] = RDB[DATA_URES_USED] + 1.0;
	}

      /**********************************************************************/
    }

  else if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_SAB)
    {
      /***** S(a,b) data ****************************************************/

      /* Set S(a,b) flag */

      SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_SAB_DATA);

      /* Number of reaction modes */

      if (JXS[3] - 1 > 0)
	NTR = 2;
      else
	NTR = 1;

      /* Reset nuclide energy boundaries */

      WDB[nuc + NUCLIDE_EMIN] = INFTY;
      WDB[nuc + NUCLIDE_EMAX] = -INFTY;

      /* Avoid compiler warning */

      Emax = -1.0;

      /* Loop over reaction channels */
      
      for (nr = 0; nr < NTR; nr++)
	{
	  /* Pointer to (in)elastic data (Table F-23, page F-36) */

	  if (nr == 0)
	    L0 = JXS[0] - 1;
	  else
	    L0 = JXS[3] - 1;

	  /* Get number of energy points */
	  
	  NES = (long)XSS[L0];
	  
	  /* Allocate memory for reaction data */
	      
	  rea = NewItem(nuc + NUCLIDE_PTR_REA, REACTION_BLOCK_SIZE);

	  /* Put nuclide pointer */

	  WDB[rea + REACTION_PTR_NUCLIDE] = (double)nuc;

	  /* Put awr */

	  WDB[rea + REACTION_AWR] = RDB[nuc + NUCLIDE_AWR];

	  /* Set mt */
	  
	  if (nr == 0)
	    WDB[rea + REACTION_MT] = 1004.0;
	  else
	    WDB[rea + REACTION_MT] = 1002.0;
	  
	  /* Set interpolation mode */

	  if ((nr == 1) && (NXS[4] == 4))
	    WDB[rea + REACTION_ITP] = 4.0;
	  else
	    WDB[rea + REACTION_ITP] = 0.0;

	  /* Store minimum and maximum energy */

	  WDB[rea + REACTION_EMIN] = XSS[L0 + 1];
	  WDB[rea + REACTION_EMAX] = XSS[L0 + NES];

	  /* Maximum S(a,b) energy (needed to get the extra point in */
	  /* elastic channel */

	  if (nr == 0)
	    Emax = XSS[L0 + NES];
	  else if (Emax < XSS[L0 + NES])
	    Emax = XSS[L0 + NES];

	  /* Store */

	  WDB[rea + REACTION_SAB_EMAX] = Emax;

	  /* Compare to nuclide minimum */

	  if (RDB[rea + REACTION_EMIN] < RDB[nuc + NUCLIDE_EMIN])
	    WDB[nuc + NUCLIDE_EMIN] = RDB[rea + REACTION_EMIN];

	  /* Compare to nuclide maximum */

	  if (RDB[rea + REACTION_EMAX] > RDB[nuc + NUCLIDE_EMAX])
	    WDB[nuc + NUCLIDE_EMAX] = RDB[rea + REACTION_EMAX];

	  /* Store number of energy points, pointer to grid and */
	  /* index to first point */

	  WDB[rea + REACTION_PTR_EGRID] = (double)(L0 + 1);
	  WDB[rea + REACTION_XS_NE] = (double)NES;
	  WDB[rea + REACTION_XS_I0] = 0.0;

	  /* Store pointer to XS data */

	  WDB[rea + REACTION_PTR_XS] = (double)(L0 + 1 + NES);

	  /* Reset ures energy boundaries */

	  WDB[rea + REACTION_URES_EMIN] = INFTY;
	  WDB[rea + REACTION_URES_EMAX] = -INFTY;

	  /* Store Q-value */

	  WDB[rea + REACTION_Q] = 0.0;

	  /* Multiplication and frame of reference */

	  WDB[rea + REACTION_TY] = 1.0;
	  WDB[rea + REACTION_WGT_F] = 1.0;

	  /* Set branching fraction to 1.0 */
	      
	  WDB[rea + REACTION_BR] = 1.0;

	  /* Set type */
		  
	  WDB[rea + REACTION_TYPE] = (double)REACTION_TYPE_PARTIAL;
	}

      /**********************************************************************/
    }

  else if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_PHOTON)
    {
      /***** Photon interaction data ****************************************/

      /* Number of energy points */
      
      NES = NXS[2];
      
      /* Put pointer to nuclide energy grid and nuber of points */

      WDB[nuc + NUCLIDE_PTR_EGRID] = (double)(JXS[0] - 1);
      WDB[nuc + NUCLIDE_EGRID_NE] = NES;
     
      /* Compare minimum and maximum value to XS limits */

      if (XSS[JXS[0] - 1] < RDB[DATA_PHOTON_XS_EMIN])
	WDB[DATA_PHOTON_XS_EMIN] = XSS[JXS[0] - 1];
      
      if (XSS[JXS[0] + NES - 2] > RDB[DATA_PHOTON_XS_EMAX])
	WDB[DATA_PHOTON_XS_EMAX] = XSS[JXS[0] + NES - 2];

      /* Loop over 4 reaction modes (incoherent, coherent, photoelectric */
      /* and pair production) and average heating numbers. */

      for (nr = 0; nr < 5; nr++)
	{
	  /* Add reaction */
      
	  rea = NewItem(nuc + NUCLIDE_PTR_REA, REACTION_BLOCK_SIZE);

	  /* Put nuclide pointer */

	  WDB[rea + REACTION_PTR_NUCLIDE] = (double)nuc;

	  /* Reaction index (used for energy distributions) */

	  WDB[rea + REACTION_NR] = -1.0;

	  /* Put type */
      
	  if (nr < 4)
	    WDB[rea + REACTION_TYPE] = (double)REACTION_TYPE_PARTIAL;
	  else
	    WDB[rea + REACTION_TYPE] = (double)REACTION_TYPE_SPECIAL;

	  /* Put mt */

	  if (nr == 0)
	    WDB[rea + REACTION_MT] = 504.0;
	  else if (nr == 1)
	    WDB[rea + REACTION_MT] = 502.0;
	  else if (nr == 2)
	    WDB[rea + REACTION_MT] = 522.0;
	  else if (nr == 3)
	    WDB[rea + REACTION_MT] = 516.0;
	  else if (nr == 4)
	    WDB[rea + REACTION_MT] = 301.0;

	  /* Set minimum and maximum energy */

	  WDB[rea + REACTION_EMIN] = exp(XSS[JXS[0] - 1]);
	  WDB[rea + REACTION_EMAX] = exp(XSS[JXS[0] + NES - 2]);
	  
	  WDB[nuc + NUCLIDE_EMIN] = exp(XSS[JXS[0] - 1]);
	  WDB[nuc + NUCLIDE_EMAX] = exp(XSS[JXS[0] + NES - 2]);

	  /* Store number of energy points, pointer to grid and */
	  /* index to first point */

	  WDB[rea + REACTION_PTR_EGRID] = (double)(JXS[0] - 1);
	  WDB[rea + REACTION_XS_NE] = (double)NES;
	  WDB[rea + REACTION_XS_I0] = 0.0;

	  /* Store pointer to XS data */
	      
	  if (nr < 4)
	    WDB[rea + REACTION_PTR_XS] = (double)(JXS[0] - 1 + (nr + 1)*NES);
	  else
	    WDB[rea + REACTION_PTR_XS] = (double)(JXS[4] - 1);
	}
    }

  /**************************************************************************/

  /***** Remove redundant reaction modes ************************************/

  rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
  while (rea > VALID_PTR)
    {
      /* Redundant (n,p) */

      if ((long)RDB[rea + REACTION_MT] == 103)
	{
	  /* Loop over reactions */

	  ptr = (long)RDB[nuc + NUCLIDE_PTR_REA];
	  while (ptr > VALID_PTR)
	    {
	      /* Check mt and set type to special */

	      if (((long)RDB[ptr + REACTION_MT] > 599) && 
		  ((long)RDB[ptr + REACTION_MT] < 650))
		WDB[ptr + REACTION_TYPE] = (double)REACTION_TYPE_SPECIAL;

	      /* Next reaction */

	      ptr = NextItem(ptr);
	    }
	}

      /* Redundant (n,d) */

      if ((long)RDB[rea + REACTION_MT] == 104)
	{
	  /* Loop over reactions */

	  ptr = (long)RDB[nuc + NUCLIDE_PTR_REA];
	  while (ptr > VALID_PTR)
	    {
	      /* Check mt and set type to special */

	      if (((long)RDB[ptr + REACTION_MT] > 649) && 
		  ((long)RDB[ptr + REACTION_MT] < 700))
		WDB[ptr + REACTION_TYPE] = (double)REACTION_TYPE_SPECIAL;

	      /* Next reaction */

	      ptr = NextItem(ptr);
	    }
	}

      /* Redundant (n,t) */

      if ((long)RDB[rea + REACTION_MT] == 105)
	{
	  /* Loop over reactions */

	  ptr = (long)RDB[nuc + NUCLIDE_PTR_REA];
	  while (ptr > VALID_PTR)
	    {
	      /* Check mt and set type to special */

	      if (((long)RDB[ptr + REACTION_MT] > 699) && 
		  ((long)RDB[ptr + REACTION_MT] < 750))
		WDB[ptr + REACTION_TYPE] = (double)REACTION_TYPE_SPECIAL;

	      /* Next reaction */

	      ptr = NextItem(ptr);
	    }
	}

      /* Redundant (n,He-3) */

      if ((long)RDB[rea + REACTION_MT] == 106)
	{
	  /* Loop over reactions */

	  ptr = (long)RDB[nuc + NUCLIDE_PTR_REA];
	  while (ptr > VALID_PTR)
	    {
	      /* Check mt and set type to special */

	      if (((long)RDB[ptr + REACTION_MT] > 749) && 
		  ((long)RDB[ptr + REACTION_MT] < 800))
		WDB[ptr + REACTION_TYPE] = (double)REACTION_TYPE_SPECIAL;

	      /* Next reaction */

	      ptr = NextItem(ptr);
	    }
	}

      /* Redundant (n,a) */

      if ((long)RDB[rea + REACTION_MT] == 107)
	{
	  /* Loop over reactions */

	  ptr = (long)RDB[nuc + NUCLIDE_PTR_REA];
	  while (ptr > VALID_PTR)
	    {
	      /* Check mt and set type to special */

	      if (((long)RDB[ptr + REACTION_MT] > 799) && 
		  ((long)RDB[ptr + REACTION_MT] < 850))
		WDB[ptr + REACTION_TYPE] = (double)REACTION_TYPE_SPECIAL;

	      /* Next reaction */

	      ptr = NextItem(ptr);
	    }
	}

      /* Next reaction */

      rea = NextItem(rea);
    }

  /**************************************************************************/

  /* Close file  */
  
  fclose(fp);	  
}

/*****************************************************************************/
