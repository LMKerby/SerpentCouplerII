/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processvr.c                                    */
/*                                                                           */
/* Created:       2011/05/15 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Processes some variance reduction stuff                      */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessVR:"

/*****************************************************************************/

void ProcessVR()
{
  long ptr;

  /* Check pointer to SB collision mesh */

  if ((ptr = (long)RDB[DATA_SBIAS_PTR_COL_MESH]) > VALID_PTR)
    {
      /****** Source biasing *************************************************/
      
      /* Set boundaries if not already set */

      if (RDB[ptr + MESH_MIN0] == -INFTY)
	WDB[ptr + MESH_MIN0] = RDB[DATA_GEOM_MINX];

      if (RDB[ptr + MESH_MAX0] == INFTY)
	WDB[ptr + MESH_MAX0] = RDB[DATA_GEOM_MAXX];

      if (RDB[ptr + MESH_MIN1] == -INFTY)
	WDB[ptr + MESH_MIN1] = RDB[DATA_GEOM_MINY];

      if (RDB[ptr + MESH_MAX1] == INFTY)
	WDB[ptr + MESH_MAX1] = RDB[DATA_GEOM_MAXY];

      if (RDB[ptr + MESH_MIN2] == -INFTY)
	WDB[ptr + MESH_MIN2] = RDB[DATA_GEOM_MINZ];

      if (RDB[ptr + MESH_MAX2] == INFTY)
	WDB[ptr + MESH_MAX2] = RDB[DATA_GEOM_MAXZ];

      /* Check mode */

      if ((long)RDB[DATA_SBIAS_MODE] != 1)
	Error(0, "Invalid source biasing mode");
            
      /***********************************************************************/
    }
}

/*****************************************************************************/
