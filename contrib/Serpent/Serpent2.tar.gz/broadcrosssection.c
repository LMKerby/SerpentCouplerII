/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : broadcrosssection.c                            */
/*                                                                           */
/* Created:       2011/07/28 (JLe)                                           */
/* Last modified: 2012/01/06 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Perfrorms integreation for DopplerBroad()                    */
/*                                                                           */
/* Comments: - From Serpent 1.1.15                                           */
/*           - Original routine developed by Tuomas Viitanen                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#include <tgmath.h>

#define FUNCTION_NAME "BroadCrossSection:"

/*****************************************************************************/

void BroadCrossSection(long L0, long L1, long NES, double currentTemperature, 
		       double finalTemperature, double awr, double *XSS, 
		       long *limits, long thresholdindex, long gridsize){

  long i, mlow, intindex;
  double alpha, auxiliary;
  register double x1, x2, v;
  double *integral, *tempcrossect;
 
  /* Varataan muistia */

  integral=(double *)Mem(MEM_ALLOC, NES, sizeof(double));
  tempcrossect=(double *)Mem(MEM_ALLOC, NES, sizeof(double));
    
  /* Varmuuden vuoksi tarkistetaan että ei jaeta nollalla ja tuoteta
     siten hölmöjä tuloksia. Tätä ei pitäisi ikinä tapahtua. Enää.
     Lisätty 27.4.2009 (TVi)*/

  if(finalTemperature==currentTemperature)
    Die(FUNCTION_NAME, "Cross section already in desired temperature");

#ifdef DEBUG

  /* Tarkistetaan negatiiviset, raja on sama kuin interpolatedata.c:ssä */
  /* (JLE 31.8.2011) */

  for (i = 0; i < NES; i++){
    if (XSS[L1 + i] < -1.0)
      Die(FUNCTION_NAME, "Negative cross sections before broadening");
  }
#endif

  /* Alffa = m/2k(delta T) Kannattaa huomioida, että SPD_C on 
     senttimetriyksiköissä, minkä vuoksi kymppitonnilla kertominen 
     osoittajassa */

  alpha=(awr*NEUTRON_E0*1E4)/(SPD_C*SPD_C*2*KELVIN*(finalTemperature
      					    -currentTemperature));



  /* Kynnyseneriallisten reaktioiden tapauksessa ensimmainen piste pitaa jattaa
     leventamatta eli kaytannossa nollaksi (muuten processxsdata.c herjaa) (TVi 2011-12-01)*/

  i=0;  
  if(thresholdindex > 0){
    i=1;
    tempcrossect[0]=XSS[L1 + 0];
  }

  for(; i<NES; i++){  

    /* Hypp�� pisteen yli (jätä leventämättä), jos integrointi menee 
       yli energiagridin (TVi 2.9.2011) */
        
    if(limits[i*3+1]>=gridsize-1){
      tempcrossect[i]=XSS[L1+i];
      continue;
    }
    
    /* v = neutronin nopeus */

    v=sqrt(2*XSS[L0+i]*SPD_C*SPD_C/(1E4*NEUTRON_E0));
  
    /*********************************************************************/
    /* Varsinainen integrointi alkaapi tästä */
    /* Integrointirajat on valmiiksi annettu limits -taulukossa */
    
    integral[i]=0.0;

    /* In case of a threshold reaction, the indexes must be shifted by thresholdindex (TVi 1.9.2011)*/

    intindex=limits[i*3]-thresholdindex;
    
    if(intindex<0)
      intindex=0;
    /* Ekstrapoloidaan tarvittaessa nollasta (0, ei ZERO) ekaan 
       energiapisteeseen, vaikutusalalla 1/v -approksimaatio
       jälkimmäinen ehto poistaa ekstrapolaation käytöstä 
       threshold-reaktioilla. Tämän kanssa ei tosin havaittu
       ongelmia, joten ehdon voisi yhtä hyvin poistaa... */
       
    if(limits[i*3]==0 && XSS[L0]<1E-8) {
  
    x2=sqrt(2*XSS[L0]*SPD_C*SPD_C/(1E4*NEUTRON_E0));
    integral[i]+=XSS[L1]*x2/(2*alpha)*(exp(-alpha*pow(v,2))-exp(-alpha*
    pow(x2-v,2))+sqrt(alpha*PI)*v*(erf(sqrt(alpha)*(x2-v))+
    erf(sqrt(alpha)*v)));

    }

    /* Energiapistevälin plow->phigh yli integrointi*/
    /* Added threshold correction (TVi 1.9.2011) */
    while(intindex<limits[i*3+1]-thresholdindex){

      x1=sqrt(2*XSS[L0+intindex]*SPD_C*SPD_C/(1E4*NEUTRON_E0));
      x2=sqrt(2*XSS[L0+intindex+1]*SPD_C*SPD_C/(1E4*NEUTRON_E0));

      /* Check coincident energy points (10.6.2011 / 1.1.15 JLe) */
      
      if (x1 == x2)
	{
	  intindex++;
	  continue;
	}
      
      /* Integraalin analyyttinen ratkaisu */

      auxiliary=sqrt(alpha*PI)*(
      v*(3+2*alpha*pow(v,2))*(XSS[L1+intindex]-XSS[L1+intindex+1])+
      (1+2*alpha*pow(v,2))*(-x2*XSS[L1+intindex]+x1*XSS[L1+intindex+1]));

      /* Voi pojat tästä oli lystiä etsiä virheitä */
      integral[i]+=1/(4*pow(alpha,2)*(x2-x1))*(-2*exp(-alpha*pow(v-x1,2))*
      ((XSS[L1+intindex]-XSS[L1+intindex+1])*(1+alpha*pow(v,2))+
       XSS[L1+intindex]*alpha*(v+x1)*(x1-x2))-auxiliary*
      erf(sqrt(alpha)*(v-x1))+2*exp(-alpha*pow(v-x2,2))*((XSS[L1+intindex]-
      XSS[L1+intindex+1])*(1+alpha*pow(v,2))+alpha*XSS[L1+intindex+1]*
      (v+x2)*(x1-x2))+auxiliary*erf(sqrt(alpha)*(v-x2)));

      intindex++;
    }

    /* Yllä oleva integrointi oli +e^(-alffa(V-v)^2) -termille, seuraava
       on -e^(-alffa(V+v)^2)-termille */

    /* Tämä integroidaan nollasta (tai thresholdista = indeksi 0) intlim-v :hen */
    
    mlow=0;
    
    /* Ekstrapoloidaan tarvittaessa nollasta (0, ei ZERO) ekaan 
       energiapisteeseen, vaikutusalalla 1/v -approksimaatio */    
    /* Ehto poistaa ekstrapoloinnin käytöstä threshold-reaktioilla */
    
    if(XSS[L0]<1E-8 && limits[i*3+2]>0){
          
      x2=sqrt(2*XSS[L0]*SPD_C*SPD_C/(1E4*NEUTRON_E0));
    integral[i]-=XSS[L1]*x2/(2*alpha)*(exp(-alpha*pow(v,2))-exp(-alpha*
      pow(x2+v,2))-sqrt(alpha*PI)*v*erf(sqrt(alpha)*(x2+v))+
      sqrt(alpha*PI)*v*erf(sqrt(alpha)*v));    

    }
   
    /* Energiapistevälin mlow->mhigh yli integrointi*/

    while(mlow<limits[i*3+2]-thresholdindex){
      x1=sqrt(2*XSS[L0+mlow]*SPD_C*SPD_C/(1E4*NEUTRON_E0));
      x2=sqrt(2*XSS[L0+mlow+1]*SPD_C*SPD_C/(1E4*NEUTRON_E0));
 
      /* Check coincident energy points (10.6.2011 / 1.1.15 JLe) */
      
      if (x1 == x2)
	{
	  mlow++;
	  continue;
	}
      
     /* Analyyttinen integraalin ratkaisu */

      auxiliary=sqrt(alpha*PI)*(
      v*(-3-2*alpha*pow(v,2))*(XSS[L1+mlow]-XSS[L1+mlow+1])+
      (1+2*alpha*pow(v,2))*(-x2*XSS[L1+mlow]+
      x1*XSS[L1+mlow+1]));
      
      integral[i]-=1/(4*pow(alpha,2)*(x2-x1))*(-2*exp(-alpha*pow(v+x1,2))*
      ((XSS[L1+mlow]-XSS[L1+mlow+1])*(1+alpha*pow(v,2))+XSS[L1+mlow]*alpha*
      (x1-v)*(x1-x2))-auxiliary*erf(sqrt(alpha)*(-v-x1))+
      2*exp(-alpha*pow(v+x2,2))*((XSS[L1+mlow]-XSS[L1+mlow+1])*(1+alpha*
      pow(v,2))+alpha*XSS[L1+mlow+1]*(x2-v)*(x1-x2))+auxiliary*
      erf(sqrt(alpha)*(-v-x2)));

      mlow++;
    }

    /* Ensin väliaikaiseen säilöön.  */

    tempcrossect[i]=(1/pow(v,2))*sqrt(alpha/PI)*integral[i];
    
  }

  /* Siirretään vaikutusalat */

  memmove(&XSS[L1], tempcrossect, NES*sizeof(double));
  
#ifdef DEBUG

  /* Tarkistetaan negatiiviset, raja on sama kuin interpolatedata.c:ssä */
  /* (JLE 31.8.2011) */
  
  for (i = 0; i < NES; i++)
    if (XSS[L1 + i] < -1.0)
      Die(FUNCTION_NAME, "Negative cross sections after broadening");

#endif

  Mem(MEM_FREE, integral);
  Mem(MEM_FREE, tempcrossect);
}
/*****************************************************************************/
