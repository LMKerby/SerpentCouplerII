/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : readinput.c                                    */
/*                                                                           */
/* Created:       2010/09/21 (JLe)                                           */
/* Last modified: 2012/01/26 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Reads input file.                                            */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"
#include "surface_types.h"

#define FUNCTION_NAME "ReadInput:"

/*****************************************************************************/

void ReadInput(char *inputfile)
{
  long np, i0, i, j, k, n, m, loc0, loc1, loc2, ptr, type, nx, ny, nz, nr, ns;
  long ne, ni, line, r, b, g;
  char *input, word[MAX_STR], str[10000], *params[MAX_INPUT_PARAMS];
  char fname[MAX_STR], pname[MAX_STR];
  double val, sum, ax, ay, az, mem, xmin, xmax, ymin, ymax, zmin, zmax;
  FILE *fp;

  /* Print file name */

  fprintf(out, "Reading input file \"%s\"...\n", inputfile);

  /* Allocate memory for input params */
  
  for (i = 0; i < MAX_INPUT_PARAMS; i++)
    params[i] = (char *)Mem(MEM_ALLOC, MAX_STR, sizeof(char));
   
  /* Copy input file name */

  strcpy(fname, inputfile);

  /* Reset j and np to avoid compiler warnings */

  j = 0;
  np = 0;

  /* Read input file */
  
  input = ReadTextFile(inputfile);

  /* Reset line number */

  line = 1;

  /***************************************************************************/

  /***** Loop over words *****************************************************/
  
  i0 = 0;

  while ((i = NextWord(&input[i0], word)) > 0)
    {
      /* Reset parameter name */

      *pname = '\0';
  
      /* update pointer */
      
      i0 = i0 + i;

      /* Get line number for error messages */

      line = GetLineNumber(input, i0);

      /***********************************************************************/
      
      /***** Read another input file *****************************************/

      if (!strcasecmp(word, "include"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 1, 1, fname);

	  /* Check that file exists */

	  if ((fp = fopen(params[0], "r")) != NULL)
	    fclose(fp);
	  else
	    {
	      /* File not found */
	      
	      Error(-1, pname, fname, line, 
		    "Input file \"%s\" does not exist", params[0]);
	    }

	  /* Read input file */

	  ReadInput(params[0]);
	}

      /***********************************************************************/

      /***** Material definition *********************************************/

      else if (!strcasecmp(word, "mat"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 4, 4*MAX_ISOTOPES + 8,
			 fname);

	  /* Get memory size */
      
	  mem = RDB[DATA_TOTAL_BYTES];

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_M0, MATERIAL_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Read data */

	  j = 0;

	  /* Material name */

	  WDB[loc0 + MATERIAL_PTR_NAME] = (double)PutText(params[j++]);

	  /* Material density */

	  if (!strcmp(params[j], "sum"))
	    {
	      /* Set value to -infinity to calculate sum from composition */
	      
	      WDB[loc0 + MATERIAL_ADENS] = -INFTY;
	      
	      j++;
	    }
	  else
	    {
	      /* Read value */
	      
	      WDB[loc0 + MATERIAL_ADENS] = 
		TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			  -100.0, 100.0);
	    }

	  /* Reset temperature */

	  WDB[loc0 + MATERIAL_TEMP] = -1.0;

	  /* Reset sum */

	  sum = 0.0;
	  
	  /* Loop over parameters */
	  
	  while (j < np)
	    {
	      /* Check parameter */

	      if (!strcmp(params[j], "tmp"))
		{
		  /***** Temperature for Doppler-breadening ******************/
		  
		  j++;

		  /* Get temperature */
		  
		  WDB[loc0 + MATERIAL_TEMP] = 
			   TestParam(pname, fname, line, params[j++], 
				     PTYPE_REAL, 0.0, 100000.0);

		  /***********************************************************/
		}
	      else if (!strcmp(params[j], "rgb"))
		{
		  /***** Material colour *************************************/

		  j++;
		  
		  /* Get r, b and g */
		  
		  r = TestParam(pname, fname, line, params[j++], PTYPE_INT, 
				0, 255);

		  g = TestParam(pname, fname, line, params[j++], PTYPE_INT, 
				0, 255);

		  b = TestParam(pname, fname, line, params[j++], PTYPE_INT, 
				0, 255);

		  /* Set color */

		  WDB[loc0 + MATERIAL_RGB] = b + 1000.0*g + 1000000.0*r;
		  
		  /***********************************************************/
		}
	      else if (!strcmp(params[j], "vol"))
		{
		  /***** Material volume *************************************/

		  j++;
		  
		  /* Get volume */
		  
		  WDB[loc0 + MATERIAL_VOLUME_GIVEN] =
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      0.0, INFTY);

		  /***********************************************************/
		}
	      else if (!strcmp(params[j], "mass"))
		{
		  /***** Material mass ***************************************/

		  j++;
		  
		  /* Get mass */
		  
		  WDB[loc0 + MATERIAL_MASS] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      0.0, INFTY);

		  /***********************************************************/
		}
	      else if (!strcmp(params[j], "burn"))
		{
		  /***** Burnable material ***********************************/
		  
		  j++;

		  /* Set burn flag */
		  
		  SetOption(loc0 + MATERIAL_OPTIONS, OPT_BURN_MAT);
		  
		  /* Set running mode */
		  
		  if ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_TRANSPORT)
		    WDB[DATA_RUNNING_MODE] = (double)RUNNING_MODE_EXT_BURN;
		  
		  /* Get number of rings */

		  WDB[loc0 + MATERIAL_BURN_RINGS] = 
			   (double)TestParam(pname, fname, line, params[j++], 
					     PTYPE_INT, 0, 10000000);
		  
		  /***********************************************************/
		}
	      else if (!strcmp(params[j], "moder"))
		{
		  /***** Thermal scattering data *****************************/

		  j++;

		  /* Check number of parameters */
		  
		  if (j > np - 3)
		    Error(loc0, "Invalid number of parameters");
		  
		  /* Create new item (use the same structure as with */
		  /* the therm card) */

		  loc1 = NewItem(loc0 + MATERIAL_PTR_SAB, THERM_BLOCK_SIZE);

		  /* Read name */
		  
		  WDB[loc1 + THERM_PTR_ALIAS] = 
		    (double)PutText(params[j++]);
		  
		  /* Read ZA */
		  
		  WDB[loc1 + THERM_ZA] =  
		    (double)TestParam(pname, fname, line, params[j++], 
				      PTYPE_INT, 1001, 120000);
		      
		  /***********************************************************/
		}
	      else 
		{
		  /***** Composition *****************************************/
		  
		  /* Create new item */
		  
		  loc1 = NewItem(loc0 + MATERIAL_PTR_COMP, 
				 COMPOSITION_BLOCK_SIZE);
		      
		  /* Check number of parameters */
		  
		  if (j > np - 2)
		    Error(loc0, "Invalid number of parameters");
		  
		  /* Read nuclide name */
		  
		  WDB[loc1 + COMPOSITION_PTR_NUCLIDE] =  
		    (double)PutText(params[j++]);
		  
		  /* Read fraction */
		  
		  val = TestParam(pname, fname, line, params[j++], 
				  PTYPE_REAL, -100.0, 1E+25);
		  
		  WDB[loc1 + COMPOSITION_ADENS] = val;
		  
		  /* Add to sum */
		  
		  sum = sum + val;
		  
		  /***********************************************************/
		}
	    }
	  
	  /* Set density if sum */

	  if (RDB[loc0 + MATERIAL_ADENS] == -INFTY)
	    WDB[loc0 + MATERIAL_ADENS] = sum;

	  /* Put memory size */
      
	  WDB[loc0 + MATERIAL_MEM_SIZE] = RDB[DATA_TOTAL_BYTES] - mem;
 	}

      /***********************************************************************/

      /***** Mixture definition **********************************************/

      else if (!strcasecmp(word, "mix"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 4, 4*MAX_ISOTOPES + 8,
			 fname);

	  /* Get memory size */
      
	  mem = RDB[DATA_TOTAL_BYTES];

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_M0, MATERIAL_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Read data */

	  j = 0;

	  /* Material name */

	  WDB[loc0 + MATERIAL_PTR_NAME] = (double)PutText(params[j++]);
	  
	  /* Reset temperature */

	  WDB[loc0 + MATERIAL_TEMP] = -1.0;

	  /* Loop over parameters */
	  
	  while (j < np)
	    {
	      /* Check parameter */

	      if (!strcmp(params[j], "rgb"))
		{
		  /***** Mixture colour **************************************/

		  j++;
		  
		  /* Get r, b and g */
		  
		  r = TestParam(pname, fname, line, params[j++], PTYPE_INT, 
				0, 255);

		  g = TestParam(pname, fname, line, params[j++], PTYPE_INT, 
				0, 255);

		  b = TestParam(pname, fname, line, params[j++], PTYPE_INT, 
				0, 255);

		  /* Set color */

		  WDB[loc0 + MATERIAL_RGB] = b + 1000.0*g + 1000000.0*r;
		  
		  /***********************************************************/
		}
	      else if (!strcmp(params[j], "vol"))
		{
		  /***** Mixture volume **************************************/

		  j++;
		  
		  /* Get volume */
		  
		  WDB[loc0 + MATERIAL_VOLUME] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      0.0, INFTY);

		  /***********************************************************/
		}
	      else if (!strcmp(params[j], "mass"))
		{
		  /***** Mixture mass ****************************************/

		  j++;
		  
		  /* Get mass */
		  
		  WDB[loc0 + MATERIAL_MASS] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      0.0, INFTY);

		  /***********************************************************/
		}
	      else
		{
		  /***** Mixed materials *************************************/

		  /* Create new item */
		  
		  loc1 = NewItem(loc0 + MATERIAL_PTR_MIX, MIXTURE_BLOCK_SIZE);

		  /* Check number of parameters */
		      
		  if (j > np - 2)
		    Error(loc0, "Invalid number of parameters");
		  
		  /* Read nuclide name */
		  
		  WDB[loc1 + MIXTURE_PTR_MAT] =  
		    (double)PutText(params[j++]);
		  
		  /* Read fraction (read to volume fraction) */
		  
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -100.0, 1E+25);
		      
		  WDB[loc1 + MIXTURE_VFRAC] = val;
		      
		  /***********************************************************/
		}
	      
	    }

	  /* Put memory size */
      
	  WDB[loc0 + MATERIAL_MEM_SIZE] = RDB[DATA_TOTAL_BYTES] - mem;
 	}

      /***********************************************************************/

      /***** Thermal scattering data *****************************************/

      else if (!strcasecmp(word, "therm"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 2, 6, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_T0, THERM_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line ;

	  /* Read data */

	  j = 0;

	  /* Read name */

	  WDB[loc0 + THERM_PTR_ALIAS] = (double)PutText(params[j++]);

	  if (np == 2)
	    {
	      /* No temperature data. Read isotope name */

	      WDB[loc0 + THERM_PTR_ISO1] = (double)PutText(params[j++]);

	      /* Reset temperature */

	      WDB[loc0 + THERM_T] = -1.0;
	    }
	  else if (np == 6)
	    {
	      /* Temperature data. Read T */

	      val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      0.0, 1E+6);
	      WDB[loc0 + THERM_T] = val;
	      
	      /* Read isotope 1 */

	      WDB[loc0 + THERM_PTR_ISO1] = (double)PutText(params[j++]);
	      val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      0.0, 1E+6);
	      WDB[loc0 + THERM_T1] = val;

	      /* Read isotope 2 */

	      WDB[loc0 + THERM_PTR_ISO2] = (double)PutText(params[j++]);
	      val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      0.0, 1E+6);
	      WDB[loc0 + THERM_T2] = val;
	    }
	  else
	    Error(loc0, "Invalid number of parameters");
 	}

      /***********************************************************************/

      /***** Surface definition **********************************************/

      else if (!strcasecmp(word, "surf"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 2, 12, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_S0, SURFACE_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Read parameters */

	  j = 0;
	  
	  /* Surface name */
	  
	  WDB[loc0 + SURFACE_PTR_NAME] = (double)PutText(params[j++]);

	  /* Find type */
	      
	  for (type = 0; type < SURFACE_TYPES + 1; type++)
	    if (!strcmp(params[j], surf_types[type]))
	      break;

	  /* Check */

	  if (type == SURFACE_TYPES + 1)
	    Error(loc0, "Surface type %s does not exist", params[j]);

	  /* Put type */
	  
	  WDB[loc0 + SURFACE_TYPE] = (double)type + 1.0;

	  /* Update counter */

	  j++;

	  /* Set number of parameters */

	  WDB[loc0 + SURFACE_N_PARAMS] = (double)(np - j);

	  /* Get parameters */

	  if (np - j > 0)
	    {
	      /* Allocate memory for parameters and set pointer */

	      ptr = ReallocMem(DATA_ARRAY, np - j);
	      WDB[loc0 + SURFACE_PTR_PARAMS] = (double)ptr;

	      /* Read parameters */
	      
	      for (n = j; n < np; n++)
		WDB[ptr++] = TestParam(pname, fname, line, params[j++], 
					PTYPE_REAL, -INFTY, INFTY);
	    }
	  else 
	    WDB[loc0 + SURFACE_PTR_PARAMS] = NULLPTR;
 	}

      /***********************************************************************/

      /***** Cell ************************************************************/

      else if (!strcasecmp(word, "cell"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 2, 6 + MAX_CELL_SURFACES, 
			 fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_C0, CELL_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Read data */

	  j = 0;

	  /* Read name */

	  WDB[loc0 + CELL_PTR_NAME] =  (double)PutText(params[j++]);

	  /* Read universe */

	  WDB[loc0 + CELL_PTR_UNI] = (double)PutText(params[j++]);

	  /* Material or fill */

	  if (!strcmp(params[j], "fill"))
	    {
	      WDB[loc0 + CELL_PTR_FILL] = (double)PutText(params[++j]);
	      WDB[loc0 + CELL_PTR_MAT] = NULLPTR;
	    }
	  else
	    {
	      WDB[loc0 + CELL_PTR_MAT] = (double)PutText(params[j]);
	      WDB[loc0 + CELL_PTR_FILL] = NULLPTR;
	    }

	  /* Allocate memory for collision counter */

	  AllocValuePair(loc0 + CELL_COL_COUNT);

	  /* Update index */

	  j++;

	  /* Read surface list to a string */
	  
	  m = 0;

	  for (n = j; n < np; n++)
	    {
	      /* Check leading minus sign */
	      
	      if (params[j][0] == '-')
		sprintf(&str[m], " - %s ", &params[j][1]); 
	      else 
		sprintf(&str[m], " %s ", params[j]);

	      /* Update counters */

	      m = strlen(str);
	      j++;	      
	    }
	  
	  /* Put pointer */
	  
	  WDB[loc0 + CELL_PTR_SURF_LIST] = (double)PutText(str);
	}

      /***********************************************************************/

      /***** Geometry nest ***************************************************/

      else if ((!strcasecmp(word, "nest")) || (!strcasecmp(word, "pin")) ||
	       (!strcasecmp(word, "particle")))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 2, 10000, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_NST0, NEST_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Read data */

	  j = 0;

	  /* Read name */

	  WDB[loc0 + NEST_PTR_NAME] = (double)PutText(params[j]);

	  /* Special treatment for pin and particle */

	  if (!strcmp(word, "pin"))
	    type = SURF_CYL - 1;
	  else if (!strcmp(word, "particle"))
	    type = SURF_SPH - 1;
	  else
	    {
	      /* Update index */

	      j++;

	      /* Check if surface type is given */
	      
	      for (type = 0; type < SURFACE_TYPES + 1; type++)
		if (!strcmp(params[j], surf_types[type]))
		  break;
	    }

	  if (type < SURFACE_TYPES)
	    {
	      /***** All regions have the same type **************************/

	      /* Check */

	      if (surf_params[type][0] < 1)
		Error(loc0, "Surface type %s not allowed in nests", params[j]);

	      /* Put type */

	      WDB[loc0 + NEST_TYPE] = (double)(type + 1);

	      /* Reset pointer */

	      loc1 = -1;

	      /* Loop over parameters */

	      j++;

	      while (j < np)
		{
		  /* Create new region */

		  loc1 = NewItem(loc0 + NEST_PTR_REGIONS, NEST_REG_BLOCK_SIZE);

		  /* Check fill entry */

		  if (!strcmp(params[j], "fill"))
		    {
		      /* Put filler universe */
		      
		      WDB[loc1 + NEST_REG_PTR_FILL] =
			(double)PutText(params[++j]);
		      WDB[loc1 + NEST_REG_PTR_MAT] = NULLPTR;
		    }
		  else
		    {
		      /* Put material */

		      WDB[loc1 + NEST_REG_PTR_MAT] =
			(double)PutText(params[j]);
		      WDB[loc1 + NEST_REG_PTR_FILL] = NULLPTR;
		    }
		  
		  /* Update counter */

		  j++;

		  /* Check if last */

		  if (j < np)
		    {
		      /* Create surface */

		      loc2 = NewItem(loc1 + NEST_REG_PTR_SURF_IN, 
				     SURFACE_BLOCK_SIZE);
		      
		      /* Put pointer */

		      WDB[loc1 + NEST_REG_PTR_SURF_IN] = (double)loc2;

		      /* Put surface type */
		      
		      WDB[loc2 + SURFACE_TYPE] = (double)(type + 1);
		      
		      /* Create parameter list */
		      
		      ptr = ReallocMem(DATA_ARRAY, surf_params[type][0]);
		      
		      /* Put pointer */
		      
		      WDB[loc2 + SURFACE_PTR_PARAMS] = (double)ptr;
		      
		      /* Put number of parameters */

		      WDB[loc2 + SURFACE_N_PARAMS] =
			(double)surf_params[type][0];

		      /* Put surface parameter */
		      
		      WDB[ptr + surf_params[type][0] - 1] = 
			TestParam(pname, fname, line, params[j++], 
				  PTYPE_REAL, -INFTY, INFTY);
		    }
		}

	      /* Check that last region has no surface */

	      if (loc1 < 0)
		Die(FUNCTION_NAME, "Pointer error");
	      else if ((long)RDB[loc1 + NEST_REG_PTR_SURF_IN] > 0)
		Error(loc0, "Last region must be unbound");

	      /***************************************************************/
	    }
	  else
	    {
	      /***** Different type for each region **************************/

	      /* Put type */

	      WDB[loc0 + NEST_TYPE] = -1.0;

	      /* Reset pointer */

	      loc1 = -1;

	      /* Loop over parameters */

	      while (j < np)
		{
		  /* Create new region */

		  loc1 = NewItem(loc0 + NEST_PTR_REGIONS, 
				 NEST_REG_BLOCK_SIZE);

		  /* Check fill entry */

		  if (!strcmp(params[j], "fill"))
		    {
		      /* Put filler universe */
		      
		      WDB[loc1 + NEST_REG_PTR_FILL] =
			(double)PutText(params[++j]);
		      WDB[loc1 + NEST_REG_PTR_MAT] = NULLPTR;
		    }
		  else
		    {
		      /* Put material */

		      WDB[loc1 + NEST_REG_PTR_MAT] =
			(double)PutText(params[j]);
		      WDB[loc1 + NEST_REG_PTR_FILL] = NULLPTR;
		    }
		  
		  /* Update counter */

		  j++;

		  /* Check if last */

		  if (j < np)
		    {
		      /* Get surface type */
		  
		      for (type = 0; type < SURFACE_TYPES + 1; type++)
			if (!strcmp(params[j], surf_types[type]))
			  break;
		  
		      /* Check */
		      
		      if (type == SURFACE_TYPES + 1)
			Error(loc0, "Surface type %s does not exist", 
			      params[j]);
		      else if (surf_params[type][0] < 1)
			Error(loc0, "Surface type %s not allowed in nests", 
			      params[j]);
		      
		      /* Update counter */

		      j++;

		      /* Create surface */
		      
		      loc2 = NewItem(loc1 + NEST_REG_PTR_SURF_IN, 
				     SURFACE_BLOCK_SIZE);

		      /* Put pointer */

		      WDB[loc1 + NEST_REG_PTR_SURF_IN] = (double)loc2;
		      
		      /* Put surface type */
		      
		      WDB[loc2 + SURFACE_TYPE] = (double)(type + 1);
		      
		      /* Create parameter list */
		      
		      ptr = ReallocMem(DATA_ARRAY, surf_params[type][0]);
		      
		      /* Put pointer */
		      
		      WDB[loc2 + SURFACE_PTR_PARAMS] = (double)ptr;

		      /* Put number of parameters */

		      WDB[loc2 + SURFACE_N_PARAMS] =
			(double)surf_params[type][0];

		      /* Read surface parameters */
		      
		      for (n = 0; n < surf_params[type][0]; n++)
			WDB[ptr++] = TestParam(pname, fname, line, 
						params[j++], PTYPE_REAL,
						-INFTY, INFTY);
		    }
		}

	      /* Check that last region has no surface */

	      if (loc1 < 0)
		Die(FUNCTION_NAME, "Pointer error");
	      else if ((long)RDB[loc1 + NEST_REG_PTR_SURF_IN] > 0)
		Error(loc0, "Last region must be unbound");

	      /***************************************************************/
	    }
	}

      /***********************************************************************/

      /***** Universe transformation *****************************************/

      else if (!strcasecmp(word, "trans"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 4, 13, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_TR0, TRANS_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Read data */

	  j = 0;
	  
	  /* Universe name */

	  WDB[loc0 + TRANS_PTR_UNI] = (double)PutText(params[j++]);

	  /* Translation */
	  
	  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			  -INFTY, INFTY);
	  WDB[loc0 + TRANS_X0] = val;

	  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			  -INFTY, INFTY);
	  WDB[loc0 + TRANS_Y0] = val;

	  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			  -INFTY, INFTY);
	  WDB[loc0 + TRANS_Z0] = val;

	  /* Check rotation */

	  if (j < np)
	    {
	      /* Put flag */

	      WDB[loc0 + TRANS_ROT] = (double)YES;

	      /* Check type */
	      
	      if (np - j == 9)
		{
		  /***** Explicit definition *********************************/

		  /* Read data */

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + TRANS_RX1] = val;

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + TRANS_RX2] = val;

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + TRANS_RX3] = val;

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + TRANS_RX4] = val;

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + TRANS_RX5] = val;

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + TRANS_RX6] = val;

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + TRANS_RX7] = val;

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + TRANS_RX8] = val;

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + TRANS_RX9] = val;

		  /* Put remaining values */

		  WDB[loc0 + TRANS_RY1] = 1.0;
		  WDB[loc0 + TRANS_RY2] = 0.0;
		  WDB[loc0 + TRANS_RY3] = 0.0;
		  WDB[loc0 + TRANS_RY4] = 0.0;
		  WDB[loc0 + TRANS_RY5] = 1.0;
		  WDB[loc0 + TRANS_RY6] = 0.0;
		  WDB[loc0 + TRANS_RY7] = 0.0;
		  WDB[loc0 + TRANS_RY8] = 0.0;
		  WDB[loc0 + TRANS_RY9] = 1.0;

		  WDB[loc0 + TRANS_RZ1] = 1.0;
		  WDB[loc0 + TRANS_RZ2] = 0.0;
		  WDB[loc0 + TRANS_RZ3] = 0.0;
		  WDB[loc0 + TRANS_RZ4] = 0.0;
		  WDB[loc0 + TRANS_RZ5] = 1.0;
		  WDB[loc0 + TRANS_RZ6] = 0.0;
		  WDB[loc0 + TRANS_RZ7] = 0.0;
		  WDB[loc0 + TRANS_RZ8] = 0.0;
		  WDB[loc0 + TRANS_RZ9] = 1.0;

		  /***********************************************************/
		}
	      else if (np - j == 3)
		{
		  /***** Angles *********************************************/

		  /* Read angles */

		  ax = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				 -360.0, 360.0);
		  ay = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				 -360.0, 360.0);
		  az = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				 -360.0, 360.0);

		  /* Convert to rad */

		  ax = ax*PI/180.0;
		  ay = ay*PI/180.0;
		  az = az*PI/180.0;

		  /* Fill matrix */

		  WDB[loc0 + TRANS_RX1] = 1.0;
		  WDB[loc0 + TRANS_RX2] = 0.0;
		  WDB[loc0 + TRANS_RX3] = 0.0;
		  WDB[loc0 + TRANS_RX4] = 0.0;
		  WDB[loc0 + TRANS_RX5] = cos(ax);
		  WDB[loc0 + TRANS_RX6] = -sin(ax);
		  WDB[loc0 + TRANS_RX7] = 0.0;
		  WDB[loc0 + TRANS_RX8] = sin(ax);
		  WDB[loc0 + TRANS_RX9] = cos(ax);

		  WDB[loc0 + TRANS_RY1] = cos(ay);
		  WDB[loc0 + TRANS_RY2] = 0.0;
		  WDB[loc0 + TRANS_RY3] = sin(ay);
		  WDB[loc0 + TRANS_RY4] = 0.0;
		  WDB[loc0 + TRANS_RY5] = 1.0;
		  WDB[loc0 + TRANS_RY6] = 0.0;
		  WDB[loc0 + TRANS_RY7] = -sin(ay);
		  WDB[loc0 + TRANS_RY8] = 0.0;
		  WDB[loc0 + TRANS_RY9] = cos(ay);

		  WDB[loc0 + TRANS_RZ1] = cos(az);
		  WDB[loc0 + TRANS_RZ2] = -sin(az);
		  WDB[loc0 + TRANS_RZ3] = 0.0;
		  WDB[loc0 + TRANS_RZ4] = sin(az);
		  WDB[loc0 + TRANS_RZ5] = cos(az);
		  WDB[loc0 + TRANS_RZ6] = 0.0;
		  WDB[loc0 + TRANS_RZ7] = 0.0;
		  WDB[loc0 + TRANS_RZ8] = 0.0;
		  WDB[loc0 + TRANS_RZ9] = 1.0;
		}
	      else
		Error(loc0,"Number of parameters for rotation must be 3 or 9");
	    }
	  else
	    WDB[loc0 + TRANS_ROT] = (double)NO;
 	}

      /***********************************************************************/

      /***** Geometry plot **************************************************/

      else if (!strcasecmp(word, "plot"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 3, 8, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_GPL0, GPL_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Read data */

	  j = 0;

	  /* Init boundaries */

	  WDB[loc0 + GPL_XMIN] = -INFTY;
	  WDB[loc0 + GPL_XMAX] =  INFTY;
	  WDB[loc0 + GPL_YMIN] = -INFTY;
	  WDB[loc0 + GPL_YMAX] =  INFTY;
	  WDB[loc0 + GPL_ZMIN] = -INFTY;
	  WDB[loc0 + GPL_ZMAX] =  INFTY;

	  /* Update counter and set index */
	  
	  WDB[DATA_N_GEOM_PLOTS] = RDB[DATA_N_GEOM_PLOTS] + 1.0;
	  WDB[loc0 + GPL_IDX] = RDB[DATA_N_GEOM_PLOTS];

	  /* Set file name */

	  sprintf(str, "%s_geom%ld.png", GetText(DATA_PTR_INPUT_FNAME),
		  (long)RDB[loc0 + GPL_IDX]);
	  
	  WDB[loc0 + GPL_PTR_FNAME] = (double)PutText(str);

	  /* Plot type */
	  
	  sprintf(str, "%s", params[j++]);

	  /* Put size */

	  n = TestParam(pname, fname, line, params[j++], PTYPE_INT, 5, 10000);
	  WDB[loc0 + GPL_PIX_X] = (double)n;

	  n = TestParam(pname, fname, line, params[j++], PTYPE_INT, 5, 10000);
	  WDB[loc0 + GPL_PIX_Y] = (double)n;

	  /* Get position */

	  if (j < np)
	    {
	      val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      -INFTY, INFTY);
	      WDB[loc0 + GPL_POS] = val;
	    }

	  /* Check mode */
      
	  if ((*str == 'x') || (*str == 'X') || (*str == '1'))
	    {
	      /* YZ-plot */

	      WDB[loc0 + GPL_TYPE] = (double)PLOT_MODE_YZ;

	      /* Read boundaries */

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_YMIN] = val;
		}

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_YMAX] = val;
		}

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_ZMIN] = val;
		}

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_ZMAX] = val;
		}
	    }

	  else if ((*str == 'y') || (*str == 'y') || (*str == '2'))
	    {
	      /* XZ-plot */

	      WDB[loc0 + GPL_TYPE] = (double)PLOT_MODE_XZ;

	      /* Read boundaries */

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_XMIN] = val;
		}

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_XMAX] = val;
		}

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_ZMIN] = val;
		}

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_ZMAX] = val;
		}
	    }

	  else if ((*str == 'z') || (*str == 'z') || (*str == '3'))
	    {
	      /* XY-plot */

	      WDB[loc0 + GPL_TYPE] = (double)PLOT_MODE_XY;

	      /* Read boundaries */

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_XMIN] = val;
		}

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_XMAX] = val;
		}

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_YMIN] = val;
		}

	      if (j < np)
		{
		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc0 + GPL_YMAX] = val;
		}
	    }
	  else
	    Error(loc0, "Invalid plot type %s", str);
 	}

      /***********************************************************************/

      /***** Mesh plot *******************************************************/

      else if (!strcasecmp(word, "mesh"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 2, 12, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_MPL0, MPL_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Init boundaries */

	  WDB[loc0 + MPL_XMIN] = -INFTY;
	  WDB[loc0 + MPL_XMAX] =  INFTY;
	  WDB[loc0 + MPL_YMIN] = -INFTY;
	  WDB[loc0 + MPL_YMAX] =  INFTY;
	  WDB[loc0 + MPL_ZMIN] = -INFTY;
	  WDB[loc0 + MPL_ZMAX] =  INFTY;

	  /* Set default type and colormap */

	  WDB[loc0 + MPL_TYPE] = MPL_TYPE_FLUXPOW;
	  WDB[loc0 + MPL_COLMAP] = PALETTE_HOTCOLD;

	  /* Reset minimum and maximum values */

	  WDB[loc0 + MPL_FMIN] = -1.0;
	  WDB[loc0 + MPL_FMAX] = -1.0;
	  WDB[loc0 + MPL_PMIN] = -1.0;
	  WDB[loc0 + MPL_PMAX] = -1.0;

	  /* Read parameters */

	  j = 0;

	  /* Get type */

	  type = TestParam(pname, fname, line, params[j++], PTYPE_INT, 1, 10);

	  /* Check type */

	  if (type < 4)
	    {
	      /* Serpent 1 style flux / fission rate plot */

	      WDB[loc0 + MPL_AX] = (double)type;
	    }
	  else if (type == MPL_TYPE_FLUXTEMP)
	    {
	      /* Flux / temperature plot */

	      WDB[loc0 + MPL_TYPE] = (double)type;

	      /* Read axis */

	      WDB[loc0 + MPL_AX] = 
		TestParam(pname, fname, line, params[j++], PTYPE_INT, 1, 3);
	    }
	  else
	    {
	      /* Put type */

	      WDB[loc0 + MPL_TYPE] = (double)type;

	      /* Read color map */
	    
	      WDB[loc0 + MPL_COLMAP] =
		TestParam(pname, fname, line, params[j++], PTYPE_INT, 1, 5);
	      
	      /* Read detector name */

	      if ((type == MPL_TYPE_DET) || (type == MPL_TYPE_DET_IMP))
		WDB[loc0 + MPL_PTR_DET] = PutText(params[j++]);
	      
	      /* Read axis */

	      WDB[loc0 + MPL_AX] = 
		TestParam(pname, fname, line, params[j++], PTYPE_INT, 1, 3);
	    }

	    /* Read size */

	  WDB[loc0 + MPL_NX] =
	    TestParam(pname, fname, line, params[j++], PTYPE_INT, 10, 5000);

	  WDB[loc0 + MPL_NY] =
	    TestParam(pname, fname, line, params[j++], PTYPE_INT, 10, 5000);

	  /* Get symmetry */

	  if (j < np)
	    WDB[loc0 + MPL_SYM] = 
	      TestParam(pname, fname, line, params[j++], PTYPE_INT, 0, 3);

	  /* Check symmetry */

	  if (((long)RDB[loc0 + MPL_SYM] != 0) && 
	      ((long)RDB[loc0 + MPL_NX] != (long)RDB[loc0 + MPL_NY]))
	    Error(loc0, "Mesh plot must be square if symmetry option is used");

	  /* Get dimensions */

	  if (j < np - 1)
	    {
	      WDB[loc0 + MPL_XMIN] = 
		TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			  -INFTY, INFTY);

	      WDB[loc0 + MPL_XMAX] = 
		TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			  -INFTY, INFTY);
	    }
	  if (j < np - 1)
	    {
	      WDB[loc0 + MPL_YMIN] = 
		TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			  -INFTY, INFTY);

	      WDB[loc0 + MPL_YMAX] = 
		TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			  -INFTY, INFTY);
	    }
	  if (j < np - 1)
	    {
	      WDB[loc0 + MPL_ZMIN] = 
		TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			  -INFTY, INFTY);

	      WDB[loc0 + MPL_ZMAX] = 
		TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			  -INFTY, INFTY);
	    }
 	}

      /***********************************************************************/

      /***** Explicit stochastic (pebble bed) geometry ***********************/
      
      else if (!strcasecmp(word, "pbed"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 3, 4, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_PB0, PBED_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Read data */

	  j = 0;

	  /* Read name */

	  WDB[loc0 + PBED_PTR_NAME] = PutText(params[j++]);

	  /* Read background universe */

	  WDB[loc0 + PBED_PTR_BG_UNIV] = PutText(params[j++]);

	  /* Read file name */

	  WDB[loc0 + PBED_PTR_FNAME] = PutText(params[j++]);

	  /* Reset results flag */

	  WDB[loc0 + PBED_CALC_RESULTS] = (double)NO;

	  /* Check if results are requested */

	  while (j < np)
	    {
	      if (!strcmp(params[j], "pow"))
		WDB[loc0 + PBED_CALC_RESULTS] = (double)YES;

	      j++;
	    }

	  /* Add to counter */

	  WDB[DATA_N_PBED] = RDB[DATA_N_PBED] + 1.0;
	}

      /***********************************************************************/

      /***** Temperature feedback ********************************************/
      
      else if (!strcasecmp(word, "tfb"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 6, 306, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_TFB0, TFB_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Read data */

	  j = 0;

	  /* Read nest */

	  WDB[loc0 + TFB_PTR_NST] = PutText(params[j++]);

	  /* Skip mode number */

	  j++;

	  /* Read boundary condition */
	      
	  WDB[loc0 + TFB_TLIM] = 
	    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 0.0, 
		      1E+6);
	  
	  /* Loop over parameters */
	      
	  while (j < np)
	    {
	      /* New region */

	      ptr = NewItem(loc0 + TFB_PTR_REG_LIST, TFB_REG_BLOCK_SIZE);

	      /* Read material */
	      
	      if (j == np)
		Error(loc0, "Missing material name");
	      else
		WDB[ptr + TFB_REG_PTR_MAT] = PutText(params[j++]);

	      /* Read temperature */
	      
	      if (j == np)
		Error(loc0, "Missing temperature");
	      else
		WDB[ptr + TFB_REG_TMAX] = 
		  TestParam(pname, fname, line, params[j++], PTYPE_REAL, 0.0, 
			    1E+6);

	      /* Read heat conductivity */
	      
	      if (j == np)
		Error(loc0, "Missing heat conductivity");
	      else
		WDB[ptr + TFB_REG_HC] = 
		  TestParam(pname, fname, line, params[j++], PTYPE_REAL, 0.0, 
			    1E+6);
	    }

	  /* Set flag */

	  WDB[DATA_USE_TFB] = (double)YES;
	}

      /***********************************************************************/

      /***** Lattice definition **********************************************/

      else if (!strcasecmp(word, "lat"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 6, MAX_LATTICE_ITEMS + 7,
			 fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_L0, LAT_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Read data */

	  j = 0;

	  /* Read name */

	  WDB[loc0 + LAT_PTR_NAME] = (double)PutText(params[j++]);

	  /* Lattice type */

	  type = TestParam(pname, fname, line, params[j++], PTYPE_INT, 1, 
			   LATTICE_TYPES);

	  /* Put type */

	  WDB[loc0 + LAT_TYPE] = type;

	  /* Lattice origin (siirr� t�� noiden if-lausekkeiden sis��n?) */
	  
	  WDB[loc0 + LAT_ORIG_X0] = 
	    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
		      -INFTY, INFTY);

	  WDB[loc0 + LAT_ORIG_Y0] = 
	    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
		      -INFTY, INFTY);

	  /* Allocate memory for collision counter */

	  AllocValuePair(loc0 + LAT_COL_COUNT);

	  /* Reset pointer */

	  ptr = -1;

	  /* Check type */
	  
	  if ((type == LAT_TYPE_S) || (type ==LAT_TYPE_HX) ||
	      (type == LAT_TYPE_HY) || (type == LAT_TYPE_INFS) || 
	      (type == LAT_TYPE_INFHY) || (type == LAT_TYPE_INFHX))
	    {
	      /***** Simple types ********************************************/
	      
	      /* Lattice size */

	      if ((type == LAT_TYPE_S) || (type ==LAT_TYPE_HX) ||
		  (type == LAT_TYPE_HY))
		{
		  nx = TestParam(pname, fname, line, params[j++], PTYPE_INT, 
				 1, 100);
		  
		  ny = TestParam(pname, fname, line, params[j++], PTYPE_INT, 
				 1, 100);
		}
	      else
		{
		  nx = 1;
		  ny = 1;
		}

	      /* Put values */

	      WDB[loc0 + LAT_NX] = (double)nx;
	      WDB[loc0 + LAT_NY] = (double)ny;
	      WDB[loc0 + LAT_NTOT] = (double)nx*ny;
	      
	      /* Lattice pitch */
	      
	      val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      ZERO, INFTY);
	      
	      WDB[loc0 + LAT_PITCH] = val;
	      
	      /* Check number of items */
	      
	      if (np - j != nx*ny)
		Error(loc0, "Invalid number of lattice elements");
	      
	      /* Allocate memory for data */
	      
	      ptr = ReallocMem(DATA_ARRAY, nx*ny + 1);
	      
	      /* Set pointer */
	      
	      WDB[loc0 + LAT_PTR_FILL] = (double)ptr;
	      
	      /* Read items */
	      
	      while (j < np)
		WDB[ptr++] = PutText(params[j++]);

	      /* Put null pointer */

	      WDB[ptr] = NULLPTR;

	      /***************************************************************/
	    }
	  else if (type == LAT_TYPE_ZSTACK)
	    {
	      /***** Vertical stack ******************************************/

	      /* Number of layers */
	      
	      ns = TestParam(pname, fname, line, params[j++], PTYPE_INT, 
			     1, 100);
	      
	      WDB[loc0 + LAT_NTOT] = (double)ns;

	      /* Check number of items */
	      
	      if (np - j != 2*ns)
		Error(loc0, "Invalid number of layers");
	      
	      /* Allocate memory for data */
	      
	      loc1 = ReallocMem(DATA_ARRAY, ns + 1);
	      loc2 = ReallocMem(DATA_ARRAY, ns);

	      /* Set pointers */
	      
	      WDB[loc0 + LAT_PTR_FILL] = (double)loc1;
	      WDB[loc0 + LAT_PTR_Z] = (double)loc2;
	      
	      /* Read data */
	      
	      for (n = 0; n < ns; n++)
		{
		  /* Z-coordinate */

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  -INFTY, INFTY);
		  WDB[loc2++] = val;

		  /* Universe */

		  WDB[loc1++] = PutText(params[j++]);		  
		}

	      /* Put null pointer */

	      WDB[loc1] = NULLPTR;

	      /***************************************************************/
	    }
	  else if (type == LAT_TYPE_CLU)
	    {
	      /***** Cluster type lattice ************************************/

	      /* Read number of rings */

	      nr = TestParam(pname, fname, line, params[j++], PTYPE_INT, 
				 1, 100);

	      WDB[loc0 + LAT_N_RINGS] = (double)nr;

	      /* Loop over rings */

	      for (n = 0; n < nr; n++)
		{
		  /* Create new ring */

		  loc1 = NewItem(loc0 + LAT_PTR_FILL, RING_BLOCK_SIZE);

		  /* Read number of sectors */

		  ns = TestParam(pname, fname, line, params[j++], PTYPE_INT, 
				 1, 100);

		  WDB[loc1 + RING_N_SEC] = (double)ns;

		  /* Add to total number of elements */

		  WDB[loc0 + LAT_NTOT] = RDB[loc0 + LAT_NTOT] + (double)ns;

		  /* Read ring radius */

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  0.0, INFTY);

		  WDB[loc1 + RING_RAD] = val;

		  /* Read tilt (convert to radians) */

		  val = TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  0.0, 360.0);

		  WDB[loc1 + RING_TILT] = PI*val/180;
		  
		  /* Allocate memory for data */
	      
		  ptr = ReallocMem(DATA_ARRAY, ns + 1);
	      
		  /* Set pointer */
	      
		  WDB[loc1 + RING_PTR_FILL] = (double)ptr;
	      
		  /* Read items */
	      
		  for (m = 0; m < ns; m++)
		    WDB[ptr++] = PutText(params[j++]);
		  
		  /* Put null pointer */

		  WDB[ptr] = NULLPTR;

		  /* Compare indexes */

		  if (j > np)
		    Error(loc0, "Invalid number of lattice elements");
		}
	      
	      /* Close ring list */

	      loc1 = (long)RDB[loc0 + LAT_PTR_FILL];
	      CloseList(loc1);	
      
	      /***************************************************************/
	    }
 	}

      /***********************************************************************/

      /****** Depletion history **********************************************/

      else if (!strcasecmp(word, "dep"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 2, 1000, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_BURN_PTR_DEP, DEP_HIS_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Set running mode */
	      
	  if (((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_TRANSPORT) ||
	      ((long)RDB[DATA_RUNNING_MODE] == RUNNING_MODE_EXT_BURN))
	    WDB[DATA_RUNNING_MODE] = RUNNING_MODE_INT_BURN;

	  /* Read data */

	  j = 0;

	  if ((ne = np - j - 1) < 1)
	    Error(loc0, "Invalid number of parameters");

	  /* Allocate memory for steps */

	  loc1 = ReallocMem(DATA_ARRAY, ne);

	  /* Set pointer */

	  WDB[loc0 + DEP_HIS_PTR_STEPS] = (double)loc1;

	  /* Read step type */

	  if (!strcmp(params[j], "bustep"))
	    WDB[loc0 + DEP_HIS_STEP_TYPE] = DEP_STEP_BU_STEP;
	  else if (!strcmp(params[j], "daystep"))
	    WDB[loc0 + DEP_HIS_STEP_TYPE] = DEP_STEP_DAY_STEP;
	  else if (!strcmp(params[j], "butot"))
	    WDB[loc0 + DEP_HIS_STEP_TYPE] = DEP_STEP_BU_TOT;
	  else if (!strcmp(params[j], "daytot"))
	    WDB[loc0 + DEP_HIS_STEP_TYPE] = DEP_STEP_DAY_TOT;
	  else if (!strcmp(params[j], "decstep"))
	    WDB[loc0 + DEP_HIS_STEP_TYPE] = DEP_STEP_DEC_STEP;
	  else if (!strcmp(params[j], "dectot"))
	    WDB[loc0 + DEP_HIS_STEP_TYPE] = DEP_STEP_DEC_TOT;
	  else
	    Error(loc0, "Invalid depletion parameter \"%s\"", params[j]);
	  
	  j++;
	  
	  /* Loop over values */
	  
	  for (n = 0; n < ne; n++)
	    WDB[loc1++] = TestParam(pname, fname, line, params[j++], 
				     PTYPE_REAL, ZERO, INFTY);

	  /* Set number of steps */

	  WDB[loc0 + DEP_HIS_N_STEPS] = (double)ne;

	  /* Add to total */

	  WDB[DATA_BURN_TOT_STEPS] = RDB[DATA_BURN_TOT_STEPS] + (double)ne;
	}

      /***********************************************************************/

      /***** External source definition **************************************/

      else if (!strcasecmp(word, "src"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 1, 10000, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_SRC0, SRC_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Reset weight */

	  WDB[loc0 + SRC_WGT] = 1.0;

	  /* Reset boundaries */

	  WDB[loc0 + SRC_XMIN] = -INFTY;
	  WDB[loc0 + SRC_XMAX] =  INFTY;
	  WDB[loc0 + SRC_YMIN] = -INFTY;
	  WDB[loc0 + SRC_YMAX] =  INFTY;
	  WDB[loc0 + SRC_ZMIN] = -INFTY;
	  WDB[loc0 + SRC_ZMAX] =  INFTY;

	  /* Reset point */

	  WDB[loc0 + SRC_X0] = -INFTY;
	  WDB[loc0 + SRC_Y0] = -INFTY;
	  WDB[loc0 + SRC_Z0] = -INFTY;

	  /* Set default type to neutron */

	  WDB[loc0 + SRC_TYPE] = (double)PARTICLE_TYPE_NEUTRON;

	  /* Reset energy */

	  WDB[loc0 + SRC_E] = -INFTY;

	  /* Read data */

	  j = 0;

	  /* Source name */
	  
	  WDB[loc0 + SRC_PTR_NAME] = (double)PutText(params[j++]);

	  /* Check if type is given */

	  if (j < np)
	    {
	      if (!strcmp(params[j], "neutron") || !strcmp(params[j], "n") ||
		  (atoi(params[j]) == PARTICLE_TYPE_NEUTRON))
		{
		  WDB[loc0 + SRC_TYPE] = (double)PARTICLE_TYPE_NEUTRON;
		  j++;
		}
	      else if (!strcmp(params[j], "photon") ||
		       !strcmp(params[j], "gamma") ||
		       !strcmp(params[j], "p") ||
		       !strcmp(params[j], "g") ||
		       (atoi(params[j]) == PARTICLE_TYPE_GAMMA))
		{
		  WDB[loc0 + SRC_TYPE] = (double)PARTICLE_TYPE_GAMMA;
		  j++;
		}
	    }

	  /* Loop over remaining parameters */

	  while (j < np)
	    {
	      /* Check parameter type */

	      strcpy(str, params[j++]);

	      if (!strcmp(str, "se"))
		{
		  /* Energy. Check number of parameters. */
		  
		  if (j == np)
		    Error(loc0, "Missing value after \"%s\"", str);
		  
		  /* Set value */
		  
		  WDB[loc0 + SRC_E] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      1E-11, 20.0);
		}
	      else if (!strcmp(str, "sw"))
		{
		  /* Weight. Check number of parameters. */
		  
		  if (j == np)
		    Error(loc0, "Missing value after \"%s\"", str);
		  
		  /* Set value */
		  
		  WDB[loc0 + SRC_WGT] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      0.0, INFTY);
		}
	      else if (!strcmp(str, "sm"))
		{
		  /* Material. Check number of parameters. */
		  
		  if (j == np)
		    Error(loc0, "Missing material name after \"%s\"", str);
		  
		  /* Set value */
		  
		  WDB[loc0 + SRC_PTR_MAT] = (double)PutText(params[j++]);
		}
	      else if (!strcmp(str, "sc"))
		{
		  /* Cell. Check number of parameters. */
		  
		  if (j == np)
		    Error(loc0, "Missing cell after \"%s\"", str);
		  
		  /* Set value */
		  
		  WDB[loc0 + SRC_PTR_CELL] = (double)PutText(params[j++]);
		}
	      else if (!strcmp(str, "su"))
		{
		  /* Universe. Check number of parameters. */
		  
		  if (j == np)
		    Error(loc0, "Missing universe number after \"%s\"", str);
		  
		  /* Set value */
		  
		  WDB[loc0 + SRC_PTR_UNIV] = (double)PutText(params[j++]);
		}
	      else if (!strcmp(str, "ss"))
		{
		  /* Surface. Check number of parameters. */
		  
		  if (j == np)
		    Error(loc0, "Missing surface after \"%s\"", str);
		  
		  /* Set value */
		  
		  WDB[loc0 + SRC_PTR_SURF] = (double)PutText(params[j++]);
		}
	      else if (!strcmp(str, "sb"))
		{
		  /* Energy bins. Check number of parameters. */
		  
		  if (j == np)
		    Error(loc0, "Missing number of bins \"%s\"", str);
		  
		  /* Get number of bins */

		  ne = TestParam(pname, fname, line, params[j++], PTYPE_INT,
				 2, 1000000);

		  /* Loop over values */

		  for (m = 0; m < ne; m++)
		    {
		      /* Allocate memory for structure */

		      loc1 = NewItem(loc0 + SRC_PTR_EBINS,
				     SRC_EBIN_BLOCK_SIZE);

		      /* Read energy */
		      
		      WDB[loc1 + SRC_EBIN_EMAX] = 
			TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  0.0, 1000.0);

		      /* Read weight */
		      
		      WDB[loc1 + SRC_EBIN_WGT] = 
			TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
				  0.0, INFTY);

		      /* Check count */

		      if (j > np)
			Error(loc0, "Not enough energy bins");
		    }

		  /* Close bin list */

		  loc1 = (long)RDB[loc0 + SRC_PTR_EBINS];
		  CloseList(loc1);
		}
	      else if (!strcmp(str, "sx"))
		{
		  /* X-boundaries. Check number of parameters. */
		  
		  if (j == np - 1)
		    Error(loc0, "Missing values after \"%s\"", str);
		  
		  /* Set values */
		  
		  WDB[loc0 + SRC_XMIN] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      -INFTY, INFTY);

		  WDB[loc0 + SRC_XMAX] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      -INFTY, INFTY);

		  /* Swap boundaries */

		  if (RDB[loc0 + SRC_XMAX] < RDB[loc0 + SRC_XMIN])
		    {
		      val = RDB[loc0 + SRC_XMAX];
		      WDB[loc0 + SRC_XMAX] = RDB[loc0 + SRC_XMIN];
		      WDB[loc0 + SRC_XMIN] = val;
		    }
		}
	      else if (!strcmp(str, "sy"))
		{
		  /* Y-boundaries. Check number of parameters. */
		  
		  if (j == np - 1)
		    Error(loc0, "Missing values after \"%s\"", str);
		  
		  /* Set values */
		  
		  WDB[loc0 + SRC_YMIN] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      -INFTY, INFTY);

		  WDB[loc0 + SRC_YMAX] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      -INFTY, INFTY);

		  /* Swap boundaries */

		  if (RDB[loc0 + SRC_YMAX] < RDB[loc0 + SRC_YMIN])
		    {
		      val = RDB[loc0 + SRC_YMAX];
		      WDB[loc0 + SRC_YMAX] = RDB[loc0 + SRC_YMIN];
		      WDB[loc0 + SRC_YMIN] = val;
		    }
		}
	      else if (!strcmp(str, "sz"))
		{
		  /* Z-boundaries. Check number of parameters. */
		  
		  if (j == np - 1)
		    Error(loc0, "Missing values after \"%s\"", str);
		  
		  /* Set values */
		  
		  WDB[loc0 + SRC_ZMIN] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      -INFTY, INFTY);

		  WDB[loc0 + SRC_ZMAX] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      -INFTY, INFTY);

		  /* Swap boundaries */

		  if (RDB[loc0 + SRC_ZMAX] < RDB[loc0 + SRC_ZMIN])
		    {
		      val = RDB[loc0 + SRC_ZMAX];
		      WDB[loc0 + SRC_ZMAX] = RDB[loc0 + SRC_ZMIN];
		      WDB[loc0 + SRC_ZMIN] = val;
		    }
		}
	      else if (!strcmp(str, "sp"))
		{
		  /* Point. Check number of parameters. */
		  
		  if (j == np - 2)
		    Error(loc0, "Missing values after \"%s\"", str);
		  
		  /* Set values */
		  
		  WDB[loc0 + SRC_X0] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      -INFTY, INFTY);

		  WDB[loc0 + SRC_Y0] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      -INFTY, INFTY);

		  WDB[loc0 + SRC_Z0] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL, 
			      -INFTY, INFTY);
		}
	      else if (!strcmp(str, "sd"))
		{
		  /* Direction. Check number of parameters. */
		  
		  if (j == np - 2)
		    Error(loc0, "Missing values after \"%s\"", str);
		  
		  /* Set values */
		  
		  WDB[loc0 + SRC_U0] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      -1.0, 1.0);

		  WDB[loc0 + SRC_V0] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      -1.0, 1.0);

		  WDB[loc0 + SRC_W0] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      -1.0, 1.0);
		}
	      else if (!strcmp(str, "sr"))
		{
		  /* Reaction. Check number of parameters. */
		  
		  if (j == np - 1)
		    Error(loc0, "Missing values after \"%s\"", str);
		  
		  /* Set values */
		  
		  WDB[loc0 + SRC_PTR_XSDATA] = (double)PutText(params[j++]);
		  WDB[loc0 + SRC_PTR_REA] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_INT,
			      2, 99);
		}     
	      else
		Error(loc0, "Invalid source parameter \"%s\"", str);
	    }
 	}

      /***********************************************************************/

      /***** Detector definition *********************************************/

      else if (!strcasecmp(word, "det"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 1, 100, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_DET0, DET_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Reset volume */

	  WDB[loc0 + DET_VOL] = 1.0;

	  /* Reset mesh data */

	  WDB[loc0 + DET_MESH_NX] = 1.0;
	  WDB[loc0 + DET_MESH_XMIN] = -INFTY;
	  WDB[loc0 + DET_MESH_XMAX] = INFTY;

	  WDB[loc0 + DET_MESH_NY] = 1.0;
	  WDB[loc0 + DET_MESH_YMIN] = -INFTY;
	  WDB[loc0 + DET_MESH_YMAX] = INFTY;

	  WDB[loc0 + DET_MESH_NZ] = 1.0;
	  WDB[loc0 + DET_MESH_ZMIN] = -INFTY;
	  WDB[loc0 + DET_MESH_ZMAX] = INFTY;

	  /* Read data */

	  j = 0;
	  
	  /* Detector name */
	  
	  WDB[loc0 + DET_PTR_NAME] = (double)PutText(params[j++]);
	  
	  /* Loop over remaining parameters */

	  while (j < np)
	    {
	      /* Check parameter type */

	      strcpy(str, params[j++]);
	      
	      if (!strcmp(str, "de"))
		{
		  /* Detector energy grid. Check number of parameters. */
		  
		  if (j == np)
		    Error(loc0, "Missing grid name after \"%s\"", str);
		  
		  /* Set value */
		  
		  WDB[loc0 + DET_PTR_EGRID] = (double)PutText(params[j++]);
		}
	      else if (!strcmp(str, "dv"))
		{
		  /* Detector volume */
		  
		  if (j == np)
		    Error(loc0, "Missing volume after \"%s\"", str);

		  WDB[loc0 + DET_VOL] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      0.0, INFTY);
		}
	      else if (!strcmp(str, "dx"))
		{
		  /* X-mesh */
		  
		  if (j == np)
		    Error(loc0, "Missing number of bins after \"%s\"", str);

		  WDB[loc0 + DET_MESH_NX] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_INT,
			      1, 1000000);

		  if (j == np)
		    Error(loc0, "Missing minimum dimension after\"%s\"", str);

		  WDB[loc0 + DET_MESH_XMIN] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      -INFTY, INFTY);

		  if (j == np)
		    Error(loc0, "Missing maximum dimension after\"%s\"", str);

		  WDB[loc0 + DET_MESH_XMAX] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      RDB[loc0 + DET_MESH_XMIN], INFTY);
		}
	      else if (!strcmp(str, "dy"))
		{
		  /* Y-mesh */
		  
		  if (j == np)
		    Error(loc0, "Missing number of bins after \"%s\"", str);

		  WDB[loc0 + DET_MESH_NY] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_INT,
			      1, 1000000);

		  if (j == np)
		    Error(loc0, "Missing minimum dimension after\"%s\"", str);

		  WDB[loc0 + DET_MESH_YMIN] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      -INFTY, INFTY);

		  if (j == np)
		    Error(loc0, "Missing maximum dimension after\"%s\"", str);

		  WDB[loc0 + DET_MESH_YMAX] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      RDB[loc0 + DET_MESH_YMIN], INFTY);
		}
	      else if (!strcmp(str, "dz"))
		{
		  /* Z-mesh */
		  
		  if (j == np)
		    Error(loc0, "Missing number of bins after \"%s\"", str);

		  WDB[loc0 + DET_MESH_NZ] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_INT,
			      1, 1000000);

		  if (j == np)
		    Error(loc0, "Missing minimum dimension after\"%s\"", str);

		  WDB[loc0 + DET_MESH_ZMIN] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      -INFTY, INFTY);

		  if (j == np)
		    Error(loc0, "Missing maximum dimension after\"%s\"", str);

		  WDB[loc0 + DET_MESH_ZMAX] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_REAL,
			      RDB[loc0 + DET_MESH_ZMIN], INFTY);
		}
	      else if (!strcmp(str, "dt"))
		{
		  /* Type. Check number of parameters. */
		  
		  if (j == np)
		    Error(loc0, "Missing detector type after \"%s\"", str);
		  
		  /* Set type */

		  WDB[loc0 + DET_TYPE] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_INT,
			      -3, 3);
		  
		  /* Check if divider or multiplier */

		  if (((long)RDB[loc0 + DET_TYPE] == 2) || 
		      ((long)RDB[loc0 + DET_TYPE] == 3))
		    {
		      /* Check number of parameters. */
		  
		      if (j == np)
			Error(loc0, 
			      "Missing divider or multiplier after \"%s\"", 
			      str);

		      /* Set name */

		      WDB[loc0 + DET_PTR_MUL] = (double)PutText(params[j++]);
		    }
		}
	      else if (!strcmp(str, "da"))
		{
		  /* Adjoint (muuta toi nimi) */
		  
		      /* Check number of parameters. */
		  
		  if (j == np)
		    Error(loc0, "Missing second detector after \"%s\"", str);

		  /* Set name */

		  WDB[loc0 + DET_PTR_ADJOINT] = (double)PutText(params[j++]);
		}
	      else if (!strcmp(str, "dr"))
		{
		  /* Detector reaction, allocate memory for structure */

		  loc1 = NewItem(loc0 + DET_PTR_RBINS, DET_RBIN_BLOCK_SIZE);


		  /* Read MT */

		  if (j == np)
		    Error(loc0, "Missing reaction mt after \"%s\"", str);
		  else
		    WDB[loc1 + DET_RBIN_MT] = 
		      TestParam(pname, fname, line, params[j++], PTYPE_INT,
				-9, 1000);
		  
		  /* Read material name */

		  if (j == np)
		    Error(loc0, "Missing material name after \"%s\"", str);
		  else
		    WDB[loc1 + DET_RBIN_PTR_MAT] = 
		      (double)PutText(params[j++]);
		}
	      else if (!strcmp(str, "du"))
		{
		  /* Detector universe, allocate memory for structure */

		  loc1 = NewItem(loc0 + DET_PTR_UBINS, DET_UBIN_BLOCK_SIZE);

		  /* Read universe */

		  if (j == np)
		    Error(loc0, "Missing universe after \"%s\"", str);
		  else
		    WDB[loc1 + DET_UBIN_PTR_UNI] = 
		      (double)PutText(params[j++]);
		}
	      else if (!strcmp(str, "dl"))
		{
		  /* Check previous definitions */

		  if ((long)RDB[loc0 + DET_PTR_LBINS] > VALID_PTR)
		    Error(loc0, "Multiple detector lattices not allowed");

		  /* Detector lattice, allocate memory for structure */

		  loc1 = NewItem(loc0 + DET_PTR_LBINS, DET_LBIN_BLOCK_SIZE);

		  /* Read universe */

		  if (j == np)
		    Error(loc0, "Missing lattice after \"%s\"", str);
		  else
		    WDB[loc1 + DET_LBIN_PTR_LAT] = 
		      (double)PutText(params[j++]);
		}
	      else if (!strcmp(str, "dc"))
		{
		  /* Detector cell, allocate memory for structure */

		  loc1 = NewItem(loc0 + DET_PTR_CBINS, DET_CBIN_BLOCK_SIZE);

		  /* Read cell */

		  if (j == np)
		    Error(loc0, "Missing cell after \"%s\"", str);
		  else
		    WDB[loc1 + DET_CBIN_PTR_CELL] = 
		      (double)PutText(params[j++]);
		}
	      else if (!strcmp(str, "dm"))
		{
		  /* Detector material, allocate memory for structure */

		  loc1 = NewItem(loc0 + DET_PTR_MBINS, DET_MBIN_BLOCK_SIZE);

		  /* Read material */

		  if (j == np)
		    Error(loc0, "Missing material after \"%s\"", str);
		  else
		    WDB[loc1 + DET_MBIN_PTR_MAT] = 
		      (double)PutText(params[j++]);
		}
	      else if (!strcmp(str, "ds"))
		{
		  /* Surface current detector, allocate memory for structure */

		  loc1 = NewItem(loc0 + DET_PTR_SBINS, DET_SBIN_BLOCK_SIZE);

		  /* Check mode */

		  if ((long)TestParam(pname, fname, line, params[j++], 
				      PTYPE_INT, 1, 2) == 1)
		    {
		      /* Read surface name */
		      
		      WDB[loc1 + DET_SBIN_PTR_SURF] = 
			(double)PutText(params[j++]);
		      
		      /* Reset universe pointer */

		      WDB[loc1 + DET_SBIN_PTR_UNI] = NULLPTR;
		    }
		  else
		    {
		      /* Read universe name */
		      
		      WDB[loc1 + DET_SBIN_PTR_UNI] = 
			(double)PutText(params[j++]);

		      /* Reset surface pointer */

		      WDB[loc1 + DET_SBIN_PTR_SURF] = NULLPTR;
		    }
		  
		  /* Read normal direction */

		  WDB[loc1 + DET_SBIN_SURF_NORM] = 
		    TestParam(pname, fname, line, params[j++], PTYPE_INT, 
			      -1, 1);
		}
	      else
		Error(loc0, "Invalid detector parameter \"%s\"", str);
	    }
 	}

      /***********************************************************************/

      /***** User-defined energy grid ****************************************/

      else if (!strcasecmp(word, "ene"))
	{
	  /* Copy parameter name */

	  strcpy (pname, word);

	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 3, 1000, fname);

	  /* Create new item */

	  loc0 = NewItem(DATA_PTR_ENE0, ENE_BLOCK_SIZE);

	  /* Put name, file name and line number */

	  WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	  WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	  WDB[loc0 + PARAM_LINE] = (double)line;

	  /* Read data */

	  j = 0;

	  /* Grid name */
	  
	  WDB[loc0 + ENE_PTR_NAME] = (double)PutText(params[j++]);

	  /* Get type */

	  type = TestParam(pname, fname, line, params[j++], PTYPE_INT, 1, 4);

	  /* Put type */

	  WDB[loc0 + ENE_TYPE] = (double)type;

	  /* Read data */

	  switch(type)
	    {
	    case EG_TYPE_ARB:
	      {
		/* Arbitrary grid. Get number of values */

		ne = np - j;

		/* Set number of bins */

		WDB[loc0 + ENE_NB] = (double)(ne - 1);

		/* Allocate memory for data */

		loc1 = ReallocMem(DATA_ARRAY, ne);

		/* Set pointer */

		WDB[loc0 + ENE_PTR_GRID] = (double)loc1;

		/* Read values */

		while(j < np)
		  WDB[loc1++] = TestParam(pname, fname, line, params[j++], 
					   PTYPE_REAL, 0.0, 1000.0);

		/* Break case */

		break;
	      }
	    case EG_TYPE_UNI_E:
	    case EG_TYPE_UNI_L:
	      {
		/* Uniform grid. Check number of parameters */

		if (np != 5)
		  Error(loc0, "Uniform grid %s must be defined by 5 values",
			GetText(loc0 + ENE_PTR_NAME));
		
		/* Read number of energy bins */
		
		WDB[loc0 + ENE_NB] = 
		  (double)TestParam(pname, fname, line, params[j++], PTYPE_INT,
				    1, 10000);
		
		/* Read minimum and maximum energy */
		
		WDB[loc0 + ENE_EMIN] = 
		  (double)TestParam(pname, fname, line, params[j++], 
				    PTYPE_REAL, 0.0, 1000.0);

		WDB[loc0 + ENE_EMAX] = 
		  (double)TestParam(pname, fname, line, params[j++], 
				    PTYPE_REAL, RDB[loc0 + ENE_EMIN], 1000.0);
		
		/* Break case */

		break;
	      }
	    case EG_TYPE_PREDEF:
	      {
		if (j == np)
		  Error(loc0, "Missing grid name after \"%s\"", str);

		/* Predefined grid, read name */

		WDB[loc0 + ENE_PTR_PREDEF] = (double)PutText(params[j++]);

		/* Break case */

		break;
	      }
	    default:
	      Error(loc0, "Invalid energy grid type %d", type);
	    }
 	}

      /***********************************************************************/

      /***** Misc. parameters ************************************************/

      else if (!strcasecmp(word, "set"))
	{
	  /* Read parameters */

	  np = GetParams(word, input, params, &i0, 1, 4000, fname);
	  
	  /* Reset counter */

	  j = 0;

	  /* Reset number of parameters */

	  k = -1;	  

	  /* Compare name */

	  if (!strcasecmp(params[j], "dt"))
	    {
	      /****** Delta-tracking parameters ******************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Get value */

	      val = TestParam(pname, fname, line, params[k++], PTYPE_REAL,
			      0.0, 1.0);

	      /* Probability threshold */

	      WDB[DATA_DT_THRESH] = 1.0 - val;
	      
	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "delnu"))
	    {
	      /***** Include (n,xn) multiplication in removal ****************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Mode */

	      if (k < np)
		WDB[DATA_USE_DELNU] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_LOGICAL);

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "mcvol"))
	    {
	      /****** Monte Carlo volume calculation *************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Get number of points if not given as command-line parameter */

	      if (WDB[DATA_VOLUME_MC_NMAX] < 1.0)
		WDB[DATA_VOLUME_MC_NMAX] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL,
			    10000.0, 1E+12);
	      else
		k++;

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "tle"))
	    {
	      /****** Track-length estimate of neutron flux ******************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Delta-tracking switch */
	      
	      if (k < np)
		{
		  n = TestParam(pname, fname, line, params[k++], 
				PTYPE_LOGICAL);

		  if (n == YES)
		    WDB[DATA_OPT_USE_DT] = (double)NO;
		  else
		    WDB[DATA_OPT_USE_DT] = (double)YES;
		}

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "seed"))
	    {
	      /****** Random number seed *************************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Seed */

	      if (k < np)
		{
		  /* Get value */

		  parent_seed = (unsigned long)atol(params[k++]);

		  /* Check */

		  if (parent_seed < 1)
		    Error(-1, pname, fname, line, "RNG seed must be positive");
			  		  
		  /* Write seed file */
		  
		  sprintf(str, "%s.seed", GetText(DATA_PTR_INPUT_FNAME));
		  
		  if ((fp = fopen(str, "w")) == NULL)
		    Die(FUNCTION_NAME, "Unable to open seed file for writing");

		  fprintf(fp, "%lu\n", parent_seed);
		  
		  fclose(fp);
		}

	      /* Set replay option */

	      WDB[DATA_OPTI_REPLAY] = (double)YES;

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "title"))
	    {
	      /****** Problem title ******************************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Title */

	      if (k < np)
		WDB[DATA_PTR_TITLE] = (double)PutText(params[k++]);
		
	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "acelib"))
	    {
	      /***** ACE directory file **************************************/
	      
	      /* Copy parameter name */
	      
	      strcpy (pname, params[j]);
	      
	      k = j + 1;

	      /* Allocate memory */

	      ptr = ReallocMem(DATA_ARRAY, np - k + 1);

	      /* Put pointer */

	      WDB[DATA_PTR_ACEDATA_FNAME_LIST] = (double)ptr;

	      /* Loop over values */

	      while (k < np)
		WDB[ptr++] = (double)PutText(params[k++]);

	      /* Put null pointer */

	      WDB[ptr] = NULLPTR;	      
	      
	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "declib"))
	    {
	      /***** Decay data file *****************************************/

	      /* Copy parameter name */
	      
	      strcpy (pname, params[j]);
	      
	      k = j + 1;

	      /* Allocate memory */

	      ptr = ReallocMem(DATA_ARRAY, np - k + 1);

	      /* Put pointer */

	      WDB[DATA_PTR_DECDATA_FNAME_LIST] = (double)ptr;

	      /* Loop over values */

	      while (k < np)
		WDB[ptr++] = (double)PutText(params[k++]);

	      /* Put null pointer */

	      WDB[ptr] = NULLPTR;	      
	      
	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "nfylib"))
	    {
	      /***** Neutron-induced fission yields **************************/

	      /* Copy parameter name */
	      
	      strcpy (pname, params[j]);
	      
	      k = j + 1;

	      /* Allocate memory */

	      ptr = ReallocMem(DATA_ARRAY, np - k + 1);

	      /* Put pointer */

	      WDB[DATA_PTR_NFYDATA_FNAME_LIST] = (double)ptr;

	      /* Loop over values */

	      while (k < np)
		WDB[ptr++] = (double)PutText(params[k++]);

	      /* Put null pointer */

	      WDB[ptr] = NULLPTR;	      

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "sfylib"))
	    {
	      /***** Spontaneous fission yields ******************************/


	      /* Copy parameter name */
	      
	      strcpy (pname, params[j]);
	      
	      k = j + 1;

	      /* Allocate memory */

	      ptr = ReallocMem(DATA_ARRAY, np - k + 1);

	      /* Put pointer */

	      WDB[DATA_PTR_SFYDATA_FNAME_LIST] = (double)ptr;

	      /* Loop over values */

	      while (k < np)
		WDB[ptr++] = (double)PutText(params[k++]);

	      /* Put null pointer */

	      WDB[ptr] = NULLPTR;	      

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "ibrlib"))
	    {
	      /***** Isomeric branching ratios *******************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      if (k < np)
		WDB[DATA_PTR_IBR_FNAME] = (double)PutText(params[k++]);

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "egrid"))
	    {
	      /****** Energy grid parameters *********************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Reconstruction tolerance */

	      if (k < np)
		WDB[DATA_ERG_TOL] = TestParam(pname, fname, line, params[k++],
					       PTYPE_REAL, 0.0, 0.1);
	      
	      /* Minimum energy */
	      
	      if (k < np)
		WDB[DATA_NEUTRON_EMIN] = TestParam(pname, fname, line, 
						    params[k++], PTYPE_REAL, 
						    0.0, 20.0);

	      /* Maximum energy */

	      if (k < np)
		WDB[DATA_NEUTRON_EMAX] = TestParam(pname, fname, line, 
						    params[k++], PTYPE_REAL,  
						    RDB[DATA_NEUTRON_EMIN], 
						    200.0);
	      
	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "opti"))
	    {
	      /****** Optimization mode **************************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Mode */
	     
	      if (k < np)
		WDB[DATA_OPTI_MODE] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 0, 4);
	      
	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "dop"))
	    {
	      /****** Doppler-broadening mode ********************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Mode */

	      if (k < np)
		WDB[DATA_DOPPLER_MODE] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 0, 2);
	      
	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "ures"))
	    {
	      /****** Unresolved resonance probability tables ****************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      if (k < np)
		WDB[DATA_USE_URES] =
		  TestParam(pname, fname, line, params[k++], PTYPE_LOGICAL);

	      /* Reset pointer */

	      loc0 = -1;

	      /* Loop over parameters */

	      while (k < np)
		{
		  /* Check if parameter is mode (not processed in Serpent 2) */

		  if ((strlen(params[k]) == 1) && ((*params[k] == '1') ||
						   (*params[k] == '2') ||
						   (*params[k] == '3')))
		    
		    k++;
		  
		  /* Check if parameter is nuclide */

		  else if (params[k][strlen(params[k]) - 1] == 'c')
		    {
		      /* Check pointer */

		      if (loc0 < 0)
			{
			  /* Allocate memory */
		  
			  loc0 = ReallocMem(DATA_ARRAY, np + 1);
		  
			  /* Set pointer */
		  
			  WDB[DATA_URES_PTR_USE_LIST] = (double)loc0;
			}

		      /* Read nuclide */

		      WDB[loc0++] = (double)PutText(params[k++]);
		    }
		  
		  /* Check if parameter is dilution cut-off */

		  else if ((atof(params[k]) >= 0.0) && (atof(params[k]) <= 1.0))
		    WDB[DATA_URES_DILU_CUT] = 
		      TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
				0.0, 1.0);
		    
		  /* Error */

		  else
		    Error(-1, pname, fname, line, 
			  "Given value \"%s\" is not mode, cut-off or nuclide name", params[k]);
		}

	      /* Set null pointer */

	      if (loc0 > 0)
		WDB[loc0] = NULLPTR;

	      /* Skip remaining parameters */
		  
	      k = np;

	      /* TODO: lis�� moodit, cut-offit ja muut */

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "xscalc"))
	    {
	      /***** Burnup xs mode ******************************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      if (k < np)
		{
		  n = TestParam(pname, fname, line, params[k++], PTYPE_INT, 
				1, 3);
		  if (n == 1)
		    WDB[DATA_BU_SPECTRUM_COLLAPSE] = (double)NO;
		  else if (n == 2)
		    WDB[DATA_BU_SPECTRUM_COLLAPSE] = (double)YES;
		  else
		    Error(-1, pname, fname, line, 
			  "Serpent 2 doesn't support xscalc = 3");

		  /* TODO: Toi errori ehk� warningiksi? */
		}

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "impl"))
	    {
	      /****** Implicit treatment of reaction modes *******************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Implicit capture */

	      if (k < np)
		WDB[DATA_OPT_IMPL_CAPT] =
		  TestParam(pname, fname, line, params[k++], PTYPE_LOGICAL);

	      /* Implicit (n,xn) */

	      if (k < np)
		WDB[DATA_OPT_IMPL_NXN] =
		  TestParam(pname, fname, line, params[k++], PTYPE_LOGICAL);

	      /* Implicit fission */

	      if (k < np)
		WDB[DATA_OPT_IMPL_FISS] =
		  TestParam(pname, fname, line, params[k++], PTYPE_LOGICAL);

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "dbrc"))
	    {
	      /****** Doppler-broadening rejection correction ****************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;
	      
	      /* Minimum energy */
	      
	      WDB[DATA_DBRC_EMIN] = 
		TestParam(pname, fname, line, params[k++], PTYPE_REAL,
			  1E-8, 1.0);
	      WDB[DATA_DBRC_EMAX] = 
		TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
			  RDB[DATA_DBRC_EMIN], 1.0);

	      /* Get number of isotopes */

	      ni = np - k;

	      /* Allocate memory */

	      loc0 = ReallocMem(DATA_ARRAY, ni + 1);

	      /* Set pointer */

	      WDB[DATA_PTR_DBRC] = (double)loc0;
	      
	      /* Read data */

	      for (n = 0; n < ni; n++) 
		WDB[loc0++] = (double)PutText(params[k++]);

	      /* Set null */

	      WDB[loc0] = NULLPTR;

	      /* Set flag */

	      WDB[DATA_USE_DBRC] = (double)YES;

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "bc"))
	    {
	      /****** Boundary conditions ************************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Check for single or multiple boundary conditions */

	      if ((np == 2) || (np == 3))
		{
		  /* Condition type */

		  if (k < np)
		    {
		      if (!strcasecmp(params[k], "black"))
			WDB[DATA_GEOM_BC0] = (double)BC_BLACK;
		      else if (!strcasecmp(params[k], "reflective"))
			WDB[DATA_GEOM_BC0] = (double)BC_REFLECTIVE;
		      else if (!strcasecmp(params[k], "periodic"))
			WDB[DATA_GEOM_BC0] = (double)BC_PERIODIC;
		      else
			WDB[DATA_GEOM_BC0] = 
			  TestParam(pname, fname, line, params[k], PTYPE_INT, 
				    1, 3);
		      
		      k++;
		    }
		  
		  /* Albedo */
		  
		  if (k < np)
		    WDB[DATA_GEOM_ALBEDO] = 
		      TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
				0.0, 1.0);
		  
		  /* Set partial conditions */

		  WDB[DATA_GEOM_BC1] = RDB[DATA_GEOM_BC0];
		  WDB[DATA_GEOM_BC2] = RDB[DATA_GEOM_BC0];
		  WDB[DATA_GEOM_BC3] = RDB[DATA_GEOM_BC0];
		}
	      else if ((np == 4) || (np == 5))
		{
		  /* Condition in x-direction */

		  if (k < np)
		    {
		      if (!strcasecmp(params[k], "black"))
			WDB[DATA_GEOM_BC1] = (double)BC_BLACK;
		      else if (!strcasecmp(params[k], "reflective"))
			WDB[DATA_GEOM_BC1] = (double)BC_REFLECTIVE;
		      else if (!strcasecmp(params[k], "periodic"))
			WDB[DATA_GEOM_BC1] = (double)BC_PERIODIC;
		      else
			WDB[DATA_GEOM_BC1] = 
			  TestParam(pname, fname, line, params[k], PTYPE_INT, 
				    1, 3);
		      
		      k++;
		    }
		  else
		    Error(-1, pname, fname, line, 
			  "Missing boundary condition in x-direction");

		  /* Condition in y-direction */

		  if (k < np)
		    {
		      if (!strcasecmp(params[k], "black"))
			WDB[DATA_GEOM_BC2] = (double)BC_BLACK;
		      else if (!strcasecmp(params[k], "reflective"))
			WDB[DATA_GEOM_BC2] = (double)BC_REFLECTIVE;
		      else if (!strcasecmp(params[k], "periodic"))
			WDB[DATA_GEOM_BC2] = (double)BC_PERIODIC;
		      else
			WDB[DATA_GEOM_BC2] = 
			  TestParam(pname, fname, line, params[k], PTYPE_INT, 
				    1, 3);
		      
		      k++;
		    }
		  else
		    Error(-1, pname, fname, line, 
			  "Missing boundary condition in y-direction");

		  /* Condition in z-direction */

		  if (k < np)
		    {
		      if (!strcasecmp(params[k], "black"))
			WDB[DATA_GEOM_BC3] = (double)BC_BLACK;
		      else if (!strcasecmp(params[k], "reflective"))
			WDB[DATA_GEOM_BC3] = (double)BC_REFLECTIVE;
		      else if (!strcasecmp(params[k], "periodic"))
			WDB[DATA_GEOM_BC3] = (double)BC_PERIODIC;
		      else
			WDB[DATA_GEOM_BC3] = 
			  TestParam(pname, fname, line, params[k], PTYPE_INT, 
				    1, 3);
		      
		      k++;
		    }
		  else
		    Error(-1, pname, fname, line, 
			  "Missing boundary condition in z-direction");
		  
		  /* Albedo */
		  
		  if (k < np)
		    WDB[DATA_GEOM_ALBEDO] = 
		      TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
				0.0, 1.0);

		  /* Reset common condition */

		  WDB[DATA_GEOM_BC0] = -1.0;
		}

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "usym"))
	    {
	      /***** Universe symmetry****************************************/

	      /* Copy parameter name */
	      
	      strcpy (pname, params[j]);
	      
	      k = j + 1;

	      /* Create new item */

	      loc0 = NewItem(DATA_PTR_USYM0, USYM_BLOCK_SIZE);

	      /* Put name, file name and line number */

	      WDB[loc0 + PARAM_PTR_NAME] = (double)PutText(word);
	      WDB[loc0 + PARAM_PTR_FNAME] = (double)PutText(fname);
	      WDB[loc0 + PARAM_LINE] = (double)line;
	      
	      /* Read Universe number */

	      WDB[loc0 + USYM_PTR_UNIV] =(double)PutText(params[k++]);

	      /* Read symmetry (allow quqdrant only for now) */
	      
	      WDB[loc0 + USYM_SYM] = 
		(double)TestParam(pname, fname, line, params[k++], PTYPE_INT, 
				  4, 4);

	      /* Read symmetry origin */
	      
	      if (k < np)	     
		WDB[loc0 + USYM_X0] = 
		  (double)TestParam(pname, fname, line, params[k++], 
				    PTYPE_REAL, -INFTY, INFTY);

	      if (k < np)	     
		WDB[loc0 + USYM_Y0] =
		  (double)TestParam(pname, fname, line, params[k++], 
				    PTYPE_REAL, -INFTY, INFTY);

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "xsplot"))
	    {
	      /****** Cross section data plot ********************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Resolution */

	      if (k < np)
		WDB[DATA_XSPLOT_NE] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 10, 
			    10000);

	      /* boundaries */

	      if (k < np)
		WDB[DATA_XSPLOT_EMIN] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
			    0.0, INFTY);

	      if (k < np)
		WDB[DATA_XSPLOT_EMAX] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL,  
			    RDB[DATA_XSPLOT_EMIN], INFTY);

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "nps"))
	    {
	      /****** Run parameters (source mode) **************************/

	      /* Copy parameter name */
      
	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Number of neutron histories */

	      if (k < np)
		WDB[DATA_NBATCH] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 
			    10, 100000000000);

	      /* Number of batches */

	      if (k < np)
		WDB[DATA_CYCLES] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT,
			    10, 100000000000);
	      else
		{
		  /* Set default to 200 */

		  WDB[DATA_CYCLES] = 200;
		}

	      /* Divide number of histories by batches */

	      WDB[DATA_NBATCH] = 
		(double)((long)(RDB[DATA_NBATCH]/RDB[DATA_CYCLES]));

	      /* Set number of inactive cycles to zero */

	      WDB[DATA_SKIP] = 0.0;
	      
	      /* Set source mode */

	      WDB[DATA_SIMULATION_MODE] = (double)SIMULATION_MODE_SRC;
	      
	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "pop"))
	    {
	      /****** Run parameters (criticality mode) *********************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Neutron population */

	      if (k < np)
		WDB[DATA_NBATCH] = 
		  TestParam(pname, fname, line,  params[k++], PTYPE_INT,
			    10, 100000000000);

	      /* Number of active cycles */

	      if (k < np)
		WDB[DATA_CYCLES] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 
			    1, 100000000000);

	      /* Number of inactive cycles */

	      if (k < np)
		WDB[DATA_SKIP] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 
			    1,  100000000000);

	      /* Initial guess for k-eff */

	      if (k < np)
		WDB[DATA_CYCLE_KEFF] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
			    0.5, 3.0);
	      /* Collect interval */

	      if (k < np)
		WDB[DATA_COLLECT_INTERVAL] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 
			    1, (long)RDB[DATA_CYCLES]);
	      
	      /* Set criticality mode */

	      WDB[DATA_SIMULATION_MODE] = (double)SIMULATION_MODE_CRIT;

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "nfg"))
	    {
	      /****** Few-group parameters ***********************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Number of energy groups */

	      if (k < np)
		{
		  /* Get number of groups */

		  ne = TestParam(pname, fname, line, params[k++], PTYPE_INT, 
				 2, 10000);

		  /* Set value */

		  WDB[DATA_ERG_FG_NG] = (double)ne;

		  /* Check if structure is given */
		  
		  if (np > 2)
		    {
		      /* Check number of given parameters */

		      if (ne != np - 1)
			Error(-1, pname, fname, line, 
			      "Invalid number of values in few-group structure");

		      /* Allocate memory */

		      loc0 = ReallocMem(DATA_ARRAY, ne + 1);
		      
		      /* Set pointer */
		      
		      WDB[DATA_ERG_FG_PTR_GRID] = (double)loc0;

		      /* Set first value */

		      WDB[loc0++] = 0.0;

		      /* Read boundaries */

		      for (n = 0; n < ne - 1 ; n++)
			WDB[loc0++] = 
			  TestParam(pname, fname, line, params[k++], 
				    PTYPE_REAL, 0.0, 1000.0);

		      /* Set last value */

		      WDB[loc0++] = INFTY;
		    }
		  else
		    WDB[DATA_ERG_FG_PTR_GRID] = NULLPTR;
		}

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "gcu"))
	    {
	      /***** Universes for group constant generation *****************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Check exclude mode */

	      if (atoi(params[k]) == -1)
		{
		  /* Put negative pointer */

		  WDB[DATA_PTR_GCU0] = -1.0;

		  /* Skip remaining parameters */
		  
		  k = np;
		}
	      else
		{
		  /* Get number of universes */
		  
		  ni = np - k;
		  		  
		  /* Loop over universes */
		  
		  for (n = 0; n < ni; n++) 
		    {
		      /* Allocate memory */

		      loc0 = NewItem(DATA_PTR_GCU0, GCU_BLOCK_SIZE);

		      /* Get universe */

		      WDB[loc0 + GCU_PTR_UNIV] = (double)PutText(params[k++]);
		    }
		}
	      
	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "cpd"))
	    {
	      /****** Core power distribution ********************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Depth */

	      if (k < np)
		WDB[DATA_CORE_PDE_DEPTH] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 3);

	      /* Reset Z-bins */

	      WDB[DATA_CORE_PDE_NZ] = 1.0;
	      WDB[DATA_CORE_PDE_ZMIN] = -INFTY;
	      WDB[DATA_CORE_PDE_ZMAX] = INFTY;
	      
	      /* Number of Z-bins */

	      if (k < np)
		WDB[DATA_CORE_PDE_NZ] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
			    1000);

	      /* Minimum z */

	      if (k < np)
		WDB[DATA_CORE_PDE_ZMIN] = 
		  TestParam(pname, fname, line, params[k++], 
				    PTYPE_REAL, -INFTY, INFTY);

	      /* Maximum z */

	      if (k < np)
		WDB[DATA_CORE_PDE_ZMAX] = 
		  TestParam(pname, fname, line, params[k++], 
			    PTYPE_REAL, RDB[DATA_CORE_PDE_ZMIN], INFTY);

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "sbias"))
	    {
	      /****** Source biasing *****************************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Reset mesh size */

	      nx = 5;
	      ny = 5;
	      nz = 1;

	      /* Reset dimensions */

	      xmin = -INFTY;
	      xmax = INFTY;
	      ymin = -INFTY;
	      ymax = INFTY;
	      zmin = -INFTY;
	      zmax = INFTY;

	      /* Get mode */

	      if (k < np)
		WDB[DATA_SBIAS_MODE] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 1);

	      /* Get order */

	      if (k < np)
		WDB[DATA_SBIAS_ORD] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL, 0.0, 
			    5.0);
	      
	      /* Get mesh size and dimensions */

	      if (k < np)
		nx = TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
			       1000);

	      if (k < np)
		xmin = TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
				 -INFTY, INFTY);

	      if (k < np)
		xmax = TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
				 xmin, INFTY);

	      if (k < np)
		ny = TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
			       1000);

	      if (k < np)
		ymin = TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
				 -INFTY, INFTY);

	      if (k < np)
		ymax = TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
				 ymin, INFTY);

	      if (k < np)
		nz = TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
			       1000);

	      if (k < np)
		zmin = TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
				 -INFTY, INFTY);

	      if (k < np)
		zmax = TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
				 zmin, INFTY);

	      /* Create mesh */

	      ptr = CreateMesh(MESH_TYPE_CARTESIAN, MESH_CONTENT_DATA, 
			       nx, xmin, xmax, ny, ymin, ymax, nz, zmin, zmax);
	      
	      /* Put pointer */

	      WDB[DATA_SBIAS_PTR_COL_MESH] = (double)ptr;	      

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "entr"))
	    {
	      /****** Fission source entropy *********************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Number of x bins */

	      if (k < np)
		WDB[DATA_ENTROPY_NX] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 
			    1, 1000);

	      /* Number of y bins */

	      if (k < np)
		WDB[DATA_ENTROPY_NY] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 
			    1, 1000);

	      /* Number of z bins */

	      if (k < np)
		WDB[DATA_ENTROPY_NZ] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 
			    1, 1000);
	      
	      /* Limits in x-direction */
	      
	      if (k < np)
		WDB[DATA_ENTROPY_XMIN] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
			    -INFTY, INFTY);
	      if (k < np)
		WDB[DATA_ENTROPY_XMAX] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
			    RDB[DATA_ENTROPY_XMIN], INFTY);

	      /* Limits in y-direction */
	      
	      if (k < np)
		WDB[DATA_ENTROPY_YMIN] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
			    -INFTY, INFTY);
	      if (k < np)
		WDB[DATA_ENTROPY_YMAX] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
			    RDB[DATA_ENTROPY_YMIN], INFTY);

	      /* Limits in z-direction */
	      
	      if (k < np)
		WDB[DATA_ENTROPY_ZMIN] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
			    -INFTY, INFTY);
	      if (k < np)
		WDB[DATA_ENTROPY_ZMAX] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL, 
			    RDB[DATA_ENTROPY_ZMIN], INFTY);

	      /***************************************************************/
	    }
	  else if (
		   !strcasecmp(params[j], "power") || 
		   !strcasecmp(params[j], "powdens") ||
		   !strcasecmp(params[j], "genrate") ||
		   !strcasecmp(params[j], "fissrate") ||
		   !strcasecmp(params[j], "absrate") ||
		   !strcasecmp(params[j], "lossrate") ||
		   !strcasecmp(params[j], "flux") ||
		   !strcasecmp(params[j], "sfrate") ||
		   !strcasecmp(params[j], "srcrate"))
	    {
	      /****** Normalization ******************************************/
	      
	      /* Copy parameter name */

	      strcpy (pname, params[j]);
	      
	      k = j;

	      /* Check number of parameters */

	      if (np < 2)
		Error(-1, params[j], fname, line, 
		      "Not enough parameters for normalization");

	      /* Create new block */

	      loc0 = NewItem(DATA_PTR_NORM, NORM_BLOCK_SIZE);

	      /* Reset coefficients */
	      
	      WDB[loc0 + NORM_POWER] = -1.0;
	      WDB[loc0 + NORM_POWDENS] = -1.0;
	      WDB[loc0 + NORM_GENRATE] = -1.0;
	      WDB[loc0 + NORM_FISSRATE] = -1.0;
	      WDB[loc0 + NORM_ABSRATE] = -1.0;
	      WDB[loc0 + NORM_LOSSRATE] = -1.0;
	      WDB[loc0 + NORM_FLUX] = -1.0;
	      WDB[loc0 + NORM_SRCRATE] = -1.0;
	      WDB[loc0 + NORM_SFRATE] = -1.0;

	      /* Read value */

	      val = TestParam(pname, fname, line, params[k + 1], PTYPE_REAL, 
			      -1.0, INFTY);

	      /* Check type and store value */

	      if (!strcasecmp(params[k], "power"))
		WDB[loc0 + NORM_POWER] = val;
	      else if (!strcasecmp(params[k], "powdens"))
		WDB[loc0 + NORM_POWDENS] = val;
	      else if (!strcasecmp(params[k], "flux"))
		WDB[loc0 + NORM_FLUX] = val;
	      else if (!strcasecmp(params[k], "genrate"))
		WDB[loc0 + NORM_GENRATE] = val;
	      else if (!strcasecmp(params[k], "fissrate"))
		WDB[loc0 + NORM_FISSRATE] = val;
	      else if (!strcasecmp(params[k], "absrate"))
		WDB[loc0 + NORM_ABSRATE] = val;
	      else if (!strcasecmp(params[k], "lossrate"))
		WDB[loc0 + NORM_LOSSRATE] = val;
	      else if (!strcasecmp(params[k], "srcrate"))
		WDB[loc0 + NORM_SRCRATE] = val;
	      else if (!strcasecmp(params[k], "sfrate"))
		WDB[loc0 + NORM_SFRATE] = val;
	      else
		Die(FUNCTION_NAME, "Error!");

	      k = k + 2;

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "pcc"))
	    {
	      /****** Predictor corrector method *****************************/
	      
	      /* Copy parameter name */

	      strcpy (pname, params[j]);
	      
	      k = j + 1;

	      /* Check number of parameters */

	      if (np < 2)
		Error(-1, params[j], fname, line,
		      "Predictor-corrector mode not given");
		 
	      /* Check mode */

	      if (!strcasecmp(params[k], "ce") ||  
		  !strcasecmp(params[k], "0"))
		{
		  /* CE (old "Euler's method") */

		  WDB[DATA_BURN_PRED_TYPE] = (double)PRED_TYPE_CONSTANT;
		  WDB[DATA_BURN_CORR_TYPE] = (double)CORR_TYPE_NONE;
		  WDB[DATA_BURN_PRED_NSS] = 1.0;
		  WDB[DATA_BURN_CORR_NSS] = -1.0;

		  /* Update index */

		  k++;

		  /* Check if substeps are given */

		  if (k < np)
		    Error(-1, pname, fname, line, 
			  "Sub-steps not allowed in this mode");
		}

	      else if (!strcasecmp(params[k], "celi") ||  
		       !strcasecmp(params[k], "1"))
		{
		  /* CE/LI (old "predictor-corrector method") */

		  WDB[DATA_BURN_PRED_TYPE] = (double)PRED_TYPE_CONSTANT;
		  WDB[DATA_BURN_CORR_TYPE] = (double)CORR_TYPE_LINEAR;
		  WDB[DATA_BURN_PRED_NSS] = 1.0;
		  WDB[DATA_BURN_CORR_NSS] = 1.0;

		  /* Update index */

		  k++;

		  /* number of corrector substeps */
	      
		  if (k < np)
		    WDB[DATA_BURN_CORR_NSS] = 
		      TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
				1000);

		  /* Check number of entries */

		  if (k < np)
		    Error(-1, pname, fname, line, 
			  "Second sub-step entry not allowed");
		}

	      else if (!strcasecmp(params[k], "le") ||  
		       !strcasecmp(params[k], "2"))
		{
		  /* LE */

		  WDB[DATA_BURN_PRED_TYPE] = (double)PRED_TYPE_LINEAR;
		  WDB[DATA_BURN_CORR_TYPE] = (double)CORR_TYPE_NONE;
		  WDB[DATA_BURN_PRED_NSS] = 1.0;
		  WDB[DATA_BURN_CORR_NSS] = -1.0;

		  /* Update index */
		  
		  k++;

		  /* number of predictor substeps */
	      
		  if (k < np)
		    WDB[DATA_BURN_PRED_NSS] = 
		      TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
				1000);

		  /* Check number of entries */

		  if (k < np)
		    Error(-1, pname, fname, line, 
			  "Second sub-step entry not allowed");
		}

	      else if (!strcasecmp(params[k], "leli") ||  
		       !strcasecmp(params[k], "3"))
		{
		  /* LE/LI */

		  WDB[DATA_BURN_PRED_TYPE] = (double)PRED_TYPE_LINEAR;
		  WDB[DATA_BURN_CORR_TYPE] = (double)CORR_TYPE_LINEAR;
		  WDB[DATA_BURN_PRED_NSS] = 1.0;
		  WDB[DATA_BURN_CORR_NSS] = 1.0;
		  
		  /* Update index */
		  
		  k++;

		  /* number of predictor substeps */
	      
		  if (k < np)
		    WDB[DATA_BURN_PRED_NSS] = 
		      TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
				1000);

		  /* number of corrector substeps */
	      
		  if (k < np)
		    WDB[DATA_BURN_CORR_NSS] = 
		      TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
				1000);
		}

	      else if (!strcasecmp(params[k], "leqi") ||  
		       !strcasecmp(params[k], "4"))
		{
		  /* LE/QI */
		  
		  WDB[DATA_BURN_PRED_TYPE] = (double)PRED_TYPE_LINEAR;
		  WDB[DATA_BURN_CORR_TYPE] = (double)CORR_TYPE_QUADRATIC;
		  WDB[DATA_BURN_PRED_NSS] = 1.0;
		  WDB[DATA_BURN_CORR_NSS] = 1.0;
		  
		  /* Update index */
		  
		  k++;

		  /* number of predictor substeps */
	      
		  if (k < np)
		    WDB[DATA_BURN_PRED_NSS] = 
		      TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
				1000);

		  /* number of corrector substeps */
	      
		  if (k < np)
		    WDB[DATA_BURN_CORR_NSS] = 
		      TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
				1000);
		}

	      else if (!strcasecmp(params[k], "5"))
		{
		  /* Custom mode, update index */
		  
		  k++;

		  /* Read predictor interpolation */

                  val = TestParam(pname, fname, line, params[k++], PTYPE_INT,
                                  0, 1);

                  if (val == 0)
                    WDB[DATA_BURN_PRED_TYPE] = (double)PRED_TYPE_CONSTANT;
                  else
                    WDB[DATA_BURN_PRED_TYPE] = (double)PRED_TYPE_LINEAR;
		  
		  /* interpolation order on corrector */
              
		  if (k < np)
		    {
		      val = TestParam(pname, fname, line, params[k++], 
				      PTYPE_INT, 1, 2);
		  
		      if(val == 1)
			WDB[DATA_BURN_CORR_TYPE] = (double)CORR_TYPE_LINEAR;
		      else 
			WDB[DATA_BURN_CORR_TYPE] = 
			  (double)CORR_TYPE_QUADRATIC;
		    }

		  /* number of predictor substeps */
	      
		  if (k < np)
		    WDB[DATA_BURN_PRED_NSS] = 
		      TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
				1000);

		  /* Number of corrector substeps */
		  
		  if (k < np)
		    WDB[DATA_BURN_CORR_NSS] = 
		      TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 
				1000);
		}
	      else
		Error(-1, pname, fname, line, 
		      "Invalid predictor-corrector mode %s", params[k]);
	    
	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "inventory"))
	    {
	      /****** Output for burnup calculation **************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Get number of isotopes */

	      ni = np - k;

	      /* Read data */
	      
	      for (n = 0; n < ni; n++) 
		{
		  /* Create new block */
		  
		  loc0 = NewItem(DATA_BURN_PTR_INVENTORY, 
				 INVENTORY_BLOCK_SIZE);
		  WDB[loc0 + INVENTORY_PTR_NAME] 
		    = (double)PutText(params[k++]);
		}

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "his"))
	    {
	      /***** Output file control *************************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Print history file */
	      
	      if (k < np)
		WDB[DATA_OPTI_PRINT_HIS] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_LOGICAL);

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "fpcut"))
	    {
	      /***** Fission product yield cut-off ***************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Get limit */

	      if (k < np)
		WDB[DATA_DEP_FP_YIELD_CUTOFF] =
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL,  0.0, 
			    2.0);

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "printm"))
	    {
	      /***** Print compositions flag *********************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      if (k < np)
		WDB[DATA_BURN_PRINT_COMP] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_LOGICAL);

	      /* Limit */

	      if (k < np)
		WDB[DATA_BURN_PRINT_COMP_LIM] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL, 0.0, 
			    1.0);

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "depmtx"))
	    {
	      /***** Print burnup matrix flag ********************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      if (k < np)
		WDB[DATA_BURN_PRINT_DEPMTX] =
		  TestParam(pname, fname, line, params[k++], PTYPE_LOGICAL); 

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "fum"))
	    {
	      /****** B1 Critical spectrum calculation ***********************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Energy grid name */

	      if (k < np)
		WDB[DATA_PTR_FUM] = (double)PutText(params[k++]);
		
	      /* Set fum-option */

	      WDB[DATA_OPTI_FUM_CALC] = (double)YES;

	      /***************************************************************/
	    }
	  	  else if (!strcasecmp(params[j], "bumode"))
	    {
	      /***** Burnup calculation mode *********************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Read mode */

	      if (!strcasecmp(params[k], "tta"))
		WDB[DATA_BURN_BUMODE] = (double)BUMODE_TTA;
	      else if (!strcasecmp(params[k], "cram"))
		WDB[DATA_BURN_BUMODE] = (double)BUMODE_CRAM;
	      else 
		{
		  /* Read mode */

		  WDB[DATA_BURN_BUMODE] = 
		    TestParam(pname, fname, line, params[k], PTYPE_INT, 1, 3);
		  
		  /* Convert mode 3 to 1 for compatibility with Serpent 1 */

		  if (RDB[DATA_BURN_BUMODE] == 3.0)
		    WDB[DATA_BURN_BUMODE] = (double)BUMODE_TTA;
		}
	      
	      /* Update index */

	      k++;

	      /* Check if cram order is given */		  
	      
	      if (k < np)
		{
		  /* Check mode */

		  if ((long)RDB[DATA_BURN_BUMODE] == BUMODE_CRAM)
		    {
		      /* Get order */
		      
		      n = TestParam(pname, fname, line, params[k++], PTYPE_INT, 
				    2, 16);

		      /* Check */
		      
		      if (n % 2)
			Error(0, "Invalid CRAM order must be divisible by 2");
		      else
			WDB[DATA_BURN_CRAM_K] = (double)n;
		    }
		}
		  	      
	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "ttacut"))
	    {
	      /***** TTA cut-off *********************************************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Get limit */

	      if (k < np)
		WDB[DATA_DEP_TTA_CUTOFF] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_REAL, 0.0, 
			    1.0);

	      /***************************************************************/
	    }
	  else if (!strcasecmp(params[j], "bunorm"))
	    {
	      /***** Normalization in burnup calculation *********************/

	      /* Copy parameter name */

	      strcpy (pname, params[j]);

	      k = j + 1;

	      /* Mode */

	      if (k < np)
		WDB[DATA_NORM_BURN] = 
		  TestParam(pname, fname, line, params[k++], PTYPE_INT, 1, 3);

	      /***************************************************************/
	    }
	  else
	    {
	      /* NOTE: kaikkia parametreja ei lueta --> aseta k = np */
	      /*       jotta ajo ei kaadu alla olevaan testaukseen.  */

	      k = np;
	    }

	  /* Check number of parameters */
	  
	  if (k != np)
	    Error(-1, params[j], fname, line, "Invalid number of parameters");
	}
    }
  
  /**************************************************************************/

  /* Free memory */
  
  Mem(MEM_FREE, input);
  
  for (i = 0; i < MAX_INPUT_PARAMS; i++)
    Mem(MEM_FREE, params[i]);
}

/*****************************************************************************/
