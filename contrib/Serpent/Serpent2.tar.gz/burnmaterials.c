/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : burnmateriala.c                                */
/*                                                                           */
/* Created:       2011/05/22 (JLe)                                           */
/* Last modified: 2012/02/01 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Performs burnup calculation for materials                    */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "BurnMaterials:"

/* Use local function to simplify OpenMP implementation */

void BurnMaterials0(long, long, long);

/*****************************************************************************/

void BurnMaterials(long dep, long step)
{
  long mat, nss, type, count;

  /***************************************************************************/

  /***** Get parameters ******************************************************/
  /* Get the number of substeps. Constant extrapolation is forced to one */
  /* substep (no point using more) */ 
  
  if ( (long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP )
    {
      if ((long)RDB[DATA_BURN_FIT_TYPE] == PRED_TYPE_CONSTANT)
	nss = 1;
      else
	nss = (long)RDB[DATA_BURN_PRED_NSS];
    }
  else
    nss = (long)RDB[DATA_BURN_CORR_NSS];
    
  /* Get step type */
  
  type = (long)RDB[dep + DEP_HIS_STEP_TYPE];

  /***************************************************************************/

  /***** Print output ********************************************************/

  fprintf(out, "Running burnup calculation:\n\n");

  fprintf(out, " - Step %ld / %ld ", (long)RDB[DATA_BURN_STEP] + 1, 
	  (long)RDB[DATA_BURN_TOT_STEPS] + 1);
	  
  if (((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_NONE) ||
      ((long)RDB[dep + DEP_HIS_STEP_TYPE] == DEP_STEP_DEC_TOT) ||
      ((long)RDB[dep + DEP_HIS_STEP_TYPE] == DEP_STEP_DEC_STEP))
    fprintf(out, "\n");
  else if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
    fprintf(out, "(predictor)\n");
  else
    fprintf(out, "(corrector)\n");

  if (((long)RDB[dep + DEP_HIS_STEP_TYPE] != DEP_STEP_DEC_TOT) &&
      ((long)RDB[dep + DEP_HIS_STEP_TYPE] != DEP_STEP_DEC_STEP))
    {
      fprintf(out, " - Algorithm: ");

      if ((long)RDB[DATA_BURN_PRED_TYPE] == PRED_TYPE_CONSTANT)
	fprintf(out, "CE");
      else
	fprintf(out, "LE");
      
      if ((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_LINEAR)
	fprintf(out, "/LI\n");
      else if ((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_QUADRATIC)
	fprintf(out, "/QI\n");
      else
	fprintf(out, "\n");
    }

  fprintf(out, " - Time interval: %s\n", 
	  TimeIntervalStr(RDB[DATA_BURN_TIME_INTERVAL]));
  fprintf(out, " - Burnup interval: %1.2f MWd/kgU\n", 
	  RDB[DATA_BURN_BURNUP_INTERVAL]);

  fprintf(out, " - Cumulative burn time after step: %s\n", 
	  TimeIntervalStr((long)RDB[DATA_BURN_CUM_BURNTIME]));
  fprintf(out, " - Cumulative burnup after step: %1.2f MWd/kgU\n", 
	  RDB[DATA_BURN_CUM_BURNUP]);

  if (nss > 1)
    fprintf(out, " - Interval divided into %ld substeps\n", nss);

  if ((type == DEP_STEP_DEC_STEP) || (type == DEP_STEP_DEC_TOT))
    fprintf(out, 
	    " - Decay step, transmutation cross sections not calculated\n");
  else if ((long)RDB[DATA_BU_SPECTRUM_COLLAPSE] == YES)
    fprintf(out, " - Transmutation cross sections from spectrum\n");
  else
    fprintf(out, " - Transmutation cross sections from direct tallies\n");
  
  /***************************************************************************/

  /***** Main loop ***********************************************************/

  /* Reduce private results */

  ReducePrivateRes();

  /* Reset thread numbers */
  
  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check thread number */
      
      WDB[mat + MATERIAL_OMP_ID] = -1.0;

      /* Next material */
      
      mat = NextItem(mat);
    }	  

  /* Reset counter */

  count = 0;

  fprintf(out, "\nBurning materials:\n\n");

  /* Start parallel timer */

  StartTimer(TIMER_OMP_PARA);

#ifdef OPEN_MP
#pragma omp parallel private (mat)
#endif
  {
    /* Loop over materials */
    
    mat = (long)RDB[DATA_PTR_M0];
    while (mat > VALID_PTR)
      {
	/* Check burn flag and MPI id number */

	if (((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT) &&
	    ((long)RDB[mat + MATERIAL_MPI_ID] == mpiid))
	  {
#ifdef OPEN_MP
#pragma omp critical
#endif
	    {
	      /* Grab material */
	      
	      if ((long)RDB[mat + MATERIAL_OMP_ID] == -1)
		WDB[mat + MATERIAL_OMP_ID] = OMP_THREAD_NUM;
	    }
	    
	    /* Check thread number */
	    
	    if ((long)RDB[mat + MATERIAL_OMP_ID] == OMP_THREAD_NUM)
	      {
		/* Print */

		if (OMP_THREAD_NUM == 0)
		  if (count < (long)RDB[DATA_MATERIALS_THREAD0])
		    fprintf(out, " %3.0f%% complete\n", 
			    100.0*(count++)/RDB[DATA_MATERIALS_THREAD0]);
		
		/* Burn */
		
		BurnMaterials0(mat, step, nss);	
	      }
	  }
	
	/* Next material */
	
	mat = NextItem(mat);
      }
  }

  /* Stop parallel timer */

  StopTimer(TIMER_OMP_PARA);

  /* Done */

  fprintf(out, " 100%% complete\n\n"); 

  /***************************************************************************/
}

/*****************************************************************************/

/*****************************************************************************/

void BurnMaterials0(long mat, long step, long nss)
{
  long iso, ptr, lst, i, sz, ss, id;
  double t, t1, t2, tot, *N, *N0; 
  struct ccsMatrix *A; 

  /* Avoid compiler warning */

  A = NULL; 
  N = NULL; 
  N0 = NULL;

  /* Get OpenMP id */

  id = OMP_THREAD_NUM;

  /* Get time step length */
      
  t = RDB[DATA_BURN_TIME_INTERVAL];
  CheckValue(FUNCTION_NAME, "t", "", t, ZERO, INFTY);
  
  /* Calculate transmutation cross sections */

  CalculateTransmuXS(mat, id);

  /* Store the xs from above */
  
  StoreTransmuXS(mat, step, id);

  /* Size of composition vector */
  
  ptr = (long)RDB[mat + MATERIAL_PTR_COMP];
  sz = ListSize(ptr);
  
  /* Allocate memory for composition vectors */
  
  N0 = (double *)Mem(MEM_ALLOC, sz, sizeof(double));
  
  /* Copy composition to N0. On predictor also store it for corrector */
  
  i = 0;
  lst = (long)RDB[mat + MATERIAL_PTR_COMP];
  
  if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
    {
      /* Predictor step, copy composition to N0 and BOS for corrector */
      
      while ((iso = ListPtr(lst, i)) > VALID_PTR)
	{
	  WDB[iso + COMPOSITION_ADENS_BOS] = 
	    RDB[iso + COMPOSITION_ADENS];
	  N0[i++] = RDB[iso + COMPOSITION_ADENS_BOS];
	}
    }
  else
    {
      /* Correcor step, copy composition from BOS to N0 */
      
      while ((iso = ListPtr(lst, i)) > VALID_PTR)
	N0[i++] = RDB[iso + COMPOSITION_ADENS_BOS];
    }
  
  /* Check size */
  
  if (i != sz)
    Die(FUNCTION_NAME, "Mismatch in size");
  
  /***************************************************************************/

  /***** Loop over substeps **************************************************/

  for (ss = 0; ss < nss; ss++)
    {          
      /* substep beginning and end times */
      
      t1 = t*ss/nss;
      t2 = t*(ss + 1)/nss;
      
      /* calculate weighted xs and flux */

      AverageTransmuXS(mat, t1, t2, id);

      /* Create burnup matrix */
      
      A = MakeBurnMatrix(mat, id);

      /* Check size (sz == i tarkistettiin jo aikaisemmin) */
      
      if (sz != A->n)
	Die(FUNCTION_NAME, "Mismatch in size");
      
      /* Print depletion matrix */
      
      PrintDepMatrix(mat, A, t2 - t1, N0, N0, id);

      /* Calculate material-wise burnup */
      
      MaterialBurnup(mat, N0, t2 - t1, id);

      /* Start burnup equation timers */
      
      ResetTimer(TIMER_BATEMAN);
      StartTimer(TIMER_BATEMAN);
      StartTimer(TIMER_BATEMAN_TOTAL);
      
      /* Solve depletion equations */
      
      if ((long)RDB[DATA_BURN_BUMODE] == BUMODE_TTA)
	N = TTA(A, N0, t2 - t1);
      else if ((long)RDB[DATA_BURN_BUMODE] == BUMODE_CRAM)
	N = MatrixExponential(A, N0, t2 - t1); 
      else
	Die(FUNCTION_NAME, "Invalid burnup mode");

      /* Stop timers */
      
      StopTimer(TIMER_BATEMAN);
      StopTimer(TIMER_BATEMAN_TOTAL);
      
      /* Print depletion matrix with final composition */
      
      PrintDepMatrix(mat, A, t2 - t1, N0, N, id); 
      
      /* Free burnup matrix and N0 (which is no longer needed)*/
      
      ccsMatrixFree(A);
      Mem(MEM_FREE, N0); 
      
      /* the final composition becomes initial for the next substep */
      
      N0 = N;
    } 
  
  /***************************************************************************/
      
  /***** Put final composition ***********************************************/
  
  /* Reset index and total atomic density */
      
  i = 0;
  tot = 0.0;
  
  /* Update composition */
  
  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
  while (iso > VALID_PTR)
    {
      /* Put atomic density */
      
      WDB[iso + COMPOSITION_ADENS] = N[i++];    
      
      /* Add to total */
      
      tot = tot + RDB[iso + COMPOSITION_ADENS]; 
      
      /* Next nuclide */
      
      iso = NextItem(iso);                       
    }
  
  /* Put total atomic density */
  
  WDB[mat + MATERIAL_ADENS] = tot;
  
  /* Free composition vectors (at this point N = N0) */
  
  Mem(MEM_FREE, N); 
}

/*****************************************************************************/
