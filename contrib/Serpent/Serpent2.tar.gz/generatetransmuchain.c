/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : generatetransmuchain.c                         */
/*                                                                           */
/* Created:       2010/09/11 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Recursive routine to generate decay and transmutation paths  */
/*              for nuclides.                                                */
/*                                                                           */
/* Comments: - Tossa pitäis vielä tarkistaa ettei reaktiota jonka pointteri  */
/*             on asetettu käydä enää uudestaan läpi. Ehkä ne vois jättää    */
/*             kokonaan asettamatta tässä ja hakea vasta sitten kun kaikki   */
/*             nuklidit on generoitu siinä cleanup-jutussa (muuta nimi)      */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "GenerateTransmuChain:"

/*****************************************************************************/

void GenerateTransmuChain(long nuc, char *lib, double T, long type, long count)
{
  long rea, ZAI, new, add, mt, tp;
  double Emin;

  /* Check pointer */

  if (nuc < VALID_PTR)
    Die(FUNCTION_NAME, "Pointer error");

  /* Check if type is switched to decay and nuclide is already processed */
  
  if ((type == NUCLIDE_TYPE_DECAY) &&
      ((long)RDB[nuc + NUCLIDE_OPTIONS] & OPT_USED))
    return;
  else
    SetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);

  /* Switch to decay type if sufficiently far from parent */

  if (count > 10)
    type = NUCLIDE_TYPE_DECAY;

  /* Loop over reactions */

  rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
  while (rea > 0)
    {
      /* Get reaction mt */

      mt = (long)RDB[rea + REACTION_MT];

      /* Get target ZAI */

      ZAI = ReactionTargetZAI(rea);

      /* Check */

      if (ZAI == (long)RDB[nuc + NUCLIDE_ZAI])
	Die(FUNCTION_NAME, "%s -> %ld (mt %ld)", 
	    GetText(nuc + NUCLIDE_PTR_NAME), ZAI, mt);

      /* Set value */

      WDB[rea + REACTION_TGT_ZAI] = (double)ZAI;
      
      /* Check ZAI */
      
      if (ZAI > 0)
	{
	  /***** Decay or transmutation reaction *****************************/
	  
	  /* Get minimum energy */

	  Emin = RDB[rea + REACTION_EMIN];
	  
	  /* Check energy cut-off */
      
	  if ((Emin > RDB[DATA_NEUTRON_EMAX]) || 
	      (Emin > RDB[DATA_BURN_ENECUT]))
	    {
	      /* Reset target ZAI */

	      WDB[rea + REACTION_TGT_ZAI] = 0.0;

	      /* Pointer to next reaction */

	      rea = NextItem(rea);

	      /* Cycle loop */

	      continue;
	    }

	  /* Add to count */

	  if ((ZAI > 900000) && ((mt == 102) || (mt == 10001)))
	    {
	      /* Actinide neutron capture and beta decay */

	      add = 1;
	    }
	  else if ((ZAI > 900000) && (mt == 16))
	    {
	      /* Actinide (n,2n) */

	      add = 5;
	    }
	  else if ((ZAI > 900000) && (mt < 10000))
	    {
	      /* Other actinide transmutation reactions */

	      add = 10;
	    }
	  else if (mt < 10000)
	    {
	      /* Other transmutation reactions */

	      add = 5;
	    }
	  else if (ZAI > 900000)
	    {
	      /* Actinide decay */

	      add = 2;
	    }
	  else
	    {
	      /* Other decay */

	      add = 5;
	    }
	  
	  /* Create nuclide (if not found, retry with decay data) */

	  if ((new = AddNuclide(NULL, ZAI, lib, T, type)) < 0)
	    Die(FUNCTION_NAME, "new < 0");
	  else if (new == 0)
	    new = AddNuclide(NULL, ZAI, lib, T, NUCLIDE_TYPE_DECAY);
	  
	  /* Check if found */

	  if (new > 0)
	    {
	      /* Get reaction type */
	      
	      tp = (long)RDB[rea + REACTION_TYPE];

	      /* Set AP, DP or BP flag */

	      if (tp == REACTION_TYPE_DECAY)
		SetOption(new + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_DP);
	      else if (tp == REACTION_TYPE_PARTIAL)
		SetOption(new + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_AP);
	      else if (tp == REACTION_TYPE_DEC_BRANCH)
		{
		  SetOption(new + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_DP);
		  SetOption(new + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_BP);
		}
	      else if (tp == REACTION_TYPE_TRA_BRANCH)
		{
		  SetOption(new + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_AP);
		  SetOption(new + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_BP);
		}
	      else
		Die(FUNCTION_NAME, "Invalid type %ld (%s mt %ld)", tp, 
		    GetText(nuc + NUCLIDE_PTR_NAME), mt);

	      /* Call recursively */
	      
	      GenerateTransmuChain(new, lib, T, type, count + add);
	    }
	  else if (new < 0)
	    Die(FUNCTION_NAME, "new < 0");

	  /*******************************************************************/
	}

      /* Next reaction */

      rea = NextItem(rea);
    }
}

/*****************************************************************************/
