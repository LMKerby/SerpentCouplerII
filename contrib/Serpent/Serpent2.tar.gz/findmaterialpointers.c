/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : findmaterialpointers.c                         */
/*                                                                           */
/* Created:       2010/10/06 (JLe)                                           */
/* Last modified: 2012/02/01 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Finds material pointers for cells, nests and detectors       */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "FindMaterialPointers:"

/*****************************************************************************/

void FindMaterialPointers()
{
  long cell, nst, mix, mat, ptr, reg, n;

  /* Check that materials are defined */

  if ((long)RDB[DATA_PTR_M0] < VALID_PTR)
    Error(0, "No material definitions in geometry");

  /**************************************************************************/

  /***** Cells **************************************************************/

  /* Loop over nests */

  cell = RDB[DATA_PTR_C0];
  while (cell > VALID_PTR)
    {
      /* Check if material is defined */
      
      if ((long)RDB[cell + CELL_PTR_MAT] < VALID_PTR)
	{
	  /* Check fill pointer */

	  if ((long)RDB[cell + CELL_PTR_FILL] < VALID_PTR)
	    Die(FUNCTION_NAME, "Pointer error");

	  /* Set type */
	  
	  WDB[cell + CELL_TYPE] = (double)CELL_TYPE_FILL;

	  /* Put null pointer */
	  
	  WDB[cell + CELL_PTR_MAT] = NULLPTR;
	}
      else if (!strcmp(GetText(cell + CELL_PTR_MAT), "void"))
	{
	  /* Void cell, put null pointer */
	  
	  WDB[cell + CELL_PTR_MAT] = NULLPTR;

	  /* Set type */
	  
	  WDB[cell + CELL_TYPE] = CELL_TYPE_VOID;
	}
      else if (!strcmp(GetText(cell + CELL_PTR_MAT), "outside"))
	{
	  /* Outside cell, put null pointer */
	  
	  WDB[cell + CELL_PTR_MAT] = NULLPTR;

	  /* Set type */
	  
	  WDB[cell + CELL_TYPE] = CELL_TYPE_OUTSIDE;
	}
      else
	{
	  /* Set type */
	  
	  WDB[cell + CELL_TYPE] = CELL_TYPE_MAT;

	  /* Find material */

	  mat = RDB[DATA_PTR_M0];
	  if ((mat = SeekListStr(mat, MATERIAL_PTR_NAME, 
				 GetText(cell + CELL_PTR_MAT))) > VALID_PTR)
	    {
	      /* Put pointer */
		  
	      WDB[cell + CELL_PTR_MAT] = (double)mat;
		  
	      /* Set used- and physical-flags */

	      SetOption(mat + MATERIAL_OPTIONS, OPT_USED);
	      SetOption(mat + MATERIAL_OPTIONS, OPT_PHYSICAL_MAT);
	    }
	  else
	    Error(cell, "Material %s is not defined", 
		  GetText(cell + CELL_PTR_MAT));
	}

      /* Next */

      cell = NextItem(cell);
    }

  /**************************************************************************/

  /***** Nests **************************************************************/

  /* Loop over nests */

  nst = RDB[DATA_PTR_NST0];
  while (nst > VALID_PTR)
    {
      /* Get pointer to regions */
	      
      if ((ptr = (long)RDB[nst + NEST_PTR_REGIONS]) < VALID_PTR)
	Die(FUNCTION_NAME, "Pointer error");
	      
      /* Loop over regions */ 
      
      n = 0;
      while ((reg = ListPtr(ptr, n++)) > VALID_PTR)
	if ((long)RDB[reg + NEST_REG_PTR_MAT] > 0)
	  {
	    /* Check if material is defined (NOTE: Tässä on jotain häröä) */
      
	    if ((long)RDB[reg + NEST_REG_PTR_MAT] < 1)
	      {
		/* Check fill pointer */
		
		if ((long)RDB[reg + NEST_REG_PTR_FILL] < 1)
		  Die(FUNCTION_NAME, "Pointer error");
		
		/* Put null pointer */
		
		WDB[reg + NEST_REG_PTR_MAT] = NULLPTR;
	      }
	    else if ((!strcmp(GetText(reg + NEST_REG_PTR_MAT), "void")) ||
		     (!strcmp(GetText(reg + NEST_REG_PTR_MAT), "outside")))
	      {
		/* Void or outside region, put null pointer */

		WDB[reg + NEST_REG_PTR_MAT] = NULLPTR;
	      }
	    else
	      {
		/* Find material */

		mat = RDB[DATA_PTR_M0];
		if ((mat = SeekListStr(mat, MATERIAL_PTR_NAME, 
				       GetText(reg + NEST_REG_PTR_MAT)))
		    > VALID_PTR)
		  {
		    /* Put pointer */
			
		    WDB[reg + NEST_REG_PTR_MAT] = (double)mat;
			
		    /* Set used- and physical-flags */
		    
		    SetOption(mat + MATERIAL_OPTIONS, OPT_USED);
		    SetOption(mat + MATERIAL_OPTIONS, OPT_PHYSICAL_MAT);
		  }
		else
		  Error(nst, "Material %s is not defined", 
			GetText(reg + NEST_REG_PTR_MAT));
	      }
	  }
      
      /* Next */

      nst = NextItem(nst);
    }

  /**************************************************************************/

  /***** Mixtures ***********************************************************/

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Use all materials if no cells are defined (needed for testing) */

      if ((long)RDB[DATA_PTR_C0] < VALID_PTR)
	{		    
	  SetOption(mat + MATERIAL_OPTIONS, OPT_USED);
	  SetOption(mat + MATERIAL_OPTIONS, OPT_PHYSICAL_MAT);
	}

      /* Check used-flag */
      
      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_USED)
	{
	  /* Loop over mixture */

	  mix = (long)RDB[mat + MATERIAL_PTR_MIX];

	  while (mix > VALID_PTR)
	    {
	      /* Find material */
	      
	      ptr = (long)RDB[DATA_PTR_M0];
	      if ((ptr = SeekListStr(ptr, MATERIAL_PTR_NAME, 
				     GetText(mix + MIXTURE_PTR_MAT))) 
		  > VALID_PTR)
		{
		  /* Put pointer */
		  
		  WDB[mix + MIXTURE_PTR_MAT] = (double)ptr;
		  
		  /* Set used- and physical-flags */
		  
		  SetOption(ptr + MATERIAL_OPTIONS, OPT_USED);
		  SetOption(ptr + MATERIAL_OPTIONS, OPT_PHYSICAL_MAT);
		}
	      else
		Error(mat, "Material %s is not defined", 
		      GetText(mix + MIXTURE_PTR_MAT));
	      
	      /* Next */
	      
	      mix = NextItem(mix);
	    }
	}

      /* Next material */

      mat = NextItem(mat);
    }

  /**************************************************************************/
}

/*****************************************************************************/
