/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : readphotondata.c                               */
/*                                                                           */
/* Created:       2011/04/07 (JLe)                                           */
/* Last modified: 2012/01/27 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Reads photon cross sections for materials                    */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ReadPhotonData:"

/*****************************************************************************/

void ReadPhotonData()
{
  long elem[110], nuc, n;

  /* Reset element array */

  for (n = 0; n < 110; n++)
    elem[n] = 0;

  /* Reset counter */

  n = 0;

  /* Loop over nuclides */

  nuc = (long)RDB[DATA_PTR_NUC0];
  while (nuc > VALID_PTR)
    {
      /* Set element index */

      if ((long)RDB[nuc + NUCLIDE_TYPE] != NUCLIDE_TYPE_PHOTON)
	elem[(long)RDB[nuc + NUCLIDE_Z]]++;

      /* Add counter */

      n++;

      /* Next nuclide */

      nuc = NextItem(nuc);
    }

  /* Check count */

  if (n == 0)
    return;
 
  fprintf(out, "\nAdding photon interaction data...\n\n");

  /* Loop over element array */

  for (n = 0; n < 110; n++)
    if (elem[n] > 0)
      {
	/* Find nuclide in data */

	if ((nuc = AddNuclide(NULL, n*10000, NULL, 0.0, NUCLIDE_TYPE_PHOTON))
	    > VALID_PTR)
	  {
	    /* Set used- and initial-flags */

	    SetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);
	    SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_INITIAL);
	  }
      }
}

/*****************************************************************************/
