/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : findtargetnuclides.c                           */
/*                                                                           */
/* Created:       2010/09/12 (JLe)                                           */
/* Last modified: 2012/02/01 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Finds target nuclides recursively for reaction channels      */
/*              and sets used-flags to enable final cleanup.                 */
/*                                                                           */
/* Comments: - Library id:n haun pitää ehkä olla tuolla silmukan sisällä     */
/*             kun funktiota kutsutaan rekursiivisesti ja myöhemmät kutsut   */
/*             voi kirjoittaa sen päälle?                                    */
/*                                                                           */
/*           - Kun U-235:n ja -238:n fission yieldejä käytetään nuklideille  */
/*             joiden omia yieldejä ei näy niin tossa etsinnässä tehdään     */
/*             paljon turhaa työtä --> kopio data instead.                   */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "FindTargetNuclides:"

/*****************************************************************************/

void FindTargetNuclides(long nuc)
{
  long rea, ZAI, Z, A, new, loc0, yld, n, mt;
  double T;
  static char lib[MAX_STR];

  /* Check flag */

  if ((long)RDB[nuc + NUCLIDE_OPTIONS] & OPT_USED)
    return;
  else
    SetOption(nuc + NUCLIDE_OPTIONS, OPT_USED);

  /* Set depletion flag */
  
  SetOption(nuc + NUCLIDE_TYPE_FLAGS, NUCLIDE_FLAG_DEP);

  /* Print */

  if ((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT)
    fprintf(out, "Nuclide %10s...\n", GetText(nuc + NUCLIDE_PTR_NAME));
	    
  /* Perform some additional checks */
  
  if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_TRANSPORT) &&
      ((long)RDB[nuc + NUCLIDE_N_TRANSPORT_REA] == 0))
    Die(FUNCTION_NAME, "Transport nuclide %s has no transport data",
	GetText(nuc + NUCLIDE_PTR_NAME));
  else if (((long)RDB[nuc + NUCLIDE_TYPE] == NUCLIDE_TYPE_DECAY) &&
	   ((long)RDB[nuc + NUCLIDE_N_TRANSPORT_REA] != 0))
    Die(FUNCTION_NAME, "Decay nuclide %s has transport data",
	GetText(nuc + NUCLIDE_PTR_NAME));
  
  /* Get library id */
  
  sprintf(lib, "%s", GetText(nuc + NUCLIDE_PTR_LIB_ID));
  
  /* Get temperature */
  
  T = RDB[nuc + NUCLIDE_TEMP];
  
  /* Loop over reactions */

  rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
  while (rea > 0)
    {
      /* Get ZAI */

      ZAI = (long)RDB[rea + REACTION_TGT_ZAI];
      
      /* Check */

      if (ZAI == (long)RDB[nuc + NUCLIDE_ZAI])
	Die(FUNCTION_NAME, "wtf?");

      /* Get mt */

      mt = (long)RDB[rea + REACTION_MT];

      /* Check that data is not already processed */
      
      if ((long)RDB[rea + REACTION_PTR_TGT] > 0)
	Die(FUNCTION_NAME, "%s mt %ld is already processed", 
	    GetText(nuc + NUCLIDE_PTR_NAME), mt);

      /* Check type */

      if (ZAI > 0)
	{
	  /*******************************************************************/

	  /***** Decay or transmutation reaction *****************************/
	      
	  /* Check reaction type */

	  if (((long)RDB[rea + REACTION_TYPE] == REACTION_TYPE_SPECIAL) ||
	      ((long)RDB[rea + REACTION_TYPE] == REACTION_TYPE_SUM))
	    Die(FUNCTION_NAME, "Invalid reaction type");

	  /* Check mt and add transmutation reaction counter */
	      
	  if ((mt < 16) || ((mt > 50) && (mt < 102)) || 
	      ((mt > 120) && (mt < 600)) || ((mt > 891) && (mt < 10000)))
	    Die(FUNCTION_NAME, "MT %ld in transmutation reaction", mt);
	  
	  /* Find match */

	  if ((new = FindNuclideData(NULL, ZAI, lib, T, -1)) > 0)
	    {
	      /* Check lib */

	      if (!CompareStr(new + NUCLIDE_PTR_LIB_ID,
			      nuc + NUCLIDE_PTR_LIB_ID))
		Die(FUNCTION_NAME, "Mismatch in library ID");

	      /* Check T */

	      if (RDB[new + NUCLIDE_TEMP] != RDB[nuc + NUCLIDE_TEMP])
		Die(FUNCTION_NAME, "Mismatch in T");

	      /* Put pointer */
	      
	      WDB[rea + REACTION_PTR_TGT] = (double)new;
	      
	      /* Call recursively */
	      
	      FindTargetNuclides(new);
	    }
	  else 
	    {
	      /* Set pointer to lost data */
	      
	      WDB[rea + REACTION_PTR_TGT] = RDB[DATA_PTR_NUCLIDE_LOST];
	      WDB[DATA_N_DEAD_PATH] = RDB[DATA_N_DEAD_PATH] + 1.0;

	      /* NOTE: Tää saattaa olla huono tarkistus. Jos nuklidilla on   */
	      /*       pelkkä transport-data ja moodi on vaihdettu decay:ksi */
	      /*       GenerateTransmuChain():ssä niin tämä löytää datan     */
	      /*       uutena. */
	      
	      if (new < 0)
		Warn(FUNCTION_NAME, 
		     "new = %ld < 0 (rea, nuc = %s, mt = %ld, ZAI = %ld T = %E)", 
		     new, GetText(nuc + NUCLIDE_PTR_NAME), mt, ZAI, T);
	    }
	  

	  /*******************************************************************/
	}
      else if (ZAI < 0)
	{
	  /*******************************************************************/

	  /***** Fission *****************************************************/
	  
	  /* Get pointer to yield */

	  if ((yld = (long)RDB[rea +  REACTION_PTR_FISSY]) > 0)
	    {
	      /* Check mt */
	      
	      if ((mt < 18) && (mt > 21) && (mt != 38) && (mt != 10006))
		Die(FUNCTION_NAME, "Invalid fission mt %ld", mt);
	      
	      /* Get pointer to distribution */
	      
	      if ((yld = (long)RDB[yld + FISSION_YIELD_PTR_DISTR]) < 0)
		Die(FUNCTION_NAME, "Pointer error");
	      
	      /* Loop over yield (data may have been processed for */
	      /* another fission channel) */
	      
	      n = 0;
	      while ((loc0 = ListPtr(yld, n++)) > 0)
		if ((long)RDB[loc0 + FY_PTR_TGT] < 1)
		  {
		    /* Get ZAI */
		    
		    ZAI = (long)RDB[loc0 + FY_TGT_ZAI];
		    
		    /* Separate Z and A for check */
		    
		    Z = (long)((double)ZAI/10000.0);
		    A = (long)(ZAI/10.0 - 1000.0*Z);
		    
		    /* Check values */
		    
		    CheckValue(FUNCTION_NAME, "Z", "", Z, 1, 80);
		    CheckValue(FUNCTION_NAME, "A", "", A, 1, 210);
		    
		    /* Find match */
		    
		    if ((new = FindNuclideData(NULL, ZAI, lib, T, -1)) > 0)
		      {
			/* Check lib */

			if (!CompareStr(new + NUCLIDE_PTR_LIB_ID,
					nuc + NUCLIDE_PTR_LIB_ID))
			  Die(FUNCTION_NAME, "Mismatch in library ID");
			
			/* Check T */
			
			if (RDB[new + NUCLIDE_TEMP] != 
			    RDB[nuc + NUCLIDE_TEMP])
			  Die(FUNCTION_NAME, "Mismatch in T");

			/* Put pointer */
			
			WDB[loc0 + FY_PTR_TGT] = (double)new;
			
			/* Call recursively */
			
			FindTargetNuclides(new);
		      }
		    else if (new == 0)
		      {
			/* Set pointer to lost data */
			
			WDB[loc0 + FY_PTR_TGT] = RDB[DATA_PTR_NUCLIDE_LOST];
			WDB[DATA_N_DEAD_PATH] = RDB[DATA_N_DEAD_PATH] + 1.0;
		      }
		    else
		      Die(FUNCTION_NAME, "new < 0 (fiss, ZAI = %ld)", ZAI);
		  }
	    }
	  else if (((long)RDB[rea + REACTION_TYPE] != REACTION_TYPE_DECAY)
		   && ((long)RDB[DATA_PTR_NFYDATA_FNAME_LIST] > 0))        
	    Die(FUNCTION_NAME, "No fission yield distribution %s mt %ld",
		GetText(nuc + NUCLIDE_PTR_NAME), mt);
	  
	  /* NOTE: Noita ei kai välttämättä oo kaikille? Myös cut-off */
	  /* voi leikata koko jakauman. */

	  /*******************************************************************/
	}

      
      /* Next */
      
      rea = NextItem(rea);
    }
}

/*****************************************************************************/
