/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processgc.                                     */
/*                                                                           */
/* Created:       2011/06/10 (JLe)                                           */
/* Last modified: 2011/12/15 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Process data needed for group constant generation            */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessGC:"

/*****************************************************************************/

void ProcessGC()
{
  long gcu, ptr, uni, ne, n;
  double *E;

  /* Check option */

  if((long)RDB[DATA_OPTI_GC_CALC] == NO)
    return;

  /***************************************************************************/

  /***** Few-group structure *************************************************/

  /* Get number of groups */

  ne = (long)RDB[DATA_ERG_FG_NG] + 1;
      
  /* Allcate memory for temporary array */
  
  E = (double *)Mem(MEM_ALLOC, ne, sizeof(double));
  
  /* Check pointer to array */
  
  if ((ptr = (long)RDB[DATA_ERG_FG_PTR_GRID]) < VALID_PTR)
    {
      /* Check two-group data */
      
      if (ne == 3)
	{
	  E[0] = 0.0;
	  E[1] = 0.625E-6;
	  E[2] = INFTY;
	}
      else if (ne == 5)
	{
	  E[0] = 0.0;
	  E[1] = 0.625E-6;
	  E[2] = 5.5E-3;
	  E[3] = 0.821;
	  E[4] = INFTY;
	}
      else
	Error(0, "Group structure must be given for few-group data");
    }
  else
    {
      /* Read data in array */
	  
      for (n = 0; n < ne; n++)
	E[n] = RDB[ptr++];
    }
  
  /* Check values */
  
  for (n = 1; n < ne; n++)
    if (E[n] <= E[n - 1])
      Error(0, "Values in few-group structure must be in ascending order");
      
  /* Make energy grid */
      
  ptr = MakeEnergyGrid(ne, 0, 0, -1, E, EG_INTERP_MODE_LIN);
      
  /* Put pointer */
  
  WDB[DATA_ERG_FG_PTR_GRID] = (double)ptr;
  
  /* Free temporary array */
  
  Mem(MEM_FREE, E);

  /***************************************************************************/

  /***** Universes ***********************************************************/

  /* Pointer is zero if list is not given */

  if((long)RDB[DATA_PTR_GCU0] == 0)
    {
      /* Allocate memory */

      gcu = NewItem(DATA_PTR_GCU0, GCU_BLOCK_SIZE);

      /* Pointer to root universe */

      ptr = (long)RDB[DATA_PTR_ROOT_UNIVERSE];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Set name */

      WDB[gcu + GCU_PTR_UNIV] = RDB[ptr + UNIVERSE_PTR_NAME];
    }

  /* Loop over gcu structures */

  gcu = (long)RDB[DATA_PTR_GCU0];
  while (gcu > VALID_PTR)
    {
      /* Find universe */

      uni = RDB[DATA_PTR_U0];
      if ((uni = SeekListStr(uni, UNIVERSE_PTR_NAME, 
			     GetText(gcu + GCU_PTR_UNIV))) < VALID_PTR)
	Error(0, "Universe %s in group constant generation does not exist", 
	      GetText(gcu + GCU_PTR_UNIV));
      
      /* Put pointers */
      
      WDB[gcu + GCU_PTR_UNIV] = (double)uni;
      WDB[uni + UNIVERSE_PTR_GCU] = (double)(gcu);

      /* Allocate memory for results */

      ptr = NewStat("FLUX", 1, ne); 
      WDB[gcu + GCU_RES_FG_FLX] = (double)ptr;
      
      ptr = NewStat("TOTXS", 1, ne); 
      WDB[gcu + GCU_RES_FG_TOTXS] = (double)ptr;
      
      ptr = NewStat("FISSXS", 1, ne); 
      WDB[gcu + GCU_RES_FG_FISSXS] = (double)ptr;
      
      ptr = NewStat("CAPTXS", 1, ne); 
      WDB[gcu + GCU_RES_FG_CAPTXS] = (double)ptr;
      
      ptr = NewStat("ABSXS", 1, ne); 
      WDB[gcu + GCU_RES_FG_ABSXS] = (double)ptr;
      
      ptr = NewStat("ELAXS", 1, ne); 
      WDB[gcu + GCU_RES_FG_ELAXS] = (double)ptr;
      
      ptr = NewStat("INELAXS", 1, ne); 
      WDB[gcu + GCU_RES_FG_INLXS] = (double)ptr;
      
      ptr = NewStat("SCATTXS", 1, ne); 
      WDB[gcu + GCU_RES_FG_SCATTXS] = (double)ptr;
      
      ptr = NewStat("N2NXS", 1, ne); 
      WDB[gcu + GCU_RES_FG_N2NXS] = (double)ptr;
      
      ptr = NewStat("REMXS", 1, ne); 
      WDB[gcu + GCU_RES_FG_REMXS] = (double)ptr;
      
      ptr = NewStat("NUBAR", 1, ne); 
      WDB[gcu + GCU_RES_FG_NUBAR] = (double)ptr;
      
      ptr = NewStat("NSF", 1, ne); 
      WDB[gcu + GCU_RES_FG_NSF] = (double)ptr;
      
      ptr = NewStat("RECIPVEL", 1, ne); 
      WDB[gcu + GCU_RES_FG_RECIPVEL] = (double)ptr;
      
      ptr = NewStat("FISSE", 1, ne); 
      WDB[gcu + GCU_RES_FG_FISSE] = (double)ptr;

      ptr = NewStat("LEAK", 1, ne); 
      WDB[gcu + GCU_RES_FG_LEAK] = (double)ptr;

      ptr = NewStat("SCATT0", 1, ne); 
      WDB[gcu + GCU_RES_FG_SCATT0] = (double)ptr;

      ptr = NewStat("SCATT1", 1, ne); 
      WDB[gcu + GCU_RES_FG_SCATT1] = (double)ptr;

      ptr = NewStat("SCATT2", 1, ne); 
      WDB[gcu + GCU_RES_FG_SCATT2] = (double)ptr;

      ptr = NewStat("SCATT3", 1, ne); 
      WDB[gcu + GCU_RES_FG_SCATT3] = (double)ptr;

      ptr = NewStat("SCATT4", 1, ne); 
      WDB[gcu + GCU_RES_FG_SCATT4] = (double)ptr;

      ptr = NewStat("SCATT5", 1, ne); 
      WDB[gcu + GCU_RES_FG_SCATT5] = (double)ptr;

      ptr = NewStat("MUBAR", 1, ne); 
      WDB[gcu + GCU_RES_FG_P1_MUBAR] = (double)ptr;

      /* Fission spectra does not include total */

      ptr = NewStat("CHI", 1, ne - 1); 
      WDB[gcu + GCU_RES_FG_CHI] = (double)ptr;

      ptr = NewStat("CHIP", 1, ne - 1); 
      WDB[gcu + GCU_RES_FG_CHIP] = (double)ptr;

      ptr = NewStat("CHID", 1, ne - 1); 
      WDB[gcu + GCU_RES_FG_CHID] = (double)ptr;

      /* Scattering matrix has extra dimension */

      ptr = NewStat("GTRANSFP", 2, ne - 1, ne - 1); 
      WDB[gcu + GCU_RES_FG_GTRANSP] = (double)ptr;

      ptr = NewStat("GTRANSFXS", 2, ne - 1, ne - 1); 
      WDB[gcu + GCU_RES_FG_GTRANSXS] = (double)ptr;

      /* Next */

      gcu = NextItem(gcu);
    }

  /* Allocate memory for universe pointer */

  AllocValuePair(DATA_GCU_PTR_UNI);

  /***************************************************************************/
}

/*****************************************************************************/
