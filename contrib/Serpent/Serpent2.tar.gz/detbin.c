/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : detbin.c                                       */
/*                                                                           */
/* Created:       2011/07/11 (JLe)                                           */
/* Last modified: 2011/11/10 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Finds detector bin                                           */
/*                                                                           */
/* Comments: - Tätä vois nopeuttaa muistamalla noi bin-arvot ja käyttämällä  */
/*             vanhoja jos rbin > 0.                                         */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "DetBin:"

/*****************************************************************************/

long DetBin(long det, long mat, double x, double y, double z, double E, 
	    long rbin, long id)
{
  long ptr, uni, lat, cell, idx, ncol;
  long ebin, ubin, cbin, mbin, lbin, zbin, ybin, xbin, tbin;
  long ne, nu, nc, nm, nl, nr, nz, ny, nx, nt, nmax;
  double xmin, xmax, ymin, ymax, zmin, zmax;

  /* Reset bins */

  ebin = 0;
  ubin = 0;
  cbin = 0;
  mbin = 0;
  lbin = 0;
  zbin = 0;
  ybin = 0;
  xbin = 0;
  tbin = 0;
  
  /* Get number of bins */
  
  ne = (long)RDB[det + DET_N_EBINS];
  nu = (long)RDB[det + DET_N_UBINS];
  nc = (long)RDB[det + DET_N_CBINS];
  nm = (long)RDB[det + DET_N_MBINS];
  nl = (long)RDB[det + DET_N_LBINS];
  nr = (long)RDB[det + DET_N_RBINS];
  nt = (long)RDB[det + DET_N_TBINS];
  nz = (long)RDB[det + DET_MESH_NZ];
  ny = (long)RDB[det + DET_MESH_NY];
  nx = (long)RDB[det + DET_MESH_NX];

  /* Get collision number */

  ptr = (long)RDB[DATA_PTR_COLLISION_COUNT];
  ncol = (long)GetPrivateData(ptr, id);
      
  /***************************************************************************/

  /***** Energy bin **********************************************************/

  /* Pointer to detector energy grid */

  if ((ptr = (long)RDB[det + DET_PTR_EGRID]) > VALID_PTR)
    {
      /* Get bin */
      
      if ((ebin = GridSearch(ptr, E)) < 0)
	{
	  /* Out of bounds */

	  return -1;
	}
      
      /* Check value */
      
      CheckValue(FUNCTION_NAME, "ebin", "", ebin, 0, ne - 1);
    }

  /***************************************************************************/

  /***** Universe bins *******************************************************/

  /* Check if universe bins are defined */

  if ((ptr = (long)RDB[det + DET_PTR_UBINS]) > VALID_PTR)
    {
      /* Loop over universe bins */
      
      while (ptr > VALID_PTR)
	{
	  /* Universe pointer */
	  
	  uni = RDB[ptr + DET_UBIN_PTR_UNI];
	  
	  /* Check pointer */
	  
	  CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);
	  
	  /* Check for collision */
	  
	  if (TestValuePair(uni + UNIVERSE_COL_COUNT, ncol, id) > 0.0)
	    break;
	  
	  /* Update bin */
	  
	  ubin++;
	  
	  /* Next bin */
	  
	  ptr = NextItem(ptr);
	}
      
      /* Check pointer */
      
      if (ptr < VALID_PTR)
	{
	  /* Not inside */
	  
	  return -1;
	}
      
      /* Check value */
      
      CheckValue(FUNCTION_NAME, "ubin", "", ubin, 0, nu - 1);
    }

  /***************************************************************************/

  /***** Lattice *************************************************************/

  /* Check if lattice bins are defined */

  if ((lat = (long)RDB[det + DET_PTR_LBINS]) > VALID_PTR)
    {
      /* Pointer to lattice */

      lat = (long)RDB[lat + DET_LBIN_PTR_LAT];

      /* Get index */
      
      if ((lbin = (long)TestValuePair(lat + LAT_COL_COUNT, ncol, id))
	  < 0)
	return -1;

      /* Check value */
      
      CheckValue(FUNCTION_NAME, "lbin", "", lbin, 0, nl - 1);
    }
  
  /***************************************************************************/

  /***** Cell bins ***********************************************************/

  /* Check if cell bins are defined */

  if ((ptr = (long)RDB[det + DET_PTR_CBINS]) > VALID_PTR)
    {
      /* Loop over cell bins */
      
      while (ptr > VALID_PTR)
	{
	  /* Cell pointer */
	  
	  cell = RDB[ptr + DET_CBIN_PTR_CELL];
	  
	  /* Check pointer */
	  
	  CheckPointer(FUNCTION_NAME, "(cell)", DATA_ARRAY, cell);
	  
	  /* Check for collision */
	  
	  if (TestValuePair(cell + CELL_COL_COUNT, ncol, id) > 0.0)
	    break;
	  
	  /* Update bin */
	  
	  cbin++;
	  
	  /* Next bin */
	  
	  ptr = NextItem(ptr);
	}
      
      /* Check pointer */
      
      if (ptr < VALID_PTR)
	{
	  /* Not inside */
	  
	  return -1;
	}
      
      /* Check value */
      
      CheckValue(FUNCTION_NAME, "ebin", "", cbin, 0, nc - 1);
    }
  
  /***************************************************************************/

  /***** Material bins *******************************************************/

  /* Check if material bins are defined */
  
  if ((ptr = (long)RDB[det + DET_PTR_MBINS]) > VALID_PTR)
    {
      /* Check material pointer */

      if (mat < VALID_PTR)
	return -1;

      /* Loop over universe bins */
      
      while (ptr > VALID_PTR)
	{
	  /* Compare material pointer */
	  
	  if ((long)RDB[ptr + DET_MBIN_PTR_MAT] == mat) 
	    break;
	  
	  /* Compare to parent (if divided in burnup calculation) */
	  
	  if ((long)RDB[ptr + DET_MBIN_PTR_MAT] == 
	      (long)RDB[mat + MATERIAL_PTR_DIV_PARENT])
	    break;
	  
	  /* Update bin */
	  
	  mbin++;
	  
	  /* Next bin */
	  
	  ptr = NextItem(ptr);
	}
      
      /* Check pointer */
      
      if (ptr < VALID_PTR)
	{
	  /* Not inside */
	  
	  return -1;
	}
      
      /* Check value */
      
      CheckValue(FUNCTION_NAME, "mbin", "", mbin, 0, nm - 1);
    }
  
  /***************************************************************************/

  /***** Mesh bins ***********************************************************/

  /* Get dimensions */
  
  xmin = RDB[det + DET_MESH_XMIN];
  xmax = RDB[det + DET_MESH_XMAX];
  ymin = RDB[det + DET_MESH_YMIN];
  ymax = RDB[det + DET_MESH_YMAX];
  zmin = RDB[det + DET_MESH_ZMIN];
  zmax = RDB[det + DET_MESH_ZMAX];
  
  /* Get sizes */
  
  nx = (long)RDB[det + DET_MESH_NX];
  ny = (long)RDB[det + DET_MESH_NY];
  nz = (long)RDB[det + DET_MESH_NZ];
  
  /* Calculate bins */
  
  xbin = (long)(((double)nx)*(x - xmin)/(xmax - xmin));
  ybin = (long)(((double)ny)*(y - ymin)/(ymax - ymin));
  zbin = (long)(((double)nz)*(z - zmin)/(zmax - zmin));
  
  /* Check boundaries */
  
  if ((xbin < 0) || (xbin > nx - 1) ||(ybin < 0) || (ybin > ny - 1) ||
      (zbin < 0) || (zbin > nz - 1))
    {
      /* Out of bounds */
      
      return -1;
    }
  
  /***************************************************************************/

  /***** Calculate bin index *************************************************/

  /* Check bins */

#ifdef DEBUG
  
  if ((ebin < 0) || (ebin > (long)RDB[det + DET_N_EBINS]))
    Die(FUNCTION_NAME, "Invalid ebin");
  if ((ubin < 0) || (ubin > (long)RDB[det + DET_N_UBINS]))
    Die(FUNCTION_NAME, "Invalid ubin");
  if ((cbin < 0) || (cbin > (long)RDB[det + DET_N_CBINS]))
    Die(FUNCTION_NAME, "Invalid cbin");
  if ((mbin < 0) || (mbin > (long)RDB[det + DET_N_MBINS]))
    Die(FUNCTION_NAME, "Invalid mbin");
  if ((lbin < 0) || (lbin > (long)RDB[det + DET_N_LBINS]))
    Die(FUNCTION_NAME, "Invalid lbin");
  if ((rbin < 0) || (rbin > (long)RDB[det + DET_N_RBINS]))
    Die(FUNCTION_NAME, "Invalid rbin");
  if ((zbin < 0) || (zbin > (long)RDB[det + DET_MESH_NZ]))
    Die(FUNCTION_NAME, "Invalid zbin");
  if ((ybin < 0) || (ybin > (long)RDB[det + DET_MESH_NY]))
    Die(FUNCTION_NAME, "Invalid ybin");
  if ((xbin < 0) || (xbin > (long)RDB[det + DET_MESH_NX]))
    Die(FUNCTION_NAME, "Invalid xbin");
  if ((tbin < 0) || (tbin > (long)RDB[det + DET_N_TBINS]))
    Die(FUNCTION_NAME, "Invalid tbin");
  
#endif
  
  /* Calculate index */
  
  nmax = 1;
  idx = 0;
  
  idx = idx + ebin*nmax;
  nmax = nmax*ne;
  
  idx = idx + ubin*nmax;
  nmax = nmax*nu;
  
  idx = idx + cbin*nmax;
  nmax = nmax*nc;
  
  idx = idx + mbin*nmax;
  nmax = nmax*nm;
  
  idx = idx + lbin*nmax;
  nmax = nmax*nl;
  
  idx = idx + rbin*nmax;
  nmax = nmax*nr;
  
  idx = idx + zbin*nmax;
  nmax = nmax*nz;
  
  idx = idx + ybin*nmax;
  nmax = nmax*ny;
  
  idx = idx + xbin*nmax;
  nmax = nmax*nx;
  
  idx = idx + tbin*nmax;
  nmax = nmax*nt;

  /* Return index */

  return idx;
}

/*****************************************************************************/
