/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : collectresults.c                               */
/*                                                                           */
/* Created:       2011/03/10 (JLe)                                           */
/* Last modified: 2012/01/25 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Collects results after cycle or batch                        */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CollectResults:"

/*****************************************************************************/

void CollectResults()
{
  long ptr, mat, i, n, m, ng, n0, n1, n2, gcu, pbd, pbl, tfb, reg;
  double nubar, tot, nuxn, capt, ela, scatt, fiss, leak, val, flx, tots;
  double rvel, norm, sum, fE, div, fmass;

  /***************************************************************************/
  
  /***** Common integral parameters ******************************************/

  /* Reduce scoring buffer */

  ReduceBuffer();

  /* Collect MPI parallel data */

  CollectBuf();

  /* Get normalization factor */

  norm = NormCoef();

  /* Analog fission nubar */

  ptr = (long)RDB[RES_ANA_NUBAR];
  nubar = BufMean(ptr, 0);

  /* Fission term */

  ptr = (long)RDB[RES_TOT_FISSRATE];
  fiss = BufVal(ptr, 0);

  /* Collision estimate of k-eff */

  ptr = (long)RDB[RES_COL_KEFF];

  if ((long)RDB[DATA_OPTI_MPI_REPRODUCIBILITY] == YES)
    AddStat(fiss*nubar/RDB[DATA_NBATCH], ptr, 0);
  else
    AddStat(fiss*nubar/RDB[DATA_SIMUL_BATCH_SIZE], ptr, 0);

  /* Total reaction rate */

  ptr = (long)RDB[RES_TOT_RR];
  tot = BufVal(ptr, 0);
  
  /* Scattering production rate */

  ptr = (long)RDB[RES_TOT_N2NRATE];
  nuxn = BufVal(ptr, 0);

  ptr = (long)RDB[RES_TOT_ELARATE];
  nuxn = nuxn + BufVal(ptr, 0);

  /* Leak term */
  
  ptr = (long)RDB[RES_TOT_LEAKRATE];
  leak = BufVal(ptr, 0);

  /* Implicit estimate of k-eff */

  ptr = (long)RDB[RES_IMP_KEFF];
  AddStat(nubar*fiss/(tot - nuxn + leak + ZERO), ptr, 0);

  /* Implicit estimate of k-inf */

  ptr = (long)RDB[RES_IMP_KINF];
  AddStat(nubar*fiss/(tot - nuxn + ZERO), ptr, 0);

  /* 1/v */

  ptr = (long)RDB[RES_TOT_RECIPVEL];
  rvel = BufVal(ptr, 0);
  
  /* Implicit estimate of neutron reproduction time */

  if ((fiss > 0.0) && (nubar > 0.0))
    {
      ptr = (long)RDB[RES_IMPL_REPROD_TIME];
      val = rvel/fiss/nubar;
      AddStat(val, ptr, 0);
    } 

  /* Prompt neutron lifetime */

  ptr = (long)RDB[RES_IMPL_PROMPT_LIFETIME];
  val = rvel/(tot - nuxn + leak + ZERO);
  AddStat(val, ptr, 0);

  /***************************************************************************/

  /***** Temperature feedback ************************************************/

  /* Loop over feedbacks */

  tfb = (long)RDB[DATA_PTR_TFB0];
  while (tfb > VALID_PTR)
    {
      /* Reset index */

      i = 0;

      /* Loop over regions */

      reg = (long)RDB[tfb + TFB_PTR_REG_LIST];
      while (reg > VALID_PTR)
	{
	  /* Power */

	  ptr = (long)RDB[tfb + TFB_PTR_MEAN_POW];
	  val = BufVal(ptr, i);
	  AddStat(val*norm, ptr, i);

	  /* Set power for next iteration */

	  WDB[reg + TFB_REG_ITER_POW] = val*norm;

	  /* Volume-averaged temperature */

	  ptr = (long)RDB[tfb + TFB_PTR_MEAN_VTEMP];
	  val = RDB[reg + TFB_REG_ITER_TEMP];
	  AddStat(val, ptr, i);

	  /* Flux */

	  ptr = (long)RDB[tfb + TFB_PTR_FLUX];
	  div = BufVal(ptr, i);

	  /* Flux-averaged temperature */

	  if (div > 0.0)
	    {
	      ptr = (long)RDB[tfb + TFB_PTR_MEAN_FTEMP];
	      val = BufVal(ptr, i);
	      AddStat(val/div, ptr, i);
	    }

	  /* Maximum temperature */

	  ptr = (long)RDB[tfb + TFB_PTR_MAX_TEMP];
	  val = BufMean(ptr, i);
	  AddStat(val, ptr, i);

	  /* Minimum temperature */

	  ptr = (long)RDB[tfb + TFB_PTR_MIN_TEMP];
	  val = BufMean(ptr, i);
	  AddStat(val, ptr, i);

	  /* Density */

	  ptr = (long)RDB[tfb + TFB_PTR_MEAN_MDENS];
	  val = BufMean(ptr, i);
	  AddStat(val, ptr, i);

	  /* Radius */

	  ptr = (long)RDB[tfb + TFB_PTR_MEAN_RAD];

	  if (i == 0)
	    {
	      val = BufMean(ptr, i);
	      AddStat(val, ptr, i);
	    }

	  val = BufMean(ptr, i + 1);
	  AddStat(val, ptr, i + 1);

	  /* Update index */

	  i++;

	  /* Next */
	  
	  reg = NextItem(reg);
	}

      /* Next */

      tfb = NextItem(tfb);
    }    

  /***************************************************************************/

  /***** Delta-tracking and reaction sampling ********************************/

  /* Loop over particle types */

  for (n = 0; n < 2; n++)
    {
      /* Delta and Surface-tracking tracks */
      
      ptr = (long)RDB[RES_TRACK_ST];
      div = BufVal(ptr, n);

      ptr = (long)RDB[RES_TRACK_DT];
      val = BufVal(ptr, n);

      /* Delta-tracking fraction */

      ptr = (long)RDB[RES_DT_FRAC];

      if ((div + val) > 0.0)
	AddStat(val/(div + val), ptr, n);
      else
	AddStat(0.0, ptr, n);

      /* Real and virtual collisions */

      ptr = (long)RDB[RES_REA_SAMPLE_REAL];
      val = BufVal(ptr, n);

      ptr = (long)RDB[RES_REA_SAMPLE_VIRT];
      div = BufVal(ptr, n);

      /* Delta-tracking efficiency */

      ptr = (long)RDB[RES_DT_EFF];

      if ((div + val) > 0.0)
	AddStat(val/(div + val), ptr, n);
      else
	AddStat(0.0, ptr, n);

      /* Accepted, rejected and failed reaction sampling fractions */

      ptr = (long)RDB[RES_REA_SAMPLE_REAL];
      div = BufVal(ptr, n);

      /* Accepted */

      ptr = (long)RDB[RES_REA_SAMPLE_ACC];
      val = BufVal(ptr, n);

      if (div > 0.0)
	AddStat(val/div, ptr, n);
      else
	AddStat(0.0, ptr, n);

      /* Rejected */

      ptr = (long)RDB[RES_REA_SAMPLE_REJ];
      val = BufVal(ptr, n);

      if (div > 0.0)
	AddStat(val/div, ptr, n);
      else
	AddStat(0.0, ptr, n);

      /* Failed */

      ptr = (long)RDB[RES_REA_SAMPLE_FAIL];
      val = BufVal(ptr, n);

      if (div > 0.0)
	AddStat(val/div, ptr, n);
      else
	AddStat(0.0, ptr, n);
    }

  /***************************************************************************/
  
  /* Check active cycle */

  if (RDB[DATA_CYCLE_IDX] < RDB[DATA_SKIP])
    return;

  /***************************************************************************/

  /***** Normalized total reaction rates *************************************/

  /* Total leak rate (no binned values) */
  
  ptr = (long)RDB[RES_TOT_LEAKRATE];
  leak = BufVal(ptr, 0);
  AddStat(norm*leak, ptr, 0);

  /* Total reaction rate */
  
  ptr = (long)RDB[RES_TOT_RR];
  val = BufVal(ptr, 0);
  AddStat(norm*val, ptr, 0);

  /* Loop over total, burnable and non-burnable rates */

  for (i = 0; i < 3; i++)
    {
      /* Analog fission energy */

      ptr = (long)RDB[RES_ANA_FISSE];
      fE = BufMean(ptr, i);
      AddStat(fE, ptr, i); 

      /* Analog fission nubar */

      ptr = (long)RDB[RES_ANA_NUBAR];
      nubar = BufMean(ptr, i);
      AddStat(fE, ptr, i); 

      /* Total fission rate */
  
      ptr = (long)RDB[RES_TOT_FISSRATE];
      fiss = BufVal(ptr, i);
      AddStat(norm*fiss, ptr, i);

      /* Total power */
  
      ptr = (long)RDB[RES_TOT_POWER];
      AddStat(norm*fiss*fE, ptr, i);

      /* Total power density */
  
      if (i == 0)
	fmass = RDB[DATA_INI_FMASS];
      else if (i == 1)
	fmass = RDB[DATA_INI_BURN_FMASS];
      else
	fmass = RDB[DATA_INI_FMASS] - RDB[DATA_INI_BURN_FMASS];

      if (fmass > 0.0)
	{
	  ptr = (long)RDB[RES_TOT_POWDENS];
	  AddStat(norm*fiss*fE/fmass, ptr, i);
	}

      /* Total generation rate */
      
      ptr = (long)RDB[RES_TOT_GENRATE];
      AddStat(norm*fiss*nubar, ptr, i);

      /* Total capture rate */
  
      ptr = (long)RDB[RES_TOT_CAPTRATE];
      capt = BufVal(ptr, i);
      AddStat(norm*capt, ptr, i);

      /* Total absorption rate */
      
      ptr = (long)RDB[RES_TOT_ABSRATE];
      AddStat(norm*(capt + fiss), ptr, i);

      /* Total loss rate */

      ptr = (long)RDB[RES_TOT_LOSSRATE];
      AddStat(norm*(leak + capt + fiss), ptr, i);
  
      /* Total flux */
  
      ptr = (long)RDB[RES_TOT_FLUX];
      val = BufVal(ptr, i);
      AddStat(norm*val, ptr, i);

      /* Total source rate */

      ptr = (long)RDB[RES_TOT_SRCRATE];
      val = BufVal(ptr, i);
      AddStat(norm*val, ptr, i);
    }

  /***************************************************************************/

  /***** Analog reaction rate estimators *************************************/

  /* Conversion ratio */
  
  ptr = (long)RDB[RES_ANA_CONV_RATIO];
  val = BufVal(ptr, 1);
  div = BufVal(ptr, 2);

  if (div > 0.0)
    AddStat(val/div, ptr, 0);
    
  /* Fission fractions */

  ptr = (long)RDB[RES_ANA_FISS_FRAC];
  div = BufVal(ptr, 0);

  if (div > 0.0)
    {
      val = BufVal(ptr, 1);
      AddStat(val/div, ptr, 1);

      val = BufVal(ptr, 2);
      AddStat(val/div, ptr, 2);

      val = BufVal(ptr, 3);
      AddStat(val/div, ptr, 3);

      val = BufVal(ptr, 4);
      AddStat(val/div, ptr, 4);

      val = BufVal(ptr, 5);
      AddStat(val/div, ptr, 5);
    }

  /***************************************************************************/

  /***** Few-group constants *************************************************/

  /* Loop over universes */

  gcu = (long)RDB[DATA_PTR_GCU0];
  while (gcu > VALID_PTR)
    {
      /* Number of energy groups */
      
      ng = (long)RDB[DATA_ERG_FG_NG];

      /* Reset total scattering rate */

      tots = 0.0;

      /* Loop over energy groups */
      
      for (n = 0; n < ng + 1; n++)
	{
	  /* Flux */
	  
	  ptr = (long)RDB[gcu + GCU_RES_FG_FLX];
	  flx = BufVal(ptr, n);
	  AddStat(norm*flx, ptr, n);

	  /* Leak */
	  
	  ptr = (long)RDB[gcu + GCU_RES_FG_LEAK];
	  val = BufVal(ptr, n);
	  AddStat(norm*val, ptr, n);
	  	  
	  /* Check value */
	  
	  if (flx > 0.0)
	    {
	      /* Total */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_TOTXS];
	      tot = BufVal(ptr, n);
	      AddStat(tot/flx, ptr, n);
	      
	      /* Fission */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_FISSXS];
	      fiss = BufVal(ptr, n);
	      AddStat(fiss/flx, ptr, n);
	      
	      /* Capture */

	      ptr = (long)RDB[gcu + GCU_RES_FG_CAPTXS];
	      capt = BufVal(ptr, n);
	      AddStat(capt/flx, ptr, n);
	      
	      /* Elastic */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_ELAXS];
	      ela = BufVal(ptr, n);
	      AddStat(ela/flx, ptr, n);
	      
	      /* Scattering multiplication */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_N2NXS];
	      nuxn = BufVal(ptr, n);
	      AddStat(nuxn/flx, ptr, n);
	      
	      /* Fission energy */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_FISSE];
	      val = BufMean(ptr, n);
	      AddStat(val/MEV, ptr, n);
	      
	      /* Nubar */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_NUBAR];
	      nubar = BufMean(ptr, n);
	      AddStat(nubar, ptr, n);
	      
	      /* NSF */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_NSF];
	      AddStat(nubar*fiss/flx, ptr, n);
	      
	      /* Absorption */

	      ptr = (long)RDB[gcu + GCU_RES_FG_ABSXS];
	      AddStat((capt + fiss)/flx, ptr, n);
	      
	      /* Scattering */
	      
	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATTXS];
	      scatt = tot - fiss - capt;
	      AddStat(scatt/flx, ptr, n);
	      
	      /* Inelastic (NOTE: Tässä on jotain ihan friikkiä numeerista */
	      /* ongelmaa. Termisessä ryhmässä sironta on kokonaan         */
	      /* elastista, mutta toi erotus poikkeaa silti nollasta. Ja   */
	      /* mikä parasta, se antaa eri arvot (~1E-15) samalla rng     */
	      /* alkiolla, vaikka scatt ja ela, ja kaikki muut parametrit  */
	      /* olisi täsmälleen samoja.) */

	      ptr = (long)RDB[gcu + GCU_RES_FG_INLXS];
	      AddStat((scatt - ela)/flx, ptr, n);

	      /* 1/v */

	      ptr = (long)RDB[gcu + GCU_RES_FG_RECIPVEL];
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      /* PN scattering cross sections */

	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT0];
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT1];
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      ptr = (long)RDB[gcu + GCU_RES_FG_P1_MUBAR];

	      if (scatt > 0.0)
		AddStat(val/scatt, ptr, n);

	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT2];
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT3];
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT4];
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      ptr = (long)RDB[gcu + GCU_RES_FG_SCATT5];
	      val = BufVal(ptr, n);
	      AddStat(val/flx, ptr, n);

	      /* Fission spectra (no total values) */

	      if (n < ng)
		{
		  /* Total chi */

		  ptr = (long)RDB[gcu + GCU_RES_FG_CHI];
		  
		  sum = 0.0;
		  for (i = 0; i < ng; i++)
		    sum = sum + BufVal(ptr, i);

		  if (sum > 0.0)
		    {
		      val = BufVal(ptr, n)/sum;
		      AddStat(val, ptr, n);
		    }
		  
		  /* Prompt chi */
		  
		  ptr = (long)RDB[gcu + GCU_RES_FG_CHIP];
		  
		  sum = 0.0;
		  for (i = 0; i < ng; i++)
		    sum = sum + BufVal(ptr, i);

		  if (sum > 0.0)
		    {
		      val = BufVal(ptr, n)/sum;
		      AddStat(val, ptr, n);
		    }
		  
		  /* Delayed chi */
		  
		  ptr = (long)RDB[gcu + GCU_RES_FG_CHID];
		  
		  sum = 0.0;
		  for (m = 0; m < ng; m++)
		    sum = sum + BufVal(ptr, m);

		  if (sum > 0.0)
		    {
		      val = BufVal(ptr, n)/sum;
		      AddStat(val, ptr, n);
		    }
		}

	      /* Scattering matrix and group-transfer probabilities */
	      
	      if (n > 0)
		{
		  /* Loop over target groups */
		  
		  for (m = 0; m < ng; m++)
		    {
		      /* Get scattering rate */
		      
		      ptr = (long)RDB[gcu + GCU_RES_FG_GTRANSXS];
		      val = BufVal(ptr, m, n - 1);
		      
		      /* Group-transfer matrix */
		      
		      if (flx > 0.0)
			AddStat(val/flx, ptr, m, n - 1);
		      
		      /* Add to total */

		      tots = tots + val;
		      
		      /* Group-transfer probabilities */
		      
		      if (scatt > 0.0)
			{
			  ptr = (long)RDB[gcu + GCU_RES_FG_GTRANSP];
			  AddStat(val/scatt, ptr, m, n - 1);
			}
		    }
		  
		  /* Group-wise removal cross section */
		  
		  ptr = (long)RDB[gcu + GCU_RES_FG_GTRANSXS];
		  val = BufVal(ptr, n - 1, n - 1);
		  val = tot - val;
		  
 		  ptr = (long)RDB[gcu + GCU_RES_FG_REMXS];
		  AddStat(val/flx, ptr, n);
		}
	    }
	}
      
      /* Total removal rate */
      
      ptr = (long)RDB[gcu + GCU_RES_FG_TOTXS];
      val = BufVal(ptr, 0) - tots;
      
      /* Total flux */
      
      ptr = (long)RDB[gcu + GCU_RES_FG_FLX];
      flx = BufVal(ptr, 0);
      
      /* Total removal cross section */
      
      if (flx > 0.0)
	{
	  ptr = (long)RDB[gcu + GCU_RES_FG_REMXS];
	  AddStat(val/flx, ptr, 0);
	}

      /* Next universe */

      gcu = NextItem(gcu);
    }

  /***************************************************************************/

  /***** Transmutation cross sections for burnup calculation *****************/

  /* Loop over materials */

  mat = (long)RDB[DATA_PTR_M0];
  while (mat > VALID_PTR)
    {
      /* Check material burn-flag */
      
      if ((long)RDB[mat + MATERIAL_OPTIONS] & OPT_BURN_MAT)
	{
	  /* Total flux for normalization */

	  ptr = (long)RDB[mat + MATERIAL_PTR_BURN_FLUX];
	  val = BufVal(ptr, 0);
	  AddStat(val*norm, ptr, 0);
	}

      /* Next material */

      mat = NextItem(mat);
    }

  /***************************************************************************/

  /***** Core power distributions ********************************************/

  /* Check if distribution is given */

  if (RDB[DATA_CORE_PDE_DEPTH] > 0.0)
    {
      /* Get normalization factor */

      norm = NormCoef();

      /* Core level */

      if ((ptr = (long)RDB[DATA_CORE_PDE_PTR_RES0]) > VALID_PTR)
	for (n0 = 0; n0 < (long)RDB[DATA_CORE_PDE_N0]; n0++)
	  {
	    val = BufVal(ptr, n0);
	    AddStat(val*norm, ptr, n0);
	  }

      /* Pin level */

      if ((ptr = (long)RDB[DATA_CORE_PDE_PTR_RES1]) > VALID_PTR)
	for (n0 = 0; n0 < (long)RDB[DATA_CORE_PDE_N0]; n0++)
	  for (n1 = 0; n1 < (long)RDB[DATA_CORE_PDE_N1]; n1++)
	    {
	      val = BufVal(ptr, n0, n1);
	      AddStat(val*norm, ptr, n0, n1);
	    }

      /* Region level */

      if ((ptr = (long)RDB[DATA_CORE_PDE_PTR_RES2]) > VALID_PTR)
	for (n0 = 0; n0 < (long)RDB[DATA_CORE_PDE_N0]; n0++)
	  for (n1 = 0; n1 < (long)RDB[DATA_CORE_PDE_N1]; n1++)
	    for (n2 = 0; n2 < (long)RDB[DATA_CORE_PDE_N2]; n2++)
	      {
		val = BufVal(ptr, n0, n1, n2);
		AddStat(val*norm, ptr, n0, n1, n2);
	      }
    }

  /***************************************************************************/

  /***** Pebble-bed power distributions **************************************/

  /* Get normalization factor */

  norm = NormCoef();

  /* Loop over pbed geometries */

  pbd = (long)RDB[DATA_PTR_PB0];
  while (pbd > 0)
    {
      /* Get pointer to distribution */
      
      if ((ptr = (long)RDB[pbd + PBED_PTR_POW]) > VALID_PTR)
	{
	  /* Loop over pebbles */
	  
	  pbl = (long)RDB[pbd + PBED_PTR_PEBBLES];
	  while (pbl > 0)
	    {
	      /* Get pebble index */
	    
	      i = (long)RDB[pbl + PEBBLE_IDX];
	    
	      /* Get power and add to statistics */
	    
	      val = BufVal(ptr, i);
	      AddStat(val*norm, ptr, i);

	      /* Next */
	      
	      pbl = NextItem(pbl);
	    }
	}

      /* Next */

      pbd = NextItem(pbd);
    }

  /***************************************************************************/
}

/*****************************************************************************/
