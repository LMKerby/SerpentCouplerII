/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : randf.c                                        */
/*                                                                           */
/* Created:       2010/11/22 (JLe)                                           */
/* Last modified: 2011/11/10 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Samples a uniformly distribute random number on the unit     */
/*              interval.                                                    */
/*                                                                           */
/* Comments: - Calls Rand64(), which is based on an algorithm that produces  */
/*             the same random number sequence for a particle history in     */
/*             both serial and parallel modes.                               */
/*                                                                           */
/*           - Should be used only during the transport cycle, for other     */
/*             purposes use C-function drand48().                            */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "RandF:"

/*****************************************************************************/

double RandF(long id)
{
  long ptr;
  unsigned long seed;
  double f;
  
  /* Get pointer to private data */

  ptr = (long)RDB[DATA_PTR_RNG_SEED];

  /* Get seed */

  seed = (unsigned long)GetPrivateData(ptr, id);

  /* Check value */

  CheckValue(FUNCTION_NAME, "seed", "", seed, 1, INFTY);

  /* Sample rng */

  f = Rand64(&seed);

  /* Check value */

  CheckValue(FUNCTION_NAME, "f", "", f, 0.0, 1.0);

  /* Store seed */

  PutPrivateData(ptr, seed, id);

  /* Return value */

  return f;
}

/*****************************************************************************/
