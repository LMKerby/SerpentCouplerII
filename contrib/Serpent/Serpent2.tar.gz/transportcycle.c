/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : transportcycle.c                               */
/*                                                                           */
/* Created:       2011/05/23 (JLe)                                           */
/* Last modified: 2012/01/12 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Prepares and runs the main transport cycle                   */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "TransportCycle:"

/*****************************************************************************/

void TransportCycle()
{
  long nb, nn, id, ptr;
  double t0;

  /***************************************************************************/

  /***** Main transport cycle ************************************************/

  fprintf(out, "Begin transport cycle...\n\n");

  /* Reset total and active timer */

  ResetTimer(TIMER_TRANSPORT);
  ResetTimer(TIMER_TRANSPORT_ACTIVE);

  /* Start transport timer */
      
  StartTimer(TIMER_TRANSPORT);
  StartTimer(TIMER_TRANSPORT_TOTAL);

  /* Reset completed flag */

  WDB[DATA_SIMULATION_COMPLETED] = 0.0;

  /* Init particle stacks */

  InitPartStacks();

  /* Check mode */

  if ((long)RDB[DATA_SIMULATION_MODE] == SIMULATION_MODE_SRC)
    {
      /***********************************************************************/

      /***** External source simulation **************************************/
      Die(FUNCTION_NAME, "Not working at the moment");
      /* Reset skip cycles */

      WDB[DATA_SKIP] = 0.0;

      /* Set cycle-wise batch size */

      WDB[DATA_CYCLE_BATCH_SIZE] = RDB[DATA_NBATCH];

      /* Start active transport timer */

      StartTimer(TIMER_TRANSPORT_ACTIVE);

      /* Loop over batches */
      
      for (nb = 0; nb < (long)RDB[DATA_CYCLES]; nb++)
	{
	  /* Reset cycle k-eff */

	  WDB[DATA_CYCLE_KEFF] = 1.0;

	  /* Put cycle index */

	  WDB[DATA_CYCLE_IDX] = (double)nb;

	  /* Get beginning time */

	  t0 = TimerVal(TIMER_TRANSPORT);

	  /* Start parallel timer */

	  StartTimer(TIMER_OMP_PARA);

#ifdef OPEN_MP
#pragma omp parallel private(id) 
#endif
	  {
	    /* Get Open MP thread id */
		
	    id = OMP_THREAD_NUM;
		
#ifdef OPEN_MP
#pragma omp for
#endif	  
	    /* Loop over source neutrons */
	  
	    for (nn = 0; nn < (long)RDB[DATA_NBATCH]; nn++)
	      {
		/* Sample source point */
		
		SampleSrcPoint(id, -1);
		
		/* Track */
		
		Tracking(id);
	      }
	  }

	  /* Stop parallel timer */

	  StopTimer(TIMER_OMP_PARA);

	  /* Get end time */

	  t0 = TimerVal(TIMER_TRANSPORT) - t0;

	  /* Score time */

	  ptr = (long)RDB[RES_CYCLE_RUNTIME];
	  AddStat(t0, ptr, 0); 

	  /* Collect and clear buffered results */

	  CollectResults();
	  /*
	  B1Solver();
	  */
	  CollectDet();
	  ClearBuf();

	  /* Print cycle-wise output */

	  PrintCycleOutput();

	  /* Sort lists */

	  SortAll();

	  /* Print results */
	  
	  if (!((nb + 1) % 50))
	    {
	      MatlabOutput();
	      DetectorOutput();
	      MeshPlotter();
	      PrintCoreDistr();
	      PrintHistoryOutput();
	      PrintPBData();
	      PrintTFBOutput();
	    }
	}

      /***********************************************************************/
    }
  else
    {
      /***********************************************************************/

      /***** Criticality source simulation ***********************************/

      /* Reset simulated batch size and index counter */
      
      WDB[DATA_SIMUL_BATCH_SIZE] = 0.0;

      /* Generate initial source */
      
      fprintf(out, "Sampling initial source...\n");

      for (nn = 0; nn < (long)RDB[DATA_NBATCH]; nn++)
	SampleSrcPoint(0, nn);
	
      fprintf(out, "OK.\n\n");

      /* Start cycle-wise transport timer */

      ResetTimer(TIMER_TRANSPORT_CYCLE);
      StartTimer(TIMER_TRANSPORT_CYCLE);

      /* Loop over batches */
      
      for (nb = 0; nb < (long)RDB[DATA_CYCLES] + (long)RDB[DATA_SKIP]; nb++)
	{
	  /* Check number of skip cycles */

	  if (nb == (long)RDB[DATA_SKIP])
	    {
	      /* Clear statistics */
	      
	      ClearStat(-1);

	      /* Start active transport timer */

	      StartTimer(TIMER_TRANSPORT_ACTIVE);
	    }
	  
	  /* Put cycle index */

	  WDB[DATA_CYCLE_IDX] = (double)nb;

	  /* Normalize source */

	  NormalizeCritSrc();

	  /* Get beginning time */

	  t0 = TimerVal(TIMER_TRANSPORT);

	  /* Start parallel timer */

	  StartTimer(TIMER_OMP_PARA);

	  /* Loop until source is empty */

#ifdef OPEN_MP
#pragma omp parallel private(id)
#endif
	  {
	    /* Get Open MP thread id */

	    id = OMP_THREAD_NUM;

	    /* Loop over source */

	    while(FromSrc(id) > VALID_PTR)
	      Tracking(id);      
	  }

	  /* Stop parallel timer */

	  StopTimer(TIMER_OMP_PARA);

	  /* Get end time */

	  t0 = TimerVal(TIMER_TRANSPORT) - t0;

	  /* Score time */

	  ptr = (long)RDB[RES_CYCLE_RUNTIME];
	  AddStat(t0, ptr, 0); 
  
	  /* Collect and clear buffered results */

	  CollectResults();
	  /*
	  B1Solver();
	  */
	  CollectDet();
	  ClearBuf();

	  /* Temperature feedback for next cycle */

	  IterateTFB();

	  /* Stop cycle-wise transport timer */

	  StopTimer(TIMER_TRANSPORT_CYCLE);
	  
	  t0 = TimerCPUVal(TIMER_TRANSPORT_CYCLE)/
	    TimerVal(TIMER_TRANSPORT_CYCLE);

	  /* CPU usage */

	  ptr = (long)RDB[RES_CPU_USAGE];
	  AddStat(t0, ptr, 0); 

	  /* Print cycle-wise output */

	  PrintCycleOutput();

	  /* Reset and restart cycle-wise transport timer */

	  ResetTimer(TIMER_TRANSPORT_CYCLE);
	  StartTimer(TIMER_TRANSPORT_CYCLE);

	  /* Sort lists */

	  SortAll();

	  /* Print results */
	  
	  if (!((nb + 1) % 50))
	    {
	      MatlabOutput();
	      DetectorOutput();
	      MeshPlotter();
	      PrintCoreDistr();
	      PrintHistoryOutput();
	      PrintPBData();
	      PrintTFBOutput();
	    }
	}

      /* Stop cycle-wise transport timer */

      StopTimer(TIMER_TRANSPORT_CYCLE);

      /***********************************************************************/
    }
       
  /***************************************************************************/

  /***** Transport cycle completed *******************************************/

  /* Collect results from MPI tasks */

  CollectParallelData();

  /* Kutsutaan tätä nyt väliaikaisesti tässä */

  B1Solver();

  /* Put completed flag */

  WDB[DATA_SIMULATION_COMPLETED] = 1.0;

  /* Stop transport timers */

  StopTimer(TIMER_TRANSPORT);
  StopTimer(TIMER_TRANSPORT_TOTAL);
  StopTimer(TIMER_TRANSPORT_ACTIVE);

  /* Remember previous value */

  if ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP)
    WDB[DATA_PRED_TRANSPORT_TIME] = TimerVal(TIMER_TRANSPORT);
  else
    WDB[DATA_CORR_TRANSPORT_TIME] = TimerVal(TIMER_TRANSPORT);

  /* Print output */

  MatlabOutput();
  DetectorOutput();
  MeshPlotter();
  PrintCoreDistr();
  PrintHistoryOutput();
  PrintPBData();
  PrintTFBOutput();

  /***************************************************************************/
}

/*****************************************************************************/
