/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processtransformations.c                       */
/*                                                                           */
/* Created:       2010/10/07 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Links transformations to universes                           */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessTransformations:"

/*****************************************************************************/

void ProcessTransformations()
{
  long ptr, uni;

  /* Loop over transformations */

  ptr = RDB[DATA_PTR_TR0];
  while (ptr > 0)
    {
      /* Find universe */

      uni = (long)RDB[DATA_PTR_U0];
      CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);

      uni = SeekListStr(uni, UNIVERSE_PTR_NAME, GetText(ptr + TRANS_PTR_UNI));

      /* Check */

      if (uni > VALID_PTR)
	{
	  /* Check that universe is not root (geometrian rajojen */
	  /* laskeminen menee pieleen */
	  
	  if (uni == (long)RDB[DATA_PTR_ROOT_UNIVERSE])
	    Error(ptr, "Transformation not allowed with root universe %s",
		  GetText(uni + UNIVERSE_PTR_NAME));
	  
	  /* Set pointers */
	  
	  WDB[ptr + TRANS_PTR_UNI] = (double)uni;
	  WDB[uni + UNIVERSE_PTR_TRANS] = (double)ptr;
	  
	  /* Set used flag */
	  
	  SetOption(ptr + TRANS_OPTIONS, OPT_USED);
	} 
      else
	Error(ptr, "Universe %s does not exist", 
	      GetText(ptr + TRANS_PTR_UNI));
      
      /* Next transformation */
      
      ptr = NextItem(ptr);
    }
}

/*****************************************************************************/
