/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : capture.c                                      */
/*                                                                           */
/* Created:       2011/02/28 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Handles (implicit) capture                                   */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Capture:"

/*****************************************************************************/

void Capture(long mat, double xs, double E, double *wgt, long id)
{
  double totxs;
  long rea;

  /* Check material pointer */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /* Get total xs */

  rea = (long)RDB[mat + MATERIAL_PTR_TOTXS];
  totxs = MacroXS(rea, E, id);

  /* Adjust weight */

  *wgt = *wgt*xs/totxs;  
}

/*****************************************************************************/
