/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : readinput.c                                    */
/*                                                                           */
/* Created:       2010/10/20 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Coordinate transformations for universe symmetry             */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "UniSym:"

/*****************************************************************************/

void UniSym(long uni, double *x, double *y, double *z, double *u,  
	    double *v, double *w)
{
  long ptr;
  double x0, y0;

  /* Check universe pointer */

  CheckPointer(FUNCTION_NAME, "(uni)", DATA_ARRAY, uni);
      
  /* Get pointer to symmetry */

  if ((ptr = (long)RDB[uni + UNIVERSE_PTR_SYM]) < VALID_PTR)
    return;

  /* Get symmetry point */

  x0 = RDB[ptr + USYM_X0];
  y0 = RDB[ptr + USYM_Y0];

  /* Check symmetry type */

  switch((long)RDB[ptr + USYM_SYM])
    {
    case 4:
      {
	/* Quadrant */
	
	if (*x < x0)
	  {
	    *x = 2.0*x0 -*x;
	    *u = -*u;
	  }
      
	if (*y < y0)
	  {
	    *y = 2.0*y0 -*y;
	    *v = -*v;
	  }
	
	/* Break loop */

	break;
      }
    default:
      {
	Error(ptr, "Invalid symmetry type %ld", (long)RDB[ptr + USYM_SYM]);
      }
    }
}

/*****************************************************************************/

