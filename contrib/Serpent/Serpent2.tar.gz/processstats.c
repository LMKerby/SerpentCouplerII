/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processstats.c                                 */
/*                                                                           */
/* Created:       2011/03/10 (JLe)                                           */
/* Last modified: 2012/01/18 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Allocates memory for statistical variables                   */
/*                                                                           */
/* Comments: - Statistics for detectors is handled in processdetectors.c     */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessStats:"

/*****************************************************************************/

void ProcessStats()
{
  long ptr;

  /***************************************************************************/

  /***** Common integral parameters ******************************************/

  /* Reaction rates with single bin */

  ptr = NewStat("TOT_N2NRATE", 1, 1);
  WDB[RES_TOT_N2NRATE] = (double)ptr;  

  ptr = NewStat("TOT_LEAKRATE", 1, 1);
  WDB[RES_TOT_LEAKRATE] = (double)ptr;  

  ptr = NewStat("TOT_ELARATE", 1, 1);
  WDB[RES_TOT_ELARATE] = (double)ptr;  

  ptr = NewStat("TOT_RR", 1, 1);
  WDB[RES_TOT_RR] = (double)ptr;  
  
  /* Three bins for burnup normalization */

  ptr = NewStat("ANA_NUBAR", 1, 3);
  WDB[RES_ANA_NUBAR] = (double)ptr;  

  ptr = NewStat("ANA_FISSE", 1, 3);
  WDB[RES_ANA_FISSE] = (double)ptr;  

  ptr = NewStat("TOT_FISSRATE", 1, 3);
  WDB[RES_TOT_FISSRATE] = (double)ptr;  

  ptr = NewStat("TOT_CAPTRATE", 1, 3);
  WDB[RES_TOT_CAPTRATE] = (double)ptr;  

  ptr = NewStat("TOT_SRCRATE", 1, 3);
  WDB[RES_TOT_SRCRATE] = (double)ptr;  

  ptr = NewStat("TOT_FLUX", 1, 3);
  WDB[RES_TOT_FLUX] = (double)ptr;  

  ptr = NewStat("RES_TOT_POWER", 1, 3);
  WDB[RES_TOT_POWER] = (double)ptr;

  ptr = NewStat("RES_TOT_POWDENS", 1, 3);
  WDB[RES_TOT_POWDENS] = (double)ptr;

  ptr = NewStat("RES_TOT_GENRATE", 1, 3);
  WDB[RES_TOT_GENRATE] = (double)ptr;

  ptr = NewStat("TOT_ABSRATE", 1, 3);
  WDB[RES_TOT_ABSRATE] = (double)ptr;  

  ptr = NewStat("TOT_LOSSRATE", 1, 3);
  WDB[RES_TOT_LOSSRATE] = (double)ptr;  

  /* Total 1/v */

  ptr = NewStat("TOT_RECIPVEL", 1, 1);
  WDB[RES_TOT_RECIPVEL] = (double)ptr;  

  /* Implicit estimator of k-eff and k-inf */

  ptr = NewStat("IMP_KEFF", 1, 1);
  AllocStatHistory(ptr);
  WDB[RES_IMP_KEFF] = (double)ptr;  

  ptr = NewStat("IMP_KINF", 1, 1);
  WDB[RES_IMP_KINF] = (double)ptr;  

  /* Analog estimator of k-eff */

  ptr = NewStat("ANA_KEFF", 1, 1);
  AllocStatHistory(ptr);
  WDB[RES_ANA_KEFF] = (double)ptr;  

  /* Collision estimator of k-eff */

  ptr = NewStat("COL_KEFF", 1, 1);
  AllocStatHistory(ptr);
  WDB[RES_COL_KEFF] = (double)ptr;  

  /* Kinetic parameters */

  ptr = NewStat("ANA_REPROD_TIME", 1, 1);
  WDB[RES_ANA_REPROD_TIME] = (double)ptr;  

  ptr = NewStat("IMPL_REPROD_TIME", 1, 1);
  WDB[RES_IMPL_REPROD_TIME] = (double)ptr;  

  ptr = NewStat("ANA_PROMPT_LIFETIME", 1, 1);
  WDB[RES_ANA_PROMPT_LIFETIME] = (double)ptr;  

  ptr = NewStat("IMPL_PROMPT_LIFETIME", 1, 1);
  WDB[RES_IMPL_PROMPT_LIFETIME] = (double)ptr;  

  /* Mean population size */

  ptr = NewStat("MEAN_POP_SIZE", 1, 1);
  AllocStatHistory(ptr);
  WDB[RES_MEAN_POP_SIZE] = (double)ptr;  

  /* Conversion ratio */

  ptr = NewStat("CONV_RATIO", 1, 3);
  WDB[RES_ANA_CONV_RATIO] = (double)ptr;  

  /* Analog fission fractions */

  ptr = NewStat("FISS_FRAC", 1, 6);
  WDB[RES_ANA_FISS_FRAC] = (double)ptr;  

  /* Cycle-wise running time */

  ptr = NewStat("TRANSPORT_RUNTIME", 1, 1);
  AllocStatHistory(ptr);
  WDB[RES_CYCLE_RUNTIME] = (double)ptr;  

  /* CPU usage in transport cycle */

  ptr = NewStat("TRANSPORT_CPU_USAGE", 1, 1);
  AllocStatHistory(ptr);
  WDB[RES_CPU_USAGE] = (double)ptr;  

  /***************************************************************************/

  /***** Reaction and DT counters ********************************************/

  ptr = NewStat("REA_SAMPLE_REAL", 1, 2);
  WDB[RES_REA_SAMPLE_REAL] = (double)ptr;

  ptr = NewStat("REA_SAMPLE_ACC", 1, 2);
  WDB[RES_REA_SAMPLE_ACC] = (double)ptr;
  
  ptr = NewStat("REA_SAMPLE_REJ", 1, 2);
  WDB[RES_REA_SAMPLE_REJ] = (double)ptr;
  
  ptr = NewStat("REA_SAMPLE_FAIL", 1, 2);
  WDB[RES_REA_SAMPLE_FAIL ] = (double)ptr;
  
  ptr = NewStat("REA_SAMPLE_VIRT", 1, 2);
  WDB[RES_REA_SAMPLE_VIRT] = (double)ptr;
  
  ptr = NewStat("REA_SAMPLE_EFF", 1, 2);
  WDB[RES_REA_SAMPLE_EFF] = (double)ptr;
  
  ptr = NewStat("TRACK_DT", 1, 2);
  WDB[RES_TRACK_DT] = (double)ptr;
  
  ptr = NewStat("TRACK_ST", 1, 2);
  WDB[RES_TRACK_ST] = (double)ptr;
  
  ptr = NewStat("DT_EFF", 1, 2);
  WDB[RES_DT_EFF] = (double)ptr;
  
  ptr = NewStat("DT_FRAC", 1, 2);
  WDB[RES_DT_FRAC] = (double)ptr;
  
  /***************************************************************************/
}

/*****************************************************************************/
