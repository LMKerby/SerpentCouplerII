/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : processfum.c                                   */
/*                                                                           */
/* Created:       2011/06/10 (JLe)                                           */
/* Last modified: 2011/11/20 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Prepares data structures and allocates memory for B1         */
/*              fundamental mode calculation                                 */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "ProcessFUM:"

/*****************************************************************************/

void ProcessFUM()
{
  long ptr, gcu, ene, ne0, ne1, loc0, loc1, n, m;

  /* Check option */

  if ((long)RDB[DATA_OPTI_FUM_CALC] == NO)
    return;

  /* Check pointer to energy grid name */

  if ((long)RDB[DATA_PTR_FUM] < 1)
    Error(0, "Energy grid %s in B1 fundamental mode calculation not defined", 
	  GetText(DATA_PTR_FUM));

  /***************************************************************************/

  /***** Process micro-group structure ***************************************/
  
  /* Find energy grid */
  
  ene = RDB[DATA_PTR_ENE0];
  if ((ene = SeekListStr(ene, ENE_PTR_NAME,GetText(DATA_PTR_FUM))) < VALID_PTR)
    Error(0, "Energy grid %s in B1 fundamental mode calculation not defined", 
	  GetText(DATA_PTR_FUM));

  /* Pointer to grid structure */

  ene = (long)RDB[ene + ENE_PTR_GRID];
  CheckPointer(FUNCTION_NAME, "(ene)", DATA_ARRAY, ene);

  /* Put pointer */

  WDB[DATA_FUM_PTR_EGRID] = (double)ene;

  /* Number of points and pointer to values */

  ne0 = (long)RDB[ene + ENERGY_GRID_NE] - 1;

  loc0 = (long)RDB[ene + ENERGY_GRID_PTR_DATA];
  CheckPointer(FUNCTION_NAME, "(loc0)", DATA_ARRAY, loc0);

  /* Pointer to few-group structure */

  ptr = (long)RDB[DATA_ERG_FG_PTR_GRID];
  CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

  /* Number of points and pointer to values */

  ne1 = (long)RDB[ptr + ENERGY_GRID_NE] - 1;

  loc1 = (long)RDB[ptr + ENERGY_GRID_PTR_DATA];
  CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);

  /* Allocate memory for indexes */

  ptr = ReallocMem(DATA_ARRAY, ne0);
  WDB[DATA_FUM_PTR_IDX_MAP] = (double)ptr;

  /* Map indexes */

  m = 0;
  for (n = 1; n < ne1; n++)
    {
      /* Loop over micro-group structure */

      while (m < ne0)
	{
	  /* Check boundary */

	  if (RDB[loc0 + m] == RDB[loc1 + n])
	    break;

	  /* Put index */

	  WDB[ptr + ne0 - m - 1] = (double)(ne1 - n);


	  /* Next */

	  m++;
	}

      /* Check match */

      if (m == ne0)
	Error(0, "Few-group boundary %1.5E not found in FUM energy grid",
	      RDB[loc1 + n]);
    }

  /* Put remaining */

  while (m < ne0)
    WDB[ptr + ne0 - m++ - 1] = (double)(ne1 - n);

  /***************************************************************************/

  /***** Allocate memory for data ********************************************/

  /* Loop over gcu structures */

  gcu = (long)RDB[DATA_PTR_GCU0];
  while (gcu > VALID_PTR)
    {
      /* Allocate memory for micro-group data */

      ptr = AllocPrivateData(ne0, RES2_ARRAY);
      WDB[gcu + GCU_FUM_PTR_FLX] = (double)ptr;

      ptr = AllocPrivateData(ne0, RES2_ARRAY);
      WDB[gcu + GCU_FUM_PTR_TOT] = (double)ptr;

      ptr = AllocPrivateData(ne0, RES2_ARRAY);
      WDB[gcu + GCU_FUM_PTR_ABS] = (double)ptr;

      ptr = AllocPrivateData(ne0, RES2_ARRAY);
      WDB[gcu + GCU_FUM_PTR_FISS] = (double)ptr;

      ptr = AllocPrivateData(ne0, RES2_ARRAY);
      WDB[gcu + GCU_FUM_PTR_CHI] = (double)ptr;

      ptr = AllocPrivateData(ne0, RES2_ARRAY);
      WDB[gcu + GCU_FUM_PTR_NSF] = (double)ptr;

      ptr = AllocPrivateData(ne0, RES2_ARRAY);
      WDB[gcu + GCU_FUM_PTR_MUBAR] = (double)ptr;

      ptr = AllocPrivateData(ne0*ne0, RES2_ARRAY);
      WDB[gcu + GCU_FUM_PTR_SCATT_MTX] = (double)ptr;

      /* Allocate memory for results */

      ptr = NewStat("B1_KINF", 1, 1);
      WDB[gcu + GCU_FUM_FG_B1_KINF] = (double)ptr;

      ptr = NewStat("B1_BUCKLING", 1, 1);
      WDB[gcu + GCU_FUM_FG_B1_BUCKLING] = (double)ptr;

      ptr = NewStat("B1_DIFFCOEF", 1, ne1 + 1);
      WDB[gcu + GCU_FUM_FG_B1_DIFFCOEF] = (double)ptr;

      ptr = NewStat("B1_ABSXS", 1, ne1 + 1);
      WDB[gcu + GCU_FUM_FG_B1_ABSXS] = (double)ptr;

      ptr = NewStat("B1_NSF", 1, ne1 + 1);
      WDB[gcu + GCU_FUM_FG_B1_NSF] = (double)ptr;

      ptr = NewStat("B1_FISSXS", 1, ne1 + 1);
      WDB[gcu + GCU_FUM_FG_B1_FISSXS] = (double)ptr;
      
      ptr = NewStat("B1_FISSXS", 1, ne1 + 1);
      WDB[gcu + GCU_FUM_FG_B1_FISSXS] = (double)ptr;
      
      ptr = NewStat("B1_SCATTXS", 2, ne1, ne1);
      WDB[gcu + GCU_FUM_FG_B1_SCATTXS] = (double)ptr;
      
      ptr = NewStat("B1_TOTXS", 1, ne1 + 1);
      WDB[gcu + GCU_FUM_FG_B1_TOTXS] = (double)ptr;
      
      ptr = NewStat("B1_FLUX", 1, ne1 + 1);
      WDB[gcu + GCU_FUM_FG_B1_FLUX] = (double)ptr;
      
      ptr = NewStat("B1_CHI", 1, ne1);
      WDB[gcu + GCU_FUM_FG_B1_CHI] = (double)ptr;
      
      ptr = NewStat("B1_REMXS", 1, ne1 + 1);
      WDB[gcu + GCU_FUM_FG_B1_REMXS] = (double)ptr;

      /* Next */

      gcu = NextItem(gcu);
    }

  /***************************************************************************/
}

/*****************************************************************************/
