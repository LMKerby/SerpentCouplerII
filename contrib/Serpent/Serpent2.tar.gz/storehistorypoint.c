/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : storehistorypoint.c                            */
/*                                                                           */
/* Created:       2011/05/13 (JLe)                                           */
/* Last modified: 2012/01/04 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Adds point in particle track in history array                */
/*                                                                           */
/* Comments: - Fixed source -laskussa pitää jotenkin huomioida se että       */
/*             lähdeneutroneilla / protoneilla ei oo historiaa               */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "StoreHistoryPoint:"

/*****************************************************************************/

void StoreHistoryPoint(long part, long mat, long rea, double x, double y, 
		       double z, double u, double v, double w, double E, 
		       double wgt, double flx, long start) 
{
  long hst;

  /* Put previous coordinates */

  WDB[part + PARTICLE_PREV_X] = x;
  WDB[part + PARTICLE_PREV_Y] = y;
  WDB[part + PARTICLE_PREV_Z] = z;

  /* Pointer to history data */

  if ((hst = (long)RDB[part + PARTICLE_PTR_HIST]) < VALID_PTR)
    return;

  /* Store data */

  WDB[hst + HIST_X] = x;
  WDB[hst + HIST_Y] = y;
  WDB[hst + HIST_Z] = z;
  WDB[hst + HIST_U] = u;
  WDB[hst + HIST_V] = v;
  WDB[hst + HIST_W] = w;
  WDB[hst + HIST_E] = E;
  WDB[hst + HIST_WGT] = wgt;
  WDB[hst + HIST_PTR_REA] = (double)rea;
  WDB[hst + HIST_PTR_MAT] = (double)mat;
  WDB[hst + HIST_START] = (double)start;
  WDB[hst + HIST_FLX] = (double)flx;
  WDB[hst + HIST_IDX] = WDB[part + PARTICLE_IDX];

  /* Get pointer to next */

  hst = (double)NextItem(hst);

  /* Update pointer */

  WDB[part + PARTICLE_PTR_HIST] = (double)hst;

  /***************************************************************************/
}

/*****************************************************************************/
