/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : materialburnup.c                               */
/*                                                                           */
/* Created:       2011/07/07 (JLe)                                           */
/* Last modified: 2011/11/11 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Calculates material-wise burnup for time step                */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "MaterialBurnup:"

/*****************************************************************************/

void MaterialBurnup(long mat, double *N, double t, long id)
{
  long iso, nuc, rea, i;
  double flx, adens, rr, Q, mass, vol;

  /* Check step type */

  if (!((long)RDB[DATA_BURN_CORR_TYPE] == CORR_TYPE_NONE) &&
      ((long)RDB[DATA_BURN_STEP_PC] == PREDICTOR_STEP))
    return;

  /* Check pointer */

  CheckPointer(FUNCTION_NAME, "(mat)", DATA_ARRAY, mat);

  /* Get flux, mass and volume */

  flx = RDB[mat + MATERIAL_BURN_FLUX_SSA];
  mass = RDB[mat + MATERIAL_INI_FMASS];
  vol = RDB[mat + MATERIAL_VOLUME];

  /* Check values */

  CheckValue(FUNCTION_NAME, "flx", "", flx, 0.0, INFTY);
  CheckValue(FUNCTION_NAME, "mass", "", mass, 0.0, INFTY);
  CheckValue(FUNCTION_NAME, "vol", "", vol, ZERO, INFTY);

  /* Loop over composition */

  iso = (long)RDB[mat + MATERIAL_PTR_COMP];
  while (iso > VALID_PTR)
    {
      /* Pointer to nuclide */

      nuc = (long)RDB[iso + COMPOSITION_PTR_NUCLIDE];
      CheckPointer(FUNCTION_NAME, "(nuc)", DATA_ARRAY, nuc);

      /* Get nuclide index */
      
      if ((i =  TestValuePair(nuc + NUCLIDE_PTR_MATRIX_IDX, (double)mat, id)) 
	  < 0)
	Die(FUNCTION_NAME, "i < 0");

      /* Get atomic density */
      
      adens = N[i];

      /* Loop over reactions */

      rea = (long)RDB[nuc + NUCLIDE_PTR_REA];
      while (rea > VALID_PTR)
	{  
	  /* Check pointer to fission yield */

	  if ((long)RDB[rea + REACTION_PTR_FISSY] > VALID_PTR)
	    {
	      /* Fission Q-value */
	    
	      Q = RDB[rea + REACTION_Q]*RDB[DATA_NORM_U235_FISSE]/U235_FISSQ;

	      /* Get reaction rate */

	      rr = TestValuePair(rea + REACTION_PTR_TRANSMUXS, mat, id);

	      /* Add to material burnup */
	      
	      if (rr > 0.0)
		WDB[mat + MATERIAL_BURNUP] = RDB[mat + MATERIAL_BURNUP] 
		  + adens*flx*rr*Q*t*vol/mass/86400/1.0E6;
	    }
	  
	  /* Next reaction */

	  rea = NextItem(rea);
	}

      /* Next nuclide */

      iso = NextItem(iso);
    }
}

/*****************************************************************************/
