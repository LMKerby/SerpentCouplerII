/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : atof.c                                         */
/*                                                                           */
/* Created:       2010/11/21 (JLe)                                           */
/* Last modified: 2011/10/28 (JLe)                                           */
/* Version:       2.1.0                                                      */
/*                                                                           */
/* Description: Array to double conversion with type checking                */
/*                                                                           */
/* Comments: - From Serpent 1.1.8                                            */
/*           - Tätä pitäisi kutsua pelkästään GetParam():sta.                */
/*                                                                           */
/*****************************************************************************/

#include "header.h"

/* atof.c: modified 14.12.2009 - Version 1.1.8 (JLe) */

#define FUNCTION_NAME "AtoF:"

/*****************************************************************************/

double AtoF(char *str, char *param, char *file, long line)
{
  long n;

  for(n = 0; n < (long)strlen(str); n++)
    if (!isdigit(str[n]) && (str[n] != '.') && (str[n] != '-') && 
	(str[n] != '+') && (str[n] != 'e') && (str[n] != 'E'))
      {
	/* Check mode */
	
	if (line > 0)
	  {
	    /* Error in input file */
	    
	    Error(-1, param, file, line, "Invalid numerical entry \"%s\"",str);
	  }
	else
	  {
	    /* Error in string */
	    
	    Die(FUNCTION_NAME, "Invalid numerical entry \"%s\"", str);
	  }
      }

  /* Return number */

  return atof(str);
}

/*****************************************************************************/
