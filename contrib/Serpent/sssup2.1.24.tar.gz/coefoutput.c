/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : coefoutput.c                                   */
/*                                                                           */
/* Created:       2014/04/15 (JLe)                                           */
/* Last modified: 2015/02/21 (JLe)                                           */
/* Version:       2.1.23                                                     */
/*                                                                           */
/* Description: Writes group constant output for coefficient calculations    */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "CoefOutput:"

/*****************************************************************************/

void CoefOutput()
{
  long loc0, loc1, ptr, n, np, gcu, ntot, idx, nv;
  char tmpstr[MAX_STR], **params;
  FILE *fp;

  /***************************************************************************/

  /***** Default list of output parameters ***********************************/

  char *default_params[] = {
    "INF_FLX",
    "INF_KINF",
    "INF_REP_TIME",
    "INF_PROMPT_LIFE",
    "INF_TOT",
    "INF_CAPT",
    "INF_FISS",
    "INF_NSF",
    "INF_KAPPA",
    "INF_INVV",
    "INF_NUBAR",
    "INF_ABS",
    "INF_REMXS",
    "INF_RABSXS",
    "INF_CHIT",
    "INF_CHIP",
    "INF_CHID",
    "INF_I135_YIELD",
    "INF_XE135_YIELD",
    "INF_PM149_YIELD",
    "INF_SM149_YIELD",
    "INF_I135_MICRO_ABS",
    "INF_XE135_MICRO_ABS",
    "INF_PM149_MICRO_ABS",
    "INF_SM149_MICRO_ABS",
    "INF_I135_MACRO_ABS",
    "INF_XE135_MACRO_ABS",
    "INF_PM149_MACRO_ABS",
    "INF_SM149_MACRO_ABS",
    "INF_S0",
    "INF_S1",
    "INF_S2",
    "INF_S3",
    "INF_S4",
    "INF_S5",
    "INF_S6",
    "INF_S7",
    "INF_SP0",
    "INF_SP1",
    "INF_SP2",
    "INF_SP3",
    "INF_SP4",
    "INF_SP5",
    "INF_SP6",
    "INF_SP7",
    "INF_SCATT0",
    "INF_SCATT1",
    "INF_SCATT2",
    "INF_SCATT3",
    "INF_SCATT4",
    "INF_SCATT5",
    "INF_SCATT6",
    "INF_SCATT7",
    "INF_SCATTP0",
    "INF_SCATTP1",
    "INF_SCATTP2",
    "INF_SCATTP3",
    "INF_SCATTP4",
    "INF_SCATTP5",
    "INF_SCATTP6",
    "INF_SCATTP7",
    "INF_TRANSPXS",
    "INF_DIFFCOEF",
    "B1_KINF",
    "B1_KEFF",
    "B1_REP_TIME",
    "B1_PROMPT_LIFE",
    "B1_B2",
    "B1_ERR",
    "B1_FLX",
    "B1_FISS_FLX",
    "B1_TOT",
    "B1_CAPT",
    "B1_FISS",
    "B1_NSF",
    "B1_KAPPA",
    "B1_INVV",
    "B1_NUBAR",
    "B1_ABS",
    "B1_REMXS",
    "B1_RABSXS",
    "B1_CHIT",
    "B1_CHIP",
    "B1_CHID",
    "B1_I135_YIELD",
    "B1_XE135_YIELD",
    "B1_PM149_YIELD",
    "B1_SM149_YIELD",
    "B1_I135_MICRO_ABS",
    "B1_XE135_MICRO_ABS",
    "B1_PM149_MICRO_ABS",
    "B1_SM149_MICRO_ABS",
    "B1_I135_MACRO_ABS",
    "B1_XE135_MACRO_ABS",
    "B1_PM149_MACRO_ABS",
    "B1_SM149_MACRO_ABS",
    "B1_S0",
    "B1_S1",
    "B1_S2",
    "B1_S3",
    "B1_S4",
    "B1_S5",
    "B1_S6",
    "B1_S7",
    "B1_SP0",
    "B1_SP1",
    "B1_SP2",
    "B1_SP3",
    "B1_SP4",
    "B1_SP5",
    "B1_SP6",
    "B1_SP7",
    "B1_SCATT0",
    "B1_SCATT1",
    "B1_SCATT2",
    "B1_SCATT3",
    "B1_SCATT4",
    "B1_SCATT5",
    "B1_SCATT6",
    "B1_SCATT7",
    "B1_SCATTP0",
    "B1_SCATTP1",
    "B1_SCATTP2",
    "B1_SCATTP3",
    "B1_SCATTP4",
    "B1_SCATTP5",
    "B1_SCATTP6",
    "B1_SCATTP7",
    "B1_TRANSPXS",
    "B1_DIFFCOEF",
    "DF_HET_SURF_FLUX", 
    "DF_HOM_SURF_FLUX", 
    "DF_SURF_DF", 
    "DF_HET_CORN_FLUX", 
    "DF_HOM_CORN_FLUX", 
    "DF_CORN_DF", 
    "DF_CORN_IN_CURR", 
    "DF_CORN_OUT_CURR", 
    "DF_CORN_NET_CURR", 
    "DF_HET_VOL_FLUX", 
    "DF_HOM_VOL_FLUX", 
    "DF_SURF_IN_CURR", 
    "DF_SURF_OUT_CURR", 
    "DF_SURF_NET_CURR", 
    "DF_MID_IN_CURR", 
    "DF_MID_OUT_CURR", 
    "DF_MID_NET_CURR", 
    "PPW", 
    "ALB_IN_CURR",
    "ALB_OUT_CURR",
    "ALB_TOT_ALB",
    "ALB_PART_ALB",
    "IMP_KEFF",
    "ANA_KEFF",
    "BETA_EFF",
    "LAMBDA",
    "\0"
  };

  /***************************************************************************/

  /***** Make parameter list *************************************************/

  /* Check if user-defined list is given */
 
  if ((ptr = (long)RDB[DATA_COEF_CALC_PTR_PARAM_LIST]) > VALID_PTR)
    {
      /* Calculate list size */

      np = 0;
      while ((long)RDB[ptr + np] > VALID_PTR)
	np++;

      /* Allocate memory */
      
      params = (char **)Mem(MEM_ALLOC, np + 1, sizeof(char *));

      for (n = 0; n < np + 1; n++)
	params[n] = (char *)Mem(MEM_ALLOC, MAX_STR, sizeof(char));

      /* Read values */

      for (n = 0; n < np; n++)
	strcpy(params[n], GetText(ptr++));
      
      /* Put terminator */

      *params[np] = '\0';
    }
  else
    {
      /* Use default list */

      params = default_params;
    }

  /***************************************************************************/

  /***** Print header data ***************************************************/

  /* Check pointer to coefficients */
  
  if ((loc0 = (long)RDB[DATA_PTR_COEF0]) < VALID_PTR)
    return;

  /* Check mpi task */

  if (mpiid > 0)
    return;

  /* Check pointer to gc universes */
  
  if ((gcu = (long)RDB[DATA_PTR_GCU0]) < VALID_PTR)
    return;

  /* Open file for writing */
  
  sprintf(tmpstr, "%s.coe", GetText(DATA_PTR_INPUT_FNAME));
  if ((fp = fopen(tmpstr, "a")) == NULL)
    Error(loc0, "Unable to open file for writing");
  
  /* Print index, total number of runs and number of universes */

  fprintf(fp, "%ld %ld %ld %ld %ld\n", (long)RDB[DATA_COEF_CALC_RUN_IDX],
	  (long)RDB[DATA_COEF_CALC_TOT_RUNS], (long)RDB[DATA_COEF_CALC_IDX],
	  (long)RDB[DATA_TOT_COEF_CALC], ListSize(gcu));

  /* Pointer to branches */
  
  loc1 = (long)RDB[loc0 + COEF_PTR_MTX];
  CheckPointer(FUNCTION_NAME, "(loc1)", DATA_ARRAY, loc1);

  /* Print dimensions */

  fprintf(fp, "%ld", ListSize(loc1));

  /* Reset number of variables */

  nv = 0;

  /* Loop over matrix and print branches */

  while (loc1 > VALID_PTR)
    {
      /* Pointer to branch name */

      ptr = (long)RDB[loc1 + COEF_MTX_PTR_BRA];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);

      /* Print */

      fprintf(fp, " %s", GetText(ptr));

      /* Add to number of variables */

      if ((ptr = (long)RDB[loc1 + COEF_MTX_PTR_VAR]) > VALID_PTR)
	nv = nv + ListSize(ptr);

      /* Next */

      loc1 = NextItem(loc1);
    }
  
  /* Print newline */

  fprintf(fp, "\n");

  /* Print number of variables */

  fprintf(fp, "%ld", nv);

  /* Loop over matrix and print variables */

  loc1 = (long)RDB[loc0 + COEF_PTR_MTX];
  while (loc1 > VALID_PTR)
    {
      /* Loop over variables */

      ptr = (long)RDB[loc1 + COEF_MTX_PTR_VAR];
      while (ptr > VALID_PTR)
	{
	  /* Print name and value */

	  fprintf(fp, " %s %s", GetText(ptr + DEP_BRA_VAR_PTR_NAME),
		  GetText(ptr + DEP_BRA_VAR_PTR_VALUE));

	  /* Next variable */

	  ptr = NextItem(ptr);
	}

      /* Next */

      loc1 = NextItem(loc1);
    }

  /* Print newline */

  fprintf(fp, "\n");

  /* Print burnup, index and total number of points */

  fprintf(fp, "%s %ld %ld\n", GetText(DATA_PTR_COEF_BU_PT), 
	  (long)RDB[DATA_COEF_CALC_BU_IDX], (long)RDB[DATA_TOT_COEF_BU]);

  /***************************************************************************/

  /***** Print output ********************************************************/

  /* Count number of parameters */

  np = 0;
  while (*params[np] != '\0')
    np++;

  /* Loop over gc universes */

  gcu = (long)RDB[DATA_PTR_GCU0];
  while (gcu > VALID_PTR)
    {
      /* Pointer to universe */

      ptr = (long)RDB[gcu + GCU_PTR_UNIV];
      CheckPointer(FUNCTION_NAME, "(ptr)", DATA_ARRAY, ptr);
      
      /* Print universe name and number of output parameters */

      fprintf(fp, "%s %ld\n", GetText(ptr + UNIVERSE_PTR_NAME), np);

      /* Loop over parameters */

      n = 0;
      while (*params[n] != '\0')
	{
	  /* Find parameter */

	  loc1 = (long)RDB[gcu + GCU_PTR_FIRST_STAT];
	  while ((loc1 > VALID_PTR) && 
		 (loc1 <= (long)RDB[gcu + GCU_PTR_LAST_STAT]))
	    {
	      /* Compare name */

	      if (!strcmp(params[n], GetText(loc1 + SCORE_PTR_NAME)))
		break;

	      /* Next */

	      loc1 = NextItem(loc1);
	    }

	  /* Check pointer and reset */

	  if ((loc1 < VALID_PTR) || 
	      (loc1 > (long)RDB[gcu + GCU_PTR_LAST_STAT]))
	    {
	      /* Loop over other stats */

	      loc1 = (long)RDB[DATA_PTR_SCORE0];
	      while (loc1 > VALID_PTR)
		{
		  /* Compare pointer */

		  if (loc1 > (long)RDB[DATA_LAST_GLOBAL_STAT])
		    {
		      /* Reset pointer */

		      loc1 = -1;

		      /* Break loop */

		      break;
		    }

		  /* Compare name */

		  if (!strcmp(params[n], GetText(loc1 + SCORE_PTR_NAME)))
		    break;

		  /* Next */
		  
		  loc1 = NextItem(loc1);
		}

	      /* Check */

	      if (loc1 < VALID_PTR)
		{
		  /* Print name and zero values */
	  
		  fprintf(fp, "%s 0\n", params[n]);
		  
		  /* Next parameter */
		  
		  n++;
		  
		  /* Cycle loop */
		  
		  continue;
		}
	    }
	  
	  /* Print name */
	  
	  fprintf(fp, "%s ", params[n]);
	  
	  /* Get number of values */

	  ntot = (long)RDB[loc1 + SCORE_STAT_SIZE];
	  fprintf(fp, "%ld ", ntot);

	  /* Loop over values */

	  for (idx = 0; idx < ntot; idx++)
	    {
	      /* Get pointer */

	      ptr = (long)RDB[loc1 + SCORE_PTR_DATA] + idx*STAT_BLOCK_SIZE;

	      /* Print */

	      if (RES1[ptr + STAT_N] > 0.0)
		fprintf(fp, "%12.5E ", RES1[ptr + STAT_X]/RES1[ptr + STAT_N]);
	      else
		fprintf(fp, "%12.5E ", 0.0);
	    }

	  /* Print newline */

	  fprintf(fp, "\n");

	  /* Next parameter */
	  
	  n++;
	}

      /* Next universe */

      gcu = NextItem(gcu);
    }

  /* Free allocated memory */

  if ((long)RDB[DATA_COEF_CALC_PTR_PARAM_LIST] > VALID_PTR)
    {
      for (n = 0; n < np + 1; n++)
	Mem(MEM_FREE, params[n]);

      Mem(MEM_FREE, params);
    }      

  /***************************************************************************/

  /* Close file */

  fclose(fp);
}

/*****************************************************************************/

