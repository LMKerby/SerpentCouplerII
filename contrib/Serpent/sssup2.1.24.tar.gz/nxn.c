/*****************************************************************************/
/*                                                                           */
/* serpent 2 (beta-version) : nxn.c                                          */
/*                                                                           */
/* Created:       2011/03/07 (JLe)                                           */
/* Last modified: 2015/06/17 (JLe)                                           */
/* Version:       2.1.24                                                     */
/*                                                                           */
/* Description: Handles (n,xn) reactions                                     */
/*                                                                           */
/* Comments:                                                                 */
/*                                                                           */
/*****************************************************************************/

#include "header.h"
#include "locations.h"

#define FUNCTION_NAME "Nxn:"

/*****************************************************************************/

void Nxn(long rea, long part, double *E0, double x, double y, double z, 
	 double *u0, double *v0, double *w0, double wgt1, double *wgt2, 
	 double t, long id)
{
  long n, new, mul;
  double E, u, v, w;

  /* Get multiplication */

  mul = (long)RDB[rea + REACTION_WGT_F];
  CheckValue(FUNCTION_NAME, "mul", "", mul, 2, 4);

  /* Check mode */

  if ((long)RDB[DATA_OPT_IMPL_NXN] == YES)
    {
      /***********************************************************************/

      /***** Implicit (nxn) **************************************************/

      /* Perform inelastic scattering on incident neutron */

      InelasticScattering(rea, E0, u0, v0, w0, id);
      
      /* Multiply weight */

      *wgt2 = wgt1*mul;

      /***********************************************************************/
    }
  else
    {
      /***********************************************************************/

      /***** Analog (n,xn) ***************************************************/
     
      /* This mode is disabled because it doesn't work with scattering */
      /* matrixes */
      
      if ((long)RDB[DATA_OPTI_GC_CALC] == YES)
	Die(FUNCTION_NAME, "Analog (n,xn) does not work with scattering mtx");

      /* Loop over product nuclides */

      for (n = 0; n < mul - 1; n++)
	{
	  /* Duplicate incident neutron */
	  
	  new = DuplicateParticle(part, id);
	  
	  /* Copy energy and angular variables */

	  E = *E0;
	  u = *u0;
	  v = *v0;
	  w = *w0;

	  /* Perform inelastic scattering on neutron */

	  InelasticScattering(rea, &E, &u, &v, &w, id);
	  
	  /* Adjust minimum and maximum */

	  if (E < 1.0000001*RDB[DATA_NEUTRON_EMIN])
	    E = 1.000001*RDB[DATA_NEUTRON_EMIN];
	  else if (E > 0.999999*RDB[DATA_NEUTRON_EMAX])
	    E = 0.999999*RDB[DATA_NEUTRON_EMAX];

	  /* Put variables */

	  WDB[new + PARTICLE_X] = x;
	  WDB[new + PARTICLE_Y] = y;
	  WDB[new + PARTICLE_Z] = z;
	  
	  WDB[new + PARTICLE_U] = u;
	  WDB[new + PARTICLE_V] = v;
	  WDB[new + PARTICLE_W] = w;
	  
	  WDB[new + PARTICLE_E] = E;
	  WDB[new + PARTICLE_WGT] = wgt1;
	  WDB[new + PARTICLE_T] = t;
	  
	  /* Put neutron in que */

	  ToQue(new, id);	  
	}

      /* Perform inelastic scattering on incident neutron */

      InelasticScattering(rea, E0, u0, v0, w0, id);
 
      /* Weight is preserved */

      *wgt2 = wgt1;

      /***********************************************************************/
    }
}

/*****************************************************************************/
